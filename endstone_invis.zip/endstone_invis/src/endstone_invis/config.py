from __future__ import annotations

import os
import tomllib
import copy
from typing import Any

DEFAULT_CONFIG: dict[str, Any] = {
    "messages": {
        "prefix": "[Invis] ",
        "invis_enabled": "Инвиз включён.",
        "invis_disabled": "Инвиз отключён.",
        "no_permission": "У вас нет прав для этого действия.",
        "player_not_found": "Игрок {player} не найден.",
        "inventory_title": "Инвентарь: {player}",
        "echest_title": "Эндер-сундук: {player}",
        "inventory_saved": "Инвентарь сохранён.",
        "settings_saved": "Настройки сохранены.",
        "block_break_denied": "Вам запрещено ломать блоки в режиме инвиза.",
        "block_place_denied": "Вам запрещено ставить блоки в режиме инвиза.",
        "fake_quit_on_enable": "{player} вышел из игры",
        "fake_join_on_disable": "{player} присоединился к игре",
    },
    "forms": {
        "main_title": "Меню инвиза",
        "main_content": "Выберите действие:",
        "btn_toggle_on": "Выключить инвиз",
        "btn_toggle_off": "Включить инвиз",
        "btn_settings": "Настройки",
        "btn_view_inv": "Просмотр инвентаря",
        "btn_view_echest": "Просмотр эндер-сундука",
        "settings_title": "Настройки инвиза",
        "settings_submit": "Сохранить",
        "toggle_invis_label": "Инвиз активен",
        "toggle_hide_list_label": "Скрывать из списка игроков",
        "toggle_fake_messages_label": "Фейковые сообщения входа/выхода",
        "toggle_save_inventory_label": "Сохранять инвентарь по режимам",
        "toggle_block_break_label": "Запретить ломание блоков",
        "toggle_block_place_label": "Запретить установку блоков",
        "toggle_mute_sounds_label": "Блокировать звуки",
        "toggle_mute_emotes_label": "Блокировать анимации (эмоуты)",
        "select_player_title": "Выбор игрока",
        "select_player_content": "Выберите игрока:",
        "inv_content_header": "Слотов занято: {count} из {total}",
        "inv_item_line": "[{slot}] {item} x{amount}",
        "inv_empty": "Инвентарь пуст.",
    },
    "defaults": {
        "invis_active": False,
        "hide_from_list": True,
        "fake_messages": True,
        "save_inventory": True,
        "block_break_denied": False,
        "block_place_denied": False,
        "mute_sounds": False,
        "mute_emotes": False,
    },
    "general": {
        )
        "sounds_to_stop": ["random.levelup", "mob.player.hurt"],
        "inventory_restore_delay_ticks": 5,
    },
}

class ConfigManager:

    def __init__(self, data_folder: str) -> None:
        self._data_folder = data_folder
        self._config: dict[str, Any] = copy.deepcopy(DEFAULT_CONFIG)
        self._load()

    def _load(self) -> None:
        path = os.path.join(self._data_folder, "config.toml")
        if not os.path.exists(path):
            self._save_default(path)
            return
        try:
            with open(path, "rb") as f:
                user_cfg = tomllib.load(f)
            self._deep_merge(self._config, user_cfg)
        except Exception as e:
            print(f"[Invis] Ошибка чтения config.toml: {e}. Используются значения по умолчанию.")

    def _save_default(self, path: str) -> None:
        os.makedirs(self._data_folder, exist_ok=True)
        lines = _dict_to_toml(DEFAULT_CONFIG)
        with open(path, "w", encoding="utf-8") as f:
            f.write(lines)

    def _deep_merge(self, base: dict, override: dict) -> None:
        for k, v in override.items():
            if k in base and isinstance(base[k], dict) and isinstance(v, dict):
                self._deep_merge(base[k], v)
            else:
                base[k] = v

    def msg(self, key: str, **kwargs: Any) -> str:
        template: str = self._config["messages"].get(key, f"<{key}>")
        prefix: str = self._config["messages"].get("prefix", "")
        result = template.format(**kwargs)
        no_prefix_keys = {"fake_quit_on_enable", "fake_join_on_disable"}
        if key in no_prefix_keys:
            return result
        return prefix + result

    def form(self, key: str, **kwargs: Any) -> str:
        template: str = self._config["forms"].get(key, f"<{key}>")
        return template.format(**kwargs)

    def default(self, key: str) -> Any:
        return self._config["defaults"].get(key)

    def general(self, key: str) -> Any:
        return self._config["general"].get(key)

def _dict_to_toml(d: dict, indent: int = 0, section: str = "") -> str:
    lines: list[str] = []
    sub_sections: list[tuple[str, dict]] = []

    for k, v in d.items():
        full_key = f"{section}.{k}" if section else k
        if isinstance(v, dict):
            sub_sections.append((full_key, v))
        elif isinstance(v, str):
            escaped = v.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{k} = "{escaped}"')
        elif isinstance(v, bool):
            lines.append(f"{k} = {'true' if v else 'false'}")
        elif isinstance(v, list):
            items = ", ".join(f'"{i}"' if isinstance(i, str) else str(i) for i in v)
            lines.append(f"{k} = [{items}]")
        else:
            lines.append(f"{k} = {v}")

    result = ""
    if section and lines:
        result += f"\n[{section}]\n"
        result += "\n".join(lines) + "\n"
    elif lines:
        result += "\n".join(lines) + "\n"

    for sec_key, sec_val in sub_sections:
        result += _dict_to_toml(sec_val, indent + 1, sec_key)

    return result
