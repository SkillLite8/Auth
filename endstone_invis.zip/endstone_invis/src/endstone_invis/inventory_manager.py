from __future__ import annotations

from endstone import Player
from endstone.inventory import ItemStack

from endstone_invis.storage import AdminData

def save_inventory(player: Player, data: AdminData, mode: str) -> None:
    inv = player.inventory
    size = inv.size
    slots: list[dict | None] = []
    for i in range(size):
        item: ItemStack | None = inv.get_item(i)
        if item is None or str(item.type) in ("minecraft:air", "air", ""):
            slots.append(None)
        else:
            slots.append({
                "slot": i,
                "type": str(item.type),
                "amount": item.amount,
            })
    data.saved_inventories[mode] = slots

def restore_inventory(player: Player, data: AdminData, mode: str) -> None:
    inv = player.inventory
    inv.clear()
    slots = data.saved_inventories.get(mode, [])
    for entry in slots:
        if entry is None:
            continue
        slot: int = entry["slot"]
        item_type: str = entry["type"]
        amount: int = entry.get("amount", 1)
        try:
            item = ItemStack(item_type, amount)
            inv.set_item(slot, item)
        except Exception:
            pass  

def get_inventory_display(player: Player) -> list[str]:
    inv = player.inventory
    lines: list[str] = []
    size = inv.size
    count = 0
    for i in range(size):
        item: ItemStack | None = inv.get_item(i)
        if item is not None and str(item.type) not in ("minecraft:air", "air", ""):
            count += 1
            item_id = str(item.type).replace("minecraft:", "")
            lines.append(f"[{i}] {item_id} x{item.amount}")
    return lines, count, size

def get_echest_display(player: Player) -> list[str]:
    inv = player.ender_chest
    lines: list[str] = []
    count = 0
    size = inv.size
    for i in range(size):
        item: ItemStack | None = inv.get_item(i)
        if item is not None and str(item.type) not in ("minecraft:air", "air", ""):
            count += 1
            item_id = str(item.type).replace("minecraft:", "")
            lines.append(f"[{i}] {item_id} x{item.amount}")
    return lines, count, size
