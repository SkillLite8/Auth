"""
storage.py — хранение состояния администраторов.
Данные сохраняются в JSON-файле между перезапусками.
"""
from __future__ import annotations

import json
import os
from typing import Any


class AdminData:
    """Данные конкретного администратора."""

    __slots__ = (
        "invis_active",
        "hide_from_list",
        "fake_messages",
        "save_inventory",
        "block_break_denied",
        "block_place_denied",
        "mute_sounds",
        "mute_emotes",
        "saved_inventories",
    )

    def __init__(
        self,
        invis_active: bool = False,
        hide_from_list: bool = True,
        fake_messages: bool = True,
        save_inventory: bool = True,
        block_break_denied: bool = False,
        block_place_denied: bool = False,
        mute_sounds: bool = False,
        mute_emotes: bool = False,
        saved_inventories: dict | None = None,
    ) -> None:
        self.invis_active = invis_active
        self.hide_from_list = hide_from_list
        self.fake_messages = fake_messages
        self.save_inventory = save_inventory
        self.block_break_denied = block_break_denied
        self.block_place_denied = block_place_denied
        self.mute_sounds = mute_sounds
        self.mute_emotes = mute_emotes
        self.saved_inventories: dict[str, list[dict | None]] = saved_inventories or {
            "normal": [],
            "invis": [],
        }

    def to_dict(self) -> dict:
        return {
            "invis_active": self.invis_active,
            "hide_from_list": self.hide_from_list,
            "fake_messages": self.fake_messages,
            "save_inventory": self.save_inventory,
            "block_break_denied": self.block_break_denied,
            "block_place_denied": self.block_place_denied,
            "mute_sounds": self.mute_sounds,
            "mute_emotes": self.mute_emotes,
            "saved_inventories": self.saved_inventories,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "AdminData":
        return cls(
            invis_active=data.get("invis_active", False),
            hide_from_list=data.get("hide_from_list", True),
            fake_messages=data.get("fake_messages", True),
            save_inventory=data.get("save_inventory", True),
            block_break_denied=data.get("block_break_denied", False),
            block_place_denied=data.get("block_place_denied", False),
            mute_sounds=data.get("mute_sounds", False),
            mute_emotes=data.get("mute_emotes", False),
            saved_inventories=data.get("saved_inventories", {"normal": [], "invis": []}),
        )


class StorageManager:
    """Загрузка и сохранение данных администраторов в JSON."""

    def __init__(self, data_folder: str) -> None:
        self._path = os.path.join(data_folder, "admin_data.json")
        self._data: dict[str, AdminData] = {}
        self._load()

    def _load(self) -> None:
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                raw: dict = json.load(f)
            for xuid, entry in raw.items():
                self._data[xuid] = AdminData.from_dict(entry)
        except Exception as e:
            print(f"[Invis] Ошибка загрузки admin_data.json: {e}")

    def save(self) -> None:
        os.makedirs(os.path.dirname(self._path), exist_ok=True)
        raw = {xuid: ad.to_dict() for xuid, ad in self._data.items()}
        try:
            with open(self._path, "w", encoding="utf-8") as f:
                json.dump(raw, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Invis] Ошибка сохранения admin_data.json: {e}")

    def get(self, xuid: str, defaults: dict[str, Any] | None = None) -> AdminData:
        """Получить данные администратора. Если не существует — создать с дефолтами."""
        if xuid not in self._data:
            d = defaults or {}
            self._data[xuid] = AdminData(
                invis_active=d.get("invis_active", False),
                hide_from_list=d.get("hide_from_list", True),
                fake_messages=d.get("fake_messages", True),
                save_inventory=d.get("save_inventory", True),
                block_break_denied=d.get("block_break_denied", False),
                block_place_denied=d.get("block_place_denied", False),
                mute_sounds=d.get("mute_sounds", False),
                mute_emotes=d.get("mute_emotes", False),
            )
        return self._data[xuid]

    def has(self, xuid: str) -> bool:
        return xuid in self._data
