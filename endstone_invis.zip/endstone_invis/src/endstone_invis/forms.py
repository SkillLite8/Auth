from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from endstone import Player
from endstone.form import ActionForm, ModalForm, Toggle, Label, Divider, Header, Button

if TYPE_CHECKING:
    from endstone_invis.plugin import InvisPlugin

def open_main_menu(plugin: "InvisPlugin", player: Player) -> None:
    cfg = plugin.cfg
    data = plugin.storage.get(player.xuid)

    btn_toggle = cfg.form("btn_toggle_on") if data.invis_active else cfg.form("btn_toggle_off")

    form = ActionForm(
        title=cfg.form("main_title"),
        content=cfg.form("main_content"),
    )
    form.add_button(btn_toggle, on_click=lambda p: plugin.toggle_invis(p))

    if player.has_permission("invis.use"):
        form.add_divider()

    if player.has_permission("invis.view_inv") or player.has_permission("invis.view_echest"):
        form.add_button(
            cfg.form("btn_view_inv"),
            on_click=lambda p: open_select_player_form(plugin, p, "inv"),
        )
        form.add_button(
            cfg.form("btn_view_echest"),
            on_click=lambda p: open_select_player_form(plugin, p, "echest"),
        )

    if player.has_permission("invis.use"):
        form.add_divider()
        form.add_button(
            cfg.form("btn_settings"),
            on_click=lambda p: open_settings_form(plugin, p),
        )

    player.send_form(form)

def open_settings_form(plugin: "InvisPlugin", player: Player) -> None:
    cfg = plugin.cfg
    data = plugin.storage.get(player.xuid)

    form = ModalForm(
        title=cfg.form("settings_title"),
        submit_button=cfg.form("settings_submit"),
    )

    controls_meta: list[tuple[str, str, bool]] = []  

    def add_toggle(perm: str, label_key: str, current: bool) -> None:
        if player.has_permission(perm):
            form.add_control(Toggle(cfg.form(label_key), default_value=current))
            controls_meta.append((perm, label_key, current))

    add_toggle("invis.use", "toggle_invis_label", data.invis_active)
    add_toggle("invis.hide_list", "toggle_hide_list_label", data.hide_from_list)
    add_toggle("invis.fake_messages", "toggle_fake_messages_label", data.fake_messages)
    add_toggle("invis.save_inventory", "toggle_save_inventory_label", data.save_inventory)

    if player.has_permission("invis.block_break") or player.has_permission("invis.block_place"):
        form.add_control(Divider())
        form.add_control(Header("Блоки"))

    add_toggle("invis.block_break", "toggle_block_break_label", data.block_break_denied)
    add_toggle("invis.block_place", "toggle_block_place_label", data.block_place_denied)

    if player.has_permission("invis.mute_sounds") or player.has_permission("invis.mute_emotes"):
        form.add_control(Divider())
        form.add_control(Header("Звуки и анимации"))

    add_toggle("invis.mute_sounds", "toggle_mute_sounds_label", data.mute_sounds)
    add_toggle("invis.mute_emotes", "toggle_mute_emotes_label", data.mute_emotes)

    def on_submit(p: Player, result_json: str) -> None:
        import json as _json
        try:
            values = _json.loads(result_json)
        except Exception:
            return
        toggle_values = [v for v in values if isinstance(v, bool)]

        if len(toggle_values) != len(controls_meta):
            p.send_message(cfg.msg("no_permission"))
            return

        prev_invis = data.invis_active

        for i, (perm, label_key, _) in enumerate(controls_meta):
            val = toggle_values[i]
            if label_key == "toggle_invis_label":
                data.invis_active = val
            elif label_key == "toggle_hide_list_label":
                data.hide_from_list = val
            elif label_key == "toggle_fake_messages_label":
                data.fake_messages = val
            elif label_key == "toggle_save_inventory_label":
                data.save_inventory = val
            elif label_key == "toggle_block_break_label":
                data.block_break_denied = val
            elif label_key == "toggle_block_place_label":
                data.block_place_denied = val
            elif label_key == "toggle_mute_sounds_label":
                data.mute_sounds = val
            elif label_key == "toggle_mute_emotes_label":
                data.mute_emotes = val

        plugin.storage.save()

        if data.invis_active != prev_invis:
            if data.invis_active:
                plugin.apply_invis(p)
            else:
                plugin.remove_invis(p)

        p.send_message(cfg.msg("settings_saved"))

    form.on_submit = on_submit
    player.send_form(form)

def open_select_player_form(plugin: "InvisPlugin", player: Player, mode: str) -> None:
    cfg = plugin.cfg

    perm = "invis.view_inv" if mode == "inv" else "invis.view_echest"
    if not player.has_permission(perm):
        player.send_message(cfg.msg("no_permission"))
        return

    online_players = [
        p for p in plugin.server.online_players
        if p.name != player.name
    ]

    if not online_players:
        player.send_message(cfg.msg("player_not_found", player="<никого>"))
        return

    form = ActionForm(
        title=cfg.form("select_player_title"),
        content=cfg.form("select_player_content"),
    )

    for target in online_players:
        target_name = target.name

        def make_click(t_name: str) -> Callable:
            def on_click(p: Player) -> None:
                t = plugin.server.get_player(t_name)
                if t is None:
                    p.send_message(cfg.msg("player_not_found", player=t_name))
                    return
                if mode == "inv":
                    open_inventory_view(plugin, p, t)
                else:
                    open_echest_view(plugin, p, t)
            return on_click

        form.add_button(target_name, on_click=make_click(target_name))

    player.send_form(form)

def open_inventory_view(plugin: "InvisPlugin", viewer: Player, target: Player) -> None:
    from endstone_invis.inventory_manager import get_inventory_display
    cfg = plugin.cfg

    lines, count, total = get_inventory_display(target)
    title = cfg.form("inventory_title", player=target.name)
    content = cfg.form("inv_content_header", count=count, total=total)

    if lines:
        content += "\n" + "\n".join(lines)
    else:
        content += "\n" + cfg.form("inv_empty")

    form = ActionForm(title=title, content=content)
    form.add_button("Закрыть")
    viewer.send_form(form)

def open_echest_view(plugin: "InvisPlugin", viewer: Player, target: Player) -> None:
    from endstone_invis.inventory_manager import get_echest_display
    cfg = plugin.cfg

    lines, count, total = get_echest_display(target)
    title = cfg.form("echest_title", player=target.name)
    content = cfg.form("inv_content_header", count=count, total=total)

    if lines:
        content += "\n" + "\n".join(lines)
    else:
        content += "\n" + cfg.form("inv_empty")

    form = ActionForm(title=title, content=content)
    form.add_button("Закрыть")
    viewer.send_form(form)
