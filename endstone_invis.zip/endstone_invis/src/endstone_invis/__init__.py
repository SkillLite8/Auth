from endstone_invis.plugin import InvisPlugin

__all__ = ["InvisPlugin"]
