"""
plugin.py — основной класс плагина Invis для Endstone 0.10.x
Minecraft Bedrock 1.21.95, Python 3.12
"""
import os

from endstone import Player
from endstone.command import Command, CommandSender
from endstone.event import (
    BlockBreakEvent,
    BlockPlaceEvent,
    PlayerChatEvent,
    PlayerEmoteEvent,
    PlayerJoinEvent,
    PlayerQuitEvent,
    ServerListPingEvent,
    event_handler,
)
from endstone.plugin import Plugin

from endstone_invis.config import ConfigManager
from endstone_invis.storage import AdminData, StorageManager
from endstone_invis import forms as _forms
from endstone_invis import inventory_manager as _inv_mgr


class InvisPlugin(Plugin):
    api_version = "0.10"
    name = "invis"
    version = "1.0.0"
    description = "Admin Invisibility Plugin"
    authors = ["AdminPlugin"]
    prefix = "Invis"

    # ── Команды ──────────────────────────────────────────────────────────────
    commands = {
        "invis": {
            "description": "Управление инвизом администратора",
            "usages": [
                "/invis",
                "/invis toggle",
                "/invis settings",
                "/invis inv <игрок>",
                "/invis echest <игрок>",
            ],
            "permissions": ["invis.use"],
        }
    }

    # ── Разрешения ────────────────────────────────────────────────────────────
    permissions = {
        "invis.use": {
            "description": "Основной инвиз (включение/выключение)",
            "default": "op",
        },
        "invis.hide_list": {
            "description": "Скрытие из списка игроков в режиме инвиза",
            "default": "op",
        },
        "invis.fake_messages": {
            "description": "Фейковые сообщения входа/выхода при инвизе",
            "default": "op",
        },
        "invis.save_inventory": {
            "description": "Сохранение инвентаря по режимам",
            "default": "op",
        },
        "invis.block_break": {
            "description": "Индивидуальный запрет ломания блоков в инвизе",
            "default": "op",
        },
        "invis.block_place": {
            "description": "Индивидуальный запрет установки блоков в инвизе",
            "default": "op",
        },
        "invis.mute_sounds": {
            "description": "Блокировка звуков в режиме инвиза",
            "default": "op",
        },
        "invis.mute_emotes": {
            "description": "Блокировка анимаций/эмоутов в режиме инвиза",
            "default": "op",
        },
        "invis.view_inv": {
            "description": "Просмотр инвентаря игрока",
            "default": "op",
        },
        "invis.view_echest": {
            "description": "Просмотр эндер-сундука игрока",
            "default": "op",
        },
    }

    # ─────────────────────────────────────────────────────────────────────────

    def on_enable(self) -> None:
        data_folder = self.data_folder
        os.makedirs(data_folder, exist_ok=True)

        self.cfg = ConfigManager(data_folder)
        self.storage = StorageManager(data_folder)

        # Множество XUID администраторов, у которых сейчас активен инвиз
        self._invis_active_xuids: set[str] = set()

        self.register_events(self)
        self.logger.info("Invis plugin enabled!")

        # Восстанавливаем инвиз для игроков, которые уже онлайн
        for player in self.server.online_players:
            self._restore_player_invis(player)

    def on_disable(self) -> None:
        # Снимаем инвиз со всех, сохраняем данные
        for player in self.server.online_players:
            xuid = player.xuid
            if xuid in self._invis_active_xuids:
                self._set_player_invisible(player, False)
        self.storage.save()
        self.logger.info("Invis plugin disabled.")

    # ── Команды ───────────────────────────────────────────────────────────────

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if not isinstance(sender, Player):
            sender.send_message("§cЭта команда только для игроков.")
            return True

        player: Player = sender

        if not player.has_permission("invis.use"):
            player.send_message(self.cfg.msg("no_permission"))
            return True

        if not args:
            _forms.open_main_menu(self, player)
            return True

        sub = args[0].lower()

        if sub == "toggle":
            self.toggle_invis(player)

        elif sub == "settings":
            _forms.open_settings_form(self, player)

        elif sub == "inv":
            if not player.has_permission("invis.view_inv"):
                player.send_message(self.cfg.msg("no_permission"))
                return True
            if len(args) < 2:
                _forms.open_select_player_form(self, player, "inv")
            else:
                target = self.server.get_player(args[1])
                if target is None:
                    player.send_message(self.cfg.msg("player_not_found", player=args[1]))
                else:
                    _forms.open_inventory_view(self, player, target)

        elif sub == "echest":
            if not player.has_permission("invis.view_echest"):
                player.send_message(self.cfg.msg("no_permission"))
                return True
            if len(args) < 2:
                _forms.open_select_player_form(self, player, "echest")
            else:
                target = self.server.get_player(args[1])
                if target is None:
                    player.send_message(self.cfg.msg("player_not_found", player=args[1]))
                else:
                    _forms.open_echest_view(self, player, target)

        else:
            _forms.open_main_menu(self, player)

        return True

    # ── Логика инвиза ─────────────────────────────────────────────────────────

    def toggle_invis(self, player: Player) -> None:
        """Переключает режим инвиза для игрока."""
        data = self.storage.get(player.xuid, self._default_data())
        if data.invis_active:
            self.remove_invis(player)
        else:
            self.apply_invis(player)

    def apply_invis(self, player: Player) -> None:
        """Включает инвиз для игрока."""
        data = self.storage.get(player.xuid, self._default_data())

        # Сохранить инвентарь обычного режима
        if data.save_inventory and player.has_permission("invis.save_inventory"):
            _inv_mgr.save_inventory(player, data, "normal")
            # Восстановить инвентарь инвиза
            _inv_mgr.restore_inventory(player, data, "invis")

        data.invis_active = True
        self._invis_active_xuids.add(player.xuid)
        self.storage.save()

        # Применить невидимость
        self._set_player_invisible(player, True)

        # Фейковое сообщение о выходе
        if data.fake_messages and player.has_permission("invis.fake_messages"):
            quit_msg = self.cfg.msg("fake_quit_on_enable", player=player.name)
            self._broadcast_to_non_admins(quit_msg, player)

        # Остановить звуки
        if data.mute_sounds and player.has_permission("invis.mute_sounds"):
            player.stop_all_sounds()

        player.send_message(self.cfg.msg("invis_enabled"))

    def remove_invis(self, player: Player) -> None:
        """Выключает инвиз для игрока."""
        data = self.storage.get(player.xuid, self._default_data())

        # Сохранить инвентарь инвиза и восстановить обычный
        if data.save_inventory and player.has_permission("invis.save_inventory"):
            _inv_mgr.save_inventory(player, data, "invis")
            _inv_mgr.restore_inventory(player, data, "normal")

        data.invis_active = False
        self._invis_active_xuids.discard(player.xuid)
        self.storage.save()

        # Снять невидимость
        self._set_player_invisible(player, False)

        # Фейковое сообщение о входе
        if data.fake_messages and player.has_permission("invis.fake_messages"):
            join_msg = self.cfg.msg("fake_join_on_disable", player=player.name)
            self._broadcast_to_non_admins(join_msg, player)

        player.send_message(self.cfg.msg("invis_disabled"))

    def _set_player_invisible(self, player: Player, invisible: bool) -> None:
        """
        Устанавливает/снимает невидимость игрока.
        В Endstone нет прямого метода set_invisible, поэтому используем
        GameMode SPECTATOR для скрытия + возвращаем обратно.

        Более надёжный способ — использовать эффект невидимости через
        perform_command, что гарантирует работу на 1.21.95.
        """
        if invisible:
            # Применяем эффект invisibility (255 уровень, 9999 секунд, hide particles)
            player.perform_command("effect @s invisibility 9999 255 true")
        else:
            # Снимаем эффект
            player.perform_command("effect @s clear")

    def _restore_player_invis(self, player: Player) -> None:
        """При входе восстанавливает состояние инвиза если было активно."""
        if not self.storage.has(player.xuid):
            return
        data = self.storage.get(player.xuid)
        if data.invis_active:
            self._invis_active_xuids.add(player.xuid)
            # Небольшая задержка для корректной инициализации клиента
            self.server.scheduler.run_task_later(
                self,
                lambda: self._set_player_invisible(player, True),
                20,  # 1 секунда
            )
            # Восстановить инвентарь инвиза
            if data.save_inventory:
                self.server.scheduler.run_task_later(
                    self,
                    lambda: _inv_mgr.restore_inventory(player, data, "invis"),
                    25,
                )

    def _broadcast_to_non_admins(self, message: str, exclude_player: Player) -> None:
        """Рассылает сообщение всем, кроме самого администратора."""
        for p in self.server.online_players:
            if p.xuid != exclude_player.xuid:
                p.send_message(message)

    def _default_data(self) -> dict:
        return {
            "invis_active": self.cfg.default("invis_active"),
            "hide_from_list": self.cfg.default("hide_from_list"),
            "fake_messages": self.cfg.default("fake_messages"),
            "save_inventory": self.cfg.default("save_inventory"),
            "block_break_denied": self.cfg.default("block_break_denied"),
            "block_place_denied": self.cfg.default("block_place_denied"),
            "mute_sounds": self.cfg.default("mute_sounds"),
            "mute_emotes": self.cfg.default("mute_emotes"),
        }

    def _is_in_invis(self, player: Player) -> bool:
        return player.xuid in self._invis_active_xuids

    # ── Обработчики событий ───────────────────────────────────────────────────

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent) -> None:
        player = event.player
        # Восстанавливаем инвиз-состояние
        self._restore_player_invis(player)

        # Если в инвизе — подавляем стандартное join-сообщение
        data = self.storage.get(player.xuid) if self.storage.has(player.xuid) else None
        if data and data.invis_active and data.fake_messages:
            if player.has_permission("invis.fake_messages"):
                event.join_message = ""  # Скрываем стандартное сообщение

    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent) -> None:
        player = event.player
        xuid = player.xuid

        if not self.storage.has(xuid):
            return

        data = self.storage.get(xuid)

        # Сохраняем инвентарь перед выходом
        if data.invis_active and data.save_inventory:
            _inv_mgr.save_inventory(player, data, "invis")
        elif not data.invis_active and data.save_inventory:
            _inv_mgr.save_inventory(player, data, "normal")

        self.storage.save()

        # Подавляем quit-сообщение если в инвизе
        if data.invis_active and data.fake_messages:
            if player.has_permission("invis.fake_messages"):
                event.quit_message = ""

        self._invis_active_xuids.discard(xuid)

    @event_handler
    def on_block_break(self, event: BlockBreakEvent) -> None:
        player = event.player
        if not self._is_in_invis(player):
            return
        if not player.has_permission("invis.block_break"):
            return
        data = self.storage.get(player.xuid)
        if data.block_break_denied:
            event.cancel()
            player.send_message(self.cfg.msg("block_break_denied"))

    @event_handler
    def on_block_place(self, event: BlockPlaceEvent) -> None:
        player = event.player
        if not self._is_in_invis(player):
            return
        if not player.has_permission("invis.block_place"):
            return
        data = self.storage.get(player.xuid)
        if data.block_place_denied:
            event.cancel()
            player.send_message(self.cfg.msg("block_place_denied"))

    @event_handler
    def on_player_emote(self, event: PlayerEmoteEvent) -> None:
        player = event.player
        if not self._is_in_invis(player):
            return
        if not player.has_permission("invis.mute_emotes"):
            return
        data = self.storage.get(player.xuid)
        if data.mute_emotes:
            # Отключаем анимацию для остальных игроков (mute = True)
            event.is_muted = True

    @event_handler
    def on_server_list_ping(self, event: ServerListPingEvent) -> None:
        """Уменьшаем видимое кол-во игроков на число администраторов в инвизе."""
        hidden_count = 0
        for p in self.server.online_players:
            if not self._is_in_invis(p):
                continue
            if not p.has_permission("invis.hide_list"):
                continue
            data = self.storage.get(p.xuid) if self.storage.has(p.xuid) else None
            if data and data.hide_from_list:
                hidden_count += 1

        if hidden_count > 0:
            current = event.num_players
            event.num_players = max(0, current - hidden_count)
