"""
endstone-admin
Система администрирования для Endstone серверов.
"""

from .admin_plugin import AdminPlugin

__all__ = ["AdminPlugin"]
