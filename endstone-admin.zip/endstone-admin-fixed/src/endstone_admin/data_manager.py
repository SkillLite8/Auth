"""
endstone-admin | data_manager.py
Управление данными: жалобы, наказания, хранение в JSON
"""

from __future__ import annotations

import json
import os
import time
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    pass


class DataManager:
    """Управляет сохранением и загрузкой данных плагина."""

    def __init__(self, data_folder: str):
        self.data_folder = data_folder
        os.makedirs(data_folder, exist_ok=True)

        self._reports_file = os.path.join(data_folder, "reports.json")
        self._punishments_file = os.path.join(data_folder, "punishments.json")
        self._bans_file = os.path.join(data_folder, "bans.json")
        self._mutes_file = os.path.join(data_folder, "mutes.json")
        self._warns_file = os.path.join(data_folder, "warns.json")

        self._reports: dict = self._load(self._reports_file, {"next_id": 1, "data": {}})
        self._punishments: list = self._load(self._punishments_file, [])
        self._bans: dict = self._load(self._bans_file, {})
        self._mutes: dict = self._load(self._mutes_file, {})
        self._warns: dict = self._load(self._warns_file, {})

    # ─── Утилиты ────────────────────────────────────────────

    def _load(self, path: str, default):
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return default

    def _save(self, path: str, data) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    # ─── Жалобы (Reports) ───────────────────────────────────

    def create_report(self, player_name: str, player_xuid: str, text: str) -> int:
        report_id = self._reports["next_id"]
        self._reports["next_id"] += 1
        self._reports["data"][str(report_id)] = {
            "id": report_id,
            "player": player_name,
            "player_xuid": player_xuid,
            "text": text,
            "status": "open",          # open / closed
            "rating": None,            # 1-5 оценка игрока
            "created_at": time.time(),
            "last_activity": time.time(),
            "messages": [
                {
                    "from": player_name,
                    "role": "player",
                    "text": text,
                    "time": time.time()
                }
            ]
        }
        self._save(self._reports_file, self._reports)
        return report_id

    def get_report(self, report_id: int) -> Optional[dict]:
        return self._reports["data"].get(str(report_id))

    def get_all_reports(self, status: Optional[str] = None) -> list:
        reports = list(self._reports["data"].values())
        if status:
            reports = [r for r in reports if r["status"] == status]
        return sorted(reports, key=lambda r: r["created_at"], reverse=True)

    def get_player_reports(self, player_xuid: str, status: Optional[str] = None) -> list:
        reports = [
            r for r in self._reports["data"].values()
            if r["player_xuid"] == player_xuid
        ]
        if status:
            reports = [r for r in reports if r["status"] == status]
        return sorted(reports, key=lambda r: r["created_at"], reverse=True)

    def add_report_message(self, report_id: int, sender: str, role: str, text: str) -> bool:
        report = self.get_report(report_id)
        if not report:
            return False
        report["messages"].append({
            "from": sender,
            "role": role,  # "player" или "admin"
            "text": text,
            "time": time.time()
        })
        report["last_activity"] = time.time()
        self._save(self._reports_file, self._reports)
        return True

    def close_report(self, report_id: int) -> bool:
        report = self.get_report(report_id)
        if not report:
            return False
        report["status"] = "closed"
        report["closed_at"] = time.time()
        self._save(self._reports_file, self._reports)
        return True

    def rate_report(self, report_id: int, rating: int) -> bool:
        """Игрок ставит оценку (1-5) после закрытия жалобы."""
        report = self.get_report(report_id)
        if not report:
            return False
        report["rating"] = max(1, min(5, rating))
        self._save(self._reports_file, self._reports)
        return True

    def get_stale_reports(self, max_inactive_seconds: int) -> list:
        """Возвращает открытые жалобы без активности дольше заданного времени."""
        now = time.time()
        return [
            r for r in self._reports["data"].values()
            if r["status"] == "open"
            and (now - r["last_activity"]) >= max_inactive_seconds
        ]

    # ─── Баны ───────────────────────────────────────────────

    def ban_player(self, xuid: str, player_name: str, admin: str, reason: str,
                   duration_minutes: int, silent: bool) -> None:
        expire_at = None if duration_minutes == 0 else time.time() + duration_minutes * 60
        self._bans[xuid] = {
            "xuid": xuid,
            "player": player_name,
            "admin": admin,
            "reason": reason,
            "duration_minutes": duration_minutes,
            "banned_at": time.time(),
            "expire_at": expire_at,
            "silent": silent,
            "permanent": duration_minutes == 0
        }
        self._save(self._bans_file, self._bans)
        self._log_punishment("ban", player_name, xuid, admin, reason, duration_minutes, silent)

    def unban_player(self, xuid: str) -> bool:
        if xuid in self._bans:
            del self._bans[xuid]
            self._save(self._bans_file, self._bans)
            return True
        return False

    def get_ban(self, xuid: str) -> Optional[dict]:
        ban = self._bans.get(xuid)
        if ban and not ban["permanent"]:
            if time.time() >= ban["expire_at"]:
                self.unban_player(xuid)
                return None
        return ban

    def is_banned(self, xuid: str) -> bool:
        return self.get_ban(xuid) is not None

    # ─── Муты ───────────────────────────────────────────────

    def mute_player(self, xuid: str, player_name: str, admin: str, reason: str,
                    duration_minutes: int, silent: bool) -> None:
        expire_at = None if duration_minutes == 0 else time.time() + duration_minutes * 60
        self._mutes[xuid] = {
            "xuid": xuid,
            "player": player_name,
            "admin": admin,
            "reason": reason,
            "duration_minutes": duration_minutes,
            "muted_at": time.time(),
            "expire_at": expire_at,
            "silent": silent,
            "permanent": duration_minutes == 0
        }
        self._save(self._mutes_file, self._mutes)
        self._log_punishment("mute", player_name, xuid, admin, reason, duration_minutes, silent)

    def unmute_player(self, xuid: str) -> bool:
        if xuid in self._mutes:
            del self._mutes[xuid]
            self._save(self._mutes_file, self._mutes)
            return True
        return False

    def get_mute(self, xuid: str) -> Optional[dict]:
        mute = self._mutes.get(xuid)
        if mute and not mute["permanent"]:
            if mute["expire_at"] and time.time() >= mute["expire_at"]:
                self.unmute_player(xuid)
                return None
        return mute

    def is_muted(self, xuid: str) -> bool:
        return self.get_mute(xuid) is not None

    # ─── Варны ──────────────────────────────────────────────

    def warn_player(self, xuid: str, player_name: str, admin: str,
                    reason: str, silent: bool) -> int:
        """Добавляет варн. Возвращает общее количество варнов."""
        if xuid not in self._warns:
            self._warns[xuid] = {"player": player_name, "warns": []}
        self._warns[xuid]["warns"].append({
            "admin": admin,
            "reason": reason,
            "time": time.time(),
            "silent": silent
        })
        self._save(self._warns_file, self._warns)
        count = len(self._warns[xuid]["warns"])
        self._log_punishment("warn", player_name, xuid, admin, reason, 0, silent)
        return count

    def get_warns(self, xuid: str) -> list:
        return self._warns.get(xuid, {}).get("warns", [])

    def get_warn_count(self, xuid: str) -> int:
        return len(self.get_warns(xuid))

    def clear_warns(self, xuid: str) -> bool:
        if xuid in self._warns:
            self._warns[xuid]["warns"] = []
            self._save(self._warns_file, self._warns)
            return True
        return False

    # ─── Лог наказаний ──────────────────────────────────────

    def _log_punishment(self, ptype: str, player: str, xuid: str,
                        admin: str, reason: str, duration: int, silent: bool) -> None:
        self._punishments.append({
            "type": ptype,
            "player": player,
            "xuid": xuid,
            "admin": admin,
            "reason": reason,
            "duration_minutes": duration,
            "silent": silent,
            "time": time.time()
        })
        self._save(self._punishments_file, self._punishments)

    def get_punishments(self, xuid: Optional[str] = None,
                        ptype: Optional[str] = None,
                        limit: int = 50) -> list:
        logs = self._punishments
        if xuid:
            logs = [p for p in logs if p["xuid"] == xuid]
        if ptype:
            logs = [p for p in logs if p["type"] == ptype]
        return sorted(logs, key=lambda p: p["time"], reverse=True)[:limit]
