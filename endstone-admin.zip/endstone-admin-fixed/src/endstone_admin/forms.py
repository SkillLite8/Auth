import json
from endstone.form import ActionForm, ModalForm, MessageForm, TextInput, Dropdown
from .utils import format_duration, format_time_left, format_timestamp, rating_stars, truncate, punishment_label


def _parse(raw):
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def show_report_menu(player, db, cfg):
    open_r = db.get_player_reports(player.xuid, status="open")
    closed_r = db.get_player_reports(player.xuid, status="closed")
    form = ActionForm(
        title="Мои жалобы",
        content="Открытые: " + str(len(open_r)) + "  |  Закрытые: " + str(len(closed_r))
    )
    form.add_button("Написать жалобу", on_click=lambda p: show_create_report_form(p, db, cfg))
    for r in open_r[:5]:
        form.add_button(
            "#" + str(r["id"]) + " " + truncate(r["text"], 32) + "\n" + format_timestamp(r["created_at"]) + "  [Открыта]",
            on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg)
        )
    for r in closed_r[:5]:
        form.add_button(
            "#" + str(r["id"]) + " " + truncate(r["text"], 32) + "\n" + format_timestamp(r["created_at"]) + "  [Закрыта] " + rating_stars(r.get("rating")),
            on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg)
        )
    player.send_form(form)


def show_create_report_form(player, db, cfg):
    open_count = len(db.get_player_reports(player.xuid, status="open"))
    max_open = cfg.get("reports", {}).get("max_open_per_player", 3)
    if open_count >= max_open:
        form = MessageForm(
            title="Лимит жалоб",
            content="У вас уже " + str(open_count) + " открытых жалоб.\nДождитесь ответа администратора.",
            button1="Понятно",
            button2="Назад"
        )
        player.send_form(form)
        return
    max_len = cfg.get("reports", {}).get("max_length", 500)
    form = ModalForm(title="Новая жалоба")
    form.add_control(TextInput(
        label="Опишите проблему (макс. " + str(max_len) + " символов):",
        placeholder="Введите текст жалобы..."
    ))
    form.submit_button = "Отправить"
    def on_submit(p, raw):
        data = _parse(raw)
        if not data:
            return
        text = str(data[0] or "").strip()
        if not text:
            p.send_message("§cТекст не может быть пустым!")
            return
        if len(text) > max_len:
            p.send_message("§cСлишком длинно!")
            return
        rid = db.create_report(p.name, p.xuid, text)
        p.send_message("§aЖалоба §e#" + str(rid) + " §aотправлена!")
    form.on_submit = on_submit
    player.send_form(form)


def show_report_dialog(player, report_id, db, cfg):
    report = db.get_report(report_id)
    if not report:
        player.send_message("§cЖалоба не найдена!")
        return
    is_owner = report["player_xuid"] == player.xuid
    is_admin = player.has_permission("admin.reports.reply")
    if not is_owner and not is_admin:
        player.send_message("§cНет прав!")
        return
    lines = []
    for m in report["messages"]:
        prefix = "[Админ] " if m["role"] == "admin" else "[Игрок] "
        lines.append(prefix + m["from"] + ": " + m["text"] + "\n" + format_timestamp(m["time"]))
    history = "\n\n".join(lines) if lines else "(нет сообщений)"
    status_str = "Открыта" if report["status"] == "open" else "Закрыта"
    form = ActionForm(
        title="Жалоба #" + str(report_id),
        content="Статус: " + status_str + "\nСоздана: " + format_timestamp(report["created_at"]) + "\nОценка: " + rating_stars(report.get("rating")) + "\n\n" + history
    )
    if report["status"] == "open":
        if is_owner:
            form.add_button("Написать ответ", on_click=lambda p: _reply_form(p, report_id, "player", db, cfg))
        if is_admin:
            form.add_button("Ответить игроку", on_click=lambda p: _reply_form(p, report_id, "admin", db, cfg))
            form.add_button("Закрыть жалобу", on_click=lambda p: _confirm_close_report(p, report_id, db, cfg))
    if report["status"] == "closed" and is_owner and report.get("rating") is None:
        form.add_button("Оценить ответ", on_click=lambda p: show_rate_report_form(p, report_id, db))
    form.add_button("Назад", on_click=lambda p: show_report_menu(p, db, cfg))
    player.send_form(form)


def _reply_form(player, report_id, role, db, cfg):
    form = ModalForm(title="Ответ на жалобу #" + str(report_id))
    form.add_control(TextInput(label="Введите ответ:", placeholder="Текст сообщения..."))
    form.submit_button = "Отправить"
    def on_submit(p, raw):
        data = _parse(raw)
        if not data:
            return
        text = str(data[0] or "").strip()
        if not text:
            p.send_message("§cСообщение не может быть пустым!")
            return
        db.add_report_message(report_id, p.name, role, text)
        p.send_message("§aОтвет отправлен!")
        show_report_dialog(p, report_id, db, cfg)
    form.on_submit = on_submit
    player.send_form(form)


def _confirm_close_report(player, report_id, db, cfg):
    form = MessageForm(
        title="Закрыть жалобу?",
        content="Закрыть жалобу #" + str(report_id) + "?\nИгрок сможет оставить оценку.",
        button1="Да, закрыть",
        button2="Отмена"
    )
    def on_submit(p, result):
        if result == 0:
            db.close_report(report_id)
            p.send_message("§aЖалоба #" + str(report_id) + " закрыта!")
            show_admin_reports_menu(p, db, cfg)
    form.on_submit = on_submit
    player.send_form(form)


def show_rate_report_form(player, report_id, db):
    form = ModalForm(title="Оценка жалобы #" + str(report_id))
    form.add_control(Dropdown(
        label="Оцените работу администратора:",
        options=["1 - Ужасно", "2 - Плохо", "3 - Нормально", "4 - Хорошо", "5 - Отлично"],
        default_index=4
    ))
    form.submit_button = "Оставить оценку"
    def on_submit(p, raw):
        data = _parse(raw)
        if not data:
            return
        rating = int(data[0] or 0) + 1
        db.rate_report(report_id, rating)
        p.send_message("§aСпасибо за оценку! " + rating_stars(rating))
    form.on_submit = on_submit
    player.send_form(form)


def show_admin_reports_menu(player, db, cfg):
    open_r = db.get_all_reports(status="open")
    closed_r = db.get_all_reports(status="closed")
    form = ActionForm(
        title="Жалобы [Админ]",
        content="Открытые: " + str(len(open_r)) + "  |  Закрытые: " + str(len(closed_r))
    )
    if open_r:
        for r in open_r[:10]:
            form.add_button(
                "#" + str(r["id"]) + " " + r["player"] + "\n" + truncate(r["text"], 30),
                on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg)
            )
    else:
        form.add_button("(нет открытых жалоб)")
    form.add_button("Закрытые жалобы", on_click=lambda p: _show_closed_reports(p, db, cfg))
    form.add_button("Главное меню", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    player.send_form(form)


def _show_closed_reports(player, db, cfg):
    closed = db.get_all_reports(status="closed")
    form = ActionForm(title="Закрытые жалобы", content="Всего: " + str(len(closed)))
    for r in closed[:15]:
        form.add_button(
            "#" + str(r["id"]) + " " + r["player"] + " " + rating_stars(r.get("rating")) + "\n" + truncate(r["text"], 30),
            on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg)
        )
    if not closed:
        form.add_button("(нет закрытых жалоб)")
    form.add_button("Назад", on_click=lambda p: show_admin_reports_menu(p, db, cfg))
    player.send_form(form)


def show_admin_main_menu(player, db, cfg):
    form = ActionForm(title="Панель администратора", content="Выберите раздел:")
    if player.has_permission("admin.reports.view"):
        open_count = len(db.get_all_reports(status="open"))
        label = "Жалобы [" + str(open_count) + "]" if open_count > 0 else "Жалобы"
        form.add_button(label, on_click=lambda p: show_admin_reports_menu(p, db, cfg))
    if player.has_permission("admin.punish"):
        form.add_button("Управление игроками", on_click=lambda p: show_player_list_menu(p, db, cfg, p.server))
    if player.has_permission("admin.punishments.view"):
        form.add_button("Отчеты наказаний", on_click=lambda p: show_punishment_logs(p, db, cfg))
    player.send_form(form)


def show_player_list_menu(player, db, cfg, server=None):
    srv = server or getattr(player, "server", None)
    form = ActionForm(title="Выбор игрока", content="Нажмите на игрока для управления:")
    players = list(srv.online_players) if srv else []
    if players:
        for p in players:
            tags = ""
            if db.is_banned(p.xuid):
                tags += " [БАН]"
            if db.is_muted(p.xuid):
                tags += " [МУТ]"
            w = db.get_warn_count(p.xuid)
            if w > 0:
                tags += " [" + str(w) + " варн]"
            form.add_button(p.name + tags, on_click=lambda adm, t=p: show_player_action_menu(adm, t, db, cfg))
    else:
        form.add_button("(нет онлайн-игроков)")
    form.add_button("Назад", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    player.send_form(form)


def show_player_list_for_action(player, db, cfg, server, action):
    titles = {
        "ban": "Выбрать игрока для бана",
        "mute": "Выбрать игрока для мута",
        "kick": "Выбрать игрока для кика",
        "warn": "Выбрать игрока для варна",
    }
    form = ActionForm(title=titles.get(action, "Выбор игрока"), content="Выберите игрока:")
    players = list(server.online_players) if server else []
    if players:
        for p in players:
            form.add_button(p.name, on_click=lambda adm, t=p: _dispatch_action(adm, t, db, cfg, action))
    else:
        form.add_button("(нет онлайн-игроков)")
    player.send_form(form)


def _dispatch_action(admin, target, db, cfg, action):
    if action == "ban":
        show_ban_form(admin, target, db, cfg)
    elif action == "mute":
        show_mute_form(admin, target, db, cfg)
    elif action == "kick":
        show_kick_form(admin, target, db, cfg)
    elif action == "warn":
        show_warn_form(admin, target, db, cfg)


def show_player_action_menu(admin, target, db, cfg):
    warn_count = db.get_warn_count(target.xuid)
    ban = db.get_ban(target.xuid)
    mute = db.get_mute(target.xuid)
    ban_status = "Активен до " + format_time_left(ban["expire_at"] if ban else None) if ban else "Нет"
    mute_status = "Активен до " + format_time_left(mute["expire_at"] if mute else None) if mute else "Нет"
    form = ActionForm(
        title=target.name,
        content="Бан: " + ban_status + "\nМут: " + mute_status + "\nВарнов: " + str(warn_count)
    )
    if admin.has_permission("admin.ban"):
        if ban:
            form.add_button("Разбанить", on_click=lambda p: _unban_player(p, target, db, cfg))
        else:
            form.add_button("Бан", on_click=lambda p: show_ban_form(p, target, db, cfg))
    if admin.has_permission("admin.mute"):
        if mute:
            form.add_button("Размутить", on_click=lambda p: _unmute_player(p, target, db, cfg))
        else:
            form.add_button("Мут", on_click=lambda p: show_mute_form(p, target, db, cfg))
    if admin.has_permission("admin.kick"):
        form.add_button("Кик", on_click=lambda p: show_kick_form(p, target, db, cfg))
    if admin.has_permission("admin.warn"):
        form.add_button("Варн", on_click=lambda p: show_warn_form(p, target, db, cfg))
        if warn_count > 0:
            form.add_button("Снять все варны", on_click=lambda p: show_clearwarns_confirm(p, target, db, cfg))
    if admin.has_permission("admin.punishments.view"):
        form.add_button("История игрока", on_click=lambda p: show_player_history(p, target, db, cfg))
    form.add_button("Назад", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    admin.send_form(form)


def show_ban_form(admin, target, db, cfg):
    default_reason = cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    form = ModalForm(title="Бан: " + target.name)
    form.add_control(TextInput(label="Причина:", placeholder=default_reason))
    form.add_control(TextInput(label="Срок в минутах (0 = навсегда):", placeholder="0"))
    form.submit_button = "Применить бан"
    def on_submit(p, raw):
        data = _parse(raw)
        if not data:
            return
        reason = str(data[0] or "").strip() or default_reason
        try:
            duration = int(str(data[1] or "0").strip())
        except (ValueError, IndexError):
            p.send_message("§cНеверный срок!")
            return
        db.ban_player(target.xuid, target.name, p.name, reason, duration, False)
        dur_str = format_duration(duration)
        if duration == 0:
            kick_msg = cfg.get("ban", {}).get("permanent_message", "§cВы заблокированы навсегда.\n§7Причина: {reason}").format(reason=reason)
        else:
            kick_msg = cfg.get("ban", {}).get("kick_message", "§cВы заблокированы на {duration}.\n§7Причина: {reason}").format(reason=reason, duration=dur_str)
        target.kick(kick_msg)
        p.send_message("§c[БАН] " + target.name + " — " + reason + " (" + dur_str + ")")
    form.on_submit = on_submit
    admin.send_form(form)


def show_mute_form(admin, target, db, cfg):
    default_reason = cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    form = ModalForm(title="Мут: " + target.name)
    form.add_control(TextInput(label="Причина:", placeholder=default_reason))
    form.add_control(TextInput(label="Срок в минутах (0 = навсегда):", placeholder="0"))
    form.submit_button = "Применить мут"
    def on_submit(p, raw):
        data = _parse(raw)
        if not data:
            return
        reason = str(data[0] or "").strip() or default_reason
        try:
            duration = int(str(data[1] or "0").strip())
        except (ValueError, IndexError):
            p.send_message("§cНеверный срок!")
            return
        db.mute_player(target.xuid, target.name, p.name, reason, duration, False)
        dur_str = format_duration(duration)
        target.send_message(cfg.get("mute", {}).get("muted_message", "§cВы замолчены. Причина: {reason}. Осталось: {time_left}").format(reason=reason, time_left=dur_str))
        p.send_message("§e[МУТ] " + target.name + " — " + reason + " (" + dur_str + ")")
    form.on_submit = on_submit
    admin.send_form(form)


def show_kick_form(admin, target, db, cfg):
    default_reason = cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    form = ModalForm(title="Кик: " + target.name)
    form.add_control(TextInput(label="Причина:", placeholder=default_reason))
    form.submit_button = "Кикнуть"
    def on_submit(p, raw):
        data = _parse(raw)
        if not data:
            return
        reason = str(data[0] or "").strip() or default_reason
        db._log_punishment("kick", target.name, target.xuid, p.name, reason, 0, False)
        target.kick(cfg.get("kick", {}).get("message", "§cВы кикнуты.\n§7Причина: {reason}").format(reason=reason))
        p.send_message("§6[КИК] " + target.name + " — " + reason)
    form.on_submit = on_submit
    admin.send_form(form)


def show_warn_form(admin, target, db, cfg):
    default_reason = cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    kicks_at = cfg.get("warn", {}).get("kicks_at", 3)
    ban_at = cfg.get("warn", {}).get("ban_at", 5)
    current = db.get_warn_count(target.xuid)
    form = ModalForm(title="Варн: " + target.name + " [" + str(current) + " варнов]")
    form.add_control(TextInput(label="Причина предупреждения:", placeholder=default_reason))
    form.submit_button = "Выдать варн"
    def on_submit(p, raw):
        data = _parse(raw)
        if not data:
            return
        reason = str(data[0] or "").strip() or default_reason
        count = db.warn_player(target.xuid, target.name, p.name, reason, False)
        target.send_message(cfg.get("warn", {}).get("message", "§eПредупреждение #{count}: {reason}").format(reason=reason, count=count))
        p.send_message("§e[ВАРН] " + target.name + " — " + reason + " [" + str(count) + "]")
        if count >= ban_at:
            db.ban_player(target.xuid, target.name, "AutoAdmin", "Автобан за варны", 0, False)
            target.kick("§cАвтоматическая блокировка за " + str(count) + " предупреждений!")
            p.send_message("§c[АВТОБАН] " + target.name + " заблокирован!")
        elif count >= kicks_at:
            target.kick("§eВы кикнуты за " + str(count) + " предупреждений!")
            p.send_message("§e[АВТОКИК] " + target.name + " кикнут!")
    form.on_submit = on_submit
    admin.send_form(form)


def show_warns_info(admin, target, db, cfg):
    warns = db.get_warns(target.xuid)
    count = len(warns)
    form = ActionForm(
        title="Варны: " + target.name,
        content="Активных варнов: " + str(count) + "\nКик при: " + str(cfg.get("warn", {}).get("kicks_at", 3)) + "  Бан при: " + str(cfg.get("warn", {}).get("ban_at", 5))
    )
    if warns:
        for i, w in enumerate(warns, 1):
            form.add_button(str(i) + ". " + w["reason"] + "\nby " + w["admin"] + "  " + format_timestamp(w["time"]))
    else:
        form.add_button("(нет варнов)")
    if count > 0 and admin.has_permission("admin.warn"):
        form.add_button("Снять все варны", on_click=lambda p: show_clearwarns_confirm(p, target, db, cfg))
    form.add_button("Назад", on_click=lambda p: show_player_action_menu(p, target, db, cfg))
    admin.send_form(form)


def show_clearwarns_confirm(admin, target, db, cfg):
    count = db.get_warn_count(target.xuid)
    form = MessageForm(
        title="Снять варны?",
        content="Снять " + str(count) + " варн(ов) с игрока " + target.name + "?\nЭто действие необратимо.",
        button1="Да, снять",
        button2="Отмена"
    )
    def on_submit(p, result):
        if result == 0:
            db.clear_warns(target.xuid)
            p.send_message("§aВарны игрока " + target.name + " сняты!")
            target.send_message("§aВаши предупреждения были сняты!")
            show_player_action_menu(p, target, db, cfg)
    form.on_submit = on_submit
    admin.send_form(form)


def show_banned_list(admin, db, cfg):
    bans = list(db._bans.items()) if hasattr(db, "_bans") else []
    form = ActionForm(title="Забаненные игроки", content="Всего забанено: " + str(len(bans)))
    if bans:
        for xuid, ban_data in bans[:20]:
            expire = format_time_left(ban_data.get("expire_at"))
            form.add_button(
                ban_data["player"] + "\n" + ban_data.get("reason", "?") + "  до: " + expire,
                on_click=lambda p, xid=xuid, bd=ban_data: _confirm_unban(p, xid, bd, db, cfg)
            )
    else:
        form.add_button("(нет забаненных)")
    form.add_button("Главное меню", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    admin.send_form(form)


def show_unban_by_name(admin, target_name, db, cfg):
    found_xuid = None
    found_data = None
    if hasattr(db, "_bans"):
        for xuid, bd in db._bans.items():
            if bd["player"].lower() == target_name.lower():
                found_xuid = xuid
                found_data = bd
                break
    if not found_xuid:
        admin.send_message("§cБан для " + target_name + " не найден!")
        return
    _confirm_unban(admin, found_xuid, found_data, db, cfg)


def _confirm_unban(admin, xuid, ban_data, db, cfg):
    form = MessageForm(
        title="Разбанить игрока?",
        content="Игрок: " + ban_data["player"] + "\nПричина бана: " + ban_data.get("reason", "?") + "\nВыдан: " + ban_data.get("admin", "?") + "\n\nРазбанить?",
        button1="Да, разбанить",
        button2="Отмена"
    )
    def on_submit(p, result):
        if result == 0:
            db.unban_player(xuid)
            p.send_message("§aИгрок " + ban_data["player"] + " разбанен!")
    form.on_submit = on_submit
    admin.send_form(form)


def _unban_player(admin, target, db, cfg):
    db.unban_player(target.xuid)
    admin.send_message("§aИгрок " + target.name + " разбанен!")
    show_player_action_menu(admin, target, db, cfg)


def _unmute_player(admin, target, db, cfg):
    db.unmute_player(target.xuid)
    admin.send_message("§aИгрок " + target.name + " размучен!")
    target.send_message("§aВы были размучены!")
    show_player_action_menu(admin, target, db, cfg)


def show_punishment_logs(player, db, cfg, filter_type=None, filter_xuid=None):
    logs = db.get_punishments(xuid=filter_xuid, ptype=filter_type, limit=30)
    form = ActionForm(title="Отчеты наказаний", content="Показано: " + str(len(logs)) + " записей")
    form.add_button("Только баны",  on_click=lambda p: show_punishment_logs(p, db, cfg, "ban"))
    form.add_button("Только муты",  on_click=lambda p: show_punishment_logs(p, db, cfg, "mute"))
    form.add_button("Только кики",  on_click=lambda p: show_punishment_logs(p, db, cfg, "kick"))
    form.add_button("Только варны", on_click=lambda p: show_punishment_logs(p, db, cfg, "warn"))
    if filter_type or filter_xuid:
        form.add_button("Сбросить фильтр", on_click=lambda p: show_punishment_logs(p, db, cfg))
    if logs:
        for log in logs:
            label = punishment_label(log["type"])
            dur_str = format_duration(log["duration_minutes"]) if log["type"] in ("ban", "mute") else ""
            ts = format_timestamp(log["time"])
            btn = "[" + label + "] " + log["player"] + "\n" + log["reason"] + ("  " + dur_str if dur_str else "") + "\n" + ts + " by " + log["admin"]
            form.add_button(btn)
    else:
        form.add_button("(нет записей)")
    form.add_button("Главное меню", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    player.send_form(form)


def show_player_history(admin, target, db, cfg):
    logs = db.get_punishments(xuid=target.xuid, limit=20)
    warns = db.get_warn_count(target.xuid)
    ban = db.get_ban(target.xuid)
    mute = db.get_mute(target.xuid)
    ban_info = "До: " + format_time_left(ban["expire_at"] if ban else None) if ban else "Нет"
    mute_info = "До: " + format_time_left(mute["expire_at"] if mute else None) if mute else "Нет"
    form = ActionForm(
        title="История: " + target.name,
        content="Бан: " + ban_info + "\nМут: " + mute_info + "\nВарнов: " + str(warns)
    )
    if logs:
        for log in logs:
            label = punishment_label(log["type"])
            dur_str = format_duration(log["duration_minutes"]) if log["type"] in ("ban", "mute") else ""
            ts = format_timestamp(log["time"])
            btn = "[" + label + "] " + log["reason"] + ("  (" + dur_str + ")" if dur_str else "") + "\n" + ts + " by " + log["admin"]
            form.add_button(btn)
    else:
        form.add_button("(нет истории)")
    form.add_button("Назад", on_click=lambda p: show_player_action_menu(p, target, db, cfg))
    admin.send_form(form)
