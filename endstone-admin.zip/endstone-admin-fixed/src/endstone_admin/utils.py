"""
endstone-admin | utils.py
Вспомогательные функции
"""

from __future__ import annotations

import time
from typing import Optional


def format_duration(minutes: int) -> str:
    """Форматирует минуты в читаемую строку."""
    if minutes == 0:
        return "Навсегда"
    if minutes < 60:
        return f"{minutes} мин."
    hours = minutes // 60
    mins = minutes % 60
    if hours < 24:
        return f"{hours} ч. {mins} мин." if mins else f"{hours} ч."
    days = hours // 24
    hrs = hours % 24
    return f"{days} д. {hrs} ч." if hrs else f"{days} д."


def format_time_left(expire_at: Optional[float]) -> str:
    """Возвращает строку с оставшимся временем."""
    if expire_at is None:
        return "Навсегда"
    left = expire_at - time.time()
    if left <= 0:
        return "Истёк"
    minutes = int(left // 60)
    return format_duration(minutes if minutes > 0 else 1)


def format_timestamp(ts: float) -> str:
    """Форматирует unix-timestamp в дату."""
    import datetime
    dt = datetime.datetime.fromtimestamp(ts)
    return dt.strftime("%d.%m.%Y %H:%M")


def rating_stars(rating: Optional[int]) -> str:
    """Превращает оценку (1-5) в звёзды."""
    if rating is None:
        return "—"
    return "★" * rating + "☆" * (5 - rating)


def truncate(text: str, max_len: int = 50) -> str:
    """Обрезает строку до max_len символов."""
    return text if len(text) <= max_len else text[:max_len - 3] + "..."


def status_icon(status: str) -> str:
    return "§a●" if status == "open" else "§8●"


def punishment_color(ptype: str) -> str:
    colors = {
        "ban":  "§c",
        "mute": "§e",
        "kick": "§6",
        "warn": "§e",
    }
    return colors.get(ptype, "§f")


def punishment_label(ptype: str) -> str:
    labels = {
        "ban":  "БАН",
        "mute": "МУТ",
        "kick": "КИК",
        "warn": "ВАРН",
    }
    return labels.get(ptype, ptype.upper())
