import time
from typing import TYPE_CHECKING, Optional

from endstone.form import ActionForm, ModalForm, MessageForm, TextInput, Toggle, Dropdown, Label

from .utils import (
    format_duration, format_time_left, format_timestamp,
    rating_stars, truncate, status_icon, punishment_color, punishment_label
)

if TYPE_CHECKING:
    from endstone import Player
    from .data_manager import DataManager


def show_report_menu(player, db, cfg) -> None:
    open_r   = db.get_player_reports(player.xuid, status="open")
    closed_r = db.get_player_reports(player.xuid, status="closed")

    form = ActionForm(
        title="§l§9 Мои жалобы",
        content=(
            "§7Открытые: §a" + str(len(open_r)) +
            "  §8|  §7Закрытые: §8" + str(len(closed_r))
        )
    )
    form.add_button("§a Написать жалобу", on_click=lambda p: show_create_report_form(p, db, cfg))

    for r in open_r[:5]:
        btn = "§e#" + str(r["id"]) + " §f" + truncate(r["text"], 32) + "\n§7" + format_timestamp(r["created_at"]) + "  §a[Открыта]"
        form.add_button(btn, on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg))

    for r in closed_r[:5]:
        stars = rating_stars(r.get("rating"))
        btn = "§8#" + str(r["id"]) + " §7" + truncate(r["text"], 32) + "\n§8" + format_timestamp(r["created_at"]) + "  [Закрыта] " + stars
        form.add_button(btn, on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg))

    player.send_form(form)


def show_create_report_form(player, db, cfg) -> None:
    open_count = len(db.get_player_reports(player.xuid, status="open"))
    max_open   = cfg.get("reports", {}).get("max_open_per_player", 3)

    if open_count >= max_open:
        form = MessageForm(
            title="§c Лимит жалоб",
            content="§7У вас уже §e" + str(open_count) + " §7открытых жалоб.\n§7Дождитесь ответа администратора.",
            button1="§aПонятно",
            button2="§7Назад"
        )
        player.send_form(form)
        return

    max_len = cfg.get("reports", {}).get("max_length", 500)
    form = ModalForm(title="§l§9 Новая жалоба")
    form.add_control(TextInput(
        label="§7Опишите проблему (макс. " + str(max_len) + " символов):",
        placeholder="Введите текст жалобы..."
    ))
    form.submit_button = "§aОтправить"

    def on_submit(p, data):
        text = (data[0] or "").strip()
        if not text:
            p.send_message("§cТекст не может быть пустым!")
            return
        if len(text) > max_len:
            p.send_message("§cСлишком длинно! Максимум " + str(max_len) + " символов.")
            return
        rid = db.create_report(p.name, p.xuid, text)
        p.send_message(cfg.get("messages", {}).get("report_submitted", "§aЖалоба §e#{id} §aотправлена!").format(id=rid))

    form.on_submit = on_submit
    player.send_form(form)


def show_report_dialog(player, report_id: int, db, cfg) -> None:
    report = db.get_report(report_id)
    if not report:
        player.send_message("§cЖалоба не найдена!")
        return

    is_owner = report["player_xuid"] == player.xuid
    is_admin = player.has_permission("admin.reports.reply")
    if not is_owner and not is_admin:
        player.send_message(cfg.get("messages", {}).get("no_permission", "§cНет прав!"))
        return

    lines = []
    for m in report["messages"]:
        color = "§a" if m["role"] == "admin" else "§7"
        lines.append(color + "[" + m["from"] + "] §f" + m["text"] + "\n§8" + format_timestamp(m["time"]))
    history = "\n\n".join(lines) if lines else "§8(нет сообщений)"

    status_str = "§aОткрыта" if report["status"] == "open" else "§8Закрыта"
    form = ActionForm(
        title="§l§9Жалоба #" + str(report_id),
        content=(
            "§7Статус: " + status_str + "\n"
            "§7Создана: §f" + format_timestamp(report["created_at"]) + "\n"
            "§7Оценка: §f" + rating_stars(report.get("rating")) + "\n\n"
            "§8--- История ---\n" + history
        )
    )

    if report["status"] == "open":
        if is_owner:
            form.add_button("§e Написать ответ", on_click=lambda p: _reply_form(p, report_id, "player", db, cfg))
        if is_admin:
            form.add_button("§a Ответить игроку",  on_click=lambda p: _reply_form(p, report_id, "admin", db, cfg))
            form.add_button("§c Закрыть жалобу",   on_click=lambda p: _confirm_close_report(p, report_id, db, cfg))

    if report["status"] == "closed" and is_owner and report.get("rating") is None:
        form.add_button("§e Оценить ответ", on_click=lambda p: show_rate_report_form(p, report_id, db))

    form.add_button("§7<- Назад", on_click=lambda p: show_report_menu(p, db, cfg))
    player.send_form(form)


def _reply_form(player, report_id: int, role: str, db, cfg) -> None:
    form = ModalForm(title="§l§9Ответ на жалобу #" + str(report_id))
    form.add_control(TextInput(label="§7Введите ответ:", placeholder="Текст сообщения..."))
    form.submit_button = "§aОтправить"

    def on_submit(p, data):
        text = (data[0] or "").strip()
        if not text:
            p.send_message("§cСообщение не может быть пустым!")
            return
        db.add_report_message(report_id, p.name, role, text)
        p.send_message("§aОтвет на жалобу §e#" + str(report_id) + " §aотправлен!")
        show_report_dialog(p, report_id, db, cfg)

    form.on_submit = on_submit
    player.send_form(form)


def _confirm_close_report(player, report_id: int, db, cfg) -> None:
    form = MessageForm(
        title="§cЗакрыть жалобу?",
        content="§7Вы уверены, что хотите закрыть жалобу §e#" + str(report_id) + "§7?\nИгрок сможет оставить оценку.",
        button1="§cДа, закрыть",
        button2="§7Отмена"
    )

    def on_submit(p, result):
        if result:
            db.close_report(report_id)
            p.send_message("§aЖалоба §e#" + str(report_id) + " §aзакрыта!")
            show_admin_reports_menu(p, db, cfg)

    form.on_submit = on_submit
    player.send_form(form)


def show_rate_report_form(player, report_id: int, db) -> None:
    form = ModalForm(title="§l§e Оценка жалобы #" + str(report_id))
    form.add_control(Dropdown(
        label="§7Оцените работу администратора:",
        options=["1 - Ужасно", "2 - Плохо", "3 - Нормально", "4 - Хорошо", "5 - Отлично"],
        default_index=4
    ))
    form.submit_button = "§aОставить оценку"

    def on_submit(p, data):
        rating = (data[0] or 0) + 1
        db.rate_report(report_id, rating)
        p.send_message("§aСпасибо за оценку! " + rating_stars(rating))

    form.on_submit = on_submit
    player.send_form(form)


def show_admin_reports_menu(player, db, cfg) -> None:
    open_r   = db.get_all_reports(status="open")
    closed_r = db.get_all_reports(status="closed")

    form = ActionForm(
        title="§l§9 Жалобы [Админ]",
        content="§7Открытые: §a" + str(len(open_r)) + "  §8|  §7Закрытые: §8" + str(len(closed_r))
    )

    if open_r:
        for r in open_r[:10]:
            btn = "§a#" + str(r["id"]) + " §f" + r["player"] + "\n§7" + truncate(r["text"], 30)
            form.add_button(btn, on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg))
    else:
        form.add_button("§8(нет открытых жалоб)")

    form.add_button("§7 Закрытые жалобы",  on_click=lambda p: _show_closed_reports(p, db, cfg))
    form.add_button("§7<- Главное меню",    on_click=lambda p: show_admin_main_menu(p, db, cfg))
    player.send_form(form)


def _show_closed_reports(player, db, cfg) -> None:
    closed = db.get_all_reports(status="closed")
    form = ActionForm(
        title="§l§8 Закрытые жалобы",
        content="§7Всего: §8" + str(len(closed))
    )
    for r in closed[:15]:
        stars = rating_stars(r.get("rating"))
        btn = "§8#" + str(r["id"]) + " §7" + r["player"] + " " + stars + "\n§8" + truncate(r["text"], 30)
        form.add_button(btn, on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg))
    if not closed:
        form.add_button("§8(нет закрытых жалоб)")
    form.add_button("§7<- Назад", on_click=lambda p: show_admin_reports_menu(p, db, cfg))
    player.send_form(form)


def show_admin_main_menu(player, db, cfg) -> None:
    form = ActionForm(
        title="§l§c Панель администратора",
        content="§7Выберите раздел:"
    )
    if player.has_permission("admin.reports.view"):
        open_count = len(db.get_all_reports(status="open"))
        label = "§9 Жалобы §8[§a" + str(open_count) + "§8]" if open_count > 0 else "§9 Жалобы"
        form.add_button(label, on_click=lambda p: show_admin_reports_menu(p, db, cfg))

    if player.has_permission("admin.punish"):
        form.add_button("§c Управление игроками", on_click=lambda p: show_player_list_menu(p, db, cfg, p.server))

    if player.has_permission("admin.punishments.view"):
        form.add_button("§e Отчёты наказаний", on_click=lambda p: show_punishment_logs(p, db, cfg))

    player.send_form(form)


def show_player_list_menu(player, db, cfg, server=None) -> None:
    srv = server or getattr(player, "server", None)
    form = ActionForm(
        title="§l§c Выбор игрока",
        content="§7Нажмите на игрока для управления:"
    )
    players = list(srv.online_players) if srv else []
    if players:
        for p in players:
            ban_m  = " §c[БАН]"  if db.is_banned(p.xuid)  else ""
            mute_m = " §e[МУТ]"  if db.is_muted(p.xuid)   else ""
            w      = db.get_warn_count(p.xuid)
            warn_m = " §6[" + str(w) + "!]" if w > 0 else ""
            form.add_button(
                "§f" + p.name + ban_m + mute_m + warn_m,
                on_click=lambda adm, t=p: show_player_action_menu(adm, t, db, cfg)
            )
    else:
        form.add_button("§8(нет онлайн-игроков)")

    form.add_button("§7<- Назад", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    player.send_form(form)


def show_player_list_for_action(player, db, cfg, server, action: str) -> None:
    titles = {
        "ban":  "§l§c Выбрать игрока для бана",
        "mute": "§l§e Выбрать игрока для мута",
        "kick": "§l§6 Выбрать игрока для кика",
        "warn": "§l§e Выбрать игрока для варна",
    }
    form = ActionForm(
        title=titles.get(action, "§lВыбор игрока"),
        content="§7Выберите игрока:"
    )
    players = list(server.online_players) if server else []
    if players:
        for p in players:
            form.add_button(
                "§f" + p.name,
                on_click=lambda adm, t=p: _dispatch_action(adm, t, db, cfg, action)
            )
    else:
        form.add_button("§8(нет онлайн-игроков)")
    player.send_form(form)


def _dispatch_action(admin, target, db, cfg, action: str) -> None:
    if action == "ban":
        show_ban_form(admin, target, db, cfg)
    elif action == "mute":
        show_mute_form(admin, target, db, cfg)
    elif action == "kick":
        show_kick_form(admin, target, db, cfg)
    elif action == "warn":
        show_warn_form(admin, target, db, cfg)


def show_player_action_menu(admin, target, db, cfg) -> None:
    warn_count = db.get_warn_count(target.xuid)
    ban  = db.get_ban(target.xuid)
    mute = db.get_mute(target.xuid)

    ban_status  = "§cАктивен до " + format_time_left(ban["expire_at"]  if ban  else None) if ban  else "§aНет"
    mute_status = "§eАктивен до " + format_time_left(mute["expire_at"] if mute else None) if mute else "§aНет"
    warn_color  = "§c" if warn_count >= 3 else ("§e" if warn_count >= 1 else "§a")

    form = ActionForm(
        title="§l§c " + target.name,
        content=(
            "§7Бан:    " + ban_status + "\n"
            "§7Мут:    " + mute_status + "\n"
            "§7Варны:  " + warn_color + str(warn_count)
        )
    )

    if admin.has_permission("admin.ban"):
        if ban:
            form.add_button("§a Разбанить",   on_click=lambda p: _unban_player(p, target, db, cfg))
        else:
            form.add_button("§c Бан",          on_click=lambda p: show_ban_form(p, target, db, cfg))

    if admin.has_permission("admin.mute"):
        if mute:
            form.add_button("§a Размутить",    on_click=lambda p: _unmute_player(p, target, db, cfg))
        else:
            form.add_button("§e Мут",          on_click=lambda p: show_mute_form(p, target, db, cfg))

    if admin.has_permission("admin.kick"):
        form.add_button("§6 Кик",              on_click=lambda p: show_kick_form(p, target, db, cfg))

    if admin.has_permission("admin.warn"):
        form.add_button("§e Варн",             on_click=lambda p: show_warn_form(p, target, db, cfg))
        if warn_count > 0:
            form.add_button("§7 Снять все варны", on_click=lambda p: show_clearwarns_confirm(p, target, db, cfg))

    if admin.has_permission("admin.punishments.view"):
        form.add_button("§8 История игрока",   on_click=lambda p: show_player_history(p, target, db, cfg))

    form.add_button("§7<- Назад",              on_click=lambda p: show_admin_main_menu(p, db, cfg))
    admin.send_form(form)


def show_ban_form(admin, target, db, cfg) -> None:
    default_reason = cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    allow_silent   = cfg.get("punishments", {}).get("allow_silent", True)

    form = ModalForm(title="§l§c Бан: " + target.name)
    form.add_control(TextInput(
        label="§7Причина бана (игрок: " + target.name + "):",
        placeholder=default_reason
    ))
    form.add_control(TextInput(
        label="§7Срок в минутах (0 = навсегда):",
        placeholder="0"
    ))
    if allow_silent:
        form.add_control(Toggle(label="§8 Тихое наказание", default_value=False))
    form.submit_button = "§cПрименить бан"

    def on_submit(p, data):
        reason = (str(data[0]) if data[0] is not None else "").strip() or default_reason
        digits = "".join(c for c in str(data[1] if data[1] is not None else "") if c.isdigit())
        duration = int(digits) if digits else 0
        silent = bool(data[2]) if allow_silent and len(data) > 2 else False

        db.ban_player(target.xuid, target.name, p.name, reason, duration, silent)
        dur_str = format_duration(duration)
        kick_msg = (
            cfg.get("ban", {}).get("permanent_message", "§cВы заблокированы навсегда.\n§7Причина: {reason}").format(reason=reason)
            if duration == 0
            else cfg.get("ban", {}).get("kick_message", "§cВы заблокированы на {duration}.\n§7Причина: {reason}").format(reason=reason, duration=dur_str)
        )
        target.kick(kick_msg)
        p.send_message(
            cfg.get("messages", {}).get("ban_notify_admin", "§c[БАН] §f{admin} §7-> §f{player} §7({reason}, {duration})").format(
                admin=p.name, player=target.name, reason=reason, duration=dur_str
            )
        )
        if silent:
            p.send_message(cfg.get("messages", {}).get("punishment_silent", "§8(тихое наказание)"))

    form.on_submit = on_submit
    admin.send_form(form)


def show_mute_form(admin, target, db, cfg) -> None:
    default_reason = cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    allow_silent   = cfg.get("punishments", {}).get("allow_silent", True)

    form = ModalForm(title="§l§e Мут: " + target.name)
    form.add_control(TextInput(
        label="§7Причина мута (игрок: " + target.name + "):",
        placeholder=default_reason
    ))
    form.add_control(TextInput(
        label="§7Срок в минутах (0 = навсегда):",
        placeholder="0"
    ))
    if allow_silent:
        form.add_control(Toggle(label="§8 Тихое наказание", default_value=False))
    form.submit_button = "§eПрименить мут"

    def on_submit(p, data):
        reason = (str(data[0]) if data[0] is not None else "").strip() or default_reason
        digits = "".join(c for c in str(data[1] if data[1] is not None else "") if c.isdigit())
        duration = int(digits) if digits else 0
        silent = bool(data[2]) if allow_silent and len(data) > 2 else False

        db.mute_player(target.xuid, target.name, p.name, reason, duration, silent)
        dur_str = format_duration(duration)
        if not silent:
            target.send_message(
                cfg.get("mute", {}).get("muted_message", "§cВы замолчены. Причина: {reason}. Осталось: {time_left}").format(
                    reason=reason, time_left=dur_str
                )
            )
        p.send_message(
            cfg.get("messages", {}).get("mute_notify_admin", "§e[МУТ] §f{admin} §7-> §f{player} §7({reason}, {duration})").format(
                admin=p.name, player=target.name, reason=reason, duration=dur_str
            )
        )
        if silent:
            p.send_message(cfg.get("messages", {}).get("punishment_silent", "§8(тихое наказание)"))

    form.on_submit = on_submit
    admin.send_form(form)


def show_kick_form(admin, target, db, cfg) -> None:
    default_reason = cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    allow_silent   = cfg.get("punishments", {}).get("allow_silent", True)

    form = ModalForm(title="§l§6 Кик: " + target.name)
    form.add_control(TextInput(
        label="§7Причина кика (игрок: " + target.name + "):",
        placeholder=default_reason
    ))
    if allow_silent:
        form.add_control(Toggle(label="§8 Тихое (без объявления)", default_value=False))
    form.submit_button = "§6Кикнуть"

    def on_submit(p, data):
        reason = (data[0] or "").strip() or default_reason
        silent = bool(data[1]) if allow_silent and len(data) > 1 else False
        db._log_punishment("kick", target.name, target.xuid, p.name, reason, 0, silent)
        target.kick(cfg.get("kick", {}).get("message", "§cВы кикнуты.\n§7Причина: {reason}").format(reason=reason))
        p.send_message(
            cfg.get("messages", {}).get("kick_notify_admin", "§6[КИК] §f{admin} §7-> §f{player} §7({reason})").format(
                admin=p.name, player=target.name, reason=reason
            )
        )
        if silent:
            p.send_message(cfg.get("messages", {}).get("punishment_silent", "§8(тихое наказание)"))

    form.on_submit = on_submit
    admin.send_form(form)


def show_warn_form(admin, target, db, cfg) -> None:
    default_reason = cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    allow_silent   = cfg.get("punishments", {}).get("allow_silent", True)
    kicks_at = cfg.get("warn", {}).get("kicks_at", 3)
    ban_at   = cfg.get("warn", {}).get("ban_at", 5)
    current  = db.get_warn_count(target.xuid)
    warn_color = "§c" if current >= kicks_at - 1 else "§e"

    form = ModalForm(title="§l§e Варн: " + target.name)
    form.add_control(TextInput(
        label=(
            "§7Игрок: §f" + target.name +
            "  §7Варнов: " + warn_color + str(current) +
            "  §7(кик: §c" + str(kicks_at) + "§7, бан: §c" + str(ban_at) + "§7)\n§7Причина:"
        ),
        placeholder=default_reason
    ))
    if allow_silent:
        form.add_control(Toggle(label="§8 Тихое (без уведомления игроку)", default_value=False))
    form.submit_button = "§eВыдать варн"

    def on_submit(p, data):
        reason = (data[0] or "").strip() or default_reason
        silent = bool(data[1]) if allow_silent and len(data) > 1 else False
        count  = db.warn_player(target.xuid, target.name, p.name, reason, silent)

        if not silent:
            target.send_message(
                cfg.get("warn", {}).get("message", "§e Предупреждение #{count}: {reason}").format(
                    reason=reason, count=count
                )
            )
        p.send_message(
            cfg.get("messages", {}).get("warn_notify_admin", "§e[ВАРН] §f{admin} §7-> §f{player} §7({reason}) [{count}]").format(
                admin=p.name, player=target.name, reason=reason, count=count
            )
        )
        if silent:
            p.send_message(cfg.get("messages", {}).get("punishment_silent", "§8(тихое наказание)"))

        if count >= ban_at:
            db.ban_player(target.xuid, target.name, "AutoAdmin", "Автобан за варны", 0, False)
            target.kick("§cАвтоматическая блокировка за " + str(count) + " предупреждений!")
            p.send_message("§c Автобан: §f" + target.name + " §cзаблокирован за превышение варнов!")
        elif count >= kicks_at:
            target.kick("§eВы кикнуты за " + str(count) + " предупреждений!")
            p.send_message("§e Автокик: §f" + target.name + " §eкикнут за предупреждения!")

    form.on_submit = on_submit
    admin.send_form(form)


def show_warns_info(admin, target, db, cfg) -> None:
    warns = db.get_warns(target.xuid)
    count = len(warns)
    warn_color = "§c" if count >= 3 else ("§e" if count >= 1 else "§a")

    form = ActionForm(
        title="§l§e Варны: " + target.name,
        content=(
            "§7Активных варнов: " + warn_color + str(count) + "\n"
            "§7Кик при: §c" + str(cfg.get("warn", {}).get("kicks_at", 3)) +
            "  §7Бан при: §c" + str(cfg.get("warn", {}).get("ban_at", 5))
        )
    )

    if warns:
        for i, w in enumerate(warns, 1):
            ts = format_timestamp(w["time"])
            form.add_button(
                "§e" + str(i) + ". §f" + w["reason"] + "\n§8by " + w["admin"] + "  " + ts
            )
    else:
        form.add_button("§8(нет варнов)")

    if count > 0 and admin.has_permission("admin.warn"):
        form.add_button("§c Снять все варны", on_click=lambda p: show_clearwarns_confirm(p, target, db, cfg))

    form.add_button("§7<- Назад", on_click=lambda p: show_player_action_menu(p, target, db, cfg))
    admin.send_form(form)


def show_clearwarns_confirm(admin, target, db, cfg) -> None:
    count = db.get_warn_count(target.xuid)
    form = MessageForm(
        title="§cСнять варны?",
        content=(
            "§7Вы хотите снять §e" + str(count) + " §7варн(ов) с игрока §f" + target.name + "§7?\n"
            "§8Это действие необратимо."
        ),
        button1="§cДа, снять",
        button2="§7Отмена"
    )

    def on_submit(p, result):
        if result:
            db.clear_warns(target.xuid)
            p.send_message("§aВарны игрока §f" + target.name + " §aсняты!")
            target.send_message("§aВаши предупреждения были сняты!")
            show_player_action_menu(p, target, db, cfg)

    form.on_submit = on_submit
    admin.send_form(form)


def show_banned_list(admin, db, cfg) -> None:
    bans = list(db._bans.items()) if hasattr(db, "_bans") else []

    form = ActionForm(
        title="§l§c Забаненные игроки",
        content="§7Всего забанено: §c" + str(len(bans))
    )

    if bans:
        for xuid, ban_data in bans[:20]:
            expire = format_time_left(ban_data.get("expire_at"))
            btn = "§c" + ban_data["player"] + "\n§7" + ban_data.get("reason", "?") + "  §8до: " + expire
            form.add_button(btn, on_click=lambda p, xid=xuid, bd=ban_data: _confirm_unban(p, xid, bd, db, cfg))
    else:
        form.add_button("§8(нет забаненных)")

    form.add_button("§7<- Главное меню", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    admin.send_form(form)


def show_unban_by_name(admin, target_name: str, db, cfg) -> None:
    found_xuid = None
    found_data = None
    if hasattr(db, "_bans"):
        for xuid, bd in db._bans.items():
            if bd["player"].lower() == target_name.lower():
                found_xuid = xuid
                found_data = bd
                break

    if not found_xuid:
        admin.send_message("§cБан для §f" + target_name + " §cне найден!")
        return

    _confirm_unban(admin, found_xuid, found_data, db, cfg)


def _confirm_unban(admin, xuid: str, ban_data: dict, db, cfg) -> None:
    form = MessageForm(
        title="§aРазбанить игрока?",
        content=(
            "§7Игрок: §f" + ban_data["player"] + "\n"
            "§7Причина бана: §c" + ban_data.get("reason", "?") + "\n"
            "§7Выдан: §f" + ban_data.get("admin", "?") + "\n\n"
            "§7Разбанить этого игрока?"
        ),
        button1="§aДа, разбанить",
        button2="§7Отмена"
    )

    def on_submit(p, result):
        if result:
            db.unban_player(xuid)
            p.send_message("§aИгрок §f" + ban_data["player"] + " §aразбанен!")

    form.on_submit = on_submit
    admin.send_form(form)


def _unban_player(admin, target, db, cfg) -> None:
    db.unban_player(target.xuid)
    admin.send_message("§aИгрок §f" + target.name + " §aразбанен!")
    show_player_action_menu(admin, target, db, cfg)


def _unmute_player(admin, target, db, cfg) -> None:
    db.unmute_player(target.xuid)
    admin.send_message("§aИгрок §f" + target.name + " §aразмучен!")
    target.send_message("§aВы были размучены!")
    show_player_action_menu(admin, target, db, cfg)


def show_punishment_logs(player, db, cfg, filter_type=None, filter_xuid=None) -> None:
    logs = db.get_punishments(xuid=filter_xuid, ptype=filter_type, limit=30)

    form = ActionForm(
        title="§l§e Отчёты наказаний",
        content="§7Показано: §f" + str(len(logs)) + " §7записей"
    )

    form.add_button("Только баны",  on_click=lambda p: show_punishment_logs(p, db, cfg, "ban"))
    form.add_button("Только муты",  on_click=lambda p: show_punishment_logs(p, db, cfg, "mute"))
    form.add_button("Только кики",  on_click=lambda p: show_punishment_logs(p, db, cfg, "kick"))
    form.add_button("Только варны", on_click=lambda p: show_punishment_logs(p, db, cfg, "warn"))
    if filter_type or filter_xuid:
        form.add_button("§7 Сбросить фильтр", on_click=lambda p: show_punishment_logs(p, db, cfg))

    if logs:
        for log in logs:
            color = punishment_color(log["type"])
            label = punishment_label(log["type"])
            dur_str = format_duration(log["duration_minutes"]) if log["type"] in ("ban", "mute") else ""
            silent_m = " §8[тихо]" if log.get("silent") else ""
            ts = format_timestamp(log["time"])
            btn = (
                color + "[" + label + "]" + silent_m + " §f" + log["player"] + "\n"
                "§7" + log["reason"]
                + ("  §8" + dur_str if dur_str else "")
                + "\n§8" + ts + " §7by §f" + log["admin"]
            )
            form.add_button(btn)
    else:
        form.add_button("§8(нет записей)")

    form.add_button("§7<- Главное меню", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    player.send_form(form)


def show_player_history(admin, target, db, cfg) -> None:
    logs  = db.get_punishments(xuid=target.xuid, limit=20)
    warns = db.get_warn_count(target.xuid)
    ban   = db.get_ban(target.xuid)
    mute  = db.get_mute(target.xuid)

    ban_info  = "§cДо: " + format_time_left(ban["expire_at"]  if ban  else None) if ban  else "§aНет"
    mute_info = "§eДо: " + format_time_left(mute["expire_at"] if mute else None) if mute else "§aНет"

    form = ActionForm(
        title="§l§7 История: " + target.name,
        content=(
            "§7Бан: " + ban_info + "\n"
            "§7Мут: " + mute_info + "\n"
            "§7Варнов: §e" + str(warns)
        )
    )

    if logs:
        for log in logs:
            color = punishment_color(log["type"])
            label = punishment_label(log["type"])
            dur_str = format_duration(log["duration_minutes"]) if log["type"] in ("ban", "mute") else ""
            ts = format_timestamp(log["time"])
            btn = (
                color + "[" + label + "] §f" + log["reason"]
                + ("  §8(" + dur_str + ")" if dur_str else "")
                + "\n§8" + ts + " by §7" + log["admin"]
            )
            form.add_button(btn)
    else:
        form.add_button("§8(нет истории)")

    form.add_button("§7<- Назад", on_click=lambda p: show_player_action_menu(p, target, db, cfg))
    admin.send_form(form)
