from __future__ import annotations

import time
from typing import Optional


def format_duration(minutes: int) -> str:
    if minutes == 0:
        return "Навсегда"
    if minutes < 60:
        return str(minutes) + " мин."
    hours = minutes // 60
    mins = minutes % 60
    if hours < 24:
        return (str(hours) + " ч. " + str(mins) + " мин.") if mins else (str(hours) + " ч.")
    days = hours // 24
    hrs = hours % 24
    return (str(days) + " д. " + str(hrs) + " ч.") if hrs else (str(days) + " д.")


def format_time_left(expire_at: Optional[float]) -> str:
    if expire_at is None:
        return "Навсегда"
    left = expire_at - time.time()
    if left <= 0:
        return "Истёк"
    minutes = int(left // 60)
    return format_duration(minutes if minutes > 0 else 1)


def format_timestamp(ts: float) -> str:
    import datetime
    dt = datetime.datetime.fromtimestamp(ts)
    return dt.strftime("%d.%m.%Y %H:%M")


def rating_stars(rating: Optional[int]) -> str:
    if rating is None:
        return "-"
    return "*" * rating + "o" * (5 - rating)


def truncate(text: str, max_len: int = 50) -> str:
    return text if len(text) <= max_len else text[:max_len - 3] + "..."


def status_icon(status: str) -> str:
    return "§a[+]" if status == "open" else "§8[-]"


def punishment_color(ptype: str) -> str:
    colors = {
        "ban":  "§c",
        "mute": "§e",
        "kick": "§6",
        "warn": "§e",
    }
    return colors.get(ptype, "§f")


def punishment_label(ptype: str) -> str:
    labels = {
        "ban":  "БАН",
        "mute": "МУТ",
        "kick": "КИК",
        "warn": "ВАРН",
    }
    return labels.get(ptype, ptype.upper())
