import os
from endstone.plugin import Plugin
from endstone.command import Command, CommandSender
from endstone.event import event_handler, PlayerChatEvent, PlayerJoinEvent, PlayerCommandEvent
from endstone import Player
import yaml

from .data_manager import DataManager
from .utils import format_duration, format_time_left, format_timestamp
from . import forms


class AdminPlugin(Plugin):
    api_version = "0.10"
    name = "admin_system"
    version = "1.0.0"
    description = "Система администрирования: жалобы, наказания, отчёты"
    authors = ["YourName"]

    permissions = {
        "admin.menu":             {"description": "Открыть главное меню администратора",  "default": "op"},
        "admin.reports.view":     {"description": "Просматривать все жалобы",             "default": "op"},
        "admin.reports.reply":    {"description": "Отвечать на жалобы игроков",           "default": "op"},
        "admin.reports.close":    {"description": "Закрывать жалобы",                     "default": "op"},
        "admin.punish":           {"description": "Доступ к меню управления игроками",    "default": "op"},
        "admin.ban":              {"description": "Банить/разбанивать игроков",           "default": "op"},
        "admin.mute":             {"description": "Мутить/размучивать игроков",           "default": "op"},
        "admin.kick":             {"description": "Кикать игроков",                       "default": "op"},
        "admin.warn":             {"description": "Выдавать/снимать варны",               "default": "op"},
        "admin.punishments.view": {"description": "Просматривать логи наказаний",         "default": "op"},
    }

    commands = {
        "admin":        {"description": "Панель администратора",           "usage": "/admin",               "permissions": ["admin.menu"]},
        "report":       {"description": "Открыть меню жалоб",             "usage": "/report [текст]",       "permissions": []},
        "reports":      {"description": "Просмотреть жалобы",             "usage": "/reports",              "permissions": []},
        "warn":         {"description": "Предупредить игрока",            "usage": "/warn [игрок]",         "permissions": ["admin.warn"]},
        "warns":        {"description": "Варны игрока",                   "usage": "/warns <игрок>",        "permissions": ["admin.punishments.view"]},
        "clearwarns":   {"description": "Снять варны с игрока",           "usage": "/clearwarns <игрок>",   "permissions": ["admin.warn"]},
        "punishments":  {"description": "Логи наказаний",                 "usage": "/punishments [игрок]",  "permissions": ["admin.punishments.view"]},
        "reportdialog": {"description": "Диалог жалобы",                  "usage": "/reportdialog <id>",    "permissions": []},
    }

    def on_enable(self) -> None:
        self._cfg = self._load_yaml_config()
        data_folder = os.path.join(self.data_folder, "data")
        self._db = DataManager(data_folder)
        self.register_events(self)
        self._start_auto_close_task()
        self.logger.info("§aendstone-admin загружен! v" + self.version)

    def on_disable(self) -> None:
        self.logger.info("§cendstone-admin выключен!")

    def _load_yaml_config(self) -> dict:
        config_path = os.path.join(self.data_folder, "config.yml")
        if not os.path.exists(config_path):
            os.makedirs(self.data_folder, exist_ok=True)
            default = os.path.join(os.path.dirname(__file__), "config.yml")
            if os.path.exists(default):
                import shutil
                shutil.copy(default, config_path)
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception as e:
            self.logger.warning("Ошибка config.yml: " + str(e))
            return {}

    def _start_auto_close_task(self) -> None:
        interval = self._cfg.get("reports", {}).get("check_interval_ticks", 1200)
        max_inactive = self._cfg.get("reports", {}).get("auto_close_seconds", 86400)

        def task():
            stale = self._db.get_stale_reports(max_inactive)
            for report in stale:
                self._db.close_report(report["id"])
                self.logger.info("Автозакрытие жалобы #" + str(report["id"]))
                target = self.server.get_player(report["player"])
                if target:
                    target.send_message("§8Жалоба §e#" + str(report["id"]) + " §8закрыта автоматически.")

        self.server.scheduler.run_task(self, task, delay=0, period=interval)

    @event_handler
    def on_player_chat(self, event: PlayerChatEvent) -> None:
        player = event.player
        mute = self._db.get_mute(player.xuid)
        if mute:
            event.cancelled = True
            msg = self._cfg.get("mute", {}).get(
                "muted_message",
                "§cВы замолчены. Причина: {reason}. Осталось: {time_left}"
            ).format(reason=mute["reason"], time_left=format_time_left(mute.get("expire_at")))
            player.send_message(msg)

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent) -> None:
        player = event.player
        if player.has_permission("admin.reports.view"):
            open_count = len(self._db.get_all_reports(status="open"))
            if open_count > 0:
                player.send_message(
                    "§e[Жалобы] §7Открытых: §a" + str(open_count) + " §7— /reports"
                )

    @event_handler
    def on_player_command(self, event: PlayerCommandEvent) -> None:
        raw = event.command.lstrip("/")
        parts = raw.split()
        if not parts:
            return
        cmd = parts[0].lower()
        if cmd not in ("ban", "unban", "mute", "unmute", "kick"):
            return

        event.cancel()
        player = event.player
        args = parts[1:]
        no_perm = self._cfg.get("messages", {}).get("no_permission", "§cНет прав!")
        not_found = self._cfg.get("messages", {}).get("player_not_found", "§cИгрок не найден!")

        if cmd == "ban":
            if not player.has_permission("admin.ban"):
                player.send_message(no_perm); return
            if not args:
                forms.show_player_list_for_action(player, self._db, self._cfg, self.server, "ban"); return
            target = self.server.get_player(args[0])
            if not target:
                player.send_message(not_found); return
            forms.show_ban_form(player, target, self._db, self._cfg)

        elif cmd == "unban":
            if not player.has_permission("admin.ban"):
                player.send_message(no_perm); return
            if not args:
                forms.show_banned_list(player, self._db, self._cfg); return
            forms.show_unban_by_name(player, args[0], self._db, self._cfg)

        elif cmd == "mute":
            if not player.has_permission("admin.mute"):
                player.send_message(no_perm); return
            if not args:
                forms.show_player_list_for_action(player, self._db, self._cfg, self.server, "mute"); return
            target = self.server.get_player(args[0])
            if not target:
                player.send_message(not_found); return
            forms.show_mute_form(player, target, self._db, self._cfg)

        elif cmd == "unmute":
            if not player.has_permission("admin.mute"):
                player.send_message(no_perm); return
            if not args:
                player.send_message("§cИспользование: /unmute <игрок>"); return
            target = self.server.get_player(args[0])
            if not target:
                player.send_message(not_found); return
            if self._db.unmute_player(target.xuid):
                player.send_message("§aИгрок §f" + target.name + " §aразмучен!")
                target.send_message("§aВы были размучены!")
            else:
                player.send_message("§c" + target.name + " §cне замолчен!")

        elif cmd == "kick":
            if not player.has_permission("admin.kick"):
                player.send_message(no_perm); return
            if not args:
                forms.show_player_list_for_action(player, self._db, self._cfg, self.server, "kick"); return
            target = self.server.get_player(args[0])
            if not target:
                player.send_message(not_found); return
            forms.show_kick_form(player, target, self._db, self._cfg)

    def on_command(self, sender: CommandSender, command: Command, args: list) -> bool:
        cmd = command.name.lower()
        no_perm = self._cfg.get("messages", {}).get("no_permission", "§cНет прав!")
        not_found = self._cfg.get("messages", {}).get("player_not_found", "§cИгрок не найден!")

        if cmd == "admin":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!"); return True
            forms.show_admin_main_menu(sender, self._db, self._cfg)
            return True

        if cmd == "report":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!"); return True
            if args:
                text = " ".join(args)
                max_len = self._cfg.get("reports", {}).get("max_length", 500)
                if len(text) > max_len:
                    sender.send_message("§cТекст слишком длинный!"); return True
                report_id = self._db.create_report(sender.name, sender.xuid, text)
                sender.send_message(
                    self._cfg.get("messages", {}).get("report_submitted", "§aЖалоба §e#{id} §aотправлена!").format(id=report_id)
                )
                self._notify_admins_new_report(report_id, sender.name, text)
            else:
                forms.show_report_menu(sender, self._db, self._cfg)
            return True

        if cmd == "reports":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!"); return True
            if sender.has_permission("admin.reports.view"):
                forms.show_admin_reports_menu(sender, self._db, self._cfg)
            else:
                forms.show_report_menu(sender, self._db, self._cfg)
            return True

        if cmd == "reportdialog":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!"); return True
            if not args:
                sender.send_message("§cИспользование: /reportdialog <id>"); return True
            try:
                forms.show_report_dialog(sender, int(args[0]), self._db, self._cfg)
            except ValueError:
                sender.send_message("§cID должен быть числом!")
            return True

        if cmd == "punishments":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!"); return True
            if args:
                target = self.server.get_player(args[0])
                if not target:
                    sender.send_message(not_found); return True
                forms.show_player_history(sender, target, self._db, self._cfg)
            else:
                forms.show_punishment_logs(sender, self._db, self._cfg)
            return True

        if cmd == "warn":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!"); return True
            if not args:
                forms.show_player_list_for_action(sender, self._db, self._cfg, self.server, "warn")
                return True
            target = self.server.get_player(args[0])
            if not target:
                sender.send_message(not_found); return True
            forms.show_warn_form(sender, target, self._db, self._cfg)
            return True

        if cmd == "warns":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!"); return True
            if not args:
                sender.send_message("§cИспользование: /warns <игрок>"); return True
            target = self.server.get_player(args[0])
            if not target:
                sender.send_message(not_found); return True
            forms.show_warns_info(sender, target, self._db, self._cfg)
            return True

        if cmd == "clearwarns":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!"); return True
            if not args:
                sender.send_message("§cИспользование: /clearwarns <игрок>"); return True
            target = self.server.get_player(args[0])
            if not target:
                sender.send_message(not_found); return True
            forms.show_clearwarns_confirm(sender, target, self._db, self._cfg)
            return True

        return False

    def _notify_admins_new_report(self, report_id: int, player_name: str, text: str) -> None:
        msg = self._cfg.get("messages", {}).get(
            "report_new_notify", "§e[Жалоба] §7#{id} от §f{player}: §7{text}"
        ).format(id=report_id, player=player_name, text=text[:50] + ("..." if len(text) > 50 else ""))
        for p in self.server.online_players:
            if p.has_permission("admin.reports.view"):
                p.send_message(msg)
