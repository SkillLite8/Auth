from .admin_plugin import AdminPlugin

__all__ = ["AdminPlugin"]
