"""
endstone-admin | admin_plugin.py
Главный файл плагина — AdminPlugin
"""

from __future__ import annotations

import os
import time
from typing import Optional

import yaml

from endstone.plugin import Plugin
from endstone.command import Command, CommandSender
from endstone.event import event_handler, PlayerChatEvent, PlayerJoinEvent
from endstone import Player

from .data_manager import DataManager
from .utils import format_duration, format_time_left, format_timestamp
from . import forms


class AdminPlugin(Plugin):
    api_version = "0.10"

    name = "admin_system"
    version = "1.0.0"
    description = "Система администрирования: жалобы, наказания, отчёты"
    authors = ["YourName"]

    # ─── Разрешения плагина ──────────────────────────────────
    permissions = {
        "admin.menu":             {"description": "Открыть главное меню администратора",    "default": "op"},
        "admin.reports.view":     {"description": "Просматривать все жалобы",               "default": "op"},
        "admin.reports.reply":    {"description": "Отвечать на жалобы игроков",             "default": "op"},
        "admin.reports.close":    {"description": "Закрывать жалобы",                       "default": "op"},
        "admin.punish":           {"description": "Доступ к меню управления игроками",      "default": "op"},
        "admin.ban":              {"description": "Банить/разбанивать игроков",             "default": "op"},
        "admin.mute":             {"description": "Мутить/размучивать игроков",             "default": "op"},
        "admin.kick":             {"description": "Кикать игроков",                         "default": "op"},
        "admin.warn":             {"description": "Выдавать/снимать варны",                 "default": "op"},
        "admin.punishments.view": {"description": "Просматривать логи наказаний",           "default": "op"},
    }

    # ─── Команды ─────────────────────────────────────────────
    commands = {
        # Главное меню
        "admin": {
            "description": "Открыть панель администратора",
            "usage": "/admin",
            "permissions": ["admin.menu"],
        },
        # Быстрые команды игрока
        "report": {
            "description": "Открыть меню жалоб",
            "usage": "/report [текст]",
            "permissions": [],  # Доступно всем
        },
        "reports": {
            "description": "Просмотреть жалобы (для админов — все, для игроков — свои)",
            "usage": "/reports",
            "permissions": [],
        },
        # Быстрые команды наказаний (для консоли и опытных админов)
        "ban": {
            "description": "Заблокировать игрока",
            "usage": "/ban <игрок> [минуты] [причина]",
            "permissions": ["admin.ban"],
        },
        "unban": {
            "description": "Разблокировать игрока",
            "usage": "/unban <игрок>",
            "permissions": ["admin.ban"],
        },
        "mute": {
            "description": "Замолчить игрока",
            "usage": "/mute <игрок> [минуты] [причина]",
            "permissions": ["admin.mute"],
        },
        "unmute": {
            "description": "Размутить игрока",
            "usage": "/unmute <игрок>",
            "permissions": ["admin.mute"],
        },
        "kick": {
            "description": "Выгнать игрока",
            "usage": "/kick <игрок> [причина]",
            "permissions": ["admin.kick"],
        },
        "warn": {
            "description": "Предупредить игрока",
            "usage": "/warn <игрок> [причина]",
            "permissions": ["admin.warn"],
        },
        "warns": {
            "description": "Посмотреть варны игрока",
            "usage": "/warns <игрок>",
            "permissions": ["admin.punishments.view"],
        },
        "clearwarns": {
            "description": "Снять все варны с игрока",
            "usage": "/clearwarns <игрок>",
            "permissions": ["admin.warn"],
        },
        "punishments": {
            "description": "Открыть отчёты наказаний",
            "usage": "/punishments [игрок]",
            "permissions": ["admin.punishments.view"],
        },
        # Диалог с конкретной жалобой
        "reportdialog": {
            "description": "Открыть диалог жалобы по ID",
            "usage": "/reportdialog <id>",
            "permissions": [],
        },
    }

    # ════════════════════════════════════════════════════════
    #   Инициализация
    # ════════════════════════════════════════════════════════

    def on_enable(self) -> None:
        self.save_default_config()
        self.reload_config()
        self._cfg = self._load_yaml_config()

        data_folder = os.path.join(self.data_folder, "data")
        self._db = DataManager(data_folder)

        self.register_events(self)
        self._start_auto_close_task()

        self.logger.info("§aendstone-admin загружен!")
        self.logger.info(f"§7Версия: {self.version}")

    def on_disable(self) -> None:
        self.logger.info("§cendstone-admin выключен!")

    def _load_yaml_config(self) -> dict:
        """Загружает config.yml из папки плагина."""
        config_path = os.path.join(self.data_folder, "config.yml")
        if not os.path.exists(config_path):
            # Копируем дефолтный конфиг
            default = os.path.join(os.path.dirname(__file__), "config.yml")
            if os.path.exists(default):
                import shutil
                shutil.copy(default, config_path)
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception as e:
            self.logger.warning(f"Ошибка загрузки config.yml: {e}")
            return {}

    # ════════════════════════════════════════════════════════
    #   Планировщик: автозакрытие жалоб
    # ════════════════════════════════════════════════════════

    def _start_auto_close_task(self) -> None:
        interval = self._cfg.get("reports", {}).get("check_interval_ticks", 1200)
        max_inactive = self._cfg.get("reports", {}).get("auto_close_seconds", 86400)

        def task():
            stale = self._db.get_stale_reports(max_inactive)
            for report in stale:
                self._db.close_report(report["id"])
                msg = self._cfg["messages"]["report_closed_auto"].format(id=report["id"])
                self.logger.info(f"Автозакрытие жалобы #{report['id']}")
                # Уведомляем игрока если он онлайн
                target = self.server.get_player(report["player"])
                if target:
                    target.send_message(msg)

        self.server.scheduler.run_task_timer(self, task, 0, interval)

    # ════════════════════════════════════════════════════════
    #   Обработчики событий
    # ════════════════════════════════════════════════════════

    @event_handler
    def on_player_chat(self, event: PlayerChatEvent) -> None:
        """Блокируем сообщения замолченных игроков."""
        player = event.player
        mute = self._db.get_mute(player.xuid)
        if mute:
            event.cancelled = True
            msg = self._cfg["mute"]["muted_message"].format(
                reason=mute["reason"],
                time_left=format_time_left(mute.get("expire_at"))
            )
            player.send_message(msg)

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent) -> None:
        """Уведомляем администраторов о новых жалобах при входе."""
        player = event.player
        if player.has_permission("admin.reports.view"):
            open_count = len(self._db.get_all_reports(status="open"))
            if open_count > 0:
                player.send_message(
                    f"§e[Жалобы] §7Открытых жалоб: §a{open_count} §7— используйте §f/reports"
                )

    # ════════════════════════════════════════════════════════
    #   Обработка команд
    # ════════════════════════════════════════════════════════

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        cmd = command.name.lower()
        no_perm = self._cfg.get("messages", {}).get("no_permission", "§cНет прав!")
        not_found = self._cfg.get("messages", {}).get("player_not_found", "§cИгрок не найден!")

        # ── /admin ─────────────────────────────────────────
        if cmd == "admin":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!")
                return True
            forms.show_admin_main_menu(sender, self._db, self._cfg)
            return True

        # ── /report [текст] ────────────────────────────────
        if cmd == "report":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!")
                return True
            if args:
                # Быстрая жалоба через команду
                text = " ".join(args)
                max_len = self._cfg.get("reports", {}).get("max_length", 500)
                if len(text) > max_len:
                    sender.send_message(f"§cТекст слишком длинный! Максимум {max_len} символов.")
                    return True
                report_id = self._db.create_report(sender.name, sender.xuid, text)
                msg = self._cfg["messages"]["report_submitted"].format(id=report_id)
                sender.send_message(msg)
                self._notify_admins_new_report(report_id, sender.name, text)
            else:
                forms.show_report_menu(sender, self._db, self._cfg)
            return True

        # ── /reports ───────────────────────────────────────
        if cmd == "reports":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!")
                return True
            if sender.has_permission("admin.reports.view"):
                forms.show_admin_reports_menu(sender, self._db, self._cfg)
            else:
                forms.show_report_menu(sender, self._db, self._cfg)
            return True

        # ── /reportdialog <id> ─────────────────────────────
        if cmd == "reportdialog":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!")
                return True
            if not args:
                sender.send_message("§cИспользование: /reportdialog <id>")
                return True
            try:
                report_id = int(args[0])
            except ValueError:
                sender.send_message("§cID должен быть числом!")
                return True
            forms.show_report_dialog(sender, report_id, self._db, self._cfg)
            return True

        # ── /punishments [игрок] ───────────────────────────
        if cmd == "punishments":
            if not isinstance(sender, Player):
                sender.send_message("§cТолько для игроков!")
                return True
            if args:
                target = self.server.get_player(args[0])
                if not target:
                    sender.send_message(not_found)
                    return True
                forms.show_player_history(sender, target, self._db, self._cfg)
            else:
                forms.show_punishment_logs(sender, self._db, self._cfg)
            return True

        # ── /ban <игрок> [мин] [причина] ──────────────────
        if cmd == "ban":
            if not args:
                sender.send_message("§cИспользование: /ban <игрок> [минуты] [причина]")
                return True
            target = self.server.get_player(args[0])
            if not target:
                sender.send_message(not_found)
                return True
            duration = 0
            reason = self._cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
            if len(args) >= 2:
                try:
                    duration = int(args[1])
                    reason = " ".join(args[2:]) if len(args) > 2 else reason
                except ValueError:
                    reason = " ".join(args[1:])
            admin_name = sender.name if isinstance(sender, Player) else "Console"
            self._db.ban_player(target.xuid, target.name, admin_name, reason, duration, False)
            dur_str = format_duration(duration)
            kick_msg = (
                self._cfg["ban"]["permanent_message"].format(reason=reason)
                if duration == 0
                else self._cfg["ban"]["kick_message"].format(reason=reason, duration=dur_str)
            )
            target.kick(kick_msg)
            sender.send_message(
                self._cfg["messages"]["ban_notify_admin"].format(
                    admin=admin_name, player=target.name, reason=reason, duration=dur_str
                )
            )
            return True

        # ── /unban <игрок/xuid> ────────────────────────────
        if cmd == "unban":
            if not args:
                sender.send_message("§cИспользование: /unban <игрок>")
                return True
            # Ищем по имени среди забаненных
            target_name = args[0]
            unbanned = False
            for xuid, ban_data in list(self._db._bans.items()):
                if ban_data["player"].lower() == target_name.lower():
                    self._db.unban_player(xuid)
                    sender.send_message(f"§aИгрок §f{ban_data['player']} §aразбанен!")
                    unbanned = True
                    break
            if not unbanned:
                sender.send_message(f"§cБан для §f{target_name} §cне найден!")
            return True

        # ── /mute <игрок> [мин] [причина] ─────────────────
        if cmd == "mute":
            if not args:
                sender.send_message("§cИспользование: /mute <игрок> [минуты] [причина]")
                return True
            target = self.server.get_player(args[0])
            if not target:
                sender.send_message(not_found)
                return True
            duration = 0
            reason = self._cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
            if len(args) >= 2:
                try:
                    duration = int(args[1])
                    reason = " ".join(args[2:]) if len(args) > 2 else reason
                except ValueError:
                    reason = " ".join(args[1:])
            admin_name = sender.name if isinstance(sender, Player) else "Console"
            self._db.mute_player(target.xuid, target.name, admin_name, reason, duration, False)
            dur_str = format_duration(duration)
            target.send_message(
                self._cfg["mute"]["muted_message"].format(reason=reason, time_left=dur_str)
            )
            sender.send_message(
                self._cfg["messages"]["mute_notify_admin"].format(
                    admin=admin_name, player=target.name, reason=reason, duration=dur_str
                )
            )
            return True

        # ── /unmute <игрок> ────────────────────────────────
        if cmd == "unmute":
            if not args:
                sender.send_message("§cИспользование: /unmute <игрок>")
                return True
            target = self.server.get_player(args[0])
            if not target:
                sender.send_message(not_found)
                return True
            if self._db.unmute_player(target.xuid):
                sender.send_message(f"§aИгрок §f{target.name} §aразмучен!")
                target.send_message("§aВы были размучены!")
            else:
                sender.send_message(f"§c{target.name} §cне замолчен!")
            return True

        # ── /kick <игрок> [причина] ────────────────────────
        if cmd == "kick":
            if not args:
                sender.send_message("§cИспользование: /kick <игрок> [причина]")
                return True
            target = self.server.get_player(args[0])
            if not target:
                sender.send_message(not_found)
                return True
            reason = " ".join(args[1:]) if len(args) > 1 else self._cfg["punishments"]["default_reason"]
            admin_name = sender.name if isinstance(sender, Player) else "Console"
            self._db._log_punishment("kick", target.name, target.xuid, admin_name, reason, 0, False)
            target.kick(self._cfg["kick"]["message"].format(reason=reason))
            sender.send_message(
                self._cfg["messages"]["kick_notify_admin"].format(
                    admin=admin_name, player=target.name, reason=reason
                )
            )
            return True

        # ── /warn <игрок> [причина] ────────────────────────
        if cmd == "warn":
            if not args:
                sender.send_message("§cИспользование: /warn <игрок> [причина]")
                return True
            target = self.server.get_player(args[0])
            if not target:
                sender.send_message(not_found)
                return True
            reason = " ".join(args[1:]) if len(args) > 1 else self._cfg["punishments"]["default_reason"]
            admin_name = sender.name if isinstance(sender, Player) else "Console"
            count = self._db.warn_player(target.xuid, target.name, admin_name, reason, False)
            target.send_message(
                self._cfg["warn"]["message"].format(reason=reason, count=count)
            )
            sender.send_message(
                self._cfg["messages"]["warn_notify_admin"].format(
                    admin=admin_name, player=target.name, reason=reason, count=count
                )
            )
            return True

        # ── /warns <игрок> ─────────────────────────────────
        if cmd == "warns":
            if not args:
                sender.send_message("§cИспользование: /warns <игрок>")
                return True
            target = self.server.get_player(args[0])
            if not target:
                sender.send_message(not_found)
                return True
            warns = self._db.get_warns(target.xuid)
            if not warns:
                sender.send_message(f"§7У игрока §f{target.name} §7нет варнов.")
                return True
            sender.send_message(f"§e⚠ Варны игрока §f{target.name} §e({len(warns)}):")
            for i, w in enumerate(warns, 1):
                ts = format_timestamp(w["time"])
                sender.send_message(f"§8{i}. §f{w['reason']} §8| by §7{w['admin']} §8| {ts}")
            return True

        # ── /clearwarns <игрок> ────────────────────────────
        if cmd == "clearwarns":
            if not args:
                sender.send_message("§cИспользование: /clearwarns <игрок>")
                return True
            target = self.server.get_player(args[0])
            if not target:
                sender.send_message(not_found)
                return True
            self._db.clear_warns(target.xuid)
            sender.send_message(f"§aВарны игрока §f{target.name} §aсняты!")
            target.send_message("§aВаши предупреждения были сняты!")
            return True

        return False

    # ════════════════════════════════════════════════════════
    #   Вспомогательные методы
    # ════════════════════════════════════════════════════════

    def _notify_admins_new_report(self, report_id: int, player_name: str, text: str) -> None:
        """Оповещает всех онлайн-администраторов о новой жалобе."""
        msg = self._cfg["messages"]["report_new_notify"].format(
            id=report_id,
            player=player_name,
            text=text[:50] + ("..." if len(text) > 50 else "")
        )
        for p in self.server.online_players:
            if p.has_permission("admin.reports.view"):
                p.send_message(msg)
