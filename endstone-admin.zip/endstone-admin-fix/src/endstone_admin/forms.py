"""
endstone-admin | forms.py
Все формы плагина: жалобы, наказания, отчёты
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Callable, Optional

from endstone.form import ActionForm, ModalForm, MessageForm, TextInput, Toggle, Dropdown, Label

from .utils import (
    format_duration, format_time_left, format_timestamp,
    rating_stars, truncate, status_icon, punishment_color, punishment_label
)

if TYPE_CHECKING:
    from endstone import Player
    from .data_manager import DataManager


# ════════════════════════════════════════════════════════════
#   ЖАЛОБЫ — Меню для игроков
# ════════════════════════════════════════════════════════════

def show_report_menu(player: "Player", db: "DataManager", cfg: dict) -> None:
    """Главное меню жалоб для игрока."""
    open_reports = db.get_player_reports(player.xuid, status="open")
    closed_reports = db.get_player_reports(player.xuid, status="closed")

    content = (
        f"§7Открытые жалобы: §a{len(open_reports)}\n"
        f"§7Закрытые жалобы: §8{len(closed_reports)}"
    )

    form = ActionForm(
        title="§l§9📋 Система жалоб",
        content=content
    )
    form.add_button("§a✉ Написать новую жалобу", on_click=lambda p: show_create_report_form(p, db, cfg))

    for r in open_reports[:5]:
        preview = truncate(r["text"], 35)
        btn_text = f"§e#{r['id']} §f{preview}\n§7{format_timestamp(r['created_at'])} §a[Открыта]"
        form.add_button(btn_text, on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg))

    for r in closed_reports[:5]:
        preview = truncate(r["text"], 35)
        stars = rating_stars(r.get("rating"))
        btn_text = f"§8#{r['id']} §7{preview}\n§7{format_timestamp(r['created_at'])} §8[Закрыта] {stars}"
        form.add_button(btn_text, on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg))

    player.send_form(form)


def show_create_report_form(player: "Player", db: "DataManager", cfg: dict) -> None:
    """Форма создания новой жалобы."""
    open_count = len(db.get_player_reports(player.xuid, status="open"))
    max_open = cfg.get("reports", {}).get("max_open_per_player", 3)

    if open_count >= max_open:
        form = MessageForm(
            title="§c⚠ Лимит жалоб",
            content=f"§7У вас уже §e{open_count} §7открытых жалоб.\n§7Дождитесь ответа администратора.",
            button1="§aПонятно",
            button2="§7Назад"
        )
        player.send_form(form)
        return

    max_len = cfg.get("reports", {}).get("max_length", 500)
    form = ModalForm(title="§l§9✉ Новая жалоба")
    form.add_control(TextInput(
        label=f"§7Опишите вашу проблему (макс. {max_len} символов):",
        placeholder="Введите текст жалобы...",
    ))
    form.submit_button = "§aОтправить жалобу"

    def on_submit(p, data):
        text = data[0].strip() if data and data[0] else ""
        if not text:
            p.send_message("§cТекст жалобы не может быть пустым!")
            return
        if len(text) > max_len:
            p.send_message(f"§cТекст слишком длинный! Максимум {max_len} символов.")
            return
        report_id = db.create_report(p.name, p.xuid, text)
        msg = cfg["messages"]["report_submitted"].format(id=report_id)
        p.send_message(msg)

    form.on_submit = on_submit
    player.send_form(form)


def show_report_dialog(player: "Player", report_id: int, db: "DataManager", cfg: dict) -> None:
    """Диалог жалобы — история сообщений + возможность ответить."""
    report = db.get_report(report_id)
    if not report:
        player.send_message("§cЖалоба не найдена!")
        return

    # Проверяем права: владелец или отменён
    is_owner = report["player_xuid"] == player.xuid
    is_admin = player.has_permission("admin.reports.reply")

    if not is_owner and not is_admin:
        player.send_message(cfg["messages"]["no_permission"])
        return

    # Строим историю сообщений
    history_lines = []
    for msg in report["messages"]:
        role_color = "§a" if msg["role"] == "admin" else "§7"
        ts = format_timestamp(msg["time"])
        history_lines.append(f"{role_color}[{msg['from']}] §f{msg['text']}\n§8{ts}")

    history_text = "\n\n".join(history_lines) if history_lines else "§8(нет сообщений)"
    status_str = "§aОткрыта" if report["status"] == "open" else "§8Закрыта"

    form = ActionForm(
        title=f"§l§9Жалоба #{report_id}",
        content=(
            f"§7Статус: {status_str}\n"
            f"§7Создана: §f{format_timestamp(report['created_at'])}\n"
            f"§7Оценка: §f{rating_stars(report.get('rating'))}\n\n"
            f"§7─── История ───\n{history_text}"
        )
    )

    if report["status"] == "open":
        if is_owner:
            form.add_button("§e💬 Написать ответ", on_click=lambda p: _reply_form(p, report_id, "player", db, cfg))
        if is_admin:
            form.add_button("§a💬 Ответить игроку", on_click=lambda p: _reply_form(p, report_id, "admin", db, cfg))
            form.add_button("§c✕ Закрыть жалобу", on_click=lambda p: _confirm_close_report(p, report_id, db, cfg))

    # Оценка — только если закрыта и владелец, и ещё не оценена
    if report["status"] == "closed" and is_owner and report.get("rating") is None:
        form.add_button("§e⭐ Оценить ответ", on_click=lambda p: show_rate_report_form(p, report_id, db))

    form.add_button("§7← Назад", on_click=lambda p: show_report_menu(p, db, cfg))
    player.send_form(form)


def _reply_form(player: "Player", report_id: int, role: str, db: "DataManager", cfg: dict) -> None:
    """Форма ввода ответного сообщения."""
    form = ModalForm(title=f"§l§9Ответ на жалобу #{report_id}")
    form.add_control(TextInput(
        label="§7Введите ваш ответ:",
        placeholder="Текст сообщения..."
    ))
    form.submit_button = "§aОтправить"

    def on_submit(p, data):
        text = data[0].strip() if data and data[0] else ""
        if not text:
            p.send_message("§cСообщение не может быть пустым!")
            return
        db.add_report_message(report_id, p.name, role, text)
        p.send_message(f"§aОтвет на жалобу #{report_id} отправлен!")

        report = db.get_report(report_id)
        if not report:
            return

        # Уведомление
        notify_msg_key = "report_reply_notify" if role == "admin" else "report_new_notify"
        notify_msg = cfg["messages"].get(notify_msg_key, "").format(
            id=report_id, admin=p.name, player=p.name, text=text
        )

        # Нужно оповестить другую сторону — это делает основной плагин через колбэк
        # Здесь мы возвращаем данные через флаг в report
        report["_notify"] = {"role": role, "sender": p.name, "text": text, "msg": notify_msg}
        show_report_dialog(p, report_id, db, cfg)

    form.on_submit = on_submit
    player.send_form(form)


def _confirm_close_report(player: "Player", report_id: int, db: "DataManager", cfg: dict) -> None:
    form = MessageForm(
        title="§cЗакрыть жалобу?",
        content=f"§7Вы уверены, что хотите закрыть жалобу §e#{report_id}§7?\nИгрок сможет оставить оценку.",
        button1="§cДа, закрыть",
        button2="§7Отмена"
    )

    def on_submit(p, result):
        if result:  # button1
            db.close_report(report_id)
            report = db.get_report(report_id)
            msg = cfg["messages"]["report_closed_manual"].format(id=report_id, admin=p.name)
            p.send_message(msg)
            if report:
                report["_close_notify"] = {"admin": p.name, "msg": msg}
            show_admin_reports_menu(p, db, cfg)

    form.on_submit = on_submit
    player.send_form(form)


def show_rate_report_form(player: "Player", report_id: int, db: "DataManager") -> None:
    """Форма оценки работы администратора."""
    form = ModalForm(title=f"§l§e⭐ Оценка жалобы #{report_id}")
    form.add_control(Dropdown(
        label="§7Оцените работу администратора:",
        options=["⭐ 1 — Ужасно", "⭐⭐ 2 — Плохо", "⭐⭐⭐ 3 — Нормально",
                 "⭐⭐⭐⭐ 4 — Хорошо", "⭐⭐⭐⭐⭐ 5 — Отлично"],
        default_index=4
    ))
    form.submit_button = "§aОставить оценку"

    def on_submit(p, data):
        rating = (data[0] or 0) + 1  # dropdown index 0-4 → 1-5
        db.rate_report(report_id, rating)
        p.send_message(f"§aСпасибо за оценку! {rating_stars(rating)}")

    form.on_submit = on_submit
    player.send_form(form)


# ════════════════════════════════════════════════════════════
#   ЖАЛОБЫ — Меню для администраторов
# ════════════════════════════════════════════════════════════

def show_admin_reports_menu(player: "Player", db: "DataManager", cfg: dict) -> None:
    """Список всех жалоб для администраторов."""
    open_reports = db.get_all_reports(status="open")
    closed_reports = db.get_all_reports(status="closed")

    form = ActionForm(
        title="§l§9📋 Отчёты жалоб [Админ]",
        content=(
            f"§7Открытые: §a{len(open_reports)} §8| §7Закрытые: §8{len(closed_reports)}"
        )
    )

    if open_reports:
        for r in open_reports[:10]:
            preview = truncate(r["text"], 30)
            btn = f"§a#{r['id']} §f{r['player']}\n§7{preview}"
            form.add_button(btn, on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg))
    else:
        form.add_button("§8(нет открытых жалоб)")

    form.add_button("§7📂 Закрытые жалобы", on_click=lambda p: _show_closed_reports(p, db, cfg))
    form.add_button("§7← Главное меню", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    player.send_form(form)


def _show_closed_reports(player: "Player", db: "DataManager", cfg: dict) -> None:
    closed = db.get_all_reports(status="closed")
    form = ActionForm(
        title="§l§8📂 Закрытые жалобы",
        content=f"§7Всего закрытых: §8{len(closed)}"
    )
    for r in closed[:15]:
        preview = truncate(r["text"], 30)
        stars = rating_stars(r.get("rating"))
        btn = f"§8#{r['id']} §7{r['player']} {stars}\n§8{preview}"
        form.add_button(btn, on_click=lambda p, rid=r["id"]: show_report_dialog(p, rid, db, cfg))

    if not closed:
        form.add_button("§8(нет закрытых жалоб)")

    form.add_button("§7← Назад", on_click=lambda p: show_admin_reports_menu(p, db, cfg))
    player.send_form(form)


# ════════════════════════════════════════════════════════════
#   ГЛАВНОЕ АДМИН-МЕНЮ
# ════════════════════════════════════════════════════════════

def show_admin_main_menu(player: "Player", db: "DataManager", cfg: dict) -> None:
    """Главное меню администратора."""
    form = ActionForm(
        title="§l§c⚙ Панель администратора",
        content="§7Выберите действие:"
    )

    if player.has_permission("admin.reports.view"):
        open_count = len(db.get_all_reports(status="open"))
        label = f"§9📋 Жалобы §8[§a{open_count}§8]" if open_count > 0 else "§9📋 Жалобы"
        form.add_button(label, on_click=lambda p: show_admin_reports_menu(p, db, cfg))

    if player.has_permission("admin.punish"):
        form.add_button("§c👥 Управление игроками", on_click=lambda p: show_player_list_menu(p, db, cfg))

    if player.has_permission("admin.punishments.view"):
        form.add_button("§e📊 Отчёты наказаний", on_click=lambda p: show_punishment_logs(p, db, cfg))

    player.send_form(form)


# ════════════════════════════════════════════════════════════
#   УПРАВЛЕНИЕ ИГРОКАМИ
# ════════════════════════════════════════════════════════════

def show_player_list_menu(player: "Player", db: "DataManager", cfg: dict,
                          server=None) -> None:
    """Список онлайн-игроков для выбора."""
    form = ActionForm(
        title="§l§c👥 Выбор игрока",
        content="§7Нажмите на игрока для управления:"
    )
    if server:
        players = list(server.online_players)
        for p in players:
            ban_mark = " §c[БАН]" if db.is_banned(p.xuid) else ""
            mute_mark = " §e[МУТ]" if db.is_muted(p.xuid) else ""
            warn_count = db.get_warn_count(p.xuid)
            warn_mark = f" §6[{warn_count}⚠]" if warn_count > 0 else ""
            form.add_button(
                f"§f{p.name}{ban_mark}{mute_mark}{warn_mark}",
                on_click=lambda adm, target=p: show_player_action_menu(adm, target, db, cfg)
            )
    else:
        form.add_button("§8(игроки не найдены)")

    form.add_button("§7← Назад", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    player.send_form(form)


def show_player_action_menu(admin: "Player", target: "Player",
                             db: "DataManager", cfg: dict) -> None:
    """Меню действий над конкретным игроком."""
    warn_count = db.get_warn_count(target.xuid)
    ban = db.get_ban(target.xuid)
    mute = db.get_mute(target.xuid)

    ban_status = f"§cАктивен до {format_time_left(ban['expire_at'] if ban else None)}" if ban else "§aНет"
    mute_status = f"§eАктивен до {format_time_left(mute['expire_at'] if mute else None)}" if mute else "§aНет"

    form = ActionForm(
        title=f"§l§c⚙ {target.name}",
        content=(
            f"§7Бан: {ban_status}\n"
            f"§7Мут: {mute_status}\n"
            f"§7Варнов: §e{warn_count}\n"
        )
    )

    if admin.has_permission("admin.ban"):
        if ban:
            form.add_button("§a🔓 Разбанить", on_click=lambda p: _unban_player(p, target, db, cfg))
        else:
            form.add_button("§c🔨 Заблокировать (Бан)", on_click=lambda p: show_ban_form(p, target, db, cfg))

    if admin.has_permission("admin.mute"):
        if mute:
            form.add_button("§a🔊 Размутить", on_click=lambda p: _unmute_player(p, target, db, cfg))
        else:
            form.add_button("§e🔇 Замолчить (Мут)", on_click=lambda p: show_mute_form(p, target, db, cfg))

    if admin.has_permission("admin.kick"):
        form.add_button("§6👢 Выгнать (Кик)", on_click=lambda p: show_kick_form(p, target, db, cfg))

    if admin.has_permission("admin.warn"):
        form.add_button("§e⚠ Предупредить (Варн)", on_click=lambda p: show_warn_form(p, target, db, cfg))
        if warn_count > 0:
            form.add_button("§7✕ Снять варны", on_click=lambda p: _clear_warns(p, target, db, cfg))

    if admin.has_permission("admin.punishments.view"):
        form.add_button("§8📜 История игрока", on_click=lambda p: show_player_history(p, target, db, cfg))

    form.add_button("§7← Назад", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    admin.send_form(form)


# ════════════════════════════════════════════════════════════
#   ФОРМЫ НАКАЗАНИЙ
# ════════════════════════════════════════════════════════════

def show_ban_form(admin: "Player", target: "Player", db: "DataManager", cfg: dict) -> None:
    allow_silent = cfg.get("punishments", {}).get("allow_silent", True)
    form = ModalForm(title=f"§l§c🔨 Бан: {target.name}")
    form.add_control(TextInput(
        label="§7Причина бана:",
        placeholder=cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    ))
    form.add_control(TextInput(
        label="§7Срок (в минутах, 0 = навсегда):",
        placeholder="например: 60, 1440, 0"
    ))
    if allow_silent:
        form.add_control(Toggle(label="§8🔕 Тихое наказание (без уведомления игроку)", default_value=False))
    form.submit_button = "§cПрименить бан"

    def on_submit(p, data):
        reason = (data[0] or "").strip() or cfg["punishments"]["default_reason"]
        try:
            duration = int(data[1] or 0)
        except ValueError:
            p.send_message("§cНеверный формат времени!")
            return
        silent = bool(data[2]) if allow_silent and len(data) > 2 else False
        db.ban_player(target.xuid, target.name, p.name, reason, duration, silent)
        dur_str = format_duration(duration)
        target.kick(cfg["ban"]["permanent_message"].format(reason=reason) if duration == 0
                    else cfg["ban"]["kick_message"].format(reason=reason, duration=dur_str))
        if not silent:
            pass  # уведомление обрабатывается в плагине
        notify = cfg["messages"]["ban_notify_admin"].format(
            admin=p.name, player=target.name, reason=reason, duration=dur_str
        )
        p.send_message(notify)
        if silent:
            p.send_message(cfg["messages"]["punishment_silent"])

    form.on_submit = on_submit
    admin.send_form(form)


def show_mute_form(admin: "Player", target: "Player", db: "DataManager", cfg: dict) -> None:
    allow_silent = cfg.get("punishments", {}).get("allow_silent", True)
    form = ModalForm(title=f"§l§e🔇 Мут: {target.name}")
    form.add_control(TextInput(
        label="§7Причина мута:",
        placeholder=cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    ))
    form.add_control(TextInput(
        label="§7Срок (в минутах, 0 = навсегда):",
        placeholder="например: 30, 60, 0"
    ))
    if allow_silent:
        form.add_control(Toggle(label="§8🔕 Тихое наказание", default_value=False))
    form.submit_button = "§eПрименить мут"

    def on_submit(p, data):
        reason = (data[0] or "").strip() or cfg["punishments"]["default_reason"]
        try:
            duration = int(data[1] or 0)
        except ValueError:
            p.send_message("§cНеверный формат времени!")
            return
        silent = bool(data[2]) if allow_silent and len(data) > 2 else False
        db.mute_player(target.xuid, target.name, p.name, reason, duration, silent)
        dur_str = format_duration(duration)
        if not silent:
            mute_msg = cfg["mute"]["muted_message"].format(
                reason=reason,
                time_left=dur_str
            )
            target.send_message(mute_msg)
        notify = cfg["messages"]["mute_notify_admin"].format(
            admin=p.name, player=target.name, reason=reason, duration=dur_str
        )
        p.send_message(notify)
        if silent:
            p.send_message(cfg["messages"]["punishment_silent"])

    form.on_submit = on_submit
    admin.send_form(form)


def show_kick_form(admin: "Player", target: "Player", db: "DataManager", cfg: dict) -> None:
    allow_silent = cfg.get("punishments", {}).get("allow_silent", True)
    form = ModalForm(title=f"§l§6👢 Кик: {target.name}")
    form.add_control(TextInput(
        label="§7Причина кика:",
        placeholder=cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    ))
    if allow_silent:
        form.add_control(Toggle(label="§8🔕 Тихое наказание", default_value=False))
    form.submit_button = "§6Выгнать"

    def on_submit(p, data):
        reason = (data[0] or "").strip() or cfg["punishments"]["default_reason"]
        silent = bool(data[1]) if allow_silent and len(data) > 1 else False
        db._log_punishment("kick", target.name, target.xuid, p.name, reason, 0, silent)
        kick_msg = cfg["kick"]["message"].format(reason=reason)
        target.kick(kick_msg)
        notify = cfg["messages"]["kick_notify_admin"].format(
            admin=p.name, player=target.name, reason=reason
        )
        p.send_message(notify)
        if silent:
            p.send_message(cfg["messages"]["punishment_silent"])

    form.on_submit = on_submit
    admin.send_form(form)


def show_warn_form(admin: "Player", target: "Player", db: "DataManager", cfg: dict) -> None:
    allow_silent = cfg.get("punishments", {}).get("allow_silent", True)
    form = ModalForm(title=f"§l§e⚠ Варн: {target.name}")
    form.add_control(TextInput(
        label="§7Причина предупреждения:",
        placeholder=cfg.get("punishments", {}).get("default_reason", "Нарушение правил")
    ))
    if allow_silent:
        form.add_control(Toggle(label="§8🔕 Тихое наказание", default_value=False))
    form.submit_button = "§eВыдать варн"

    def on_submit(p, data):
        reason = (data[0] or "").strip() or cfg["punishments"]["default_reason"]
        silent = bool(data[1]) if allow_silent and len(data) > 1 else False
        count = db.warn_player(target.xuid, target.name, p.name, reason, silent)
        if not silent:
            warn_msg = cfg["warn"]["message"].format(reason=reason, count=count)
            target.send_message(warn_msg)

        notify = cfg["messages"]["warn_notify_admin"].format(
            admin=p.name, player=target.name, reason=reason, count=count
        )
        p.send_message(notify)
        if silent:
            p.send_message(cfg["messages"]["punishment_silent"])

        # Автоматические действия по варнам
        kicks_at = cfg.get("warn", {}).get("kicks_at", 3)
        ban_at = cfg.get("warn", {}).get("ban_at", 5)
        if count >= ban_at:
            db.ban_player(target.xuid, target.name, "AutoAdmin", "Автобан за варны", 0, False)
            target.kick("§cВы автоматически заблокированы за превышение лимита предупреждений!")
        elif count >= kicks_at:
            target.kick("§cВы автоматически кикнуты за превышение лимита предупреждений!")

    form.on_submit = on_submit
    admin.send_form(form)


def _unban_player(admin: "Player", target: "Player", db: "DataManager", cfg: dict) -> None:
    db.unban_player(target.xuid)
    admin.send_message(f"§aИгрок §f{target.name} §aразбанен!")
    target.send_message("§aВы были разбанены!")
    show_player_action_menu(admin, target, db, cfg)


def _unmute_player(admin: "Player", target: "Player", db: "DataManager", cfg: dict) -> None:
    db.unmute_player(target.xuid)
    admin.send_message(f"§aИгрок §f{target.name} §aразмучен!")
    target.send_message("§aВы были размучены!")
    show_player_action_menu(admin, target, db, cfg)


def _clear_warns(admin: "Player", target: "Player", db: "DataManager", cfg: dict) -> None:
    db.clear_warns(target.xuid)
    admin.send_message(f"§aВарны игрока §f{target.name} §aсняты!")
    target.send_message("§aВаши предупреждения были сняты!")
    show_player_action_menu(admin, target, db, cfg)


# ════════════════════════════════════════════════════════════
#   ОТЧЁТЫ НАКАЗАНИЙ
# ════════════════════════════════════════════════════════════

def show_punishment_logs(player: "Player", db: "DataManager", cfg: dict,
                         filter_type: Optional[str] = None,
                         filter_xuid: Optional[str] = None) -> None:
    """Красивый лог всех наказаний."""
    logs = db.get_punishments(xuid=filter_xuid, ptype=filter_type, limit=30)

    form = ActionForm(
        title="§l§e📊 Отчёты наказаний",
        content=f"§7Показано: §f{len(logs)} §7записей"
    )

    # Кнопки фильтра
    form.add_button("🔴 Только баны", on_click=lambda p: show_punishment_logs(p, db, cfg, "ban"))
    form.add_button("🟡 Только муты", on_click=lambda p: show_punishment_logs(p, db, cfg, "mute"))
    form.add_button("🟠 Только кики", on_click=lambda p: show_punishment_logs(p, db, cfg, "kick"))
    form.add_button("⚠ Только варны", on_click=lambda p: show_punishment_logs(p, db, cfg, "warn"))
    if filter_type or filter_xuid:
        form.add_button("§7✕ Сбросить фильтр", on_click=lambda p: show_punishment_logs(p, db, cfg))

    form.add_button("§8─────────────────")

    if logs:
        for log in logs:
            color = punishment_color(log["type"])
            label = punishment_label(log["type"])
            dur_str = format_duration(log["duration_minutes"]) if log["type"] in ("ban", "mute") else ""
            silent_mark = " §8[🔕]" if log.get("silent") else ""
            ts = format_timestamp(log["time"])
            btn_text = (
                f"{color}[{label}]{silent_mark} §f{log['player']}\n"
                f"§7{log['reason']}"
                + (f" §8| {dur_str}" if dur_str else "")
                + f"\n§8{ts} §7by §f{log['admin']}"
            )
            form.add_button(btn_text)
    else:
        form.add_button("§8(нет записей)")

    form.add_button("§7← Главное меню", on_click=lambda p: show_admin_main_menu(p, db, cfg))
    player.send_form(form)


def show_player_history(admin: "Player", target: "Player",
                        db: "DataManager", cfg: dict) -> None:
    """История наказаний конкретного игрока."""
    logs = db.get_punishments(xuid=target.xuid, limit=20)
    warns = db.get_warn_count(target.xuid)
    ban = db.get_ban(target.xuid)
    mute = db.get_mute(target.xuid)

    ban_info = f"§cДо: {format_time_left(ban['expire_at'] if ban else None)}" if ban else "§aНет"
    mute_info = f"§eДо: {format_time_left(mute['expire_at'] if mute else None)}" if mute else "§aНет"

    form = ActionForm(
        title=f"§l§7📜 История: {target.name}",
        content=(
            f"§7Бан: {ban_info}\n"
            f"§7Мут: {mute_info}\n"
            f"§7Активных варнов: §e{warns}\n"
            f"§8─────────────────"
        )
    )

    if logs:
        for log in logs:
            color = punishment_color(log["type"])
            label = punishment_label(log["type"])
            dur_str = format_duration(log["duration_minutes"]) if log["type"] in ("ban", "mute") else ""
            ts = format_timestamp(log["time"])
            btn_text = (
                f"{color}[{label}] §f{log['reason']}"
                + (f" §8({dur_str})" if dur_str else "")
                + f"\n§8{ts} by §7{log['admin']}"
            )
            form.add_button(btn_text)
    else:
        form.add_button("§8(нет истории)")

    form.add_button("§7← Назад", on_click=lambda p: show_player_action_menu(p, target, db, cfg))
    admin.send_form(form)
