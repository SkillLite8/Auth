extends Node3D

# Бесконечный воксельный мир. Чанки 16x16x384 (как в Bedrock), данные хранятся в
# PackedByteArray, генерация и построение мешей идут в рабочих потоках, в основном
# потоке только создание узлов и загрузка готовых мешей. Коллизий физического движка нет:
# игрок и лучи работают напрямую с данными блоков (см. is_solid_cell / raycast).

const B = preload("res://scripts/3d/block_registry.gd")
const WorldGen = preload("res://scripts/3d/world_gen.gd")
const Mesher = preload("res://scripts/3d/chunk_mesher.gd")

const CHUNK_SIZE: int = 16
const MIN_Y: int = -64
const MAX_Y: int = 320
const COL_H: int = 384
const SECTIONS: int = 24
const BEDROCK_Y: int = -64
const SEA_LEVEL: int = 63
const VIEW_DISTANCE_CHUNKS: int = 6
const ATLAS_PATH: String = "res://assets/atlas/blocks_atlas.png"
const MESH_BUDGET_USEC: int = 4000
const MAX_INSTALLS_PER_FRAME: int = 6
const NO_CHUNK: Vector2i = Vector2i(2147483647, 2147483647)

const BLOCK_SHADER: String = """
shader_type spatial;
render_mode unshaded, %MODE%;

uniform sampler2D atlas : filter_nearest, repeat_disable;
uniform vec3 sky_tint = vec3(1.0);
uniform float cave_light = 0.30;
uniform float water_alpha = 0.72;

void fragment() {
    vec4 t = texture(atlas, UV);
%ALPHA%
    vec3 cave = min(sky_tint, vec3(cave_light));
    vec3 light = mix(cave, sky_tint, COLOR.a);
    vec3 col = t.rgb * COLOR.rgb * light;
    ALBEDO = pow(col, vec3(2.2));
%OUT%
}
"""

class ChunkData:
    extends RefCounted
    var coord: Vector2i = Vector2i.ZERO
    var blocks: PackedByteArray = PackedByteArray()
    var tops: PackedInt32Array = PackedInt32Array()
    var biomes: PackedByteArray = PackedByteArray()
    var max_y: int = -64
    var state: int = 0 # 0 запрошен, 1 сгенерирован, 2 меш в очереди, 3 есть меш
    var root: Node3D = null
    var nodes: Array = []
    var section_req: PackedInt32Array = PackedInt32Array()

    func _init(c: Vector2i) -> void:
        coord = c
        nodes.resize(24)
        section_req.resize(24)

var seed_value: int = 0
var view_distance_chunks: int = VIEW_DISTANCE_CHUNKS
var chunks: Dictionary = {}                # Vector2i -> ChunkData
var edits_by_chunk: Dictionary = {}        # Vector2i -> {Vector3i: id блока}
var dirty: Dictionary = {}                 # Vector2i -> {секция: true}
var urgent: Array = []
var mesh_ready: Array = []
var gen_queue: Array = []
var tasks: Array = []
var gen_results: Array = []
var mesh_results: Array = []
var mutex := Mutex.new()
var token_counter: int = 0
var max_jobs: int = 3
var stream_target: Node3D
var cloud_layer
var stream_center: Vector2i = NO_CHUNK
var main_gen
var mat_opaque: ShaderMaterial
var mat_cutout: ShaderMaterial
var mat_water: ShaderMaterial
var atlas_texture: Texture2D
var light_color: Color = Color.WHITE
var last_chunk_coord: Vector2i = NO_CHUNK
var last_chunk: ChunkData = null
var spawn_cell: Vector3i = Vector3i.ZERO

func generate(new_seed: int = 0, saved_changes: Dictionary = {}) -> void:
    B.setup()
    seed_value = new_seed if new_seed != 0 else randi()
    seed_value = absi(seed_value) % 2000000000
    chunks.clear()
    edits_by_chunk.clear()
    dirty.clear()
    urgent.clear()
    mesh_ready.clear()
    gen_queue.clear()
    max_jobs = clampi(OS.get_processor_count() - 1, 2, 6)
    main_gen = WorldGen.new(seed_value)
    spawn_cell = main_gen.find_spawn(0, 4)
    _create_materials()
    _apply_saved_changes(saved_changes)

func _exit_tree() -> void:
    for task_id in tasks:
        WorkerThreadPool.wait_for_task_completion(int(task_id))
    tasks.clear()

# ------------------------------------------------------------------ materials

func _make_shader(mode: String, alpha_code: String, out_code: String) -> Shader:
    var shader := Shader.new()
    shader.code = BLOCK_SHADER.replace("%MODE%", mode).replace("%ALPHA%", alpha_code).replace("%OUT%", out_code)
    return shader

func _create_materials() -> void:
    atlas_texture = load(ATLAS_PATH) as Texture2D
    mat_opaque = ShaderMaterial.new()
    mat_opaque.shader = _make_shader("cull_back", "", "")
    mat_cutout = ShaderMaterial.new()
    mat_cutout.shader = _make_shader("cull_disabled", "    if (t.a < 0.5) { discard; }", "")
    mat_water = ShaderMaterial.new()
    mat_water.shader = _make_shader("blend_mix, depth_draw_opaque, cull_disabled", "", "    ALPHA = water_alpha;")
    for mat in [mat_opaque, mat_cutout, mat_water]:
        mat.set_shader_parameter("atlas", atlas_texture)
    set_light_color(light_color)

# Цвет небесного света (время суток); пещерная темнота запечена в вершинах.
func set_light_color(color: Color) -> void:
    light_color = color
    var tint := Vector3(color.r, color.g, color.b)
    for mat in [mat_opaque, mat_cutout, mat_water]:
        if mat != null:
            mat.set_shader_parameter("sky_tint", tint)

# ------------------------------------------------------------------ lookups

func _cell_chunk(cell: Vector3i) -> Vector2i:
    return Vector2i(cell.x >> 4, cell.z >> 4)

func _get_chunk(coord: Vector2i) -> ChunkData:
    if coord == last_chunk_coord:
        return last_chunk
    var chunk: ChunkData = chunks.get(coord)
    if chunk != null:
        last_chunk_coord = coord
        last_chunk = chunk
    return chunk

# ID блока или -1, если чанк ещё не загружен.
func get_block_id_xyz(x: int, y: int, z: int) -> int:
    if y < MIN_Y:
        return B.BEDROCK
    if y >= MAX_Y:
        return B.AIR
    var chunk: ChunkData = _get_chunk(Vector2i(x >> 4, z >> 4))
    if chunk == null or chunk.state < 1:
        return -1
    return chunk.blocks[((z & 15) * 16 + (x & 15)) * COL_H + (y - MIN_Y)]

func get_block_id(cell: Vector3i) -> int:
    return get_block_id_xyz(cell.x, cell.y, cell.z)

func get_block_kind(cell: Vector3i) -> String:
    var block_id: int = get_block_id(cell)
    if block_id < 0:
        return "air"
    return B.names[block_id]

# Для физики: незагруженная область считается твёрдой, чтобы игрок не провалился.
func is_solid_cell(x: int, y: int, z: int) -> bool:
    var block_id: int = get_block_id_xyz(x, y, z)
    if block_id < 0:
        return true
    if B.solid[block_id] == 1:
        return true
    if is_instance_valid(cloud_layer) and cloud_layer.is_cloud_solid(x, y, z):
        return true
    return false

func is_position_in_water(position: Vector3) -> bool:
    var block_id: int = get_block_id_xyz(floori(position.x + 0.5), floori(position.y + 0.5), floori(position.z + 0.5))
    return block_id == B.WATER

func is_chunk_ready_at(position: Vector3) -> bool:
    var chunk: ChunkData = _get_chunk(Vector2i(floori(position.x + 0.5) >> 4, floori(position.z + 0.5) >> 4))
    return chunk != null and chunk.state >= 1

func sky_exposure_at(position: Vector3) -> float:
    var x: int = floori(position.x + 0.5)
    var y: int = floori(position.y + 0.5)
    var z: int = floori(position.z + 0.5)
    var chunk: ChunkData = _get_chunk(Vector2i(x >> 4, z >> 4))
    if chunk == null or chunk.state < 1:
        return 1.0
    var top_y: int = chunk.tops[(z & 15) * 16 + (x & 15)]
    var overhead: int = top_y - y
    if overhead <= 0:
        return 1.0
    var opaque_cover: int = 0
    var leaf_cover: int = 0
    var water_cover: int = 0
    var scan_end: int = mini(top_y, y + 32)
    for scan_y in range(y + 1, scan_end + 1):
        var block_id: int = get_block_id_xyz(x, scan_y, z)
        if block_id <= 0 or B.blocks_sky[block_id] == 0:
            continue
        var kind: int = B.render[block_id]
        var block_name: String = B.names[block_id]
        if kind == B.R_LEAVES or block_name.ends_with("_log") or block_name.ends_with("_stripped_log"):
            leaf_cover += 1
        elif kind == B.R_WATER:
            water_cover += 1
        else:
            opaque_cover += 1
    if opaque_cover > 0:
        return 0.08
    if water_cover > 0:
        return 0.30
    if leaf_cover > 0:
        return clampf(exp(-float(leaf_cover) * 0.13 - float(overhead) * 0.025), 0.38, 0.88)
    return clampf(exp(-float(overhead) * 0.06), 0.28, 1.0)

func depth_below_surface(position: Vector3) -> float:
    # Use the generated terrain surface, not tree crowns; leaves shade blocks but do not turn
    # the space beneath a tree into a cave for player lighting.
    var x: int = floori(position.x + 0.5)
    var z: int = floori(position.z + 0.5)
    return float(height_at(x, z)) - position.y

func biome_at(x: int, z: int) -> int:
    var chunk: ChunkData = _get_chunk(Vector2i(x >> 4, z >> 4))
    if chunk != null and chunk.state >= 1:
        return chunk.biomes[(z & 15) * 16 + (x & 15)]
    return main_gen.biome_at(x, z)

func biome_name_at(x: int, z: int) -> String:
    var biome: int = biome_at(x, z)
    return str(WorldGen.BIOME_NAMES[clampi(biome, 0, WorldGen.BIOME_COUNT - 1)])

func height_at(x: int, z: int) -> int:
    return main_gen.height_at(x, z)

func get_spawn_position() -> Vector3:
    return Vector3(float(spawn_cell.x), float(spawn_cell.y) + 1.42, float(spawn_cell.z))

func is_ore(kind: String) -> bool:
    return B.is_ore_name(kind)

func loaded_chunk_count() -> int:
    var total: int = 0
    for chunk_variant in chunks.values():
        var chunk: ChunkData = chunk_variant
        if chunk.state >= 1:
            total += 1
    return total

func pending_job_count() -> int:
    return tasks.size() + gen_queue.size() + mesh_ready.size()

# Доля готовых (с мешем) чанков вокруг точки; нужна для экрана загрузки.
func readiness_around(position: Vector3, radius: int) -> float:
    var center := Vector2i(floori(position.x + 0.5) >> 4, floori(position.z + 0.5) >> 4)
    var total: int = 0
    var ready: int = 0
    for dx in range(-radius, radius + 1):
        for dz in range(-radius, radius + 1):
            total += 1
            var chunk: ChunkData = chunks.get(center + Vector2i(dx, dz))
            if chunk != null and chunk.state >= 3:
                ready += 1
    return float(ready) / float(maxi(1, total))

# ------------------------------------------------------------------ raycast

# Обход вокселей по лучу (Amanatides-Woo). Клетка (x,y,z) занимает [x-0.5, x+0.5].
func raycast(origin: Vector3, direction: Vector3, max_distance: float) -> Dictionary:
    var dir: Vector3 = direction.normalized()
    var p: Vector3 = origin + Vector3(0.5, 0.5, 0.5)
    var cx: int = floori(p.x)
    var cy: int = floori(p.y)
    var cz: int = floori(p.z)
    var step_x: int = 1 if dir.x > 0.0 else -1
    var step_y: int = 1 if dir.y > 0.0 else -1
    var step_z: int = 1 if dir.z > 0.0 else -1
    var inv_x: float = INF if absf(dir.x) < 0.000001 else absf(1.0 / dir.x)
    var inv_y: float = INF if absf(dir.y) < 0.000001 else absf(1.0 / dir.y)
    var inv_z: float = INF if absf(dir.z) < 0.000001 else absf(1.0 / dir.z)
    var t_max_x: float = INF
    var t_max_y: float = INF
    var t_max_z: float = INF
    if inv_x != INF:
        t_max_x = ((float(cx + 1) - p.x) if step_x > 0 else (p.x - float(cx))) * inv_x
    if inv_y != INF:
        t_max_y = ((float(cy + 1) - p.y) if step_y > 0 else (p.y - float(cy))) * inv_y
    if inv_z != INF:
        t_max_z = ((float(cz + 1) - p.z) if step_z > 0 else (p.z - float(cz))) * inv_z
    var normal := Vector3i.ZERO
    var distance: float = 0.0
    for i in range(160):
        var block_id: int = get_block_id_xyz(cx, cy, cz)
        if block_id > 0:
            var kind: int = B.render[block_id]
            if kind != B.R_WATER and kind != B.R_NONE:
                return {"hit": true, "cell": Vector3i(cx, cy, cz), "normal": normal, "id": block_id, "distance": distance}
        if t_max_x < t_max_y and t_max_x < t_max_z:
            distance = t_max_x
            if distance > max_distance:
                break
            cx += step_x
            t_max_x += inv_x
            normal = Vector3i(-step_x, 0, 0)
        elif t_max_y < t_max_z:
            distance = t_max_y
            if distance > max_distance:
                break
            cy += step_y
            t_max_y += inv_y
            normal = Vector3i(0, -step_y, 0)
        else:
            distance = t_max_z
            if distance > max_distance:
                break
            cz += step_z
            t_max_z += inv_z
            normal = Vector3i(0, 0, -step_z)
    return {"hit": false}

# ------------------------------------------------------------------ edits

func mine_cell(cell: Vector3i) -> Dictionary:
    if cell.y <= MIN_Y:
        return {"ok": false, "message": "Коренная порода не поддаётся кирке."}
    var block_id: int = get_block_id(cell)
    if block_id <= 0 or B.render[block_id] == B.R_WATER:
        return {"ok": false, "message": "Здесь нет блока."}
    if block_id == B.BEDROCK:
        return {"ok": false, "message": "Коренная порода не поддаётся кирке."}
    var kind: String = B.names[block_id]
    if not set_block_id(cell, B.AIR):
        return {"ok": false, "message": "Область ещё загружается."}
    return {"ok": true, "kind": kind, "cell": cell}

func place_block(cell: Vector3i, kind: String) -> bool:
    if cell.y <= MIN_Y or cell.y >= MAX_Y:
        return false
    var new_id: int = B.id_of(kind)
    if new_id <= 0 or not B.is_placeable_name(kind):
        return false
    var existing: int = get_block_id(cell)
    if existing < 0:
        return false
    var existing_kind: int = B.render[existing]
    if not (existing == B.AIR or existing_kind == B.R_WATER or existing_kind == B.R_CROSS):
        return false
    return set_block_id(cell, new_id)

func set_block_id(cell: Vector3i, new_id: int) -> bool:
    if cell.y < MIN_Y or cell.y >= MAX_Y:
        return false
    var coord: Vector2i = _cell_chunk(cell)
    var chunk: ChunkData = _get_chunk(coord)
    if chunk == null or chunk.state < 1:
        return false
    var lx: int = cell.x & 15
    var lz: int = cell.z & 15
    var idx: int = (lz * 16 + lx) * COL_H + (cell.y - MIN_Y)
    if chunk.blocks[idx] == new_id:
        return false
    chunk.blocks[idx] = new_id
    if cell.y > chunk.max_y:
        chunk.max_y = cell.y
    if not edits_by_chunk.has(coord):
        edits_by_chunk[coord] = {}
    var chunk_edits: Dictionary = edits_by_chunk[coord]
    chunk_edits[cell] = new_id

    var col: int = lz * 16 + lx
    var old_top: int = chunk.tops[col]
    if B.blocks_sky[new_id] == 1:
        if cell.y > old_top:
            chunk.tops[col] = cell.y
    elif cell.y == old_top:
        _recompute_top(chunk, lx, lz)
    var new_top: int = chunk.tops[col]
    var y_lo: int = cell.y - 1
    var y_hi: int = cell.y + 1
    if new_top != old_top:
        y_lo = mini(y_lo, mini(old_top, new_top) - 12)
        y_hi = maxi(y_hi, maxi(old_top, new_top) + 1)
    _mark_dirty_range(coord, lx, lz, y_lo, y_hi)
    return true

func _recompute_top(chunk: ChunkData, lx: int, lz: int) -> void:
    var base: int = (lz * 16 + lx) * COL_H
    var y: int = mini(chunk.max_y + 1, MAX_Y - 1)
    var sky: PackedByteArray = B.blocks_sky
    while y > MIN_Y:
        if sky[chunk.blocks[base + (y - MIN_Y)]] == 1:
            break
        y -= 1
    chunk.tops[lz * 16 + lx] = y

func _mark_dirty_range(coord: Vector2i, lx: int, lz: int, y_lo: int, y_hi: int) -> void:
    var sy_lo: int = clampi((y_lo - MIN_Y) >> 4, 0, SECTIONS - 1)
    var sy_hi: int = clampi((y_hi - MIN_Y) >> 4, 0, SECTIONS - 1)
    var dxs: Array = [0]
    var dzs: Array = [0]
    if lx == 0:
        dxs.append(-1)
    elif lx == 15:
        dxs.append(1)
    if lz == 0:
        dzs.append(-1)
    elif lz == 15:
        dzs.append(1)
    for dx in dxs:
        for dz in dzs:
            var target: Vector2i = coord + Vector2i(int(dx), int(dz))
            if not chunks.has(target):
                continue
            var entry: Dictionary = dirty.get(target, {})
            for sy in range(sy_lo, sy_hi + 1):
                entry[sy] = true
            dirty[target] = entry

func export_changes() -> Dictionary:
    var out: Array = []
    for coord_variant in edits_by_chunk.keys():
        var chunk_edits: Dictionary = edits_by_chunk[coord_variant]
        for cell_variant in chunk_edits.keys():
            var cell: Vector3i = cell_variant
            out.append([cell.x, cell.y, cell.z, B.name_of(int(chunk_edits[cell_variant]))])
    return {"edits": out}

func _apply_saved_changes(changes: Dictionary) -> void:
    for raw in changes.get("edits", []):
        if raw is Array and raw.size() >= 4:
            var block_id: int = B.id_of(str(raw[3]))
            if block_id < 0:
                continue
            var cell := Vector3i(int(raw[0]), int(raw[1]), int(raw[2]))
            if cell.y < MIN_Y or cell.y >= MAX_Y:
                continue
            var coord: Vector2i = _cell_chunk(cell)
            if not edits_by_chunk.has(coord):
                edits_by_chunk[coord] = {}
            var chunk_edits: Dictionary = edits_by_chunk[coord]
            chunk_edits[cell] = block_id

# ------------------------------------------------------------------ streaming

func set_stream_target(target: Node3D) -> void:
    stream_target = target
    stream_center = NO_CHUNK
    if is_instance_valid(target):
        _update_center()

func _update_center() -> void:
    var pos: Vector3 = stream_target.global_position
    var center := Vector2i(floori(pos.x + 0.5) >> 4, floori(pos.z + 0.5) >> 4)
    if center == stream_center:
        return
    stream_center = center
    var gen_radius: int = view_distance_chunks + 1
    var wanted: Array = []
    for dx in range(-gen_radius, gen_radius + 1):
        for dz in range(-gen_radius, gen_radius + 1):
            var coord: Vector2i = center + Vector2i(dx, dz)
            if not chunks.has(coord):
                wanted.append(coord)
    wanted.sort_custom(func(a: Vector2i, other: Vector2i) -> bool:
        return (a - center).length_squared() < (other - center).length_squared())
    gen_queue = wanted
    var unload_radius: int = view_distance_chunks + 2
    var to_remove: Array = []
    for coord_variant in chunks.keys():
        var coord2: Vector2i = coord_variant
        if absi(coord2.x - center.x) > unload_radius or absi(coord2.y - center.y) > unload_radius:
            to_remove.append(coord2)
    for coord3 in to_remove:
        _unload_chunk(coord3)
    for chunk_variant in chunks.values():
        var chunk: ChunkData = chunk_variant
        if chunk.state == 1:
            _try_queue_mesh(chunk.coord)

func _unload_chunk(coord: Vector2i) -> void:
    var chunk: ChunkData = chunks.get(coord)
    if chunk == null:
        return
    if is_instance_valid(chunk.root):
        chunk.root.queue_free()
    chunks.erase(coord)
    dirty.erase(coord)
    urgent.erase(coord)
    mesh_ready.erase(coord)
    last_chunk_coord = NO_CHUNK
    last_chunk = null

func _in_mesh_range(coord: Vector2i) -> bool:
    return absi(coord.x - stream_center.x) <= view_distance_chunks and absi(coord.y - stream_center.y) <= view_distance_chunks

func _try_queue_mesh(coord: Vector2i) -> void:
    var chunk: ChunkData = chunks.get(coord)
    if chunk == null or chunk.state != 1 or not _in_mesh_range(coord):
        return
    for dx in range(-1, 2):
        for dz in range(-1, 2):
            var other: ChunkData = chunks.get(coord + Vector2i(dx, dz))
            if other == null or other.state < 1:
                return
    chunk.state = 2
    mesh_ready.append(coord)

func _process(_delta: float) -> void:
    _reap_tasks()
    _drain_results()
    if is_instance_valid(stream_target):
        _update_center()
    _flush_dirty()
    _pump_jobs()

func _reap_tasks() -> void:
    var still: Array = []
    for task_id in tasks:
        if WorkerThreadPool.is_task_completed(int(task_id)):
            WorkerThreadPool.wait_for_task_completion(int(task_id))
        else:
            still.append(task_id)
    tasks = still

func _flush_dirty() -> void:
    for coord_variant in dirty.keys():
        var coord: Vector2i = coord_variant
        var chunk: ChunkData = chunks.get(coord)
        if chunk == null:
            dirty.erase(coord)
        elif chunk.state == 3 and not urgent.has(coord):
            urgent.append(coord)

func _pump_jobs() -> void:
    while tasks.size() < max_jobs:
        if not _start_next_job():
            break

# Девять соседних массивов блоков; пустой результат, если кого-то уже выгрузили.
func _collect9(coord: Vector2i) -> Array:
    var blocks9: Array = []
    var tops9: Array = []
    for dz in range(-1, 2):
        for dx in range(-1, 2):
            var chunk: ChunkData = chunks.get(coord + Vector2i(dx, dz))
            if chunk == null or chunk.state < 1:
                return []
            blocks9.append(chunk.blocks)
            tops9.append(chunk.tops)
    return [blocks9, tops9]

func _start_mesh_job(coord: Vector2i, sections: Array, full: bool) -> bool:
    var chunk: ChunkData = chunks[coord]
    var data: Array = _collect9(coord)
    if data.is_empty():
        return false
    token_counter += 1
    for sy in sections:
        chunk.section_req[int(sy)] = token_counter
    var job: Callable = _mesh_job.bind(coord, data[0], data[1], sections, chunk.max_y, token_counter, full)
    tasks.append(WorkerThreadPool.add_task(job, false, "chunk_mesh"))
    return true

func _start_next_job() -> bool:
    while not urgent.is_empty():
        var coord: Vector2i = urgent.pop_front()
        var chunk: ChunkData = chunks.get(coord)
        if chunk == null or chunk.state != 3:
            continue
        var entry: Dictionary = dirty.get(coord, {})
        dirty.erase(coord)
        if entry.is_empty():
            continue
        if _start_mesh_job(coord, entry.keys(), false):
            return true
    if not mesh_ready.is_empty():
        var best_index: int = 0
        var best_dist: int = 2147483647
        for i in range(mesh_ready.size()):
            var c: Vector2i = mesh_ready[i]
            var d: int = (c - stream_center).length_squared()
            if d < best_dist:
                best_dist = d
                best_index = i
        var mesh_coord: Vector2i = mesh_ready[best_index]
        mesh_ready.remove_at(best_index)
        var mesh_chunk: ChunkData = chunks.get(mesh_coord)
        if mesh_chunk == null:
            return true
        var last_section: int = clampi((mesh_chunk.max_y - MIN_Y + 1) >> 4, 0, SECTIONS - 1)
        var all_sections: Array = []
        for sy in range(last_section + 1):
            all_sections.append(sy)
        dirty.erase(mesh_coord)
        if not _start_mesh_job(mesh_coord, all_sections, true):
            mesh_chunk.state = 1
        return true
    while not gen_queue.is_empty():
        var gen_coord: Vector2i = gen_queue.pop_front()
        if chunks.has(gen_coord):
            continue
        chunks[gen_coord] = ChunkData.new(gen_coord)
        last_chunk_coord = NO_CHUNK
        tasks.append(WorkerThreadPool.add_task(_gen_job.bind(gen_coord, seed_value), false, "chunk_gen"))
        return true
    return false

# --- рабочие потоки (не трогают дерево сцены) ---

func _gen_job(coord: Vector2i, job_seed: int) -> void:
    var generator = WorldGen.new(job_seed)
    var data: Dictionary = generator.generate_chunk(coord.x, coord.y)
    mutex.lock()
    gen_results.append([coord, data])
    mutex.unlock()

func _mesh_job(coord: Vector2i, blocks9: Array, tops9: Array, sections: Array, max_y: int, token: int, full: bool) -> void:
    var mesher = Mesher.new()
    var result: Dictionary = mesher.mesh_chunk(blocks9, tops9, sections, max_y, MIN_Y)
    mutex.lock()
    mesh_results.append([coord, result, token, full])
    mutex.unlock()

# --- возврат результатов в основной поток ---

func _drain_results() -> void:
    mutex.lock()
    var gens: Array = gen_results
    var meshes: Array = mesh_results
    gen_results = []
    mesh_results = []
    mutex.unlock()

    var installed: int = 0
    var leftover_gens: Array = []
    for item_variant in gens:
        var item: Array = item_variant
        if installed >= MAX_INSTALLS_PER_FRAME:
            leftover_gens.append(item)
        else:
            _install_chunk(item[0], item[1])
            installed += 1

    var start: int = Time.get_ticks_usec()
    var processed: int = 0
    var leftover_meshes: Array = []
    for item_variant in meshes:
        var mesh_item: Array = item_variant
        if processed >= 1 and Time.get_ticks_usec() - start > MESH_BUDGET_USEC:
            leftover_meshes.append(mesh_item)
        else:
            _apply_mesh_result(mesh_item[0], mesh_item[1], int(mesh_item[2]), bool(mesh_item[3]))
            processed += 1

    if not leftover_gens.is_empty() or not leftover_meshes.is_empty():
        mutex.lock()
        leftover_gens.append_array(gen_results)
        gen_results = leftover_gens
        leftover_meshes.append_array(mesh_results)
        mesh_results = leftover_meshes
        mutex.unlock()

func _install_chunk(coord: Vector2i, data: Dictionary) -> void:
    var chunk: ChunkData = chunks.get(coord)
    if chunk == null or chunk.state != 0:
        return
    chunk.blocks = data["blocks"]
    chunk.tops = data["tops"]
    chunk.biomes = data["biomes"]
    chunk.max_y = int(data["max_y"])
    chunk.state = 1
    chunk.root = Node3D.new()
    chunk.root.name = "Chunk_%d_%d" % [coord.x, coord.y]
    chunk.root.position = Vector3(float(coord.x * CHUNK_SIZE), 0.0, float(coord.y * CHUNK_SIZE))
    add_child(chunk.root)
    if edits_by_chunk.has(coord):
        var chunk_edits: Dictionary = edits_by_chunk[coord]
        var touched: Dictionary = {}
        for cell_variant in chunk_edits.keys():
            var cell: Vector3i = cell_variant
            var idx: int = ((cell.z & 15) * 16 + (cell.x & 15)) * COL_H + (cell.y - MIN_Y)
            chunk.blocks[idx] = int(chunk_edits[cell_variant])
            if cell.y > chunk.max_y:
                chunk.max_y = cell.y
            touched[Vector2i(cell.x & 15, cell.z & 15)] = true
        for col_variant in touched.keys():
            var col: Vector2i = col_variant
            _recompute_top(chunk, col.x, col.y)
    for dx in range(-1, 2):
        for dz in range(-1, 2):
            _try_queue_mesh(coord + Vector2i(dx, dz))

func _apply_mesh_result(coord: Vector2i, result: Dictionary, token: int, full: bool) -> void:
    var chunk: ChunkData = chunks.get(coord)
    if chunk == null or not is_instance_valid(chunk.root):
        return
    for sy_variant in result.keys():
        var sy: int = int(sy_variant)
        if token < chunk.section_req[sy]:
            continue
        _apply_section(chunk, sy, result[sy_variant])
    if full and chunk.state == 2:
        chunk.state = 3

func _apply_section(chunk: ChunkData, sy: int, entry: Dictionary) -> void:
    var instance: MeshInstance3D = chunk.nodes[sy]
    if entry.is_empty():
        if instance != null:
            instance.mesh = null
            instance.visible = false
        return
    var mesh := ArrayMesh.new()
    var surface: int = 0
    var materials: Array = [["o", mat_opaque], ["c", mat_cutout], ["w", mat_water]]
    for pair in materials:
        var key: String = pair[0]
        if not entry.has(key):
            continue
        var part: Dictionary = entry[key]
        var arrays: Array = []
        arrays.resize(Mesh.ARRAY_MAX)
        arrays[Mesh.ARRAY_VERTEX] = part["v"]
        arrays[Mesh.ARRAY_TEX_UV] = part["uv"]
        arrays[Mesh.ARRAY_COLOR] = part["c"]
        arrays[Mesh.ARRAY_INDEX] = part["i"]
        mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
        mesh.surface_set_material(surface, pair[1])
        surface += 1
    if instance == null:
        instance = MeshInstance3D.new()
        instance.name = "Section_%d" % sy
        instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        chunk.root.add_child(instance)
        chunk.nodes[sy] = instance
    instance.mesh = mesh
    instance.visible = true
