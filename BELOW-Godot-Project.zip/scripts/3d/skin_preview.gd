extends Control
# Live 3D preview of the player's skin. In the inventory the head and body follow the mouse
# cursor like in Minecraft; in the profile menu the model turns slowly.

const PM = preload("res://scripts/3d/player_model.gd")

var viewport: SubViewport
var camera: Camera3D
var model_root: Node3D
var model
var auto_spin: bool = false
var spin_angle: float = 0.0
var look_yaw: float = 0.0
var look_pitch: float = 0.0
var armor_signature: String = ""

func setup(skin: Texture2D, preview_size: Vector2, spin: bool = false, show_background: bool = true) -> void:
    auto_spin = spin
    custom_minimum_size = preview_size
    size = preview_size
    mouse_filter = Control.MOUSE_FILTER_IGNORE

    if show_background:
        var background := ColorRect.new()
        background.color = Color(0.04, 0.04, 0.05)
        background.size = preview_size
        background.mouse_filter = Control.MOUSE_FILTER_IGNORE
        add_child(background)

    var container := SubViewportContainer.new()
    container.stretch = true
    container.size = preview_size
    container.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(container)

    viewport = SubViewport.new()
    viewport.size = Vector2i(int(preview_size.x), int(preview_size.y))
    viewport.transparent_bg = true
    viewport.own_world_3d = true
    viewport.msaa_3d = Viewport.MSAA_DISABLED
    viewport.gui_disable_input = true
    viewport.render_target_update_mode = SubViewport.UPDATE_WHEN_VISIBLE
    container.add_child(viewport)

    var preview_environment := WorldEnvironment.new()
    var preview_env := Environment.new()
    preview_env.background_mode = Environment.BG_COLOR
    preview_env.background_color = Color(0.04, 0.04, 0.05)
    preview_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    preview_env.ambient_light_color = Color(0.82, 0.86, 0.92)
    preview_env.ambient_light_energy = 0.85
    preview_environment.environment = preview_env
    viewport.add_child(preview_environment)

    var preview_light := DirectionalLight3D.new()
    preview_light.rotation_degrees = Vector3(-28.0, -28.0, 0.0)
    preview_light.light_energy = 0.9
    preview_light.shadow_enabled = false
    viewport.add_child(preview_light)

    camera = Camera3D.new()
    camera.fov = 26.0
    camera.near = 0.1
    camera.far = 30.0
    camera.position = Vector3(0.0, 0.95, 4.6)
    camera.current = true
    viewport.add_child(camera)

    model_root = Node3D.new()
    model_root.rotation.y = PI
    viewport.add_child(model_root)
    model = PM.new()
    model_root.add_child(model)
    model.setup(skin)
    set_armor([])

func set_armor(items: Array) -> void:
    var ids: PackedStringArray = PackedStringArray()
    for item_variant in items:
        ids.append(str(item_variant))
    var signature: String = "|".join(ids)
    if signature == armor_signature:
        return
    armor_signature = signature
    if model != null and is_instance_valid(model):
        model.set_armor(items)

func _process(delta: float) -> void:
    if model == null or not is_visible_in_tree():
        return
    if auto_spin:
        spin_angle += delta * 0.9
        model_root.rotation.y = PI + sin(spin_angle) * 0.9
        model.update_pose(delta, 0.0, 0.0, 0.0, false, true)
    else:
        model_root.rotation.y = PI + look_yaw * 0.55
        model.update_pose(delta, 0.0, 0.0, 0.0, false, true)
        model.head.rotation.y = look_yaw * 0.45
        model.head.rotation.x = look_pitch

# Called by the inventory every frame with the global mouse position.
func look_at_mouse(mouse_position: Vector2) -> void:
    var center: Vector2 = global_position + Vector2(size.x * 0.5, size.y * 0.30)
    var offset: Vector2 = mouse_position - center
    look_yaw = atan(offset.x / 60.0)
    look_pitch = -atan(offset.y / 60.0) * 0.6
