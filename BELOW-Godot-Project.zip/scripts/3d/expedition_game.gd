extends Node3D

const WorldScript = preload("res://scripts/3d/voxel_world.gd")
const ExplorerScene: PackedScene = preload("res://scenes/3d/explorer.tscn")
const HudScript = preload("res://scripts/3d/voxel_hud.gd")
const DayNight = preload("res://scripts/3d/day_night.gd")
const SkyDomeScript = preload("res://scripts/3d/sky_dome.gd")
const PlayerModelScript = preload("res://scripts/3d/player_model.gd")
const SkinPreviewScript = preload("res://scripts/3d/skin_preview.gd")
const CloudLayerScript = preload("res://scripts/3d/cloud_layer.gd")

const SAVE_PATH: String = "user://recraft_save.json"
const TIME_FAST_FORWARD: float = 60.0 # Hold F6 to watch the day/night transition quickly.
const CAVE_MIN_LIGHT: float = 0.32
const DEFAULT_SKIN_PATH: String = "res://assets/skins/default_skin.png"

var world
var player
var hud
var title_layer: CanvasLayer
var is_paused: bool = false
var inventory_open: bool = false
var game_started: bool = false
var world_seed: int = 0
var autosave_timer: float = 0.0
var preferred_view_distance: int = 6
var loading: bool = false
var debug_visible: bool = false
var day_night = DayNight.new()
var sky_dome
var cloud_layer
var scene_environment: Environment
var sun_light: DirectionalLight3D
var cave_blend: float = 0.0
var cave_target: float = 0.0
var local_sky_exposure: float = 1.0
var target_sky_exposure: float = 1.0
var cave_probe_timer: float = 0.0
var clock_timer: float = 0.0
var applied_light: Color = Color(-1.0, -1.0, -1.0)
var menu_popup: PanelContainer

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _load_settings()
    _create_environment()
    _show_title_menu()

func _load_settings() -> void:
    var config := ConfigFile.new()
    if config.load("user://recraft_settings.cfg") == OK:
        preferred_view_distance = clampi(int(config.get_value("graphics", "view_distance_chunks", 6)), 2, 12)

func _save_settings() -> void:
    var config := ConfigFile.new()
    config.set_value("graphics", "view_distance_chunks", preferred_view_distance)
    config.save("user://recraft_settings.cfg")

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_game(false)
        get_tree().quit()

func _create_environment() -> void:
    var world_environment := WorldEnvironment.new()
    world_environment.name = "ReCraftWorldEnvironment"
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("c0d8ff")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color.WHITE
    env.ambient_light_energy = 0.38
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = false
    env.ssao_enabled = false
    env.ssil_enabled = false
    env.sdfgi_enabled = false
    env.fog_enabled = false
    env.fog_light_color = Color("c0d8ff")
    # Linear depth fog hides the edge of the streamed world (property names differ slightly
    # between engine versions, so they are assigned dynamically).
    env.set("fog_mode", 1)
    env.set("fog_depth_curve", 1.0)
    env.set("fog_depth_begin", 30.0)
    env.set("fog_depth_end", 60.0)
    scene_environment = env
    world_environment.environment = env
    add_child(world_environment)

    sun_light = DirectionalLight3D.new()
    sun_light.name = "SoftSunlight"
    sun_light.light_color = Color(1.0, 0.96, 0.88)
    sun_light.light_energy = 0.55
    sun_light.shadow_enabled = true
    sun_light.directional_shadow_max_distance = 80.0
    add_child(sun_light)

    sky_dome = SkyDomeScript.new()
    add_child(sky_dome)
    day_night.set_time(DayNight.START_TICK, 0)
    sky_dome.apply_time(day_night)
    _update_sunlight()

func _configure_fog() -> void:
    if not is_instance_valid(scene_environment):
        return
    var distance: float = float(preferred_view_distance * 16)
    scene_environment.fog_enabled = true
    scene_environment.set("fog_depth_begin", distance * 0.40)
    scene_environment.set("fog_depth_end", distance - 3.0)

func _compute_world_light() -> Color:
    var sky: Color = day_night.sky_light_tint()
    var brightness: float = maxf(0.05, day_night.sky_brightness())
    var cave_factor: float = minf(1.0, CAVE_MIN_LIGHT / brightness)
    var cave: Color = Color(sky.r * cave_factor, sky.g * cave_factor, sky.b * cave_factor)
    var scene_light: Color = sky.lerp(cave, cave_blend)
    return scene_light * local_sky_exposure

func _update_sky(delta: float) -> void:
    var speed: float = 1.0
    if game_started and not is_paused and Input.is_physical_key_pressed(KEY_F6):
        speed = TIME_FAST_FORWARD
    day_night.advance(delta * speed)
    if is_instance_valid(sky_dome):
        sky_dome.apply_time(day_night)
        sky_dome.advance_clouds(delta * speed)
        sky_dome.follow(get_viewport().get_camera_3d())
    _update_sunlight()
    var fog_color: Color = day_night.fog_color()
    if is_instance_valid(scene_environment):
        scene_environment.background_color = fog_color
        scene_environment.fog_light_color = fog_color
    # Underground dimming: blend toward a dim cave light when well below the terrain surface.
    if game_started and is_instance_valid(world) and is_instance_valid(player):
        cave_probe_timer += delta
        if cave_probe_timer >= 0.2:
            cave_probe_timer = 0.0
            var light_probe: Vector3 = player.global_position + Vector3(0.0, 0.7, 0.0)
            var depth: float = world.depth_below_surface(light_probe)
            cave_target = clampf((depth - 2.0) / 6.0, 0.0, 1.0)
            target_sky_exposure = world.sky_exposure_at(light_probe)
        cave_blend = lerpf(cave_blend, cave_target, minf(1.0, 1.6 * delta))
        local_sky_exposure = lerpf(local_sky_exposure, target_sky_exposure, minf(1.0, 3.5 * delta))
    else:
        cave_blend = 0.0
        target_sky_exposure = 1.0
        local_sky_exposure = lerpf(local_sky_exposure, 1.0, minf(1.0, 2.0 * delta))
    var light: Color = _compute_world_light()
    var change: float = absf(light.r - applied_light.r) + absf(light.g - applied_light.g) + absf(light.b - applied_light.b)
    if change > 0.004:
        applied_light = light
        if is_instance_valid(world):
            world.set_light_color(day_night.sky_light_tint())
        if is_instance_valid(player):
            player.set_world_light(light)
    if game_started and is_instance_valid(hud):
        clock_timer += delta
        if clock_timer >= 1.0:
            clock_timer = 0.0
            hud.set_time_text("День %d  ·  %s" % [day_night.day_count + 1, day_night.clock_text()])

func _update_sunlight() -> void:
    if not is_instance_valid(sun_light):
        return
    var sun_dir: Vector3 = day_night.sun_direction().normalized()
    sun_light.global_basis = Basis.looking_at(-sun_dir, Vector3.BACK)
    var elevation: float = day_night.sun_elevation()
    var daylight_amount: float = smoothstep(-0.08, 0.28, elevation)
    sun_light.light_energy = lerpf(0.0, 0.62, daylight_amount)
    var warm_amount: float = day_night.twilight() * 0.62
    sun_light.light_color = Color(1.0, 0.96, 0.89).lerp(Color(1.0, 0.63, 0.40), warm_amount)
    sun_light.visible = elevation > -0.12

func _show_title_menu() -> void:
    if is_instance_valid(title_layer):
        title_layer.queue_free()
    menu_popup = null
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    title_layer = CanvasLayer.new()
    title_layer.name = "ReCraftMainMenu"
    title_layer.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(title_layer)

    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    title_layer.add_child(root)

    var background := TextureRect.new()
    background.texture = load("res://assets/sprites/recraft_menu_background.png") as Texture2D
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    background.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    root.add_child(background)

    var tint := ColorRect.new()
    tint.color = Color(0.035, 0.055, 0.10, 0.18)
    tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(tint)

    var brand := Label.new()
    brand.text = "+   RECRAFT"
    brand.position = Vector2(34, 22)
    brand.size = Vector2(270, 30)
    brand.add_theme_font_size_override("font_size", 14)
    brand.add_theme_color_override("font_color", Color("e2eafa"))
    root.add_child(brand)

    var status := Label.new()
    status.text = "●  ОДИНОЧНЫЙ МИР"
    status.anchor_left = 1.0
    status.anchor_right = 1.0
    status.offset_left = -300
    status.offset_right = -32
    status.offset_top = 22
    status.offset_bottom = 50
    status.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    status.add_theme_font_size_override("font_size", 13)
    status.add_theme_color_override("font_color", Color("eef2ff"))
    root.add_child(status)

    var title := Label.new()
    title.text = "ReCraft"
    title.anchor_left = 0.0
    title.anchor_right = 1.0
    title.offset_top = 116
    title.offset_bottom = 190
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 58)
    title.add_theme_color_override("font_color", Color("f5f8ff"))
    title.add_theme_color_override("font_shadow_color", Color(0.05, 0.08, 0.18, 0.7))
    title.add_theme_constant_override("shadow_offset_x", 2)
    title.add_theme_constant_override("shadow_offset_y", 3)
    root.add_child(title)

    var subtitle := Label.new()
    subtitle.text = "ИГРАЙ  ·  СОЗДАВАЙ  ·  ИССЛЕДУЙ"
    subtitle.anchor_left = 0.0
    subtitle.anchor_right = 1.0
    subtitle.offset_top = 190
    subtitle.offset_bottom = 225
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.add_theme_font_size_override("font_size", 14)
    subtitle.add_theme_color_override("font_color", Color("e2e9f6"))
    root.add_child(subtitle)

    var menu_box := VBoxContainer.new()
    menu_box.name = "MenuButtons"
    menu_box.anchor_left = 0.5
    menu_box.anchor_right = 0.5
    menu_box.anchor_top = 0.5
    menu_box.anchor_bottom = 0.5
    menu_box.offset_left = -180
    menu_box.offset_right = 180
    menu_box.offset_top = -18
    menu_box.offset_bottom = 244
    menu_box.add_theme_constant_override("separation", 10)
    root.add_child(menu_box)
    menu_box.add_child(_make_menu_button("ИГРАТЬ    ›", _open_play_panel, true))
    menu_box.add_child(_make_menu_button("ПРОФИЛЬ    ›", _open_profile_panel))
    menu_box.add_child(_make_menu_button("НАСТРОЙКИ    ›", _open_settings_panel))
    menu_box.add_child(_make_menu_button("ВЫХОД    ›", func(): get_tree().quit()))

    var version := Label.new()
    version.text = "v2.0.0"
    version.position = Vector2(34, -39)
    version.anchor_top = 1.0
    version.anchor_bottom = 1.0
    version.size = Vector2(120, 26)
    version.add_theme_font_size_override("font_size", 12)
    version.add_theme_color_override("font_color", Color("ecf0ff"))
    root.add_child(version)

    var footer := Label.new()
    footer.text = "ReCraft"
    footer.anchor_left = 1.0
    footer.anchor_right = 1.0
    footer.offset_left = -200
    footer.offset_right = -34
    footer.anchor_top = 1.0
    footer.anchor_bottom = 1.0
    footer.offset_top = -39
    footer.offset_bottom = -13
    footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    footer.add_theme_font_size_override("font_size", 12)
    footer.add_theme_color_override("font_color", Color("ecf0ff"))
    root.add_child(footer)

func _make_panel_style(background_color: Color, border_color: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = background_color
    style.border_color = border_color
    style.set_border_width_all(1)
    style.set_corner_radius_all(2)
    style.content_margin_left = 18
    style.content_margin_right = 18
    style.content_margin_top = 12
    style.content_margin_bottom = 12
    return style

func _make_menu_button(caption: String, callback: Callable, primary: bool = false) -> Button:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(360, 48)
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size", 15)
    button.add_theme_color_override("font_color", Color("f5f7ff"))
    var normal_color: Color = Color("657df0", 0.94) if primary else Color(0.035, 0.07, 0.15, 0.77)
    var hover_color: Color = Color("7891ff", 0.98) if primary else Color(0.10, 0.16, 0.27, 0.93)
    button.add_theme_stylebox_override("normal", _make_panel_style(normal_color, Color(0.64, 0.74, 1.0, 0.28)))
    button.add_theme_stylebox_override("hover", _make_panel_style(hover_color, Color("dce5ff")))
    button.add_theme_stylebox_override("pressed", _make_panel_style(Color("4f65cc"), Color("eff3ff")))
    button.pressed.connect(callback)
    return button

func _make_popup(title_text: String, width: float = 390.0, height: float = 290.0) -> VBoxContainer:
    if is_instance_valid(menu_popup):
        menu_popup.queue_free()
    menu_popup = PanelContainer.new()
    menu_popup.name = "MenuPopup"
    menu_popup.anchor_left = 0.5
    menu_popup.anchor_right = 0.5
    menu_popup.anchor_top = 0.5
    menu_popup.anchor_bottom = 0.5
    menu_popup.offset_left = -width * 0.5
    menu_popup.offset_right = width * 0.5
    menu_popup.offset_top = -height * 0.5
    menu_popup.offset_bottom = height * 0.5
    menu_popup.custom_minimum_size = Vector2(width, height)
    menu_popup.add_theme_stylebox_override("panel", _make_panel_style(Color(0.035, 0.055, 0.105, 0.92), Color(0.76, 0.83, 1.0, 0.55)))
    title_layer.add_child(menu_popup)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    menu_popup.add_child(box)
    var heading := Label.new()
    heading.text = title_text
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    heading.add_theme_font_size_override("font_size", 24)
    heading.add_theme_color_override("font_color", Color("f4f7ff"))
    box.add_child(heading)
    return box

func _open_play_panel() -> void:
    var box := _make_popup("ИГРАТЬ")
    box.add_child(_make_menu_button("НОВЫЙ МИР", func(): _start_game(false), true))
    var continue_button := _make_menu_button("ПРОДОЛЖИТЬ", func(): _start_game(true))
    continue_button.disabled = not FileAccess.file_exists(SAVE_PATH)
    box.add_child(continue_button)
    box.add_child(_make_menu_button("НАЗАД", _close_menu_popup))

func _open_profile_panel() -> void:
    var box := _make_popup("ПРОФИЛЬ", 390.0, 470.0)
    var preview_holder := CenterContainer.new()
    box.add_child(preview_holder)
    var skin_preview = SkinPreviewScript.new()
    skin_preview.setup(PlayerModelScript.load_skin_texture(), Vector2(190, 270), true, true)
    preview_holder.add_child(skin_preview)
    var label := Label.new()
    label.text = "ИГРОК\nТвой скин"
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 15)
    label.add_theme_color_override("font_color", Color("e2eafa"))
    box.add_child(label)
    box.add_child(_make_menu_button("ГОТОВО", _close_menu_popup, true))

func _open_settings_panel() -> void:
    var box := _make_popup("НАСТРОЙКИ")
    var label := Label.new()
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 15)
    label.add_theme_color_override("font_color", Color("e2eafa"))
    label.name = "RenderDistanceLabel"
    _update_render_distance_label(label)
    box.add_child(label)
    var controls := HBoxContainer.new()
    controls.add_theme_constant_override("separation", 8)
    var less := _make_menu_button("−", func(): _change_render_distance(-1))
    less.custom_minimum_size = Vector2(70, 42)
    var more := _make_menu_button("+", func(): _change_render_distance(1))
    more.custom_minimum_size = Vector2(70, 42)
    controls.add_child(less)
    controls.add_child(more)
    box.add_child(controls)
    box.add_child(_make_menu_button("ГОТОВО", _close_menu_popup, true))

func _update_render_distance_label(label: Label) -> void:
    if is_instance_valid(label):
        label.text = "Дальность прорисовки: %d чанков (%d блоков)" % [preferred_view_distance, preferred_view_distance * 16]

func _change_render_distance(delta_value: int) -> void:
    preferred_view_distance = clampi(preferred_view_distance + delta_value, 2, 12)
    _save_settings()
    if not is_instance_valid(menu_popup):
        return
    var label := menu_popup.find_child("RenderDistanceLabel", true, false) as Label
    _update_render_distance_label(label)

func _close_menu_popup() -> void:
    if is_instance_valid(menu_popup):
        menu_popup.queue_free()
    menu_popup = null

func _start_game(continue_save: bool) -> void:
    var save_data: Dictionary = {}
    if continue_save:
        save_data = _read_save()
        if save_data.is_empty():
            notify("Сохранение не найдено или повреждено. Создаём новый мир.")
        elif int(save_data.get("version", 0)) < 4:
            # Мир старого формата несовместим с новой генерацией: сохраняем только вещи игрока.
            save_data.erase("world_changes")
            save_data.erase("world_seed")
            var old_player: Variant = save_data.get("player", {})
            if old_player is Dictionary:
                old_player.erase("position")
    if is_instance_valid(title_layer):
        title_layer.queue_free()
        title_layer = null

    var random := RandomNumberGenerator.new()
    random.randomize()
    world_seed = int(save_data.get("world_seed", random.randi_range(100000, 2000000000)))
    day_night.set_time(float(save_data.get("time_ticks", DayNight.START_TICK)), int(save_data.get("day_count", 0)))
    cave_blend = 0.0
    cave_target = 0.0
    applied_light = Color(-1.0, -1.0, -1.0)
    world = WorldScript.new()
    world.name = "ReCraftWorld"
    world.view_distance_chunks = preferred_view_distance
    add_child(world)
    var saved_changes: Variant = save_data.get("world_changes", {})
    world.generate(world_seed, saved_changes if saved_changes is Dictionary else {})

    player = ExplorerScene.instantiate()
    player.game = self
    player.name = "Explorer"
    add_child(player)
    var saved_player: Variant = save_data.get("player", {})
    if saved_player is Dictionary:
        player.load_save_data(saved_player)
        var raw_position: Variant = saved_player.get("position", [])
        if raw_position is Array and raw_position.size() >= 3:
            # Worlds stream indefinitely in X/Z; only sanity-limit malformed save coordinates.
            var saved_x := clampf(float(raw_position[0]), -1000000.0, 1000000.0)
            var saved_z := clampf(float(raw_position[2]), -1000000.0, 1000000.0)
            var saved_y := clampf(float(raw_position[1]), float(WorldScript.MIN_Y) + 1.5, float(WorldScript.MAX_Y) + 8.0)
            player.teleport(Vector3(saved_x, saved_y, saved_z))
        else:
            player.teleport(world.get_spawn_position())
    else:
        player.teleport(world.get_spawn_position())

    world.set_stream_target(player)
    cloud_layer = CloudLayerScript.new()
    cloud_layer.name = "ReCraftCloudLayer"
    add_child(cloud_layer)
    cloud_layer.setup(world, player)
    world.cloud_layer = cloud_layer
    _configure_fog()
    hud = HudScript.new()
    add_child(hud)
    hud.setup(self, player, world)
    hud.set_creative_mode(player.creative)
    loading = true
    game_started = true
    is_paused = false
    inventory_open = false
    autosave_timer = 0.0
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
    # Persist a newly created world immediately so Continue can never reopen an older save.
    save_game(false)
    notify("Добро пожаловать в ReCraft. Исследуй мир и строй что захочешь.")

func _process(delta: float) -> void:
    _update_sky(delta)
    if game_started and loading and is_instance_valid(world) and is_instance_valid(player):
        var ready_fraction: float = world.readiness_around(player.global_position, 1)
        hud.set_loading(true, ready_fraction)
        if ready_fraction >= 0.99:
            loading = false
            hud.set_loading(false, 1.0)
    if not game_started or loading or is_paused or inventory_open:
        return
    autosave_timer += delta
    if autosave_timer >= 90.0:
        autosave_timer = 0.0
        save_game(false)

func interact() -> void:
    if not game_started or is_paused or inventory_open:
        return
    notify("Здесь нечего использовать.")

func toggle_pause(force_value: Variant = null) -> void:
    if not game_started or inventory_open:
        return
    if force_value == null:
        is_paused = not is_paused
    else:
        is_paused = bool(force_value)
    if is_paused:
        Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
        hud.set_pause_visible(true)
    else:
        hud.set_pause_visible(false)
        Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func toggle_inventory(show_now: bool) -> void:
    if not game_started or is_paused:
        return
    inventory_open = show_now
    if not show_now and is_instance_valid(player):
        player.return_loose_items()
    hud.set_inventory_visible(inventory_open)
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE if inventory_open else Input.MOUSE_MODE_CAPTURED)
    refresh_hud()

func toggle_debug() -> void:
    debug_visible = not debug_visible
    if is_instance_valid(hud):
        hud.set_debug_visible(debug_visible)

# Вызывается игроком при смене режима (C): обновляет HUD и инвентарь.
func on_creative_changed(is_creative: bool) -> void:
    if is_instance_valid(hud):
        hud.set_creative_mode(is_creative)
    refresh_hud()

func refresh_hud() -> void:
    if is_instance_valid(hud):
        hud.refresh()

func notify(message: String, duration: float = 3.2) -> void:
    if is_instance_valid(hud):
        hud.notify(message, duration)

func save_game(show_notification: bool = true) -> bool:
    if not game_started or not is_instance_valid(player) or not is_instance_valid(world):
        return false
    var data := {
        "version": 4,
        "world_seed": world_seed,
        "time_ticks": day_night.ticks,
        "day_count": day_night.day_count,
        "player": player.make_save_data(),
        "world_changes": world.export_changes()
    }
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        notify("Не удалось сохранить игру: %s" % error_string(FileAccess.get_open_error()))
        return false
    file.store_string(JSON.stringify(data, "\t"))
    file.close()
    if show_notification:
        notify("Мир сохранён.")
    return true

func _read_save() -> Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        return {}
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return {}
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    return parsed if parsed is Dictionary else {}

func player_died() -> void:
    if not is_instance_valid(hud):
        return
    is_paused = true
    inventory_open = false
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    hud.set_inventory_visible(false)
    hud.show_death()

func return_to_title() -> void:
    if game_started:
        save_game(false)
    game_started = false
    is_paused = false
    inventory_open = false
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    for node in [hud, player, world]:
        if is_instance_valid(node):
            node.queue_free()
    hud = null
    player = null
    world = null
    cave_blend = 0.0
    cave_target = 0.0
    applied_light = Color(-1.0, -1.0, -1.0)
    if is_instance_valid(scene_environment):
        scene_environment.fog_enabled = false
    _show_title_menu()

func respawn_player() -> void:
    if not is_instance_valid(player) or not is_instance_valid(world):
        return
    player.is_dead = false
    player.health = 10.0
    player.hunger = 20.0
    player.teleport(world.get_spawn_position())
    is_paused = false
    hud.hide_ending()
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
    refresh_hud()
    notify("Ты возродился у точки появления.")
