extends CanvasLayer
# First-person hand drawn in its own transparent viewport on top of the world, so it never
# clips into walls. The arm uses the player's skin (including the sleeve layer). The pose
# maths are the exact Minecraft first-person transforms (arm and held item), driven by
# swing / equip / walking-bob / mouse-sway animations.

const PM = preload("res://scripts/3d/player_model.gd")
const ItemModels = preload("res://scripts/3d/item_models.gd")

const SWING_TIME: float = 0.3
const EQUIP_SPEED: float = 5.0
const HAND_FOV: float = 70.0
const PX: float = 1.0 / 16.0

var container: SubViewportContainer
var viewport: SubViewport
var camera: Camera3D
var rig: Node3D
var arm_node: Node3D
var item_node: Node3D
var material: StandardMaterial3D
var side: float = 1.0
var slim: bool = false
var shown_item: String = ""
var target_item: String = ""
var lower: float = 0.0
var swing_active: bool = false
var swing_t: float = 0.0
var bob_phase: float = 0.0
var bob_amount: float = 0.0
var sway: Vector2 = Vector2.ZERO
var look_delta: Vector2 = Vector2.ZERO
var light_color: Color = Color.WHITE

func setup(skin: Texture2D) -> void:
    name = "FirstPersonHand"
    layer = 0
    slim = PM.is_slim(skin)
    material = PM.make_material(skin)

    container = SubViewportContainer.new()
    container.name = "HandViewportContainer"
    container.stretch = true
    container.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(container)
    container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    viewport = SubViewport.new()
    viewport.name = "HandViewport"
    viewport.transparent_bg = true
    viewport.own_world_3d = true
    viewport.msaa_3d = Viewport.MSAA_DISABLED
    viewport.gui_disable_input = true
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    container.add_child(viewport)

    camera = Camera3D.new()
    camera.name = "HandCamera"
    camera.fov = HAND_FOV
    camera.near = 0.02
    camera.far = 20.0
    camera.current = true
    viewport.add_child(camera)

    rig = Node3D.new()
    rig.name = "HandRig"
    viewport.add_child(rig)

    arm_node = Node3D.new()
    arm_node.name = "Arm"
    rig.add_child(arm_node)
    var arm_w: float = 3.0 if slim else 4.0
    var off_x: float = (0.5 if slim else 1.0) * side
    var arm_uv: Vector2 = Vector2(40, 16) if side > 0.0 else Vector2(32, 48)
    var sleeve_uv: Vector2 = Vector2(40, 32) if side > 0.0 else Vector2(48, 48)
    var base := MeshInstance3D.new()
    base.name = "ArmBase"
    base.mesh = PM.make_box_mesh(Vector3(arm_w, 12, 4), arm_uv, 0.0, PX)
    base.material_override = material
    base.position = Vector3(off_x * PX, -4.0 * PX, 0.0)
    base.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    arm_node.add_child(base)
    var sleeve := MeshInstance3D.new()
    sleeve.name = "ArmSleeve"
    sleeve.mesh = PM.make_box_mesh(Vector3(arm_w, 12, 4), sleeve_uv, 0.25, PX)
    sleeve.material_override = material
    sleeve.position = base.position
    sleeve.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    arm_node.add_child(sleeve)

    item_node = Node3D.new()
    item_node.name = "HeldItem"
    rig.add_child(item_node)
    _apply_poses(0.0)

func set_active(active: bool) -> void:
    visible = active
    if viewport != null:
        viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS if active else SubViewport.UPDATE_DISABLED

func swing() -> void:
    swing_active = true
    swing_t = 0.0

func is_swinging() -> bool:
    return swing_active

func add_look(relative: Vector2) -> void:
    look_delta += relative

func set_light(color: Color) -> void:
    light_color = color
    if material != null:
        material.albedo_color = color
    if item_node != null:
        for child in item_node.get_children():
            ItemModels.apply_light(child, color)

func _show_item(item_id: String) -> void:
    shown_item = item_id
    for child in item_node.get_children():
        child.queue_free()
    if item_id == "":
        return
    var model: Node3D = ItemModels.build(item_id)
    if model == null:
        return
    item_node.add_child(model)
    ItemModels.apply_light(model, light_color)

func update_hand(delta: float, horizontal_speed: float, grounded: bool, wanted_item: String) -> void:
    if rig == null:
        return
    target_item = wanted_item
    if shown_item != target_item:
        lower = minf(1.0, lower + EQUIP_SPEED * delta)
        if lower >= 1.0:
            _show_item(target_item)
    else:
        lower = maxf(0.0, lower - EQUIP_SPEED * delta)

    var swing_progress: float = 0.0
    if swing_active:
        swing_t += delta / SWING_TIME
        if swing_t >= 1.0:
            swing_active = false
            swing_t = 0.0
        else:
            swing_progress = swing_t

    var walking: bool = grounded and horizontal_speed > 0.5
    var bob_target: float = minf(horizontal_speed / 5.4, 1.0) * 0.1 if walking else 0.0
    bob_amount = lerpf(bob_amount, bob_target, minf(1.0, 8.0 * delta))
    if walking:
        bob_phase += horizontal_speed * delta * 0.55
    var bob_x: float = sin(bob_phase * PI) * bob_amount * 0.5
    var bob_y: float = -absf(cos(bob_phase * PI)) * bob_amount
    var bob_rz: float = sin(bob_phase * PI) * bob_amount * deg_to_rad(3.0)
    var bob_rx: float = absf(cos(bob_phase * PI - 0.2)) * bob_amount * deg_to_rad(5.0)

    var target_sway := Vector2(clampf(look_delta.x * 0.0022, -0.12, 0.12), clampf(look_delta.y * 0.0022, -0.12, 0.12))
    look_delta = Vector2.ZERO
    sway = sway.lerp(target_sway, minf(1.0, 14.0 * delta))

    rig.transform = Transform3D(Basis.from_euler(Vector3(sway.y + bob_rx, sway.x, bob_rz)), Vector3(bob_x, bob_y, 0.0))
    _apply_poses(swing_progress)

func _apply_poses(swing_progress: float) -> void:
    arm_node.transform = _arm_transform(swing_progress)
    item_node.visible = shown_item != ""
    if shown_item != "":
        item_node.transform = _item_transform(swing_progress, ItemModels.is_flat(shown_item))

# Minecraft's first-person arm transform (ItemRenderer.renderArmHoldingItem).
func _arm_transform(swing_progress: float) -> Transform3D:
    var f: float = side
    var g: float = sqrt(swing_progress)
    var h: float = -0.3 * sin(g * PI)
    var i: float = 0.4 * sin(g * TAU)
    var j: float = -0.4 * sin(swing_progress * PI)
    var t := Transform3D.IDENTITY
    t = t.translated_local(Vector3(f * (h + 0.64000005), i - 0.6 - lower * 0.6, j - 0.71999997))
    t = t.rotated_local(Vector3.UP, deg_to_rad(f * 45.0))
    var k: float = sin(swing_progress * swing_progress * PI)
    var l: float = sin(g * PI)
    t = t.rotated_local(Vector3.UP, deg_to_rad(f * l * 70.0))
    t = t.rotated_local(Vector3.BACK, deg_to_rad(f * k * -20.0))
    t = t.translated_local(Vector3(f * -1.0, 3.6, 3.5))
    t = t.rotated_local(Vector3.BACK, deg_to_rad(f * 120.0))
    t = t.rotated_local(Vector3.RIGHT, deg_to_rad(200.0))
    t = t.rotated_local(Vector3.UP, deg_to_rad(f * -135.0))
    t = t.translated_local(Vector3(f * 5.6, 0.0, 0.0))
    # Shoulder pivot of the arm model (model space is Y-down, hence the half turn about Z).
    var pivot_y: float = 2.5 if slim else 2.0
    t = t.translated_local(Vector3(f * -5.0 * PX, pivot_y * PX, 0.0))
    t = t.rotated_local(Vector3.BACK, PI)
    return t

# Minecraft's first-person item transform (applyEquipOffset + applySwingOffset + display).
func _item_transform(swing_progress: float, flat: bool) -> Transform3D:
    var f: float = side
    var g: float = sqrt(swing_progress)
    var v: float = -0.4 * sin(g * PI)
    var w: float = 0.2 * sin(g * TAU)
    var x: float = -0.2 * sin(swing_progress * PI)
    var t := Transform3D.IDENTITY
    t = t.translated_local(Vector3(f * v, w, x))
    t = t.translated_local(Vector3(f * 0.56, -0.52 - lower * 0.6, -0.72))
    var k: float = sin(swing_progress * swing_progress * PI)
    t = t.rotated_local(Vector3.UP, deg_to_rad(f * (45.0 + k * -20.0)))
    var l: float = sin(g * PI)
    t = t.rotated_local(Vector3.BACK, deg_to_rad(f * l * -20.0))
    t = t.rotated_local(Vector3.RIGHT, deg_to_rad(l * -80.0))
    t = t.rotated_local(Vector3.UP, deg_to_rad(f * -45.0))
    if flat:
        var held_scale: float = 0.56
        if shown_item == "pickaxe":
            held_scale = 0.48
        elif shown_item == "berries" or shown_item == "salve":
            held_scale = 0.54
        t = t.translated_local(Vector3(f * 1.13 * PX, 3.2 * PX, 1.13 * PX))
        t = t.rotated_local(Vector3.UP, deg_to_rad(f * -90.0))
        t = t.rotated_local(Vector3.BACK, deg_to_rad(20.0 if shown_item == "pickaxe" else 25.0))
        t = t.scaled_local(Vector3.ONE * held_scale)
    else:
        t = t.translated_local(Vector3(0.0, 0.06, 0.0))
        t = t.rotated_local(Vector3.UP, deg_to_rad(f * 45.0))
        t = t.scaled_local(Vector3(0.4, 0.4, 0.4))
    return t
