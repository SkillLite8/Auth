extends Node3D

const CLOUD_COUNT: int = 18
const RECYCLE_DISTANCE: float = 170.0
const WIND_MIN: float = 0.22
const WIND_MAX: float = 0.48

var world_ref
var player_ref
var cloud_entries: Array = []
var solid_cells: Dictionary = {}
var cloud_material: StandardMaterial3D
var cloud_mesh: BoxMesh
var rng := RandomNumberGenerator.new()
var cloud_altitude: int = 112

func setup(world, player) -> void:
    world_ref = world
    player_ref = player
    rng.randomize()
    _make_resources()
    var base_x: int = floori(player.global_position.x + 0.5)
    var base_z: int = floori(player.global_position.z + 0.5)
    var terrain_height: int = world.height_at(base_x, base_z)
    cloud_altitude = clampi(terrain_height + 48, 92, 154)
    for i in range(CLOUD_COUNT):
        var offsets: Array = _make_cloud_shape()
        var cloud_root := Node3D.new()
        cloud_root.name = "Cloud_%02d" % i
        cloud_root.position = Vector3(
            base_x + rng.randf_range(-125.0, 125.0),
            cloud_altitude + rng.randi_range(-4, 5),
            base_z + rng.randf_range(-125.0, 125.0)
        )
        add_child(cloud_root)
        var multi := MultiMesh.new()
        multi.transform_format = MultiMesh.TRANSFORM_3D
        multi.use_colors = true
        multi.mesh = cloud_mesh
        multi.instance_count = offsets.size()
        for j in range(offsets.size()):
            var offset: Vector3i = offsets[j]
            multi.set_instance_transform(j, Transform3D(Basis.IDENTITY, Vector3(offset)))
            var shade: float = rng.randf_range(0.91, 1.0)
            multi.set_instance_color(j, Color(shade, shade, minf(1.0, shade + 0.025), 1.0))
        var cloud_mesh_instance := MultiMeshInstance3D.new()
        cloud_mesh_instance.name = "CloudVolume"
        cloud_mesh_instance.multimesh = multi
        cloud_mesh_instance.material_override = cloud_material
        cloud_mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        cloud_root.add_child(cloud_mesh_instance)
        cloud_entries.append({
            "node": cloud_root,
            "offsets": offsets,
            "speed": rng.randf_range(WIND_MIN, WIND_MAX) * (1.0 if rng.randf() > 0.5 else -1.0),
            "drift_z": rng.randf_range(-0.085, 0.085)
        })
    _rebuild_collision_cells()

func _make_resources() -> void:
    cloud_mesh = BoxMesh.new()
    cloud_mesh.size = Vector3(1.02, 1.02, 1.02)
    cloud_material = StandardMaterial3D.new()
    cloud_material.albedo_color = Color(0.96, 0.975, 1.0)
    cloud_material.vertex_color_use_as_albedo = true
    cloud_material.roughness = 1.0
    cloud_material.metallic = 0.0
    cloud_material.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
    cloud_material.cull_mode = BaseMaterial3D.CULL_BACK

func _make_cloud_shape() -> Array:
    var offsets: Array = []
    var radius_x: int = rng.randi_range(4, 9)
    var radius_z: int = rng.randi_range(3, 6)
    var layers: int = rng.randi_range(2, 4)
    for y in range(layers):
        var shrink: float = 1.0 - float(y) * rng.randf_range(0.11, 0.19)
        var rx: float = maxf(2.0, float(radius_x) * shrink)
        var rz: float = maxf(2.0, float(radius_z) * shrink)
        var shift_x: int = rng.randi_range(-1, 1)
        var shift_z: int = rng.randi_range(-1, 1)
        for x in range(-radius_x, radius_x + 1):
            for z in range(-radius_z, radius_z + 1):
                var nx: float = float(x - shift_x) / rx
                var nz: float = float(z - shift_z) / rz
                var distance: float = nx * nx + nz * nz
                if distance > 1.05:
                    continue
                if distance > 0.68 and rng.randf() < 0.28:
                    continue
                if y > 0 and distance > 0.42 and rng.randf() < 0.18:
                    continue
                offsets.append(Vector3i(x, y, z))
    if offsets.is_empty():
        offsets.append(Vector3i.ZERO)
    return offsets

func _process(delta: float) -> void:
    if cloud_entries.is_empty():
        return
    var player_position: Vector3 = player_ref.global_position if is_instance_valid(player_ref) else Vector3.ZERO
    var collision_grid_changed: bool = false
    for entry_variant in cloud_entries:
        var entry: Dictionary = entry_variant
        var node: Node3D = entry["node"]
        var old_origin := Vector3i(roundi(node.position.x), roundi(node.position.y), roundi(node.position.z))
        node.position.x += float(entry["speed"]) * delta
        node.position.z += float(entry["drift_z"]) * delta
        var far_x: float = node.position.x - player_position.x
        var far_z: float = node.position.z - player_position.z
        if far_x * far_x + far_z * far_z > RECYCLE_DISTANCE * RECYCLE_DISTANCE:
            node.position.x = player_position.x + rng.randf_range(-125.0, 125.0)
            node.position.z = player_position.z + rng.randf_range(-125.0, 125.0)
            node.position.y = cloud_altitude + rng.randi_range(-4, 5)
        var new_origin := Vector3i(roundi(node.position.x), roundi(node.position.y), roundi(node.position.z))
        if new_origin != old_origin:
            collision_grid_changed = true
    if collision_grid_changed:
        _rebuild_collision_cells()

func _rebuild_collision_cells() -> void:
    solid_cells.clear()
    for entry_variant in cloud_entries:
        var entry: Dictionary = entry_variant
        var node: Node3D = entry["node"]
        var origin := Vector3i(roundi(node.position.x), roundi(node.position.y), roundi(node.position.z))
        for offset_variant in entry["offsets"]:
            var offset: Vector3i = offset_variant
            solid_cells[origin + offset] = true

func is_cloud_solid(x: int, y: int, z: int) -> bool:
    return solid_cells.has(Vector3i(x, y, z))
