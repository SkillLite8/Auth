extends RefCounted
# Каталог предметов: обычные предметы (кирка, аптечка, ягоды) + все блоки из реестра.
# Блоки хранятся в инвентаре под своим именем (id блока = имя предмета).

const B = preload("res://scripts/3d/block_registry.gd")
const Atlas = preload("res://scripts/3d/atlas_data.gd")

const ITEM_DIR: String = "res://assets/textures/items/"
const UI_DIR: String = "res://assets/textures/ui/"
const ATLAS_PATH: String = "res://assets/atlas/blocks_atlas.png"
const ICONS_PATH: String = "res://assets/atlas/icons_atlas.png"

const ITEM_NAMES: Dictionary = {
    "pickaxe": "Кирка",
    "salve": "Аптечка",
    "berries": "Ягоды",
    "iron_helmet": "Железный шлем",
    "iron_chestplate": "Железный нагрудник",
    "iron_leggings": "Железные поножи",
    "iron_boots": "Железные ботинки"
}
const PLAIN_ITEMS: Array = [
    "pickaxe", "salve", "berries",
    "iron_helmet", "iron_chestplate", "iron_leggings", "iron_boots"
]

static var _icon_cache: Dictionary = {}
static var _tile_cache: Dictionary = {}
static var _icons_texture: Texture2D = null
static var _atlas_image: Image = null

static func normalize_item(item_id: String) -> String:
    if PLAIN_ITEMS.has(item_id) or item_id == "":
        return item_id
    var block_id: int = B.id_of(item_id)
    if block_id > 0:
        return B.names[block_id]
    return item_id

static func is_known_item(item_id: String) -> bool:
    return PLAIN_ITEMS.has(item_id) or B.is_placeable_name(item_id)

static func item_name(item_id: String) -> String:
    if ITEM_NAMES.has(item_id):
        return str(ITEM_NAMES[item_id])
    return B.ru_name(item_id)

static func is_flat_item(item_id: String) -> bool:
    if PLAIN_ITEMS.has(item_id):
        return true
    var block_id: int = B.id_of(item_id)
    return block_id > 0 and B.render[block_id] == B.R_CROSS

static func icon(item_id: String) -> Texture2D:
    if _icon_cache.has(item_id):
        return _icon_cache[item_id]
    var result: Texture2D = null
    if PLAIN_ITEMS.has(item_id):
        var path: String = ITEM_DIR + item_id + ".png"
        if ResourceLoader.exists(path):
            result = load(path) as Texture2D
    else:
        var block_id: int = B.id_of(item_id)
        if block_id > 0:
            if _icons_texture == null:
                _icons_texture = load(ICONS_PATH) as Texture2D
            var atlas_tex := AtlasTexture.new()
            atlas_tex.atlas = _icons_texture
            var cell: int = Atlas.ICON_SIZE
            atlas_tex.region = Rect2(float((block_id % Atlas.ICON_COLS) * cell), float((block_id / Atlas.ICON_COLS) * cell), float(cell), float(cell))
            result = atlas_tex
    _icon_cache[item_id] = result
    return result

static func _get_atlas_image() -> Image:
    if _atlas_image == null:
        var tex: Texture2D = load(ATLAS_PATH) as Texture2D
        _atlas_image = tex.get_image()
        if _atlas_image.is_compressed():
            _atlas_image.decompress()
        _atlas_image.convert(Image.FORMAT_RGBA8)
    return _atlas_image

# Квадрат 16x16 из атласа по имени тайла.
static func tile_image(tile_name: String) -> Image:
    var index: int = int(Atlas.TILES.get(tile_name, 0))
    var size: int = Atlas.TILE_SIZE
    return _get_atlas_image().get_region(Rect2i((index % Atlas.ATLAS_COLS) * size, (index / Atlas.ATLAS_COLS) * size, size, size))

static func tile_texture(tile_name: String) -> Texture2D:
    if _tile_cache.has(tile_name):
        return _tile_cache[tile_name]
    var tex: Texture2D = ImageTexture.create_from_image(tile_image(tile_name))
    _tile_cache[tile_name] = tex
    return tex

# Изображение для плоской модели в руке (инструменты, еда, растения, факел).
static func flat_image(item_id: String) -> Image:
    if PLAIN_ITEMS.has(item_id):
        var tex: Texture2D = icon(item_id)
        if tex == null:
            return null
        var img: Image = tex.get_image()
        if img.is_compressed():
            img.decompress()
        img.convert(Image.FORMAT_RGBA8)
        return img
    var block_id: int = B.id_of(item_id)
    if block_id <= 0:
        return null
    return tile_image(B.tile_name(block_id, 1))

static func ui_texture(texture_name: String) -> Texture2D:
    var path: String = UI_DIR + texture_name + ".png"
    if not ResourceLoader.exists(path):
        return null
    return load(path) as Texture2D

static func max_stack(item_id: String) -> int:
    if item_id == "pickaxe" or is_armor_item(item_id):
        return 1
    return 64

static func is_armor_item(item_id: String) -> bool:
    return item_id in ["iron_helmet", "iron_chestplate", "iron_leggings", "iron_boots"]

static func armor_slot(item_id: String) -> int:
    match item_id:
        "iron_helmet":
            return 0
        "iron_chestplate":
            return 1
        "iron_leggings":
            return 2
        "iron_boots":
            return 3
    return -1

static func block_kind(item_id: String) -> String:
    if B.is_placeable_name(item_id):
        return item_id
    return ""

static func drop_for_block(kind: String) -> String:
    match kind:
        "grass":
            return "dirt"
        "stone":
            return "cobblestone"
        "water", "air", "bedrock":
            return ""
    if kind.ends_with("_leaves"):
        var roll: float = randf()
        if roll < 0.12:
            return "berries"
        if roll < 0.20:
            return kind.trim_suffix("_leaves") + "_sapling"
        return kind
    if B.is_placeable_name(kind):
        return kind
    return ""

# Предметы для творческого инвентаря: [id, категория]
static func creative_entries() -> Array:
    var out: Array = []
    for plain in PLAIN_ITEMS:
        out.append([plain, "misc"])
    for block_name in B.creative_items():
        var block_id: int = B.id_of(str(block_name))
        out.append([str(block_name), B.categories[block_id]])
    return out
