#!/usr/bin/env python3
"""Static integrity checks for the ReCraft Godot project (does not replace a Godot runtime test)."""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

for rel in ("project.godot", "scenes/main.tscn", "scripts/main.gd", ".github/workflows/build-windows.yml", "export_presets.cfg"):
    if not (ROOT / rel).is_file():
        errors.append(f"Missing required file: {rel}")

for json_rel in ("data/items.json", "data/recipes.json"):
    try:
        with (ROOT / json_rel).open(encoding="utf-8") as f:
            json.load(f)
    except Exception as exc:
        errors.append(f"Invalid JSON {json_rel}: {exc}")

# Every explicit res:// reference in scene and script files must resolve.
gd_sources = list(ROOT.rglob("*.gd"))
for path in list(ROOT.rglob("*.tscn")) + gd_sources + [ROOT / "project.godot"]:
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8")
    for value in re.findall(r'res://([^"\']+)', text):
        target = ROOT / value
        if not target.exists():
            errors.append(f"Broken resource reference in {path.relative_to(ROOT)}: res://{value}")

try:
    items = json.loads((ROOT / "data/items.json").read_text(encoding="utf-8"))
    recipes = json.loads((ROOT / "data/recipes.json").read_text(encoding="utf-8"))
    for recipe_id, recipe in recipes.items():
        for item_id in recipe.get("ingredients", {}):
            if item_id not in items:
                errors.append(f"Recipe {recipe_id} refers to unknown ingredient {item_id}")
        result_id = recipe.get("result", {}).get("id")
        if result_id not in items:
            errors.append(f"Recipe {recipe_id} refers to unknown result {result_id}")
    for item_id, item in items.items():
        if not isinstance(item, dict):
            errors.append(f"Item {item_id} must be an object")
            continue
        if not isinstance(item.get("name"), str) or not item.get("name", "").strip():
            errors.append(f"Item {item_id} has no display name")
        if int(item.get("max_stack", 0)) < 1:
            errors.append(f"Item {item_id} has invalid max_stack")
        icon = int(item.get("icon", -1))
        if not 0 <= icon < 16:
            errors.append(f"Item {item_id} has icon index outside the 8x2 icon atlas")
    for recipe_id, recipe in recipes.items():
        if not isinstance(recipe, dict):
            errors.append(f"Recipe {recipe_id} must be an object")
            continue
        ingredients = recipe.get("ingredients", {})
        if not isinstance(ingredients, dict) or not ingredients:
            errors.append(f"Recipe {recipe_id} has no valid ingredients")
            continue
        for item_id, amount in ingredients.items():
            if int(amount) <= 0:
                errors.append(f"Recipe {recipe_id} has a non-positive amount for {item_id}")
except Exception as exc:
    errors.append(f"Data validation error: {exc}")

# Guard against the Godot Node.get_name() override that previously stopped ItemDB compiling.
for path in gd_sources:
    source = path.read_text(encoding="utf-8")
    if re.search(r"^\s*func\s+get_name\s*\(", source, re.MULTILINE):
        errors.append(f"{path.relative_to(ROOT)} overrides native Node.get_name(); use a domain-specific name")
    if "ItemDB.get_name(" in source:
        errors.append(f"{path.relative_to(ROOT)} calls the conflicting ItemDB.get_name() method")

item_db_source = (ROOT / "scripts/systems/item_database.gd").read_text(encoding="utf-8")
item_db_methods = set(re.findall(r"^\s*func\s+(\w+)\s*\(", item_db_source, re.MULTILINE))
for path in gd_sources:
    source = path.read_text(encoding="utf-8")
    for method in re.findall(r"\bItemDB\.(\w+)\s*\(", source):
        if method not in item_db_methods:
            errors.append(f"{path.relative_to(ROOT)} calls unknown ItemDB method: {method}")

# Ensure the exported project now launches the 3D first-person expedition.
project_settings = (ROOT / "project.godot").read_text(encoding="utf-8")
if 'run/main_scene="res://scenes/main_3d.tscn"' not in project_settings:
    errors.append("Default main scene is not the new 3D expedition")
for rel in ("scenes/main_3d.tscn", "scenes/3d/explorer.tscn", "scripts/3d/expedition_game.gd", "scripts/3d/voxel_world.gd", "scripts/3d/explorer.gd", "scripts/3d/voxel_hud.gd", "tools/smoke_test_3d.gd", "shaders/recraft_sky.gdshader", "assets/sky/clouds.png", "assets/sky/sun.png", "assets/sky/moon.png", "assets/skins/default_skin.png", "assets/sprites/recraft_menu_background.png"):
    if not (ROOT / rel).is_file():
        errors.append(f"Missing 3D game file: {rel}")

movement_source = (ROOT / "scripts/3d/explorer.gd").read_text(encoding="utf-8")
for key in ("KEY_W", "KEY_A", "KEY_S", "KEY_D"):
    if f"is_physical_key_pressed({key})" not in movement_source:
        errors.append(f"3D keyboard movement is missing {key}")
if "jump_buffer_timer = JUMP_BUFFER_SECONDS" not in movement_source:
    errors.append("Space jump input is not buffered")
if 'config/name="ReCraft"' not in project_settings:
    errors.append("Godot project name is not ReCraft")
world_source = (ROOT / "scripts/3d/voxel_world.gd").read_text(encoding="utf-8")
for expected in ("CHUNK_SIZE", "VIEW_DISTANCE_CHUNKS", "MIN_Y: int = -64", "MAX_Y: int = 320", "SEA_LEVEL: int = 63", "_load_chunk", "_unload_distant_chunks", "_build_water_mesh", "_ore_kind_at", "_surface_material_key"):
    if expected not in world_source:
        errors.append(f"Streamed voxel-world feature is missing: {expected}")
if '"voxel_chunks"' not in world_source:
    errors.append("Chunk collision groups were not found")

# Ensure every texture named by the block-face table exists in the project.
texture_table_match = re.search(r"const TEXTURED_BLOCKS: Dictionary = \{(.*?)\n\}", world_source, re.DOTALL)
if not texture_table_match:
    errors.append("Block texture table could not be found")
else:
    for face_texture_list in re.findall(r": \[(.*?)\]", texture_table_match.group(1)):
        for texture_name in re.findall(r'"([a-z0-9_]+)"', face_texture_list):
            texture_path = ROOT / "assets" / "textures" / "blocks" / f"{texture_name}.png"
            if not texture_path.is_file():
                errors.append(f"Missing block texture: {texture_path.relative_to(ROOT)}")
for water_index in range(5):
    if not (ROOT / "assets" / "textures" / "blocks" / f"water_{water_index}.png").is_file():
        errors.append(f"Missing water texture: water_{water_index}.png")
for ore_name in ("coal_ore", "iron_ore", "copper_ore", "hematite_ore", "cassiterite_ore", "pentlandite_ore", "garnierite_ore", "sphalerite_ore", "gold_ore", "lapis_ore", "redstone_ore", "diamond_ore", "titan_ore", "uranium_ore"):
    if not (ROOT / "assets" / "textures" / "blocks" / f"{ore_name}.png").is_file():
        errors.append(f"Missing ore texture: {ore_name}.png")

# The expanded creative catalog must match the labels and imported world textures.
catalog_source = (ROOT / "scripts/3d/item_catalog.gd").read_text(encoding="utf-8")
name_section_match = re.search(r"const NAMES: Dictionary = \{(.*?)^\}", catalog_source, re.DOTALL | re.MULTILINE)
block_section_match = re.search(r"const BLOCK_ITEMS: Array = \[(.*?)^\]", catalog_source, re.DOTALL | re.MULTILINE)
if not name_section_match or not block_section_match:
    errors.append("Creative item catalog could not be parsed")
else:
    known_names = set(re.findall(r'"([a-z0-9_]+)"\s*:', name_section_match.group(1)))
    block_ids = re.findall(r'"([a-z0-9_]+)"', block_section_match.group(1))
    if len(block_ids) != len(set(block_ids)):
        errors.append("Creative block catalog contains duplicate IDs")
    for block_id in block_ids:
        if block_id not in known_names:
            errors.append(f"Creative block has no display name: {block_id}")
if "static func creative_items() -> Array" not in catalog_source:
    errors.append("Creative inventory catalog function is missing")
if "key_event.keycode == KEY_C" not in (ROOT / "scripts/3d/explorer.gd").read_text(encoding="utf-8"):
    errors.append("C creative-mode shortcut is missing")

tree_root = ROOT / "assets/textures/trees"
tree_species_dirs = [path for path in tree_root.iterdir() if path.is_dir()] if tree_root.is_dir() else []
if len(tree_species_dirs) != 18:
    errors.append(f"Expected 18 tree texture sets, found {len(tree_species_dirs)}")
for tree_dir in tree_species_dirs:
    for texture_name in ("log_side.png", "log_top.png", "leaves.png", "planks.png", "stripped_log_side.png", "sapling.png"):
        if not (tree_dir / texture_name).is_file():
            errors.append(f"Missing {tree_dir.name} tree texture: {texture_name}")

workflow = (ROOT / ".github/workflows/build-windows.yml").read_text(encoding="utf-8")
if "include-templates: true" not in workflow:
    errors.append("Windows workflow does not explicitly install Godot export templates")
if "tools/smoke_test.gd" not in workflow:
    errors.append("Windows workflow does not run the legacy gameplay smoke test")
if "tools/smoke_test_3d.gd" not in workflow:
    errors.append("Windows workflow does not run the 3D gameplay smoke test")

if errors:
    print("ReCraft static validation FAILED:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print("ReCraft static validation passed: resources, item/recipe data, ItemDB calls and CI safeguards are consistent.")
print("Note: Godot parser/runtime validation is performed by the GitHub Actions smoke-test job, not by this Python check.")
