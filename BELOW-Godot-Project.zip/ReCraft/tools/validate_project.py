#!/usr/bin/env python3
"""Статическая проверка проекта ReCraft (не заменяет запуск Godot)."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

for rel in ("project.godot", "scenes/main_3d.tscn", "scenes/3d/explorer.tscn", "scripts/3d/expedition_game.gd",
            "scripts/3d/block_table.gd", "scripts/3d/atlas_data.gd", "assets/atlas/blocks_atlas.png",
            "assets/atlas/icons_atlas.png", "export_presets.cfg", ".github/workflows/build-windows.yml"):
    if not (ROOT / rel).is_file():
        errors.append(f"Нет обязательного файла: {rel}")

# Все ссылки res:// должны существовать.
sources = list(ROOT.rglob("*.gd")) + list(ROOT.rglob("*.tscn")) + [ROOT / "project.godot"]
for path in sources:
    if "texture_sources" in path.parts or not path.is_file():
        continue
    text = path.read_text(encoding="utf-8")
    for value in re.findall(r'res://([^"\']+)', text):
        if not (ROOT / value).exists():
            errors.append(f"Битая ссылка в {path.relative_to(ROOT)}: res://{value}")

# Таблица блоков: уникальные имена, тайлы есть в атласе.
table = (ROOT / "scripts/3d/block_table.gd").read_text(encoding="utf-8")
atlas = (ROOT / "scripts/3d/atlas_data.gd").read_text(encoding="utf-8")
tiles = set(re.findall(r'"([a-z0-9_]+)":\s*\d+', atlas))
names = []
for row in re.findall(r'^\s*\["([a-z0-9_]+)",\s*"[^"]*",\s*"([a-z0-9_]+)",\s*"([a-z0-9_]+)",\s*"([a-z0-9_]+)"', table, re.MULTILINE):
    names.append(row[0])
    for tile in row[1:]:
        if tile not in tiles:
            errors.append(f"Блок {row[0]} ссылается на неизвестный тайл {tile}")
if len(names) != len(set(names)):
    errors.append("В таблице блоков есть повторяющиеся имена")
if not 100 <= len(names) <= 255:
    errors.append(f"Число блоков {len(names)} вне диапазона 100..255 (ID хранится в байте)")

# Переопределение Node.get_name() ломает компиляцию.
for path in ROOT.rglob("*.gd"):
    if "texture_sources" in path.parts:
        continue
    source = path.read_text(encoding="utf-8")
    if re.search(r"^\s*func\s+get_name\s*\(", source, re.MULTILINE):
        errors.append(f"{path.relative_to(ROOT)} переопределяет Node.get_name()")
    if "\t" in source:
        errors.append(f"{path.relative_to(ROOT)} содержит символы табуляции (скрипты используют 4 пробела)")

main_scene = (ROOT / "project.godot").read_text(encoding="utf-8")
if 'run/main_scene="res://scenes/main_3d.tscn"' not in main_scene:
    errors.append("Главная сцена должна быть scenes/main_3d.tscn")
if "ItemDB" in main_scene or "SaveManager" in main_scene:
    errors.append("В project.godot остались автозагрузки старого 2D-кода")

if errors:
    print("Проверка не пройдена:")
    for error in errors:
        print(" -", error)
    sys.exit(1)
print(f"Проверка пройдена: {len(names)} блоков, {len(tiles)} тайлов.")
