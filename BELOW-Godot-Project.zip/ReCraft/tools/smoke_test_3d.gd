extends SceneTree

const MainScene: PackedScene = preload("res://scenes/main_3d.tscn")

func _initialize() -> void:
    call_deferred("_run_test")

func _fail(message: String) -> void:
    push_error("ReCraft 3D smoke test failed: " + message)
    quit(1)

func _run_test() -> void:
    var main = MainScene.instantiate()
    root.add_child(main)
    await process_frame
    if not is_instance_valid(main.title_layer):
        _fail("main menu did not initialize")
        return

    main._start_game(false)
    for _frame in range(12):
        await process_frame
    if not main.game_started or main.world == null or main.player == null or main.hud == null:
        _fail("world, player, or HUD did not initialize")
        return
    if main.world.chunk_cache.size() < 10:
        _fail("chunk streaming did not load the nearby terrain")
        return
    var surface_test: int = main.world.height_at(1234, -5678)
    if surface_test < 60 or surface_test > 192:
        _fail("surface height is outside the expected natural range")
        return
    if int(main.world.MAX_Y) - int(main.world.MIN_Y) != 384:
        _fail("world vertical range is not 384 block levels")
        return
    if main.world.get_block_kind(Vector3i(0, main.world.MIN_Y, 0)) != "bedrock":
        _fail("bedrock layer at Y=-64 is missing")
        return
    if main.world.get_block_kind(Vector3i(0, main.world.MAX_Y, 0)) != "air":
        _fail("the exclusive upper world boundary at Y=320 is not respected")
        return
    for ore_kind in ["coal_ore", "iron_ore", "copper_ore", "hematite_ore", "cassiterite_ore", "pentlandite_ore", "garnierite_ore", "sphalerite_ore", "gold_ore", "lapis_ore", "redstone_ore", "diamond_ore", "titan_ore", "uranium_ore"]:
        if not main.world.is_ore(ore_kind):
            _fail("ore catalog is missing " + ore_kind)
            return
    if main.player.groups_ids["inv"].size() != 36 or main.player.get_slot_id("inv", 0) != "pickaxe":
        _fail("36-slot Minecraft-style inventory with hotbar is missing")
        return
    if main.world.has_method("find_nearby_story_object"):
        _fail("story mission logic should not be present in the sandbox build")
        return
    if not ResourceLoader.exists("res://assets/skins/default_skin.png") or main.player.view_arm == null:
        _fail("the default player skin was not loaded")
        return

    var Catalog = load("res://scripts/3d/item_catalog.gd")
    if not Catalog.BLOCK_ITEMS.has("diorite") or not Catalog.BLOCK_ITEMS.has("oak_log") or not Catalog.BLOCK_ITEMS.has("mushroom_leaves"):
        _fail("new geology/tree blocks are missing from the creative catalog")
        return
    if Catalog.creative_items().size() < 130:
        _fail("creative inventory is missing the expanded block catalog")
        return
    if not ResourceLoader.exists("res://assets/textures/trees/sequoia/log_side.png") or not ResourceLoader.exists("res://assets/textures/blocks/diorite.png"):
        _fail("new block/tree textures were not imported")
        return
    main.toggle_creative_mode()
    if not main.player.creative_mode or not main.player.is_flying or not main.hud.creative_inventory_root.visible:
        _fail("C creative-mode toggle did not enable flight and creative inventory")
        return
    var creative_health: float = main.player.health
    main.player.take_damage(2.0)
    if main.player.health != creative_health:
        _fail("creative mode did not protect the player from damage")
        return
    main.toggle_creative_mode()
    if main.player.creative_mode or main.player.is_flying:
        _fail("creative mode did not return to survival")
        return

    var test_cell := Vector3i(4, main.world.height_at(4, 4), 4)
    if main.world.get_block_kind(test_cell) == "air":
        _fail("expected surface block does not exist")
        return
    var mine_result: Dictionary = main.world.mine_cell(test_cell)
    if not mine_result.get("ok", false) or main.world.get_block_kind(test_cell) != "air":
        _fail("block mining failed")
        return
    var below_cell := test_cell + Vector3i(0, -1, 0)
    var chunk_coord := Vector2i(0, 0)
    var chunk_data: Dictionary = main.world.chunk_cache[chunk_coord]
    if not chunk_data["faces"].has(below_cell) or not chunk_data["faces"][below_cell]["faces"].has("top"):
        _fail("mining did not reveal the solid block beneath the surface")
        return
    if not main.world.place_block(test_cell, "stone") or main.world.get_block_kind(test_cell) != "stone":
        _fail("block placement failed")
        return

    if not main.save_game(false):
        _fail("save file could not be written")
        return
    var loaded: Dictionary = main._read_save()
    if int(loaded.get("world_seed", 0)) != main.world_seed:
        _fail("world seed did not survive a save round-trip")
        return
    if not loaded.has("world_changes"):
        _fail("block edits were not included in the save")
        return

    main.return_to_title()
    await process_frame
    if main.game_started or main.world != null or main.player != null:
        _fail("return to menu did not clean up the expedition")
        return

    print("ReCraft 3D smoke test passed: startup, streamed chunks, block/tree catalog, creative toggle, world height, bedrock, default skin, hotbar, mining, placing, saving and cleanup.")
    quit(0)
