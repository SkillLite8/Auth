extends SceneTree
# Дымовой тест: генератор, реестр блоков, потоковая загрузка, физика игрока, правки мира и творческий режим.

const MainScene: PackedScene = preload("res://scenes/main_3d.tscn")
const B = preload("res://scripts/3d/block_registry.gd")
const WorldGen = preload("res://scripts/3d/world_gen.gd")
const BlockData = preload("res://scripts/3d/block_data.gd")

const SPECIES: Array = ["oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "cherry", "mangrove", "ancient",
    "maple", "aspen", "willow", "baobab", "sequoia", "azure", "crystal", "dead", "mushroom"]

func _initialize() -> void:
    call_deferred("_run_test")

func _fail(message: String) -> void:
    push_error("ReCraft 3D smoke test failed: " + message)
    quit(1)

func _run_test() -> void:
    B.setup()
    if B.count < 150 or B.count > 255:
        _fail("unexpected block count %d" % B.count)
        return
    for species in SPECIES:
        for suffix in ["_log", "_planks", "_leaves", "_stripped_log", "_sapling"]:
            if B.id_of(species + suffix) <= 0:
                _fail("missing block " + species + suffix)
                return
    for block_name in ["granite", "diorite", "andesite", "obsidian", "quartz_ore", "ruby_ore", "deep_iron_ore", "salt_block", "marble"]:
        if B.id_of(block_name) <= 0:
            _fail("missing block " + block_name)
            return

    # --- генератор ---
    var generator = WorldGen.new(424242)
    var total_logs: int = 0
    var total_ore: int = 0
    var found_biomes: Dictionary = {}
    for cz in range(-6, 6):
        for cx in range(-6, 6):
            var data: Dictionary = generator.generate_chunk(cx, cz)
            var blocks: PackedByteArray = data["blocks"]
            if blocks.size() != 16 * 16 * 384:
                _fail("chunk data has the wrong size")
                return
            if blocks[0] != B.BEDROCK:
                _fail("bedrock layer missing at the bottom of the chunk")
                return
            var biomes: PackedByteArray = data["biomes"]
            for biome in biomes:
                found_biomes[int(biome)] = true
            for i in range(0, blocks.size(), 7):
                var cat: String = B.categories[blocks[i]]
                if cat == "wood":
                    total_logs += 1
                elif cat == "ore":
                    total_ore += 1
    if total_logs < 50:
        _fail("trees are not generated")
        return
    if total_ore < 50:
        _fail("ores are not generated")
        return
    if found_biomes.size() < 5:
        _fail("too few biomes in a 12x12 chunk area: %d" % found_biomes.size())
        return

    # --- игра ---
    var main = MainScene.instantiate()
    root.add_child(main)
    await process_frame
    if not is_instance_valid(main.title_layer):
        _fail("main menu did not initialize")
        return
    main._start_game(false)
    var frames: int = 0
    while main.loading and frames < 3000:
        await process_frame
        frames += 1
    if main.loading:
        _fail("the world did not finish loading")
        return
    var world = main.world
    var player = main.player
    if world.loaded_chunk_count() < 9:
        _fail("chunk streaming did not load the nearby terrain")
        return
    if world.get_block_kind(Vector3i(0, world.MIN_Y, 0)) != "bedrock":
        _fail("bedrock layer at Y=-64 is missing")
        return
    if world.get_block_kind(Vector3i(0, world.MAX_Y, 0)) != "air":
        _fail("the exclusive upper world boundary is not respected")
        return
    if player.groups_ids["inv"].size() != 36 or player.get_slot_id("inv", 0) != "pickaxe":
        _fail("36-slot inventory with the pickaxe is missing")
        return

    # --- физика: падение и приземление ---
    var spawn: Vector3 = world.get_spawn_position()
    player.teleport(spawn + Vector3(0.0, 6.0, 0.0))
    for i in range(160):
        player._tick(false)
    if not player.on_ground:
        _fail("the player did not land on the ground")
        return
    var feet_y: float = player.pos.y
    if feet_y < spawn.y - 0.9 - 2.0 or feet_y > spawn.y + 20.0:
        _fail("the player landed at a wrong height: %f vs %f" % [feet_y, spawn.y - 0.9])
        return

    # --- прыжок как в Bedrock: 0.42 -> около 1.25 блока ---
    player.jump_buffer = 3
    var peak: float = feet_y
    for i in range(30):
        player._tick(true)
        peak = maxf(peak, player.pos.y)
    var jump_height: float = peak - feet_y
    if jump_height < 1.1 or jump_height > 1.4:
        _fail("jump height %f is not Minecraft-like (about 1.25)" % jump_height)
        return

    # --- правки мира ---
    var ground_cell := Vector3i(roundi(player.pos.x), roundi(feet_y) - 1, roundi(player.pos.z))
    var ground_id: int = world.get_block_id(ground_cell)
    if ground_id <= 0:
        _fail("no ground block under the player")
        return
    var below := Vector3i(ground_cell.x + 3, ground_cell.y, ground_cell.z)
    var original: String = world.get_block_kind(below)
    if original != "air":
        var mined: Dictionary = world.mine_cell(below)
        if not mined.get("ok", false) or world.get_block_kind(below) != "air":
            _fail("mining a block did not remove it")
            return
        if not world.place_block(below, "granite") or world.get_block_kind(below) != "granite":
            _fail("placing a block did not work")
            return
    var changes: Dictionary = world.export_changes()
    if (changes["edits"] as Array).is_empty():
        _fail("world edits were not recorded")
        return

    # --- луч ---
    var hit: Dictionary = world.raycast(Vector3(player.pos.x, player.pos.y + 1.6, player.pos.z), Vector3.DOWN, 6.0)
    if not hit.get("hit", false):
        _fail("raycast did not hit the ground")
        return

    # --- время добычи ---
    if absf(float(BlockData.break_time("dirt", "")) - 0.75) > 0.001:
        _fail("dirt break time is not the vanilla 0.75 s")
        return
    if absf(float(BlockData.break_time("stone", "pickaxe")) - 0.4) > 0.001:
        _fail("stone with the pickaxe should take 0.4 s")
        return

    # --- творческий режим ---
    player.set_creative(true)
    if not player.creative:
        _fail("creative mode did not switch on")
        return
    player.flying = true
    player.velocity = Vector3.ZERO
    var before_y: float = player.pos.y
    for i in range(20):
        player._tick(false)
    if absf(player.pos.y - before_y) > 0.5:
        _fail("flying player is falling")
        return
    player.set_creative(false)

    print("ReCraft 3D smoke test passed: %d blocks, %d chunks, %d biomes" % [B.count, world.loaded_chunk_count(), found_biomes.size()])
    quit(0)
