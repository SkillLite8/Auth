#!/usr/bin/env python3
"""Собирает атласы текстур и таблицу блоков ReCraft.

Запуск:  python3 tools/build_assets.py   (нужен Pillow + numpy)

Результат:
  assets/atlas/blocks_atlas.png   - все текстуры блоков 16x16 в одном атласе
  assets/atlas/icons_atlas.png    - изометрические иконки блоков 32x32 (индекс = ID блока)
  scripts/3d/atlas_data.gd        - имя тайла -> индекс в атласе
  scripts/3d/block_table.gd       - таблица блоков (ID = порядок строки)

Чтобы добавить блок: положите PNG 16x16 в tools/texture_sources/..., допишите блок
в функцию build_blocks() ниже и запустите скрипт.
"""
from pathlib import Path
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "tools" / "texture_sources"
TILE = 16
COLS = 32
ICON = 32
ICON_COLS = 16

SPECIES = [
    ("oak", "Дуб"), ("spruce", "Ель"), ("birch", "Берёза"), ("jungle", "Тропическое дерево"),
    ("acacia", "Акация"), ("dark_oak", "Тёмный дуб"), ("cherry", "Сакура"),
    ("mangrove", "Мангровое дерево"), ("ancient", "Древнее дерево"), ("maple", "Клён"),
    ("aspen", "Осина"), ("willow", "Ива"), ("baobab", "Баобаб"), ("sequoia", "Секвойя"),
    ("azure", "Лазурное дерево"), ("crystal", "Кристальное дерево"), ("dead", "Мёртвое дерево"),
    ("mushroom", "Грибодерево"),
]
ROOTED = {"mangrove", "ancient", "willow", "baobab", "dead", "mushroom"}

# render: 0 нет, 1 сплошной куб, 2 листва (вырезы), 3 крест (растение/факел), 4 вода
R_NONE, R_SOLID, R_LEAVES, R_CROSS, R_WATER = 0, 1, 2, 3, 4

# файл пака -> имя тайла (дубликаты пака становятся «глубинными» вариантами руд)
PACK_SKIP = {"stone", "dirt", "sand", "grass_soil"}
PACK_RENAME = {
    "cobble": "pebbles",
    "coal_ore": "deep_coal_ore", "iron_ore": "deep_iron_ore", "copper_ore": "deep_copper_ore",
    "gold_ore": "deep_gold_ore", "uranium_ore": "deep_uranium_ore",
}
GAME_SKIP = {"leaves", "wood_side", "wood_top"}


def load_tiles():
    tiles = {}
    for p in sorted((SRC / "game").glob("*.png")):
        if p.stem in GAME_SKIP:
            continue
        tiles[p.stem] = Image.open(p).convert("RGBA")
    for p in sorted((SRC / "pack").glob("*.png")):
        if p.stem in PACK_SKIP:
            continue
        tiles[PACK_RENAME.get(p.stem, p.stem)] = Image.open(p).convert("RGBA")
    for p in sorted((SRC / "trees").glob("*.png")):
        tiles[p.stem] = Image.open(p).convert("RGBA")
    # Коренная порода: затемнённый камень
    st = np.asarray(tiles["stone"]).astype(np.float32)
    st[..., 0] *= 0.30
    st[..., 1] *= 0.33
    st[..., 2] *= 0.40
    tiles["bedrock"] = Image.fromarray(st.clip(0, 255).astype(np.uint8), "RGBA")
    for name, im in tiles.items():
        if im.size != (TILE, TILE):
            raise SystemExit(f"Тайл {name} имеет размер {im.size}, нужен {TILE}x{TILE}")
    return tiles


# ----------------------------------------------------------------------------
# Таблица блоков
# ----------------------------------------------------------------------------
def build_blocks(tiles):
    """Строки: (name, ru, top, side, bottom, hardness, pick, sound, render, category)."""
    rows = []

    def add(name, ru, top, side=None, bottom=None, hard=1.5, pick=False, sound="stone", render=R_SOLID, cat="nature"):
        side = side or top
        bottom = bottom or top
        for t in (top, side, bottom):
            if t not in tiles:
                raise SystemExit(f"Блок {name}: нет тайла {t}")
        rows.append((name, ru, top, side, bottom, hard, 1 if pick else 0, sound, render, cat))

    rows.append(("air", "Воздух", "stone", "stone", "stone", -1.0, 0, "stone", R_NONE, "hidden"))
    add("bedrock", "Коренная порода", "bedrock", hard=-1.0, cat="stone")
    add("stone", "Камень", "stone", hard=1.5, pick=True, cat="stone")
    add("cobblestone", "Булыжник", "cobblestone", hard=2.0, pick=True, cat="stone")
    add("dirt", "Земля", "dirt", hard=0.5, sound="dirt", cat="nature")
    add("grass", "Дёрн", "grass_top", "grass_side", "dirt", hard=0.6, sound="dirt", cat="nature")
    add("sand", "Песок", "sand", hard=0.5, sound="sand", cat="nature")
    add("gravel", "Гравий", "gravel", hard=0.6, sound="sand", cat="nature")
    add("water", "Вода", "water_2", hard=-1.0, render=R_WATER, cat="hidden")

    # Каменные породы
    for n, ru, h in [("granite", "Гранит", 1.5), ("diorite", "Диорит", 1.5), ("andesite", "Андезит", 1.5),
                     ("slate", "Сланец", 3.0), ("limestone", "Известняк", 1.5), ("sandstone", "Песчаник", 0.8),
                     ("claystone", "Глинистый камень", 1.2), ("tuff", "Туф", 1.5), ("gneiss", "Гнейс", 2.0),
                     ("deep_stone", "Глубинный камень", 3.0)]:
        add(n, ru, n, hard=h, pick=True, cat="stone")

    # Грунт
    add("podzol", "Подзол", "podzol", hard=0.5, sound="dirt", cat="nature")
    add("red_sand", "Красный песок", "red_sand", hard=0.5, sound="sand", cat="nature")
    add("red_clay", "Красная глина", "red_clay", hard=0.6, sound="dirt", cat="nature")
    add("pebbles", "Галька", "pebbles", hard=0.6, sound="sand", cat="nature")
    add("clay_with_stone", "Глина с камнем", "clay_with_stone", hard=0.8, sound="dirt", cat="nature")
    add("loam", "Суглинок", "loam", hard=0.5, sound="dirt", cat="nature")
    add("marl", "Мергель", "marl", hard=0.8, sound="dirt", cat="nature")
    add("packed_soil", "Плотный грунт", "packed_soil", hard=1.0, sound="dirt", cat="nature")
    add("silt", "Ил", "silt", hard=0.5, sound="dirt", cat="nature")
    add("mud", "Грязь", "mud", hard=0.5, sound="dirt", cat="nature")
    add("snow", "Снег", "snow", hard=0.2, sound="dirt", cat="nature")
    add("packed_snow", "Уплотнённый снег", "packed_snow", hard=0.5, sound="dirt", cat="nature")
    add("ice", "Лёд", "ice", hard=0.5, cat="nature")
    add("ice_blue", "Плотный лёд", "ice_blue", hard=0.8, cat="nature")
    add("blue_ice_ore", "Синяя ледяная жила", "blue_ice_ore", hard=1.0, pick=True, cat="nature")

    # Пещерные и особые породы
    for n, ru, h in [("deep_rock", "Глубинная порода", 3.0), ("basalt", "Базальт", 1.25),
                     ("obsidian", "Обсидиан", 50.0), ("dripstone", "Капельный камень", 1.5),
                     ("stalactite_rock", "Камень сталактитов", 1.5), ("limestone_rock", "Известняковая порода", 1.5),
                     ("pale_rock", "Светлая порода", 1.5), ("salt_block", "Соляной блок", 0.8),
                     ("gypsum", "Гипс", 0.8), ("marble", "Мрамор", 1.5),
                     ("glowstone_rock", "Светящийся камень", 0.3), ("glassstone", "Стеклянный камень", 0.3),
                     ("lava_rock", "Лавовый камень", 1.5), ("red_fungus_block", "Красный грибной блок", 1.5),
                     ("mossy_stone", "Мшистый камень", 1.5)]:
        add(n, ru, n, hard=h, pick=True, cat="stone")

    # Руды из игры (с боковыми текстурами)
    for n, ru, h in [("coal_ore", "Угольная руда", 3.0), ("iron_ore", "Железная руда", 3.0),
                     ("copper_ore", "Медная руда", 3.0), ("hematite_ore", "Гематит / магнетит", 3.0),
                     ("cassiterite_ore", "Касситерит (олово)", 3.0), ("pentlandite_ore", "Пентландит (никель)", 3.0),
                     ("garnierite_ore", "Гарниерит (никель)", 3.0), ("sphalerite_ore", "Сфалерит (цинк)", 3.0),
                     ("gold_ore", "Золотая руда", 3.0), ("lapis_ore", "Лазурит", 3.0),
                     ("redstone_ore", "Редстоуновая руда", 3.0), ("diamond_ore", "Алмазная руда", 3.0),
                     ("titan_ore", "Титановая руда", 5.0), ("uranium_ore", "Урановая руда", 5.0)]:
        add(n, ru, n, n + "_side", n, hard=h, pick=True, cat="ore")
    # Руды из пака
    for n, ru, h in [("quartz_ore", "Кварцевая жила", 3.0), ("flint_ore", "Кремневая жила", 3.0),
                     ("emerald_ore", "Зелёный минерал", 3.0), ("ruby_ore", "Красный минерал", 3.0),
                     ("sapphire_ore", "Синий минерал", 3.0), ("amethyst_ore", "Фиолетовый минерал", 3.0),
                     ("mixed_ore", "Смешанная руда", 3.0), ("silver_ore", "Серебряная руда", 3.5),
                     ("tin_ore", "Оловянная руда", 3.5), ("nickel_ore", "Никелевая руда", 4.0),
                     ("cobalt_ore", "Кобальтовая руда", 4.0), ("titanium_ore", "Титановая руда (кристаллы)", 5.0),
                     ("echorite_ore", "Эхорит", 5.0), ("astralite_ore", "Астралит", 5.0),
                     ("void_ore", "Пустотная руда", 5.0), ("livingstone", "Живокамень", 3.0),
                     ("shadow_ore", "Сумрачная руда", 5.0), ("chronosteel_ore", "Хроносталь", 5.0)]:
        add(n, ru, n, hard=h, pick=True, cat="ore")
    for n, ru, h in [("deep_coal_ore", "Глубинная угольная руда", 4.5), ("deep_iron_ore", "Глубинная железная руда", 4.5),
                     ("deep_copper_ore", "Глубинная медная руда", 4.5), ("deep_gold_ore", "Глубинная золотая руда", 4.5),
                     ("deep_uranium_ore", "Глубинная урановая руда", 6.0)]:
        add(n, ru, n, hard=h, pick=True, cat="ore")

    # Деревья
    for sp, ru in SPECIES:
        add(sp + "_log", ru + ": бревно", sp + "_log_top", sp + "_log_side", sp + "_log_top",
            hard=2.0, sound="wood", cat="wood")
        add(sp + "_stripped_log", ru + ": стёсанное бревно", sp + "_log_top", sp + "_stripped_log_side", sp + "_log_top",
            hard=2.0, sound="wood", cat="wood")
        add(sp + "_planks", ru + ": доски", sp + "_planks", hard=2.0, sound="wood", cat="wood")
        add(sp + "_leaves", ru + ": листва", sp + "_leaves", hard=0.2, sound="dirt", render=R_LEAVES, cat="leaves")
        add(sp + "_sapling", ru + ": саженец", sp + "_sapling", hard=0.0, sound="dirt", render=R_CROSS, cat="leaves")
        if sp in ROOTED:
            add(sp + "_roots", ru + ": корни", sp + "_roots", hard=1.0, sound="wood", cat="wood")

    add("torch", "Факел", "torch", hard=0.0, sound="wood", render=R_CROSS, cat="misc")
    return rows


# ----------------------------------------------------------------------------
# Изометрические иконки
# ----------------------------------------------------------------------------
def render_icon(top, side, bottom, leaves=False):
    """Куб в изометрии 32x32 (вид как в Minecraft)."""
    size = ICON
    out = np.zeros((size, size, 4), dtype=np.float32)
    c = size / 2.0
    r = size / 2.0 - 0.5
    dx = r * 0.866
    dy = r * 0.5
    # вершины: верх, правый-верх, центр, левый-верх, правый-низ, низ, левый-низ
    T = np.array([c, c - r])
    UR = np.array([c + dx, c - dy])
    C = np.array([c, c])
    UL = np.array([c - dx, c - dy])
    LL = np.array([c - dx, c + dy])
    B = np.array([c, c + r])
    LR = np.array([c + dx, c + dy])
    faces = [
        # (origin, edge_u, edge_v, image, shade)
        (T, UR - T, UL - T, top, 1.0),
        (UL, C - UL, LL - UL, side, 0.80),
        (C, UR - C, LR - UR, side, 0.62),
    ]
    for origin, eu, ev, img, shade in faces:
        arr = np.asarray(img).astype(np.float32)
        m = np.array([[eu[0], ev[0]], [eu[1], ev[1]]])
        inv = np.linalg.inv(m)
        for y in range(size):
            for x in range(size):
                p = np.array([x + 0.5, y + 0.5]) - origin
                s, t = inv @ p
                if 0.0 <= s < 1.0 and 0.0 <= t < 1.0:
                    px = arr[int(t * TILE), int(s * TILE)].copy()
                    if leaves and px[3] < 128:
                        continue
                    px[:3] *= shade
                    px[3] = 255 if px[3] >= 128 else 0
                    out[y, x] = px
    return Image.fromarray(out.clip(0, 255).astype(np.uint8), "RGBA")


def flat_icon(img):
    return img.resize((ICON, ICON), Image.NEAREST)


def solid_leaves(img):
    """Для иконки листвы закрашиваем прозрачные пиксели тёмным средним цветом."""
    arr = np.asarray(img).astype(np.float32)
    mask = arr[..., 3] >= 128
    if mask.any():
        avg = arr[mask][:, :3].mean(axis=0) * 0.45
    else:
        avg = np.zeros(3)
    arr[~mask, :3] = avg
    arr[..., 3] = 255
    return Image.fromarray(arr.astype(np.uint8), "RGBA")


def main():
    tiles = load_tiles()
    rows = build_blocks(tiles)

    # Только используемые тайлы, в стабильном порядке
    used = []
    for r in rows:
        for t in (r[2], r[3], r[4]):
            if t not in used:
                used.append(t)
    # Тайлы воды (5 вариантов) и разрушения живут отдельно
    for i in range(5):
        used.append(f"water_{i}") if f"water_{i}" not in used else None
    used = [t for t in used if t != "stone" or True]
    if "stone" not in used:
        used.append("stone")
    index = {name: i for i, name in enumerate(used)}

    rows_count = (len(used) + COLS - 1) // COLS
    atlas = Image.new("RGBA", (COLS * TILE, rows_count * TILE), (0, 0, 0, 0))
    for name, i in index.items():
        atlas.paste(tiles[name], ((i % COLS) * TILE, (i // COLS) * TILE))
    out_dir = ROOT / "assets" / "atlas"
    out_dir.mkdir(parents=True, exist_ok=True)
    atlas.save(out_dir / "blocks_atlas.png", optimize=True)

    # Иконки: индекс = ID блока
    icon_rows = (len(rows) + ICON_COLS - 1) // ICON_COLS
    icons = Image.new("RGBA", (ICON_COLS * ICON, icon_rows * ICON), (0, 0, 0, 0))
    for bid, r in enumerate(rows):
        name, render = r[0], r[8]
        if render in (R_NONE, R_WATER):
            continue
        top, side, bottom = tiles[r[2]], tiles[r[3]], tiles[r[4]]
        if render == R_CROSS:
            icon = flat_icon(side)
        elif render == R_LEAVES:
            icon = render_icon(solid_leaves(top), solid_leaves(side), solid_leaves(bottom))
        else:
            icon = render_icon(top, side, bottom)
        icons.paste(icon, ((bid % ICON_COLS) * ICON, (bid // ICON_COLS) * ICON))
    icons.save(out_dir / "icons_atlas.png", optimize=True)

    # atlas_data.gd
    lines = [
        "extends RefCounted",
        "# Сгенерировано tools/build_assets.py - не редактировать вручную.",
        "",
        f"const TILE_SIZE: int = {TILE}",
        f"const ATLAS_COLS: int = {COLS}",
        f"const ATLAS_ROWS: int = {rows_count}",
        f"const ICON_SIZE: int = {ICON}",
        f"const ICON_COLS: int = {ICON_COLS}",
        "",
        "const TILES: Dictionary = {",
    ]
    lines += [f'    "{n}": {i},' for n, i in index.items()]
    lines[-1] = lines[-1].rstrip(",")
    lines += ["}", ""]
    (ROOT / "scripts" / "3d" / "atlas_data.gd").write_text("\n".join(lines), encoding="utf-8")

    # block_table.gd
    lines = [
        "extends RefCounted",
        "# Сгенерировано tools/build_assets.py - не редактировать вручную.",
        "# Строка: [имя, название, плитка сверху, сбоку, снизу, твёрдость, нужна кирка, звук, тип отрисовки, категория]",
        "# ID блока = номер строки. Тип отрисовки: 0 нет, 1 куб, 2 листва, 3 крест, 4 вода.",
        "",
        "const TABLE: Array = [",
    ]
    for r in rows:
        lines.append(f'    ["{r[0]}", "{r[1]}", "{r[2]}", "{r[3]}", "{r[4]}", {r[5]}, {r[6]}, "{r[7]}", {r[8]}, "{r[9]}"],')
    lines[-1] = lines[-1].rstrip(",")
    lines += ["]", ""]
    (ROOT / "scripts" / "3d" / "block_table.gd").write_text("\n".join(lines), encoding="utf-8")
    print(f"Блоков: {len(rows)}, тайлов: {len(used)}, атлас: {atlas.size}")


if __name__ == "__main__":
    main()
