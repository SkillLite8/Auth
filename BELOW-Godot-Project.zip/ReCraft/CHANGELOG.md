# ReCraft — changelog

## 1.2.0 — Bedrock-style hand, skin model, day/night and mining

- First-person hand rebuilt with Minecraft's exact arm/item transforms, drawn in its own viewport so it never clips into walls; uses the skin's arm and sleeve layer; swing, equip, walking-bob and mouse-sway animations; held blocks are cubes and tools/food are extruded 3D sprites.
- Full skinned player model (classic/slim, hat/jacket/sleeve/pants layers) with walking, swing and sneak animation.
- F5 cycles first person → second person (front) → third person (back); the third-person camera collides with terrain.
- The inventory shows a live 3D skin preview whose head and body follow the mouse; the profile menu shows a turning preview.
- Hold-to-mine uses vanilla break times and harvest rules, 10 crack stages, break and hit particles, block outline, 0.25 s break cooldown and 0.25 s place cooldown; material-specific dig/break/place sounds.
- New sky: a camera-following dome (works on every renderer) with sun, 8-phase moon, stars, blocky clouds, sunrise/sunset glow and depth fog; 20-minute days, time is saved, F6 fast-forwards.
- Blocks use Minecraft-style per-face shading and a time-of-day light tint; caves dim smoothly.

## 1.1.0 — Sandbox and performance update

- The project launches as ReCraft with a voxel-sunset main menu: Play, Profile, Settings and Exit.
- Removed the active story/mission path, its collectible objectives, beacon objects and guardian AI from the 3D game.
- Reduced view distance to 3 chunks by default, with an option for 2 chunks; only one queued chunk is generated per frame.
- Built the exposed terrain shell directly from cached height samples instead of repeatedly resolving every adjacent voxel during first-time chunk generation.
- Grouped mesh surfaces by shared block texture to reduce draw calls per chunk.
- Disabled dynamic world shadows, SSAO, SSIL, SDFGI and glow by default for smoother play on a broad range of PCs and laptops.
- Replaced per-tick full block checks for water with a cached-height/sea-level check; reduced cave geometry probes.
- Buffered Space input and added a short grounded grace window for reliable jumping.
- Added the supplied 64×64 skin as the default first-person arm texture.
- Added blocky cloud, sun and moon textures and a shader-driven day/night cycle with warm sunrise and sunset transitions.
- New worlds are immediately written to the ReCraft save so Continue cannot accidentally load an older world.

## 1.0.0 — 3D prototype foundation

- Chunk-based procedural voxel terrain with height limits Y=-64…319 and sea level Y=63.
- Water, trees, leaves, caves and height-distributed ore generation.
- Player movement, mining, block placement, inventory, hotbar and save/load.
