## Crash fix v1.3.0

- Reduced world-creation CPU spikes by constructing the visible terrain shell from cached neighbouring heights instead of repeatedly resolving every block and its cave/ore neighbours.
- Cave and ore sampling now occurs only on exposed underground cliff faces during initial chunk construction; sparse edits and trees continue through the existing block resolver.
- Delayed activation of the gameplay camera until terrain collision and HUD initialization complete, and slowed chunk streaming to reduce render/physics spikes immediately after start.
- Added startup-log markers around noise setup, chunk face generation, render-mesh building, collider creation, HUD construction and camera activation.
- Extended the 3D smoke test wait window to account for staged chunk generation and asynchronous collision preparation.
- This is a static/source-level hardening pass; runtime launch still needs confirmation in Godot 4.7.2 on the target PC.

# ReCraft — журнал изменений

## Crash fix v1.2.0
- Rebuilt world startup as a staged flow: the loading screen appears before terrain setup, and the initial chunk/collider are prepared before creating the player camera and HUD.
- Deferred player model/HUD initialization until the spawn collision exists to avoid combining first chunk creation with initial 3D camera activation.
- Lazily create the inventory's secondary 3D skin-preview viewport only when the inventory is first opened.
- Replaced the per-pixel hash-based star field with a small transparent pixel-star panorama to reduce shader work in the GL Compatibility renderer.
- Added startup stage logging around world setup, spawn mesh generation and triangle collision creation.
- Reduced first-world render distance to two chunks by default; users can still increase it in Settings.
- Added a 45-second startup timeout message and expanded the 3D smoke test for the staged loader.

# Changelog

## Crash fix v1.1.1
- Reworked Create World into a staged startup flow with a loading overlay.
- Chunk mesh generation is queued instead of being triggered synchronously in the menu callback or when crossing a chunk boundary.
- Triangle collision creation is deferred and guarded against stale/unloaded chunk data.
- Player physics remains disabled until the spawn chunk has a valid collision shape.
- Reduced default view distance to 2 chunks and added `user://recraft_startup.log` startup-stage diagnostics.
- Cached derived tree cell occupancy to avoid repeatedly scanning surrounding tree candidates during mesh construction.
- Updated the 3D smoke test to wait for spawn-chunk readiness.

# ReCraft — changelog

## 1.1.0 — Sandbox and performance update

- The project launches as ReCraft with a voxel-sunset main menu: Play, Profile, Settings and Exit.
- Removed the active story/mission path, its collectible objectives, beacon objects and guardian AI from the 3D game.
- Reduced view distance to 3 chunks by default, with an option for 2 chunks; only one queued chunk is generated per frame.
- Built the exposed terrain shell directly from cached height samples instead of repeatedly resolving every adjacent voxel during first-time chunk generation.
- Grouped mesh surfaces by shared block texture to reduce draw calls per chunk.
- Disabled dynamic world shadows, SSAO, SSIL, SDFGI and glow by default for smoother play on a broad range of PCs and laptops.
- Replaced per-tick full block checks for water with a cached-height/sea-level check; reduced cave geometry probes.
- Buffered Space input and added a short grounded grace window for reliable jumping.
- Mapped the supplied 64×64 Minecraft skin atlas onto the first-person right arm, full 3D avatar, head/body/limb overlays, and the inventory/profile preview; removed the old placeholder character preview.
- Added F5 perspective cycling: first person, front-facing third person, and rear third person; added subtle walking sway to the first-person arm.
- Reworked the sky shader to derive the sun and opposite moon directly from the saved orbit phase, which avoids the sky/light sign mismatch; added daylight startup, moving clouds, warm twilight, and smoothly appearing nighttime stars.
- Set a 20-minute day/night loop and saved the current day phase in the world save.
- New worlds are immediately written to the ReCraft save so Continue cannot accidentally load an older world.

## 1.0.0 — 3D prototype foundation

- Chunk-based procedural voxel terrain with height limits Y=-64…319 and sea level Y=63.
- Water, trees, leaves, caves and height-distributed ore generation.
- Player movement, mining, block placement, inventory, hotbar and save/load.
