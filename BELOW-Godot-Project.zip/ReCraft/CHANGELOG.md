# ReCraft — changelog

## 1.1.0 — Sandbox and performance update

- The project launches as ReCraft with a voxel-sunset main menu: Play, Profile, Settings and Exit.
- Removed the active story/mission path, its collectible objectives, beacon objects and guardian AI from the 3D game.
- Reduced view distance to 3 chunks by default, with an option for 2 chunks; only one queued chunk is generated per frame.
- Built the exposed terrain shell directly from cached height samples instead of repeatedly resolving every adjacent voxel during first-time chunk generation.
- Grouped mesh surfaces by shared block texture to reduce draw calls per chunk.
- Disabled dynamic world shadows, SSAO, SSIL, SDFGI and glow by default for smoother play on a broad range of PCs and laptops.
- Replaced per-tick full block checks for water with a cached-height/sea-level check; reduced cave geometry probes.
- Buffered Space input and added a short grounded grace window for reliable jumping.
- Added the supplied 64×64 skin as the default first-person arm texture.
- Added blocky cloud, sun and moon textures and a shader-driven day/night cycle with warm sunrise and sunset transitions.
- New worlds are immediately written to the ReCraft save so Continue cannot accidentally load an older world.

## 1.0.0 — 3D prototype foundation

- Chunk-based procedural voxel terrain with height limits Y=-64…319 and sea level Y=63.
- Water, trees, leaves, caves and height-distributed ore generation.
- Player movement, mining, block placement, inventory, hotbar and save/load.
