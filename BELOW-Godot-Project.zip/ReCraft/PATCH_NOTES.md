# ReCraft — project update

The project is now a free-build survival sandbox. Mission progression, story collectibles, the beacon and guardian spawning have been removed from the active 3D game. The title screen is branded ReCraft and has Play, Profile, Settings and Exit actions.

Performance work reduces chunk radius, spreads loading across frames, caches height samples for exposed terrain, groups mesh surfaces by texture, removes expensive shadow rendering and avoids full block lookups during water checks. Cave geometry is generated only near the explored area.

The provided skin is installed as the default texture for the first-person arm and shown in Profile. The sky uses custom pixel textures for clouds, sun and moon; its colour and the sunlight change gradually through the day/night cycle.

Static validation passes. A Godot runtime parse/play test still needs to be executed in Godot 4.7.2 because the engine binary was not available in the packaging environment.


## Expanded world, trees and creative mode

- Imported all 18 tree-species texture sets and made procedural trees use species-specific bark, foliage and canopy silhouettes.
- Added the 68 custom block/ore textures to the game catalog and registered geology, snow/ice, ore and wood variants for use by terrain and the creative inventory.
- Improved jump input with buffering and coyote time. Added the `C` creative-mode toggle, creative flight, unlimited block placement and a scrollable creative item grid opened with `E`.
- Added cave-shell refresh around the player and a below-world recovery guard to reduce the risk of falling through unloaded terrain. Horizontal chunks remain 16×16 blocks, with vertical range Y=-64…319.
- Godot runtime testing remains pending in this packaging environment; use the included headless smoke test in Godot 4.7.2.
