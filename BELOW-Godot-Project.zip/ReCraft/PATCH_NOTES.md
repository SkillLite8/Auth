# ReCraft — project update

The project is now a free-build survival sandbox. Mission progression, story collectibles, the beacon and guardian spawning have been removed from the active 3D game. The title screen is branded ReCraft and has Play, Profile, Settings and Exit actions.

Performance work reduces chunk radius, spreads loading across frames, caches height samples for exposed terrain, groups mesh surfaces by texture, removes expensive shadow rendering and avoids full block lookups during water checks. Cave geometry is generated only near the explored area.

The provided 64×64 Minecraft skin atlas drives the right first-person arm and a full blocky player model with the outer skin layers. Inventory and Profile render that same model in a 3D preview rather than a placeholder cartoon. F5 cycles first person → front-facing third person → rear third person. The first-person arm has a subtle movement sway.

The sky shader now positions the pixel sun from the same saved phase as the world time and places the moon opposite it, avoiding a renderer-dependent directional-light sign mismatch. New worlds begin in daylight, with moving block clouds, warm sunrise/sunset transitions, nighttime moon and fading stars. The 20-minute cycle is saved and resumes with the world.

Static validation passes. A Godot runtime parse/play test still needs to be executed in Godot 4.7.2 because the engine binary was not available in the packaging environment.
