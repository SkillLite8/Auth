extends RefCounted
class_name CraftingDatabase
## Helpers for Godot 4. Grid is an Array of 9 item IDs (String); empty slots are "" or null.
## Inventory consumption and output insertion are intentionally handled by the game inventory.
const DEFAULT_RECIPE_PATH := "res://assets/block_texture_pack/gameplay/recipes.json"
static var _cache: Dictionary = {}
static func load_database(path: String = DEFAULT_RECIPE_PATH) -> Dictionary:
    if _cache.has(path): return _cache[path]
    if not FileAccess.file_exists(path):
        push_error("CraftingDatabase: missing file: %s" % path); return {}
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
    if typeof(parsed) != TYPE_DICTIONARY:
        push_error("CraftingDatabase: invalid JSON: %s" % path); return {}
    _cache[path] = parsed
    return parsed
static func find_recipe(grid: Array, path: String = DEFAULT_RECIPE_PATH) -> Dictionary:
    if grid.size() != 9: return {}
    var db := load_database(path)
    for recipe in db.get("crafting", []):
        if recipe.get("type", "") == "shaped" and _matches_shaped(grid, recipe): return recipe.duplicate(true)
        if recipe.get("type", "") == "shapeless" and _matches_shapeless(grid, recipe): return recipe.duplicate(true)
    return {}
static func get_smelting_result(item_id: String, path: String = DEFAULT_RECIPE_PATH) -> Dictionary:
    for recipe in load_database(path).get("smelting", []):
        if str(recipe.get("input", "")) == item_id: return recipe.duplicate(true)
    return {}
static func get_smithing_result(template_id: String, base_id: String, addition_id: String, path: String = DEFAULT_RECIPE_PATH) -> Dictionary:
    var db := load_database(path)
    for recipe in db.get("smithing", []):
        if str(recipe.get("template", "")) == template_id and str(recipe.get("base", "")) == base_id and str(recipe.get("addition", "")) == addition_id:
            return recipe.duplicate(true)
    return {}
static func get_item(item_id: String, path: String = "res://assets/block_texture_pack/gameplay/items.json") -> Dictionary:
    if not FileAccess.file_exists(path): return {}
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
    if typeof(parsed) != TYPE_DICTIONARY: return {}
    for item in parsed.get("items", []):
        if str(item.get("id", "")) == item_id: return item.duplicate(true)
    return {}
static func get_ore_drops(ore_id: String, path: String = "res://assets/block_texture_pack/gameplay/ore_drops.json") -> Array:
    if not FileAccess.file_exists(path): return []
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
    if typeof(parsed) != TYPE_DICTIONARY: return []
    return parsed.get("ore_drops", {}).get(ore_id, []).duplicate(true)
static func _matches_shaped(grid: Array, recipe: Dictionary) -> bool:
    var pattern: Array = recipe.get("pattern", [])
    var key: Dictionary = recipe.get("key", {})
    if pattern.size() != 3:
        return false
    var min_x := 3
    var max_x := -1
    var min_y := 3
    var max_y := -1
    for y in range(3):
        var line := str(pattern[y])
        if line.length() != 3:
            return false
        for x in range(3):
            if line.substr(x, 1) != " ":
                min_x = mini(min_x, x)
                max_x = maxi(max_x, x)
                min_y = mini(min_y, y)
                max_y = maxi(max_y, y)
    if max_x < min_x or max_y < min_y:
        return false
    var width := max_x - min_x + 1
    var height := max_y - min_y + 1
    for mirrored in [false, true]:
        for off_y in range(4 - height):
            for off_x in range(4 - width):
                var matches := true
                for y in range(3):
                    for x in range(3):
                        var expected := ""
                        var rx := x - off_x
                        var ry := y - off_y
                        if rx >= 0 and rx < width and ry >= 0 and ry < height:
                            var px := max_x - rx if mirrored else min_x + rx
                            var py := min_y + ry
                            var symbol := str(pattern[py]).substr(px, 1)
                            if symbol != " ":
                                expected = str(key.get(symbol, ""))
                                if expected == "":
                                    return false
                        if _id(grid[y * 3 + x]) != expected:
                            matches = false
                if matches:
                    return true
    return false

static func _matches_shapeless(grid: Array, recipe: Dictionary) -> bool:
    var have: Dictionary = {}; var need: Dictionary = {}
    for value in grid:
        var id := _id(value)
        if id != "": have[id] = int(have.get(id, 0)) + 1
    for value in recipe.get("ingredients", []):
        var id := str(value); need[id] = int(need.get(id, 0)) + 1
    return have == need
static func _id(value) -> String:
    return "" if value == null else str(value)
