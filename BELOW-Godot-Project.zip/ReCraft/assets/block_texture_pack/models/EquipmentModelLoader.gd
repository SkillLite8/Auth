extends RefCounted
class_name EquipmentModelLoader
## Godot 4 helper for standalone equipment previews. GLB files import as PackedScenes.
const CATALOG_PATH := "res://assets/block_texture_pack/models/equipment_model_catalog.json"
static var _catalog: Dictionary = {}
static func _load_catalog() -> Dictionary:
    if not _catalog.is_empty(): return _catalog
    if not FileAccess.file_exists(CATALOG_PATH):
        push_error("EquipmentModelLoader: missing model catalog: %s" % CATALOG_PATH)
        return {}
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(CATALOG_PATH))
    if typeof(parsed) != TYPE_DICTIONARY:
        push_error("EquipmentModelLoader: invalid model catalog")
        return {}
    _catalog = parsed
    return _catalog
static func instantiate_tool(item_id: String) -> Node3D:
    return _instantiate("tools", item_id)
static func instantiate_armor(item_id: String) -> Node3D:
    return _instantiate("armor", item_id)
static func _instantiate(section: String, item_id: String) -> Node3D:
    var entry: Dictionary = _load_catalog().get(section, {}).get(item_id, {})
    if entry.is_empty():
        push_warning("EquipmentModelLoader: unknown %s item '%s'" % [section, item_id])
        return null
    var packed := load(str(entry.get("scene", ""))) as PackedScene
    if packed == null:
        push_error("EquipmentModelLoader: failed to load model for '%s'" % item_id)
        return null
    return packed.instantiate() as Node3D
