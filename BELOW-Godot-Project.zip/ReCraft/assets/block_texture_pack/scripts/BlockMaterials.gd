extends RefCounted
class_name BlockMaterials
## Godot 4: готовые материалы для блоков. Исправляет «чёрные» блоки:
## без albedo-текстуры/фильтра NEAREST и с металликом материал выглядит чёрным или мыльным.
const FACES_PATH := "res://assets/block_texture_pack/blocks/block_faces.json"
static var _faces: Dictionary = {}
static var _cache: Dictionary = {}

static func _load_faces() -> Dictionary:
    if not _faces.is_empty(): return _faces
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(FACES_PATH))
    if typeof(parsed) == TYPE_DICTIONARY:
        _faces = parsed
    return _faces

## Материал для одной текстуры. cutout=true — для листвы (прозрачные пиксели).
static func make_material(tex_path: String, cutout: bool = false) -> StandardMaterial3D:
    var key := "%s|%s" % [tex_path, cutout]
    if _cache.has(key): return _cache[key]
    var m := StandardMaterial3D.new()
    m.albedo_texture = load(tex_path) as Texture2D
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS   # чёткие пиксели как в Bedrock
    m.metallic = 0.0
    m.roughness = 1.0
    m.metallic_specular = 0.0
    m.vertex_color_use_as_albedo = false
    if cutout:
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
        m.alpha_scissor_threshold = 0.5
        m.cull_mode = BaseMaterial3D.CULL_DISABLED
    _cache[key] = m
    return m

## Материал грани блока: face = "top" | "side" | "bottom".
static func face_material(block_id: String, face: String = "side") -> Material:
    var info: Dictionary = _load_faces().get("blocks", {}).get(block_id, {})
    if info.is_empty():
        push_warning("BlockMaterials: unknown block '%s'" % block_id)
        return null
    if info.get("liquid", false):
        return load(info["material"]) as Material
    var root: String = _load_faces().get("texture_root", "res://assets/block_texture_pack/textures_16x16/")
    return make_material(root + str(info.get(face, info.get("side"))) + ".png", info.get("alpha_scissor", false))
