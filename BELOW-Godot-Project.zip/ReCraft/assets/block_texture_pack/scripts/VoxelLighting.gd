extends Node
class_name VoxelLighting
## Godot 4: освещение «как в Minecraft» — тени не уходят в чёрный.
## Использование: add_child(VoxelLighting.new()) в сцене мира.
@export var sun_energy := 1.1
@export var ambient_energy := 0.9
@export var sun_rotation_deg := Vector3(-55.0, -35.0, 0.0)

func _ready() -> void:
    var env := Environment.new()
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = Color(0.36, 0.58, 0.92)
    sm.sky_horizon_color = Color(0.72, 0.84, 0.96)
    sm.ground_horizon_color = Color(0.72, 0.84, 0.96)
    sm.ground_bottom_color = Color(0.45, 0.50, 0.55)
    sky.sky_material = sm
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY   # свет от неба заполняет тени
    env.ambient_light_energy = ambient_energy
    env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = sun_rotation_deg
    sun.light_energy = sun_energy
    sun.shadow_enabled = true
    add_child(sun)
