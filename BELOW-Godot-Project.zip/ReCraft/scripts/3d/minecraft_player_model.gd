extends Node3D

# Minecraft 64x64 classic (4-pixel-wide arm) skin renderer.
# Every face reads its own rectangle from the standard skin atlas.
const PIXEL_SCALE: float = 0.05625 # 32 skin pixels = 1.8 world units.
const ATLAS_SIZE: float = 64.0

var _skin_material: StandardMaterial3D
var _head_pivot: Node3D
var _right_arm_pivot: Node3D
var _left_arm_pivot: Node3D
var _right_leg_pivot: Node3D
var _left_leg_pivot: Node3D

func build_player(skin: Texture2D) -> void:
    _clear_model()
    scale = Vector3.ONE * PIXEL_SCALE
    _skin_material = _make_material(skin)

    # Head, including the optional second-layer hat/hood.
    _head_pivot = Node3D.new()
    _head_pivot.name = "HeadPivot"
    _head_pivot.position = Vector3(0, 8, 0)
    add_child(_head_pivot)
    var head_regions := _head_regions(0, 0)
    _add_box(_head_pivot, "Head", Vector3(0, 4, 0), Vector3(8, 8, 8), head_regions)
    _add_box(_head_pivot, "HeadOverlay", Vector3(0, 4, 0), Vector3(8, 8, 8), _head_regions(32, 0), 0.28)

    # Torso and the optional jacket layer.
    _add_box(self, "Body", Vector3(0, 2, 0), Vector3(8, 12, 4), _body_regions(20, 16))
    _add_box(self, "BodyOverlay", Vector3(0, 2, 0), Vector3(8, 12, 4), _body_regions(20, 32), 0.24)

    # Pivots are located at the shoulders/hips so the limbs swing naturally.
    _right_arm_pivot = Node3D.new()
    _right_arm_pivot.name = "RightArmPivot"
    _right_arm_pivot.position = Vector3(6, 8, 0)
    add_child(_right_arm_pivot)
    _add_box(_right_arm_pivot, "RightArm", Vector3(0, -6, 0), Vector3(4, 12, 4), _right_arm_regions(false))
    _add_box(_right_arm_pivot, "RightSleeve", Vector3(0, -6, 0), Vector3(4, 12, 4), _right_arm_regions(true), 0.24)

    _left_arm_pivot = Node3D.new()
    _left_arm_pivot.name = "LeftArmPivot"
    _left_arm_pivot.position = Vector3(-6, 8, 0)
    add_child(_left_arm_pivot)
    _add_box(_left_arm_pivot, "LeftArm", Vector3(0, -6, 0), Vector3(4, 12, 4), _left_arm_regions(false))
    _add_box(_left_arm_pivot, "LeftSleeve", Vector3(0, -6, 0), Vector3(4, 12, 4), _left_arm_regions(true), 0.24)

    _right_leg_pivot = Node3D.new()
    _right_leg_pivot.name = "RightLegPivot"
    _right_leg_pivot.position = Vector3(2, -4, 0)
    add_child(_right_leg_pivot)
    _add_box(_right_leg_pivot, "RightLeg", Vector3(0, -6, 0), Vector3(4, 12, 4), _right_leg_regions(false))
    _add_box(_right_leg_pivot, "RightTrouserOverlay", Vector3(0, -6, 0), Vector3(4, 12, 4), _right_leg_regions(true), 0.22)

    _left_leg_pivot = Node3D.new()
    _left_leg_pivot.name = "LeftLegPivot"
    _left_leg_pivot.position = Vector3(-2, -4, 0)
    add_child(_left_leg_pivot)
    _add_box(_left_leg_pivot, "LeftLeg", Vector3(0, -6, 0), Vector3(4, 12, 4), _left_leg_regions(false))
    _add_box(_left_leg_pivot, "LeftTrouserOverlay", Vector3(0, -6, 0), Vector3(4, 12, 4), _left_leg_regions(true), 0.22)

    set_process(false)

func build_arm(skin: Texture2D, left_arm: bool = false, use_overlay: bool = true) -> void:
    _clear_model()
    scale = Vector3.ONE * PIXEL_SCALE
    _skin_material = _make_material(skin)
    var regions: Dictionary = _left_arm_regions(false) if left_arm else _right_arm_regions(false)
    _add_box(self, "SkinArm", Vector3.ZERO, Vector3(4, 12, 4), regions)
    if use_overlay:
        var overlay_regions: Dictionary = _left_arm_regions(true) if left_arm else _right_arm_regions(true)
        _add_box(self, "SleeveOverlay", Vector3.ZERO, Vector3(4, 12, 4), overlay_regions, 0.24)

func set_head_pitch(pitch_radians: float) -> void:
    if is_instance_valid(_head_pivot):
        _head_pivot.rotation.x = clampf(pitch_radians, deg_to_rad(-65.0), deg_to_rad(65.0))

func update_pose(walk_amount: float, time_seconds: float) -> void:
    if not is_instance_valid(_right_arm_pivot):
        return
    var amount := clampf(walk_amount, 0.0, 1.0)
    var swing := sin(time_seconds * 9.0) * 0.68 * amount
    _right_arm_pivot.rotation.x = swing
    _left_arm_pivot.rotation.x = -swing
    _right_leg_pivot.rotation.x = -swing
    _left_leg_pivot.rotation.x = swing

func _clear_model() -> void:
    for child in get_children():
        remove_child(child)
        child.queue_free()
    _skin_material = null
    _head_pivot = null
    _right_arm_pivot = null
    _left_arm_pivot = null
    _right_leg_pivot = null
    _left_leg_pivot = null

func _make_material(skin: Texture2D) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_texture = skin
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_ALPHA_PREPASS
    material.cull_mode = BaseMaterial3D.CULL_DISABLED
    material.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
    material.albedo_color = Color.WHITE
    return material

func _head_regions(x: int, y: int) -> Dictionary:
    return {
        "top": Rect2(x + 8, y, 8, 8),
        "bottom": Rect2(x + 16, y, 8, 8),
        "front": Rect2(x + 8, y + 8, 8, 8),
        "back": Rect2(x + 24, y + 8, 8, 8),
        "right": Rect2(x, y + 8, 8, 8),
        "left": Rect2(x + 16, y + 8, 8, 8)
    }

func _body_regions(x: int, y: int) -> Dictionary:
    return {
        "top": Rect2(x, y, 8, 4),
        "bottom": Rect2(x + 8, y, 8, 4),
        "front": Rect2(x, y + 4, 8, 12),
        "back": Rect2(x + 12, y + 4, 8, 12),
        "right": Rect2(x - 4, y + 4, 4, 12),
        "left": Rect2(x + 8, y + 4, 4, 12)
    }

func _right_arm_regions(overlay: bool) -> Dictionary:
    var y_top := 32 if overlay else 16
    var y_side := 36 if overlay else 20
    return {
        "top": Rect2(44, y_top, 4, 4),
        "bottom": Rect2(48, y_top, 4, 4),
        "front": Rect2(44, y_side, 4, 12),
        "back": Rect2(52, y_side, 4, 12),
        "right": Rect2(48, y_side, 4, 12),
        "left": Rect2(40, y_side, 4, 12)
    }

func _left_arm_regions(overlay: bool) -> Dictionary:
    var top_x := 52 if overlay else 36
    var side_y := 52 if overlay else 52
    var top_y := 48
    var front_x := 52 if overlay else 36
    return {
        "top": Rect2(top_x, top_y, 4, 4),
        "bottom": Rect2(top_x + 4, top_y, 4, 4),
        "front": Rect2(front_x, side_y, 4, 12),
        "back": Rect2(front_x + 8, side_y, 4, 12),
        "right": Rect2(front_x + 4, side_y, 4, 12),
        "left": Rect2(front_x - 4, side_y, 4, 12)
    }

func _right_leg_regions(overlay: bool) -> Dictionary:
    var x_top := 4
    var y_top := 32 if overlay else 16
    var y_side := 36 if overlay else 20
    return {
        "top": Rect2(x_top, y_top, 4, 4),
        "bottom": Rect2(x_top + 4, y_top, 4, 4),
        "front": Rect2(x_top, y_side, 4, 12),
        "back": Rect2(x_top + 8, y_side, 4, 12),
        "right": Rect2(x_top + 4, y_side, 4, 12),
        "left": Rect2(x_top - 4, y_side, 4, 12)
    }

func _left_leg_regions(overlay: bool) -> Dictionary:
    var x_top := 4 if overlay else 20
    var y_top := 48
    var y_side := 52
    return {
        "top": Rect2(x_top, y_top, 4, 4),
        "bottom": Rect2(x_top + 4, y_top, 4, 4),
        "front": Rect2(x_top, y_side, 4, 12),
        "back": Rect2(x_top + 8, y_side, 4, 12),
        "right": Rect2(x_top + 4, y_side, 4, 12),
        "left": Rect2(x_top - 4, y_side, 4, 12)
    }

func _add_box(parent: Node3D, part_name: String, center_pixels: Vector3, size_pixels: Vector3, regions: Dictionary, expansion: float = 0.0) -> MeshInstance3D:
    var final_size := size_pixels + Vector3.ONE * expansion
    var half := final_size * 0.5
    var face_data: Array = [
        {"key": "top", "normal": Vector3.UP, "corners": [Vector3(-half.x, half.y, -half.z), Vector3(half.x, half.y, -half.z), Vector3(half.x, half.y, half.z), Vector3(-half.x, half.y, half.z)]},
        {"key": "bottom", "normal": Vector3.DOWN, "corners": [Vector3(-half.x, -half.y, half.z), Vector3(half.x, -half.y, half.z), Vector3(half.x, -half.y, -half.z), Vector3(-half.x, -half.y, -half.z)]},
        {"key": "front", "normal": Vector3(0, 0, -1), "corners": [Vector3(half.x, half.y, -half.z), Vector3(-half.x, half.y, -half.z), Vector3(-half.x, -half.y, -half.z), Vector3(half.x, -half.y, -half.z)]},
        {"key": "back", "normal": Vector3(0, 0, 1), "corners": [Vector3(-half.x, half.y, half.z), Vector3(half.x, half.y, half.z), Vector3(half.x, -half.y, half.z), Vector3(-half.x, -half.y, half.z)]},
        {"key": "right", "normal": Vector3.RIGHT, "corners": [Vector3(half.x, half.y, -half.z), Vector3(half.x, half.y, half.z), Vector3(half.x, -half.y, half.z), Vector3(half.x, -half.y, -half.z)]},
        {"key": "left", "normal": Vector3.LEFT, "corners": [Vector3(-half.x, half.y, half.z), Vector3(-half.x, half.y, -half.z), Vector3(-half.x, -half.y, -half.z), Vector3(-half.x, -half.y, half.z)]}
    ]
    var vertices := PackedVector3Array()
    var normals := PackedVector3Array()
    var uvs := PackedVector2Array()
    var indices := PackedInt32Array()
    var uv_corners: Array[Vector2] = [Vector2.ZERO, Vector2(1, 0), Vector2.ONE, Vector2(0, 1)]
    for face_variant in face_data:
        var face: Dictionary = face_variant
        var region: Rect2 = regions[face["key"]]
        var base := vertices.size()
        var corners: Array = face["corners"]
        for i in range(4):
            vertices.append(corners[i])
            normals.append(face["normal"])
            var uv: Vector2 = uv_corners[i]
            uvs.append(Vector2((region.position.x + uv.x * region.size.x) / ATLAS_SIZE, (region.position.y + uv.y * region.size.y) / ATLAS_SIZE))
        indices.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))

    var arrays: Array = []
    arrays.resize(Mesh.ARRAY_MAX)
    arrays[Mesh.ARRAY_VERTEX] = vertices
    arrays[Mesh.ARRAY_NORMAL] = normals
    arrays[Mesh.ARRAY_TEX_UV] = uvs
    arrays[Mesh.ARRAY_INDEX] = indices
    var mesh := ArrayMesh.new()
    mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
    mesh.surface_set_material(0, _skin_material)

    var instance := MeshInstance3D.new()
    instance.name = part_name
    instance.mesh = mesh
    instance.position = center_pixels
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    instance.material_override = _skin_material
    parent.add_child(instance)
    return instance
