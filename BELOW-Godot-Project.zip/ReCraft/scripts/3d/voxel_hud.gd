extends CanvasLayer

const Catalog = preload("res://scripts/3d/item_catalog.gd")
const SkinPreviewScript = preload("res://scripts/3d/skin_preview.gd")

const CREATIVE_TABS: Array = [["all", "Все"], ["nature", "Природа"], ["stone", "Камни"], ["ore", "Руды"], ["wood", "Дерево"], ["leaves", "Листва"], ["misc", "Разное"]]
const SLOT_SIZE: int = 50
const SLOT_PITCH: int = 54
const ICON_PITCH: int = 17
const ICON_SIZE: int = 18

var game
var player
var world
var root: Control
var brand_panel: PanelContainer
var sandbox_label: Label
var brand_label: Label
var hint_label: Label
var skin_preview
var crosshair_wanted: bool = true
var toast_label: Label
var crosshair: Label
var hotbar_holder: Panel
var hotbar_widgets: Array = []
var inv_widgets: Array = []
var heart_icons: Array = []
var armor_icons: Array = []
var food_icons: Array = []
var ui_textures: Dictionary = {}
var xp_back: ColorRect
var xp_fill: ColorRect
var level_label: Label
var inventory_dim: ColorRect
var inventory_panel: Panel
var tooltip_label: Label
var cursor_box: Control
var cursor_icon: TextureRect
var cursor_count_label: Label
var hover_group: String = ""
var hover_index: int = 0
var pause_overlay: ColorRect
var pause_panel: PanelContainer
var ending_overlay: ColorRect
var ending_title: Label
var ending_message: Label
var ending_continue_button: Button
var toast_timer: float = 0.0
var creative_panel: Panel
var creative_scroll: ScrollContainer
var creative_grid: GridContainer
var creative_search: LineEdit
var creative_cells: Array = []
var creative_tab_buttons: Array = []
var creative_hotbar_widgets: Array = []
var creative_tab: String = "all"
var hover_creative_item: String = ""
var creative_mode: bool = false
var water_overlay: ColorRect
var loading_overlay: ColorRect
var loading_label: Label
var loading_bar: ColorRect
var debug_label: Label
var debug_timer: float = 0.0

func setup(game_ref: Node, player_ref: Node3D, world_ref: Node3D) -> void:
    game = game_ref
    player = player_ref
    world = world_ref
    _build_ui()
    refresh()

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS

func _process(delta: float) -> void:
    toast_timer = maxf(0.0, toast_timer - delta)
    if toast_timer <= 0.0 and is_instance_valid(toast_label):
        toast_label.visible = false
    if is_instance_valid(water_overlay) and is_instance_valid(player):
        water_overlay.visible = bool(player.head_in_water)
    if is_instance_valid(debug_label) and debug_label.visible:
        debug_timer -= delta
        if debug_timer <= 0.0:
            debug_timer = 0.2
            _update_debug_text()
    if _any_inventory_visible():
        var mouse_position: Vector2 = get_viewport().get_mouse_position()
        if skin_preview != null:
            skin_preview.look_at_mouse(mouse_position)
        cursor_box.position = mouse_position - Vector2(16, 16)
        tooltip_label.position = mouse_position + Vector2(16, -36)

# ------------------------------------------------------------------ styles

func _panel_style(background: Color = Color(0.035, 0.05, 0.065, 0.88), border: Color = Color("65717a")) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = background
    style.border_color = border
    style.set_border_width_all(2)
    style.set_corner_radius_all(0)
    style.content_margin_left = 12
    style.content_margin_right = 12
    style.content_margin_top = 9
    style.content_margin_bottom = 9
    return style

func _flat_style(background: Color, border: Color, border_width: int) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = background
    style.border_color = border
    style.set_border_width_all(border_width)
    style.set_corner_radius_all(0)
    return style

func _slot_style(dark: bool, selected: bool, hovered: bool) -> StyleBoxFlat:
    if dark:
        if selected:
            return _flat_style(Color(0.16, 0.16, 0.16, 0.85), Color("ffffff"), 3)
        return _flat_style(Color(0.06, 0.06, 0.06, 0.72), Color("3a3a3a"), 2)
    if hovered:
        return _flat_style(Color("b9b9b9"), Color("ffffff"), 2)
    return _flat_style(Color("8b8b8b"), Color("373737"), 2)

# ------------------------------------------------------------------ building

func _load_ui_textures() -> void:
    for texture_name in ["heart_full", "heart_half", "heart_empty", "armor_full", "armor_half", "armor_empty", "food_full", "food_half", "food_empty"]:
        ui_textures[texture_name] = Catalog.ui_texture(str(texture_name))

func _make_icon_rect() -> TextureRect:
    var rect := TextureRect.new()
    rect.size = Vector2(ICON_SIZE, ICON_SIZE)
    rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    rect.stretch_mode = TextureRect.STRETCH_SCALE
    rect.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return rect

func _build_ui() -> void:
    _load_ui_textures()
    root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_PASS
    add_child(root)

    water_overlay = ColorRect.new()
    water_overlay.color = Color(0.10, 0.25, 0.62, 0.38)
    water_overlay.visible = false
    water_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(water_overlay)
    water_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    brand_panel = PanelContainer.new()
    brand_panel.position = Vector2(18, 18)
    brand_panel.custom_minimum_size = Vector2(245, 54)
    brand_panel.size = Vector2(245, 54)
    brand_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.025, 0.055, 0.11, 0.72), Color(0.72, 0.80, 1.0, 0.30)))
    root.add_child(brand_panel)
    var brand_box := VBoxContainer.new()
    brand_box.add_theme_constant_override("separation", 1)
    brand_panel.add_child(brand_box)
    brand_label = Label.new()
    brand_label.text = "ReCraft  /  SURVIVAL"
    brand_label.add_theme_font_size_override("font_size", 16)
    brand_label.add_theme_color_override("font_color", Color("f2f6ff"))
    brand_box.add_child(brand_label)
    sandbox_label = Label.new()
    sandbox_label.text = "Исследуй мир и строй"
    sandbox_label.add_theme_font_size_override("font_size", 11)
    sandbox_label.add_theme_color_override("font_color", Color("c9d7f2"))
    brand_box.add_child(sandbox_label)

    hint_label = Label.new()
    hint_label.text = "WASD ходьба · Ctrl или 2×W бег · Shift присесть · Space прыжок · C творческий режим · E инвентарь · ЛКМ добывать · ПКМ поставить · F3 отладка · F5 вид"
    hint_label.position = Vector2(18, 145)
    hint_label.size = Vector2(980, 22)
    hint_label.add_theme_font_size_override("font_size", 12)
    hint_label.add_theme_color_override("font_color", Color("d2d5ce"))
    root.add_child(hint_label)

    crosshair = Label.new()
    crosshair.name = "Crosshair"
    crosshair.text = "+"
    crosshair.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    crosshair.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    crosshair.add_theme_font_size_override("font_size", 24)
    crosshair.add_theme_color_override("font_color", Color("ffffff"))
    crosshair.add_theme_color_override("font_shadow_color", Color("151b20"))
    crosshair.add_theme_constant_override("shadow_offset_x", 1)
    crosshair.add_theme_constant_override("shadow_offset_y", 1)
    crosshair.size = Vector2(28, 28)
    root.add_child(crosshair)

    toast_label = Label.new()
    toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    toast_label.add_theme_font_size_override("font_size", 18)
    toast_label.add_theme_color_override("font_color", Color("ffe6a7"))
    toast_label.add_theme_color_override("font_shadow_color", Color("101820"))
    toast_label.add_theme_constant_override("shadow_offset_x", 2)
    toast_label.add_theme_constant_override("shadow_offset_y", 2)
    toast_label.size = Vector2(780, 38)
    toast_label.visible = false
    root.add_child(toast_label)

    debug_label = Label.new()
    debug_label.position = Vector2(18, 180)
    debug_label.size = Vector2(520, 160)
    debug_label.visible = false
    debug_label.add_theme_font_size_override("font_size", 14)
    debug_label.add_theme_color_override("font_color", Color("ffffff"))
    debug_label.add_theme_color_override("font_outline_color", Color("000000"))
    debug_label.add_theme_constant_override("outline_size", 4)
    debug_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(debug_label)

    _build_status_bars()
    _build_hotbar()
    _build_inventory_panel()
    _build_creative_panel()
    _build_pause_panel()
    _build_ending_panel()
    _build_loading_overlay()
    _layout()
    get_viewport().size_changed.connect(_layout)

func _build_status_bars() -> void:
    for i in range(10):
        var heart := _make_icon_rect()
        root.add_child(heart)
        heart_icons.append(heart)
        var armor := _make_icon_rect()
        root.add_child(armor)
        armor_icons.append(armor)
        var food := _make_icon_rect()
        root.add_child(food)
        food_icons.append(food)
    xp_back = ColorRect.new()
    xp_back.color = Color(0.05, 0.05, 0.05, 0.85)
    xp_back.size = Vector2(486, 8)
    xp_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(xp_back)
    xp_fill = ColorRect.new()
    xp_fill.color = Color("7ed321")
    xp_fill.size = Vector2(0, 8)
    xp_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(xp_fill)
    level_label = Label.new()
    level_label.size = Vector2(60, 24)
    level_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    level_label.add_theme_font_size_override("font_size", 18)
    level_label.add_theme_color_override("font_color", Color("80ff20"))
    level_label.add_theme_color_override("font_outline_color", Color("000000"))
    level_label.add_theme_constant_override("outline_size", 5)
    level_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(level_label)

func _make_slot(parent: Control, group: String, index: int, pos: Vector2, interactive: bool, dark: bool) -> Dictionary:
    var panel := Panel.new()
    panel.position = pos
    panel.size = Vector2(SLOT_SIZE, SLOT_SIZE)
    panel.add_theme_stylebox_override("panel", _slot_style(dark, false, false))
    parent.add_child(panel)
    var icon := TextureRect.new()
    icon.position = Vector2(9, 9)
    icon.size = Vector2(32, 32)
    icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    icon.stretch_mode = TextureRect.STRETCH_SCALE
    icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.add_child(icon)
    var count_label := Label.new()
    count_label.position = Vector2(0, 27)
    count_label.size = Vector2(SLOT_SIZE - 4, 20)
    count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    count_label.add_theme_font_size_override("font_size", 14)
    count_label.add_theme_color_override("font_color", Color("ffffff"))
    count_label.add_theme_color_override("font_outline_color", Color("1a1a1a"))
    count_label.add_theme_constant_override("outline_size", 4)
    count_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.add_child(count_label)
    if interactive:
        panel.gui_input.connect(_on_slot_gui_input.bind(group, index))
        panel.mouse_entered.connect(_on_slot_hover.bind(group, index))
        panel.mouse_exited.connect(_on_slot_unhover)
    else:
        panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return {"panel": panel, "icon": icon, "count": count_label, "group": group, "index": index, "dark": dark}

func _build_hotbar() -> void:
    hotbar_holder = Panel.new()
    hotbar_holder.size = Vector2(9 * SLOT_PITCH + 10, 62)
    hotbar_holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hotbar_holder.add_theme_stylebox_override("panel", _flat_style(Color(0.02, 0.02, 0.02, 0.45), Color(0, 0, 0, 0), 0))
    root.add_child(hotbar_holder)
    for index in range(9):
        var widget: Dictionary = _make_slot(hotbar_holder, "inv", index, Vector2(5 + index * SLOT_PITCH, 6), false, true)
        hotbar_widgets.append(widget)

func _add_label(parent: Control, text_value: String, pos: Vector2, font_size: int, color: Color) -> Label:
    var label := Label.new()
    label.text = text_value
    label.position = pos
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(label)
    return label

func _add_rect(parent: Control, pos: Vector2, rect_size: Vector2, color: Color) -> ColorRect:
    var rect := ColorRect.new()
    rect.position = pos
    rect.size = rect_size
    rect.color = color
    rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(rect)
    return rect

func _build_inventory_panel() -> void:
    inventory_dim = ColorRect.new()
    inventory_dim.color = Color(0, 0, 0, 0.5)
    inventory_dim.visible = false
    inventory_dim.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(inventory_dim)
    inventory_dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    inventory_panel = Panel.new()
    inventory_panel.visible = false
    inventory_panel.size = Vector2(522, 506)
    inventory_panel.mouse_filter = Control.MOUSE_FILTER_STOP
    inventory_panel.add_theme_stylebox_override("panel", _flat_style(Color("c6c6c6"), Color("1b1b1b"), 3))
    root.add_child(inventory_panel)

    # armour slots (decorative for now - no armour items exist yet)
    for i in range(4):
        inv_widgets.append(_make_slot(inventory_panel, "armor", i, Vector2(20, 22 + i * SLOT_PITCH), true, false))

    # live 3D preview of the player's skin; head and body follow the mouse cursor
    skin_preview = SkinPreviewScript.new()
    skin_preview.position = Vector2(78, 22)
    inventory_panel.add_child(skin_preview)
    skin_preview.setup(player.get_skin_texture(), Vector2(140, 212), false, true)

    inv_widgets.append(_make_slot(inventory_panel, "offhand", 0, Vector2(228, 184), true, false))

    _add_label(inventory_panel, "Создание", Vector2(252, 18), 18, Color("404040"))
    for row in range(2):
        for column in range(2):
            var craft_index: int = row * 2 + column
            inv_widgets.append(_make_slot(inventory_panel, "craft", craft_index, Vector2(252 + column * SLOT_PITCH, 48 + row * SLOT_PITCH), true, false))
    _add_label(inventory_panel, "→", Vector2(372, 68), 40, Color("707070"))
    inv_widgets.append(_make_slot(inventory_panel, "result", 0, Vector2(424, 75), true, false))

    _add_label(inventory_panel, "Рюкзак", Vector2(22, 238), 15, Color("404040"))
    for row in range(3):
        for column in range(9):
            var main_index: int = 9 + row * 9 + column
            inv_widgets.append(_make_slot(inventory_panel, "inv", main_index, Vector2(20 + column * SLOT_PITCH, 262 + row * SLOT_PITCH), true, false))
    for column in range(9):
        inv_widgets.append(_make_slot(inventory_panel, "inv", column, Vector2(20 + column * SLOT_PITCH, 436), true, false))

    tooltip_label = Label.new()
    tooltip_label.visible = false
    tooltip_label.add_theme_font_size_override("font_size", 15)
    tooltip_label.add_theme_color_override("font_color", Color("ffffff"))
    var tip_style := _flat_style(Color(0.06, 0.0, 0.1, 0.94), Color("2b0a5c"), 2)
    tip_style.content_margin_left = 8
    tip_style.content_margin_right = 8
    tip_style.content_margin_top = 4
    tip_style.content_margin_bottom = 4
    tooltip_label.add_theme_stylebox_override("normal", tip_style)
    tooltip_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(tooltip_label)

    cursor_box = Control.new()
    cursor_box.visible = false
    cursor_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(cursor_box)
    cursor_icon = TextureRect.new()
    cursor_icon.size = Vector2(32, 32)
    cursor_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    cursor_icon.stretch_mode = TextureRect.STRETCH_SCALE
    cursor_icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    cursor_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cursor_box.add_child(cursor_icon)
    cursor_count_label = Label.new()
    cursor_count_label.position = Vector2(-4, 16)
    cursor_count_label.size = Vector2(40, 20)
    cursor_count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    cursor_count_label.add_theme_font_size_override("font_size", 14)
    cursor_count_label.add_theme_color_override("font_color", Color("ffffff"))
    cursor_count_label.add_theme_color_override("font_outline_color", Color("1a1a1a"))
    cursor_count_label.add_theme_constant_override("outline_size", 4)
    cursor_count_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cursor_box.add_child(cursor_count_label)

func _build_pause_panel() -> void:
    pause_overlay = ColorRect.new()
    pause_overlay.color = Color(0.015, 0.02, 0.025, 0.75)
    pause_overlay.visible = false
    pause_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(pause_overlay)
    pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var center := CenterContainer.new()
    pause_overlay.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    pause_panel = PanelContainer.new()
    pause_panel.custom_minimum_size = Vector2(350, 290)
    pause_panel.add_theme_stylebox_override("panel", _panel_style(Color("222820"), Color("9aab88")))
    center.add_child(pause_panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    pause_panel.add_child(box)
    var title := Label.new()
    title.text = "ПАУЗА"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 18)
    title.add_theme_color_override("font_color", Color("e3c47d"))
    box.add_child(title)
    _add_menu_button(box, "ПРОДОЛЖИТЬ", func(): game.toggle_pause(false))
    _add_menu_button(box, "СОХРАНИТЬ", func(): game.save_game())
    _add_menu_button(box, "В ГЛАВНОЕ МЕНЮ", func(): game.return_to_title())

func _build_ending_panel() -> void:
    ending_overlay = ColorRect.new()
    ending_overlay.color = Color(0.012, 0.02, 0.03, 0.88)
    ending_overlay.visible = false
    ending_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(ending_overlay)
    ending_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var center := CenterContainer.new()
    ending_overlay.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(580, 310)
    panel.add_theme_stylebox_override("panel", _panel_style(Color("1c2829"), Color("8ac5bd")))
    center.add_child(panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    panel.add_child(box)
    ending_title = Label.new()
    ending_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ending_title.add_theme_font_size_override("font_size", 28)
    ending_title.add_theme_color_override("font_color", Color("e3c47d"))
    box.add_child(ending_title)
    ending_message = Label.new()
    ending_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    ending_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ending_message.add_theme_font_size_override("font_size", 16)
    ending_message.add_theme_color_override("font_color", Color("d6e4dd"))
    box.add_child(ending_message)
    ending_continue_button = Button.new()
    ending_continue_button.custom_minimum_size = Vector2(300, 42)
    ending_continue_button.add_theme_font_size_override("font_size", 15)
    ending_continue_button.add_theme_color_override("font_color", Color("e2e8df"))
    ending_continue_button.add_theme_stylebox_override("normal", _panel_style(Color("343e34"), Color("71876c")))
    ending_continue_button.add_theme_stylebox_override("hover", _panel_style(Color("4b5a43"), Color("d5c27e")))
    ending_continue_button.pressed.connect(_on_ending_continue)
    box.add_child(ending_continue_button)
    _add_menu_button(box, "ВЕРНУТЬСЯ В ГЛАВНОЕ МЕНЮ", func(): game.return_to_title())

func _add_menu_button(parent: VBoxContainer, caption: String, callback: Callable) -> void:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(300, 42)
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size", 15)
    button.add_theme_color_override("font_color", Color("e2e8df"))
    button.add_theme_stylebox_override("normal", _panel_style(Color("343e34"), Color("71876c")))
    button.add_theme_stylebox_override("hover", _panel_style(Color("4b5a43"), Color("d5c27e")))
    parent.add_child(button)
    button.pressed.connect(callback)

# ------------------------------------------------------------------ layout

func _layout() -> void:
    if not is_instance_valid(root):
        return
    var view_size: Vector2 = get_viewport().get_visible_rect().size
    crosshair.position = view_size * 0.5 - crosshair.size * 0.5
    toast_label.position = Vector2((view_size.x - toast_label.size.x) * 0.5, 75)
    var holder_x: float = (view_size.x - hotbar_holder.size.x) * 0.5
    var holder_y: float = view_size.y - 74.0
    hotbar_holder.position = Vector2(holder_x, holder_y)
    xp_back.position = Vector2(holder_x + 5.0, holder_y - 14.0)
    xp_fill.position = xp_back.position
    level_label.position = Vector2(holder_x + hotbar_holder.size.x * 0.5 - 30.0, holder_y - 42.0)
    for i in range(10):
        var heart: TextureRect = heart_icons[i]
        heart.position = Vector2(holder_x + 5.0 + i * ICON_PITCH, holder_y - 36.0)
        var armor: TextureRect = armor_icons[i]
        armor.position = Vector2(holder_x + 5.0 + i * ICON_PITCH, holder_y - 58.0)
        var food: TextureRect = food_icons[i]
        food.position = Vector2(holder_x + hotbar_holder.size.x - 5.0 - ICON_SIZE - i * ICON_PITCH, holder_y - 36.0)
    inventory_panel.position = ((view_size - inventory_panel.size) * 0.5).floor()
    creative_panel.position = ((view_size - creative_panel.size) * 0.5).floor()

# ------------------------------------------------------------------ refresh

func _tri_texture(value: int, index: int, prefix: String) -> Texture2D:
    var full_need: int = index * 2 + 2
    if value >= full_need:
        return ui_textures.get(prefix + "_full") as Texture2D
    if value == full_need - 1:
        return ui_textures.get(prefix + "_half") as Texture2D
    return ui_textures.get(prefix + "_empty") as Texture2D

func _update_slot_widget(widget: Dictionary, item_id: String, amount: int, selected: bool, hovered: bool) -> void:
    var icon: TextureRect = widget["icon"]
    var count_label: Label = widget["count"]
    var panel: Panel = widget["panel"]
    if item_id == "":
        icon.texture = null
        count_label.text = ""
    else:
        icon.texture = Catalog.icon(item_id)
        count_label.text = str(amount) if amount > 1 else ""
    var is_dark: bool = bool(widget["dark"])
    panel.add_theme_stylebox_override("panel", _slot_style(is_dark, selected, hovered))

func refresh() -> void:
    if not is_instance_valid(player):
        return
    var inventory_open: bool = _any_inventory_visible()
    var survival_ui: bool = not inventory_open and not creative_mode

    var hp: int = int(round(player.health))
    var hunger_points: int = int(ceil(player.hunger))
    var armor_points: int = int(player.get_armor_points())
    for i in range(10):
        var heart: TextureRect = heart_icons[i]
        heart.texture = _tri_texture(hp, i, "heart")
        heart.visible = survival_ui
        var armor: TextureRect = armor_icons[i]
        armor.texture = _tri_texture(armor_points, i, "armor")
        armor.visible = survival_ui and armor_points > 0
        var food: TextureRect = food_icons[i]
        food.texture = _tri_texture(hunger_points, i, "food")
        food.visible = survival_ui
    var level: int = int(player.get_level())
    var progress: float = float(player.get_level_progress())
    xp_back.visible = survival_ui
    xp_fill.visible = survival_ui
    xp_fill.size = Vector2(xp_back.size.x * progress, xp_back.size.y)
    level_label.visible = survival_ui and level > 0
    level_label.text = str(level)
    hotbar_holder.visible = not inventory_open
    crosshair.visible = (not inventory_open) and crosshair_wanted


    var selected: int = int(player.selected_slot)
    for widget in hotbar_widgets:
        var hotbar_index: int = int(widget["index"])
        var hotbar_item: String = player.get_slot_id("inv", hotbar_index)
        var hotbar_amount: int = player.get_slot_count("inv", hotbar_index)
        _update_slot_widget(widget, hotbar_item, hotbar_amount, hotbar_index == selected, false)
    for widget in creative_hotbar_widgets:
        var cr_index: int = int(widget["index"])
        _update_slot_widget(widget, player.get_slot_id("inv", cr_index), player.get_slot_count("inv", cr_index), cr_index == selected, hover_group == "inv" and hover_index == cr_index)
    for widget in inv_widgets:
        var group_name: String = str(widget["group"])
        var slot_index: int = int(widget["index"])
        var slot_item: String = player.get_slot_id(group_name, slot_index)
        var slot_amount: int = player.get_slot_count(group_name, slot_index)
        var hovered: bool = group_name == hover_group and slot_index == hover_index
        _update_slot_widget(widget, slot_item, slot_amount, false, hovered)

    var cursor_item: String = str(player.cursor_id)
    cursor_box.visible = inventory_open and cursor_item != ""
    if cursor_item != "":
        cursor_icon.texture = Catalog.icon(cursor_item)
        var cursor_amount: int = int(player.cursor_count)
        cursor_count_label.text = str(cursor_amount) if cursor_amount > 1 else ""
    _update_tooltip()

func _update_tooltip() -> void:
    var show_tip: bool = false
    if hover_creative_item != "" and is_instance_valid(player) and str(player.cursor_id) == "":
        tooltip_label.text = Catalog.item_name(hover_creative_item)
        tooltip_label.reset_size()
        show_tip = true
    elif hover_group != "" and is_instance_valid(player) and str(player.cursor_id) == "":
        var item_id: String = player.get_slot_id(hover_group, hover_index)
        if item_id != "":
            tooltip_label.text = Catalog.item_name(item_id)
            tooltip_label.reset_size()
            show_tip = true
    tooltip_label.visible = show_tip and _any_inventory_visible()

# ------------------------------------------------------------------ interaction

func _on_slot_gui_input(event: InputEvent, group: String, index: int) -> void:
    var mouse_event := event as InputEventMouseButton
    if mouse_event == null or not mouse_event.pressed:
        return
    if mouse_event.button_index == MOUSE_BUTTON_LEFT:
        player.slot_click(group, index, false)
    elif mouse_event.button_index == MOUSE_BUTTON_RIGHT:
        player.slot_click(group, index, true)
    else:
        return
    refresh()

func _on_slot_hover(group: String, index: int) -> void:
    hover_group = group
    hover_index = index
    refresh()

func _on_slot_unhover() -> void:
    hover_group = ""
    refresh()

func notify(message: String, duration: float = 3.2) -> void:
    if not is_instance_valid(toast_label):
        return
    toast_label.text = message
    toast_label.visible = true
    toast_timer = duration

func set_inventory_visible(visible_now: bool) -> void:
    var use_creative: bool = is_instance_valid(player) and bool(player.creative)
    inventory_panel.visible = visible_now and not use_creative
    creative_panel.visible = visible_now and use_creative
    inventory_dim.visible = visible_now
    hover_group = ""
    hover_creative_item = ""
    if not visible_now and is_instance_valid(creative_search):
        creative_search.release_focus()
    if visible_now and use_creative:
        _apply_creative_filter()
    refresh()

func set_crosshair_visible(visible_now: bool) -> void:
    crosshair_wanted = visible_now
    if is_instance_valid(crosshair):
        crosshair.visible = visible_now and not _any_inventory_visible()

func set_time_text(text_value: String) -> void:
    if is_instance_valid(sandbox_label):
        sandbox_label.text = text_value

func set_pause_visible(visible_now: bool) -> void:
    pause_overlay.visible = visible_now

func _on_ending_continue() -> void:
    game.respawn_player()

func show_death() -> void:
    ending_title.text = "ТЫ ПОГИБ"
    ending_continue_button.text = "ВОЗРОДИТЬСЯ"
    ending_message.text = "Ты потерял сознание. Возродись и продолжай исследовать мир."
    ending_overlay.visible = true

func hide_ending() -> void:
    ending_overlay.visible = false

# ------------------------------------------------------------------ creative inventory

func _any_inventory_visible() -> bool:
    return (is_instance_valid(inventory_panel) and inventory_panel.visible) or (is_instance_valid(creative_panel) and creative_panel.visible)

func _build_creative_panel() -> void:
    creative_panel = Panel.new()
    creative_panel.visible = false
    creative_panel.size = Vector2(522, 524)
    creative_panel.mouse_filter = Control.MOUSE_FILTER_STOP
    creative_panel.add_theme_stylebox_override("panel", _flat_style(Color("c6c6c6"), Color("1b1b1b"), 3))
    root.add_child(creative_panel)

    _add_label(creative_panel, "Творческий инвентарь", Vector2(20, 14), 18, Color("404040"))
    creative_search = LineEdit.new()
    creative_search.position = Vector2(300, 10)
    creative_search.size = Vector2(202, 30)
    creative_search.placeholder_text = "Поиск…"
    creative_search.clear_button_enabled = true
    creative_search.add_theme_font_size_override("font_size", 14)
    creative_search.text_changed.connect(func(_text: String) -> void: _apply_creative_filter())
    creative_panel.add_child(creative_search)

    var tab_width: float = 70.0
    for i in range(CREATIVE_TABS.size()):
        var tab: Array = CREATIVE_TABS[i]
        var button := Button.new()
        button.text = str(tab[1])
        button.toggle_mode = true
        button.position = Vector2(20 + i * (tab_width - 2), 46)
        button.size = Vector2(tab_width, 28)
        button.focus_mode = Control.FOCUS_NONE
        button.add_theme_font_size_override("font_size", 12)
        button.pressed.connect(_on_creative_tab.bind(str(tab[0])))
        creative_panel.add_child(button)
        creative_tab_buttons.append([str(tab[0]), button])

    creative_scroll = ScrollContainer.new()
    creative_scroll.position = Vector2(14, 82)
    creative_scroll.size = Vector2(496, 274)
    creative_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    creative_panel.add_child(creative_scroll)
    creative_grid = GridContainer.new()
    creative_grid.columns = 9
    creative_grid.add_theme_constant_override("h_separation", SLOT_PITCH - SLOT_SIZE)
    creative_grid.add_theme_constant_override("v_separation", SLOT_PITCH - SLOT_SIZE)
    creative_scroll.add_child(creative_grid)

    for entry_variant in Catalog.creative_entries():
        var entry: Array = entry_variant
        var item_id: String = str(entry[0])
        var cell := Panel.new()
        cell.custom_minimum_size = Vector2(SLOT_SIZE, SLOT_SIZE)
        cell.add_theme_stylebox_override("panel", _slot_style(false, false, false))
        var icon := TextureRect.new()
        icon.position = Vector2(9, 9)
        icon.size = Vector2(32, 32)
        icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        icon.stretch_mode = TextureRect.STRETCH_SCALE
        icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
        icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
        icon.texture = Catalog.icon(item_id)
        cell.add_child(icon)
        cell.gui_input.connect(_on_creative_cell_input.bind(item_id))
        cell.mouse_entered.connect(_on_creative_cell_hover.bind(item_id, cell))
        cell.mouse_exited.connect(_on_creative_cell_unhover.bind(cell))
        creative_grid.add_child(cell)
        creative_cells.append({
            "panel": cell,
            "id": item_id,
            "cat": str(entry[1]),
            "search": (Catalog.item_name(item_id) + " " + item_id).to_lower()
        })

    _add_label(creative_panel, "Панель быстрого доступа", Vector2(20, 366), 14, Color("404040"))
    for column in range(9):
        creative_hotbar_widgets.append(_make_slot(creative_panel, "inv", column, Vector2(20 + column * SLOT_PITCH, 390), true, false))

    var trash := Panel.new()
    trash.position = Vector2(20, 452)
    trash.size = Vector2(200, 32)
    trash.add_theme_stylebox_override("panel", _flat_style(Color("8b8b8b"), Color("373737"), 2))
    trash.gui_input.connect(_on_creative_trash_input)
    creative_panel.add_child(trash)
    var trash_label := Label.new()
    trash_label.text = "Убрать предмет с курсора"
    trash_label.position = Vector2(10, 5)
    trash_label.add_theme_font_size_override("font_size", 13)
    trash_label.add_theme_color_override("font_color", Color("ffffff"))
    trash_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    trash.add_child(trash_label)

    _add_label(creative_panel, "ЛКМ — взять стак · ПКМ — взять 1 · СКМ в мире — копировать блок · 2×Space — полёт", Vector2(20, 494), 11, Color("505050"))
    _refresh_creative_tabs()
    _apply_creative_filter()

func _on_creative_tab(tab_id: String) -> void:
    creative_tab = tab_id
    _refresh_creative_tabs()
    _apply_creative_filter()

func _refresh_creative_tabs() -> void:
    for pair_variant in creative_tab_buttons:
        var pair: Array = pair_variant
        var button: Button = pair[1]
        button.button_pressed = str(pair[0]) == creative_tab

func _apply_creative_filter() -> void:
    var query: String = creative_search.text.strip_edges().to_lower() if is_instance_valid(creative_search) else ""
    for cell_variant in creative_cells:
        var cell: Dictionary = cell_variant
        var matches_tab: bool = creative_tab == "all" or str(cell["cat"]) == creative_tab
        var matches_query: bool = query == "" or str(cell["search"]).contains(query)
        var panel: Panel = cell["panel"]
        panel.visible = matches_tab and matches_query
    if is_instance_valid(creative_scroll):
        creative_scroll.scroll_vertical = 0

func _on_creative_cell_input(event: InputEvent, item_id: String) -> void:
    var mouse_event := event as InputEventMouseButton
    if mouse_event == null or not mouse_event.pressed:
        return
    var stack: int = Catalog.max_stack(item_id)
    if mouse_event.button_index == MOUSE_BUTTON_LEFT:
        player.cursor_id = item_id
        player.cursor_count = stack
    elif mouse_event.button_index == MOUSE_BUTTON_RIGHT:
        if str(player.cursor_id) == item_id:
            player.cursor_count = mini(stack, int(player.cursor_count) + 1)
        else:
            player.cursor_id = item_id
            player.cursor_count = 1
    else:
        return
    refresh()

func _on_creative_cell_hover(item_id: String, cell: Panel) -> void:
    hover_creative_item = item_id
    cell.add_theme_stylebox_override("panel", _slot_style(false, false, true))
    refresh()

func _on_creative_cell_unhover(cell: Panel) -> void:
    hover_creative_item = ""
    cell.add_theme_stylebox_override("panel", _slot_style(false, false, false))
    refresh()

func _on_creative_trash_input(event: InputEvent) -> void:
    var mouse_event := event as InputEventMouseButton
    if mouse_event == null or not mouse_event.pressed:
        return
    player.cursor_id = ""
    player.cursor_count = 0
    refresh()

func set_creative_mode(is_creative: bool) -> void:
    creative_mode = is_creative
    if is_instance_valid(brand_label):
        brand_label.text = "ReCraft  /  CREATIVE" if is_creative else "ReCraft  /  SURVIVAL"
    if _any_inventory_visible():
        set_inventory_visible(true)
    refresh()

# ------------------------------------------------------------------ loading / debug

func _build_loading_overlay() -> void:
    loading_overlay = ColorRect.new()
    loading_overlay.color = Color(0.03, 0.05, 0.09, 0.96)
    loading_overlay.visible = false
    loading_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(loading_overlay)
    loading_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var center := CenterContainer.new()
    loading_overlay.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    center.add_child(box)
    loading_label = Label.new()
    loading_label.text = "Генерация мира…"
    loading_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    loading_label.add_theme_font_size_override("font_size", 24)
    loading_label.add_theme_color_override("font_color", Color("e8eeff"))
    box.add_child(loading_label)
    var bar_back := ColorRect.new()
    bar_back.color = Color(0.15, 0.18, 0.26, 1.0)
    bar_back.custom_minimum_size = Vector2(360, 10)
    box.add_child(bar_back)
    loading_bar = ColorRect.new()
    loading_bar.color = Color("7ed321")
    loading_bar.size = Vector2(0, 10)
    bar_back.add_child(loading_bar)

func set_loading(visible_now: bool, progress: float) -> void:
    if not is_instance_valid(loading_overlay):
        return
    loading_overlay.visible = visible_now
    if visible_now:
        loading_label.text = "Генерация мира… %d%%" % int(progress * 100.0)
        loading_bar.size = Vector2(360.0 * clampf(progress, 0.0, 1.0), 10.0)

func set_debug_visible(visible_now: bool) -> void:
    debug_label.visible = visible_now
    debug_timer = 0.0

func _update_debug_text() -> void:
    if not is_instance_valid(player) or not is_instance_valid(world):
        return
    var pos: Vector3 = player.feet_position()
    var cx: int = floori(pos.x + 0.5) >> 4
    var cz: int = floori(pos.z + 0.5) >> 4
    var biome: String = world.biome_name_at(floori(pos.x + 0.5), floori(pos.z + 0.5))
    var lines: Array = []
    lines.append("FPS: %d" % Engine.get_frames_per_second())
    lines.append("XYZ: %.2f / %.2f / %.2f" % [pos.x, pos.y, pos.z])
    lines.append("Чанк: %d, %d   Биом: %s" % [cx, cz, biome])
    lines.append("Загружено чанков: %d   задач: %d" % [world.loaded_chunk_count(), world.pending_job_count()])
    lines.append("Дальность: %d чанков   Сид: %d" % [world.view_distance_chunks, world.seed_value])
    if bool(player.has_target):
        lines.append("Цель: %s (%d, %d, %d)" % [Catalog.item_name(str(player.target_kind)), player.target_cell.x, player.target_cell.y, player.target_cell.z])
    lines.append("Режим: %s%s" % ["творческий" if player.creative else "выживание", " · полёт" if player.flying else ""])
    debug_label.text = "\n".join(lines)
