extends RefCounted
# Minecraft-style block hardness and break-time rules.
#
# Break time follows the vanilla formula (in game ticks, 20 per second):
#   ticks = ceil(hardness * (30 if the tool may harvest the block else 100) / tool_speed)
# Examples: dirt by hand 0.75 s, stone with an iron pickaxe 0.4 s, stone by hand 7.5 s.
# The only tool in this game is the pickaxe; it behaves like an iron pickaxe (speed 6).

const BREAK_TIME_SCALE: float = 1.0 # Multiply every break time (e.g. 2.0 = twice as slow).
const TICK: float = 0.05
const PICKAXE_SPEED: float = 6.0

const HARDNESS: Dictionary = {
    "grass": 0.6,
    "dirt": 0.5,
    "sand": 0.5,
    "wood": 2.0,
    "leaves": 0.2,
    "torch": 0.0,
    "stone": 1.5,
    "cobblestone": 2.0,
    "ancient": 1.5,
    "coal_ore": 3.0,
    "iron_ore": 3.0,
    "copper_ore": 3.0,
    "hematite_ore": 3.0,
    "cassiterite_ore": 3.0,
    "pentlandite_ore": 3.0,
    "garnierite_ore": 3.0,
    "sphalerite_ore": 3.0,
    "gold_ore": 3.0,
    "lapis_ore": 3.0,
    "redstone_ore": 3.0,
    "diamond_ore": 3.0,
    "titan_ore": 5.0,
    "uranium_ore": 5.0
}

const PICKAXE_REQUIRED: Array = [
    "stone", "cobblestone", "ancient",
    "coal_ore", "iron_ore", "copper_ore", "hematite_ore", "cassiterite_ore",
    "pentlandite_ore", "garnierite_ore", "sphalerite_ore", "gold_ore", "lapis_ore",
    "redstone_ore", "diamond_ore", "titan_ore", "uranium_ore"
]

static func is_breakable(kind: String) -> bool:
    return HARDNESS.has(kind)

static func hardness(kind: String) -> float:
    return float(HARDNESS.get(kind, -1.0))

static func needs_pickaxe(kind: String) -> bool:
    return PICKAXE_REQUIRED.has(kind)

static func can_harvest(kind: String, tool_id: String) -> bool:
    if not needs_pickaxe(kind):
        return true
    return tool_id == "pickaxe"

static func tool_speed(kind: String, tool_id: String) -> float:
    if tool_id == "pickaxe" and needs_pickaxe(kind):
        return PICKAXE_SPEED
    return 1.0

static func break_time(kind: String, tool_id: String) -> float:
    # Returns seconds, or INF when the block cannot be broken.
    if not HARDNESS.has(kind):
        return INF
    var h: float = float(HARDNESS[kind])
    if h <= 0.0:
        return 0.0
    var divisor: float = 30.0 if can_harvest(kind, tool_id) else 100.0
    var ticks: float = ceil(h * divisor / tool_speed(kind, tool_id))
    return maxf(1.0, ticks) * TICK * BREAK_TIME_SCALE

static func sound_group(kind: String) -> String:
    match kind:
        "grass", "dirt", "leaves":
            return "dirt"
        "sand":
            return "sand"
        "wood", "torch":
            return "wood"
    return "stone"
