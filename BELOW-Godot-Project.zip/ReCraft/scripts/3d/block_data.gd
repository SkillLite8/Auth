extends RefCounted
# Правила добычи блоков по образцу Minecraft. Твёрдость, потребность в кирке и звук берутся из реестра.
#
# Время добычи (в тиках, 20 в секунду):  ceil(твёрдость * (30, если инструмент подходит, иначе 100) / скорость)
# Примеры: земля рукой 0.75 с, камень кирой 0.4 с, камень рукой 7.5 с.
# Единственный инструмент - кирка; она работает как железная (скорость 6).

const B = preload("res://scripts/3d/block_registry.gd")
const Catalog = preload("res://scripts/3d/item_catalog.gd")

const BREAK_TIME_SCALE: float = 1.0 # Множитель ко всем временам добычи.
const TICK: float = 0.05
const PICKAXE_SPEED: float = 6.0

static func is_breakable(kind: String) -> bool:
    var block_id: int = B.id_of(kind)
    return block_id > 0 and B.hardness[block_id] >= 0.0

static func hardness(kind: String) -> float:
    var block_id: int = B.id_of(kind)
    if block_id <= 0:
        return -1.0
    return B.hardness[block_id]

static func needs_pickaxe(kind: String) -> bool:
    var block_id: int = B.id_of(kind)
    return block_id > 0 and B.needs_pick[block_id] == 1

static func can_harvest(kind: String, tool_id: String) -> bool:
    if not needs_pickaxe(kind):
        return true
    return Catalog.tool_type(tool_id) == "pickaxe" and Catalog.mining_tier(tool_id) >= 0

static func _tool_matches_block(tool_kind: String, block_kind: String) -> bool:
    if tool_kind == "axe":
        return block_kind.contains("log") or block_kind.contains("wood") or block_kind.contains("planks") or block_kind.contains("fence") or block_kind.contains("door") or block_kind.contains("trapdoor") or block_kind.contains("ladder") or block_kind.contains("chest") or block_kind.contains("barrel") or block_kind.contains("sign")
    if tool_kind == "shovel":
        return block_kind in ["dirt", "grass", "sand", "red_sand", "gravel", "snow", "packed_snow", "clay", "mud", "podzol", "mycelium", "soul_sand", "soul_soil", "farmland"] or block_kind.contains("dirt") or block_kind.contains("sand")
    if tool_kind == "sword":
        return block_kind.ends_with("_leaves") or block_kind == "cobweb" or block_kind == "bamboo"
    if tool_kind == "hoe":
        return block_kind.ends_with("_leaves") or block_kind in ["hay_block", "moss_block", "mossy_stone"]
    return false

static func tool_speed(kind: String, tool_id: String) -> float:
    var tool_kind: String = Catalog.tool_type(tool_id)
    if tool_kind == "pickaxe" and needs_pickaxe(kind):
        return Catalog.mining_speed(tool_id)
    if _tool_matches_block(tool_kind, kind):
        return Catalog.mining_speed(tool_id)
    if tool_id == "pickaxe" and needs_pickaxe(kind):
        return PICKAXE_SPEED
    return 1.0

# Секунды или INF, если блок сломать нельзя.
static func break_time(kind: String, tool_id: String) -> float:
    if not is_breakable(kind):
        return INF
    var h: float = hardness(kind)
    if h <= 0.0:
        return 0.0
    var divisor: float = 30.0 if can_harvest(kind, tool_id) else 100.0
    var ticks: float = ceil(h * divisor / tool_speed(kind, tool_id))
    return maxf(1.0, ticks) * TICK * BREAK_TIME_SCALE

static func sound_group(kind: String) -> String:
    var block_id: int = B.id_of(kind)
    if block_id <= 0:
        return "stone"
    return B.sounds[block_id]
