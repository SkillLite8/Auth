extends RefCounted
# Правила добычи блоков по образцу Minecraft.
#
# Время добычи (в тиках, 20 в секунду): ceil(твёрдость * (30, если инструмент подходит, иначе 100) / скорость).
# Скорость берётся у предмета в руке, если тип инструмента совпадает с типом блока (кирка - камень, топор - дерево,
# лопата - земля). Блоки из камня и руды дают добычу только инструментом нужного типа и уровня.

const B = preload("res://scripts/3d/block_registry.gd")
const I = preload("res://scripts/3d/item_registry.gd")

const BREAK_TIME_SCALE: float = 1.0
const TICK: float = 0.05

static func is_breakable(kind: String) -> bool:
    var block_id: int = B.id_of(kind)
    return block_id > 0 and B.hardness[block_id] >= 0.0

static func hardness(kind: String) -> float:
    var block_id: int = B.id_of(kind)
    if block_id <= 0:
        return -1.0
    return B.hardness[block_id]

static func tool_class(kind: String) -> String:
    var block_id: int = B.id_of(kind)
    if block_id <= 0:
        return "none"
    return B.tool_of[block_id]

static func needs_tool(kind: String) -> bool:
    var block_id: int = B.id_of(kind)
    return block_id > 0 and B.needs_pick[block_id] == 1

static func needs_pickaxe(kind: String) -> bool:
    return needs_tool(kind)

static func required_tier(kind: String) -> int:
    var block_id: int = B.id_of(kind)
    if block_id <= 0:
        return 0
    return B.tier_of[block_id]

static func tool_matches(kind: String, tool_id: String) -> bool:
    return tool_id != "" and I.has(tool_id) and I.tool_type(tool_id) == tool_class(kind)

static func can_harvest(kind: String, tool_id: String) -> bool:
    if not needs_tool(kind):
        return true
    return tool_matches(kind, tool_id) and I.tier(tool_id) >= required_tier(kind)

static func tool_speed(kind: String, tool_id: String) -> float:
    if tool_matches(kind, tool_id):
        return maxf(1.0, I.speed(tool_id))
    return 1.0

# Секунды или INF, если блок сломать нельзя.
static func break_time(kind: String, tool_id: String) -> float:
    if not is_breakable(kind):
        return INF
    var h: float = hardness(kind)
    if h <= 0.0:
        return 0.0
    var divisor: float = 30.0 if can_harvest(kind, tool_id) else 100.0
    var ticks: float = ceil(h * divisor / tool_speed(kind, tool_id))
    return maxf(1.0, ticks) * TICK * BREAK_TIME_SCALE

static func sound_group(kind: String) -> String:
    var block_id: int = B.id_of(kind)
    if block_id <= 0:
        return "stone"
    return B.sounds[block_id]
