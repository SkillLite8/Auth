extends Node3D
# Выпавшие предметы: маленькие вращающиеся модели с физикой по воксельным данным.
# Подбираются при приближении игрока (с «магнитом»), одинаковые стаки рядом сливаются,
# через 5 минут исчезают. Q в мире выбрасывает предмет из руки.

const Catalog = preload("res://scripts/3d/item_catalog.gd")
const ItemModels = preload("res://scripts/3d/item_models.gd")
const I = preload("res://scripts/3d/item_registry.gd")

const GRAVITY: float = 16.0
const HALF: float = 0.125
const MAX_DROPS: int = 256
const DESPAWN_SECONDS: float = 300.0
const MAGNET_RADIUS: float = 2.1
const PICKUP_DISTANCE: float = 0.55
const MERGE_RADIUS: float = 0.75

class Drop:
    extends RefCounted
    var item_id: String = ""
    var count: int = 1
    var pos: Vector3 = Vector3.ZERO
    var vel: Vector3 = Vector3.ZERO
    var age: float = 0.0
    var delay: float = 0.5
    var node: Node3D = null
    var on_ground: bool = false
    var phase: float = 0.0
    var shown_count: int = 0

var world
var player
var drops: Array = []
var protos: Dictionary = {}
var light_color: Color = Color.WHITE
var merge_timer: float = 0.0

func setup(world_ref, player_ref) -> void:
    name = "ItemDrops"
    world = world_ref
    player = player_ref

func set_light(color: Color) -> void:
    light_color = color
    for key in protos.keys():
        var entry: Dictionary = protos[key]
        ItemModels.apply_light(entry["root"], color)

func _exit_tree() -> void:
    for key in protos.keys():
        var entry: Dictionary = protos[key]
        var proto_root: Node = entry["root"]
        if is_instance_valid(proto_root):
            proto_root.free()
    protos.clear()

func _proto(item_id: String) -> Dictionary:
    var base: String = I.base_id(item_id)
    if protos.has(base):
        return protos[base]
    var root: Node3D = ItemModels.build(base)
    var entry: Dictionary = {"root": root, "mesh": null, "flat": Catalog.is_flat_item(base)}
    if root != null and root.get_child_count() > 0:
        var mesh_instance := root.get_child(0) as MeshInstance3D
        if mesh_instance != null:
            entry["mesh"] = mesh_instance.mesh
    ItemModels.apply_light(root, light_color)
    protos[base] = entry
    return entry

func count_drops() -> int:
    return drops.size()

func spawn(item_id: String, count: int, position: Vector3, velocity: Vector3, pickup_delay: float = 0.5) -> void:
    if item_id == "" or count <= 0:
        return
    var drop := Drop.new()
    drop.item_id = item_id
    drop.count = count
    drop.pos = position
    drop.vel = velocity
    drop.delay = pickup_delay
    drop.phase = randf() * TAU
    var entry: Dictionary = _proto(item_id)
    if entry["mesh"] == null:
        return
    drop.node = Node3D.new()
    add_child(drop.node)
    _rebuild_visual(drop, entry)
    drops.append(drop)
    if drops.size() > MAX_DROPS:
        _remove(drops[0])

func _rebuild_visual(drop: Drop, entry: Dictionary) -> void:
    for child in drop.node.get_children():
        child.queue_free()
    var copies: int = 1
    if drop.count > 1:
        copies = 2
    if drop.count > 16:
        copies = 3
    var flat: bool = bool(entry["flat"])
    var scale_value: float = 0.42 if flat else 0.27
    for i in range(copies):
        var mesh_instance := MeshInstance3D.new()
        mesh_instance.mesh = entry["mesh"]
        mesh_instance.scale = Vector3.ONE * scale_value
        mesh_instance.position = Vector3(0.06 * float(i), 0.0, 0.05 * float(i % 2) - 0.02 * float(i))
        mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        drop.node.add_child(mesh_instance)
    drop.shown_count = copies

func _remove(drop: Drop) -> void:
    if is_instance_valid(drop.node):
        drop.node.queue_free()
    drops.erase(drop)

func _solid(x: float, y: float, z: float) -> bool:
    return world.is_solid_cell(floori(x + 0.5), floori(y + 0.5), floori(z + 0.5))

func _process(delta: float) -> void:
    if world == null or not is_instance_valid(world):
        return
    var dt: float = minf(delta, 0.05)
    var player_center := Vector3.ZERO
    var can_pick: bool = is_instance_valid(player) and not bool(player.is_dead)
    if can_pick:
        player_center = player.global_position
    var remove_list: Array = []
    for drop_variant in drops:
        var d: Drop = drop_variant
        d.age += dt
        if d.age > DESPAWN_SECONDS or d.pos.y < float(world.MIN_Y) - 20.0:
            remove_list.append(d)
            continue
        _physics(d, dt)
        if can_pick and d.age >= d.delay:
            var to_player: Vector3 = player_center - d.pos
            var dist: float = to_player.length()
            if dist < MAGNET_RADIUS and player.can_accept(d.item_id):
                d.pos += to_player.normalized() * minf(dist, 9.0 * dt)
                d.vel = Vector3.ZERO
                if dist < PICKUP_DISTANCE:
                    var left: int = int(player.pickup_item(d.item_id, d.count))
                    if left <= 0:
                        remove_list.append(d)
                        continue
                    d.count = left
                    d.delay = d.age + 0.5
        _update_node(d)
    for item in remove_list:
        _remove(item)
    merge_timer -= dt
    if merge_timer <= 0.0:
        merge_timer = 0.4
        _merge_nearby()

func _physics(d: Drop, dt: float) -> void:
    if _solid(d.pos.x, d.pos.y, d.pos.z):
        d.pos.y += 3.0 * dt
        d.vel.y = 0.0
        return
    d.vel.y -= GRAVITY * dt
    var drag: float = pow(0.98, dt * 20.0)
    d.vel.x *= drag
    d.vel.z *= drag
    var new_y: float = d.pos.y + d.vel.y * dt
    d.on_ground = false
    if d.vel.y <= 0.0 and _solid(d.pos.x, new_y - HALF, d.pos.z):
        var cell_y: int = floori(new_y - HALF + 0.5)
        d.pos.y = float(cell_y) + 0.5 + HALF
        d.vel.y = 0.0
        d.on_ground = true
    elif d.vel.y > 0.0 and _solid(d.pos.x, new_y + HALF, d.pos.z):
        d.vel.y = 0.0
    else:
        d.pos.y = new_y
    var new_x: float = d.pos.x + d.vel.x * dt
    if _solid(new_x + signf(d.vel.x) * HALF, d.pos.y, d.pos.z):
        d.vel.x *= -0.2
    else:
        d.pos.x = new_x
    var new_z: float = d.pos.z + d.vel.z * dt
    if _solid(d.pos.x, d.pos.y, new_z + signf(d.vel.z) * HALF):
        d.vel.z *= -0.2
    else:
        d.pos.z = new_z
    if d.on_ground:
        var friction: float = pow(0.546, dt * 20.0)
        d.vel.x *= friction
        d.vel.z *= friction

func _update_node(d: Drop) -> void:
    if not is_instance_valid(d.node):
        return
    var bob: float = sin(d.age * 2.4 + d.phase) * 0.05 + 0.08
    d.node.position = d.pos + Vector3(0.0, bob, 0.0)
    d.node.rotation.y = d.age * 1.6 + d.phase

func _merge_nearby() -> void:
    var count: int = drops.size()
    if count < 2:
        return
    var removed: Array = []
    for i in range(count):
        var a: Drop = drops[i]
        if removed.has(a):
            continue
        var limit: int = Catalog.max_stack(a.item_id)
        if a.count >= limit:
            continue
        for j in range(i + 1, count):
            var b: Drop = drops[j]
            if removed.has(b) or b.item_id != a.item_id:
                continue
            if a.pos.distance_squared_to(b.pos) > MERGE_RADIUS * MERGE_RADIUS:
                continue
            var space: int = limit - a.count
            var moved: int = mini(space, b.count)
            a.count += moved
            b.count -= moved
            a.age = minf(a.age, b.age)
            if b.count <= 0:
                removed.append(b)
            if a.count >= limit:
                break
    for item in removed:
        _remove(item)
    for d_variant in drops:
        var d: Drop = d_variant
        var wanted: int = 1
        if d.count > 1:
            wanted = 2
        if d.count > 16:
            wanted = 3
        if wanted != d.shown_count:
            _rebuild_visual(d, _proto(d.item_id))
