extends Node3D
# Физический предмет в мире: подпрыгивает, вращается, лежит на поверхности, подбирается игроком
# и сохраняется в файле мира. Не удаляется при заполненном инвентаре.

const Catalog = preload("res://scripts/3d/item_catalog.gd")
const ItemModels = preload("res://scripts/3d/item_models.gd")
const DROP_HALF_HEIGHT: float = 0.16
const PICKUP_DISTANCE: float = 1.35
const PICKUP_DELAY: float = 0.55

var game
var item_id: String = ""
var amount: int = 1
var velocity: Vector3 = Vector3.ZERO
var lived: float = 0.0
var pickup_timer: float = 0.0
var visual: Node3D
var count_label: Label3D
var phase: float = 0.0
var start_y: float = 0.0

func setup(game_ref: Node, item: String, count: int, spawn_position: Vector3, impulse: Vector3 = Vector3.ZERO) -> void:
    game = game_ref
    item_id = Catalog.normalize_item(item)
    amount = maxi(1, count)
    global_position = spawn_position
    velocity = impulse
    phase = randf() * TAU
    start_y = spawn_position.y
    _build_visual()

func _ready() -> void:
    set_process(true)

func _build_visual() -> void:
    for child in get_children():
        child.queue_free()
    visual = Node3D.new()
    visual.name = "DroppedItem3DVisual"
    add_child(visual)
    var model: Node3D = ItemModels.build(item_id)
    if model != null:
        visual.add_child(model)
        if Catalog.block_kind(item_id) != "" and not ItemModels.is_flat(item_id):
            model.scale = Vector3.ONE * 0.34
        elif Catalog.has_item_model(item_id):
            model.scale = Vector3.ONE * 0.44
        else:
            model.scale = Vector3.ONE * 0.42
        model.position = Vector3(0.0, 0.02, 0.0)
    count_label = Label3D.new()
    count_label.name = "DroppedStackCount"
    count_label.position = Vector3(0.19, -0.16, 0.02)
    count_label.font_size = 42
    count_label.pixel_size = 0.0020
    count_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    count_label.no_depth_test = true
    count_label.outline_size = 8
    count_label.modulate = Color.WHITE
    count_label.visible = amount > 1
    count_label.text = str(amount) if amount > 1 else ""
    add_child(count_label)

func _process(delta: float) -> void:
    if not is_instance_valid(game) or not is_instance_valid(game.world):
        return
    if game.is_paused or game.loading:
        return
    lived += delta
    pickup_timer = maxf(0.0, pickup_timer - delta)
    var next_position: Vector3 = global_position
    velocity.y -= 14.0 * delta
    velocity.y = maxf(velocity.y, -18.0)
    next_position += velocity * delta

    var cell_x: int = floori(next_position.x + 0.5)
    var cell_z: int = floori(next_position.z + 0.5)
    var ground_y: int = floori(next_position.y - DROP_HALF_HEIGHT + 0.48)
    if game.world.is_solid_cell(cell_x, ground_y, cell_z):
        next_position.y = float(ground_y) + 0.5 + DROP_HALF_HEIGHT
        if velocity.y < -1.0:
            velocity.y = -velocity.y * 0.22
        else:
            velocity.y = 0.0
        velocity.x = move_toward(velocity.x, 0.0, 2.6 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 2.6 * delta)
    global_position = next_position
    rotation.y += delta * 1.35
    if is_instance_valid(visual):
        visual.rotation.y = sin(lived * 2.0 + phase) * 0.12
    if velocity.length_squared() < 0.012 and lived > 0.6:
        global_position.y = lerpf(global_position.y, float(ground_y) + 0.66, minf(1.0, delta * 7.0))

    if not is_instance_valid(game.player) or lived < PICKUP_DELAY or pickup_timer > 0.0:
        return
    if global_position.distance_to(game.player.global_position + Vector3.UP * 0.45) <= PICKUP_DISTANCE:
        var remainder: int = int(game.player.add_item(item_id, amount))
        amount = remainder
        if amount <= 0:
            queue_free()
            return
        _update_count()
        pickup_timer = 0.55

func _update_count() -> void:
    if not is_instance_valid(count_label):
        return
    count_label.visible = amount > 1
    count_label.text = str(amount) if amount > 1 else ""

func save_data() -> Dictionary:
    return {
        "id": item_id,
        "count": amount,
        "position": [global_position.x, global_position.y, global_position.z],
        "velocity": [velocity.x, velocity.y, velocity.z]
    }

func load_data(data: Dictionary) -> void:
    var p: Variant = data.get("position", [])
    var v: Variant = data.get("velocity", [0.0, 0.0, 0.0])
    if p is Array and p.size() >= 3:
        global_position = Vector3(float(p[0]), float(p[1]), float(p[2]))
    if v is Array and v.size() >= 3:
        velocity = Vector3(float(v[0]), float(v[1]), float(v[2]))
    start_y = global_position.y
