extends Node3D
# Minecraft-style player model built directly from a 64x64 skin (classic or slim arms),
# including the second skin layer (hat, jacket, sleeves, pants). Used for the third-person
# camera and for the inventory/profile previews. The model faces -Z, feet at y = 0.

const PX: float = 1.8 / 32.0
const SKIN_USER_PATH: String = "user://skin.png"
const SKIN_DEFAULT_PATH: String = "res://assets/skins/default_skin.png"
const SWING_TIME: float = 0.3
const ItemModels = preload("res://scripts/3d/item_models.gd")

var skin: Texture2D
var slim: bool = false
var material: StandardMaterial3D
var upper: Node3D
var head: Node3D
var right_arm: Node3D
var left_arm: Node3D
var right_leg: Node3D
var left_leg: Node3D
var hand_holder: Node3D
var held_item_id: String = ""
var light_color: Color = Color.WHITE

var last_yaw: float = 0.0
var yaw_initialised: bool = false
var body_offset: float = 0.0
var limb_pos: float = 0.0
var limb_amt: float = 0.0
var anim_time: float = 0.0
var lean: float = 0.0
var swing_active: bool = false
var swing_t: float = 0.0

# ------------------------------------------------------------------ skin helpers

static func load_skin_texture() -> Texture2D:
    # A skin placed at user://skin.png (64x64) overrides the bundled default.
    if FileAccess.file_exists(SKIN_USER_PATH):
        var img: Image = Image.load_from_file(SKIN_USER_PATH)
        if img != null and img.get_width() == 64 and img.get_height() == 64:
            img.convert(Image.FORMAT_RGBA8)
            return ImageTexture.create_from_image(img)
    return load(SKIN_DEFAULT_PATH) as Texture2D

static func is_slim(tex: Texture2D) -> bool:
    if tex == null:
        return false
    var img: Image = tex.get_image()
    if img == null or img.get_width() < 64 or img.get_height() < 64:
        return false
    # Slim (3 px) arms leave the 4th column of the arm faces empty.
    for y in range(20, 32):
        if img.get_pixel(54, y).a > 0.1 or img.get_pixel(55, y).a > 0.1:
            return false
    return true

static func make_material(tex: Texture2D) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_texture = tex
    mat.vertex_color_use_as_albedo = true
    mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
    mat.alpha_scissor_threshold = 0.5
    mat.cull_mode = BaseMaterial3D.CULL_BACK
    return mat

# Builds a box centred on the origin and maps it with the standard Minecraft skin layout.
# size/uv_origin/grow are in skin pixels, px converts one skin pixel to scene units.
static func make_box_mesh(size: Vector3, uv_origin: Vector2, grow: float, px: float, tex_size: Vector2 = Vector2(64.0, 64.0)) -> ArrayMesh:
    var w: float = size.x
    var h: float = size.y
    var d: float = size.z
    var hx: float = (w * 0.5 + grow) * px
    var hy: float = (h * 0.5 + grow) * px
    var hz: float = (d * 0.5 + grow) * px
    var u: float = uv_origin.x
    var v: float = uv_origin.y
    # Corners are listed top-left, top-right, bottom-right, bottom-left as seen from outside.
    var faces: Array = [
        {"c": [Vector3(hx, hy, -hz), Vector3(-hx, hy, -hz), Vector3(-hx, -hy, -hz), Vector3(hx, -hy, -hz)], "uv": Rect2(u + d, v + d, w, h), "shade": 0.8, "n": Vector3(0, 0, -1)},
        {"c": [Vector3(-hx, hy, hz), Vector3(hx, hy, hz), Vector3(hx, -hy, hz), Vector3(-hx, -hy, hz)], "uv": Rect2(u + 2.0 * d + w, v + d, w, h), "shade": 0.8, "n": Vector3(0, 0, 1)},
        {"c": [Vector3(hx, hy, hz), Vector3(hx, hy, -hz), Vector3(hx, -hy, -hz), Vector3(hx, -hy, hz)], "uv": Rect2(u, v + d, d, h), "shade": 0.6, "n": Vector3(1, 0, 0)},
        {"c": [Vector3(-hx, hy, -hz), Vector3(-hx, hy, hz), Vector3(-hx, -hy, hz), Vector3(-hx, -hy, -hz)], "uv": Rect2(u + d + w, v + d, d, h), "shade": 0.6, "n": Vector3(-1, 0, 0)},
        {"c": [Vector3(hx, hy, hz), Vector3(-hx, hy, hz), Vector3(-hx, hy, -hz), Vector3(hx, hy, -hz)], "uv": Rect2(u + d, v, w, d), "shade": 1.0, "n": Vector3(0, 1, 0)},
        {"c": [Vector3(hx, -hy, -hz), Vector3(-hx, -hy, -hz), Vector3(-hx, -hy, hz), Vector3(hx, -hy, hz)], "uv": Rect2(u + d + w, v, w, d), "shade": 0.5, "n": Vector3(0, -1, 0)}
    ]
    var vertices := PackedVector3Array()
    var normals := PackedVector3Array()
    var uvs := PackedVector2Array()
    var colors := PackedColorArray()
    var indices := PackedInt32Array()
    for face_variant in faces:
        var face: Dictionary = face_variant
        var corners: Array = face["c"]
        var rect: Rect2 = face["uv"]
        var shade: float = float(face["shade"])
        var normal: Vector3 = face["n"]
        var base: int = vertices.size()
        var uv_list: Array = [
            Vector2(rect.position.x, rect.position.y),
            Vector2(rect.position.x + rect.size.x, rect.position.y),
            Vector2(rect.position.x + rect.size.x, rect.position.y + rect.size.y),
            Vector2(rect.position.x, rect.position.y + rect.size.y)
        ]
        for i in range(4):
            vertices.append(corners[i])
            normals.append(normal)
            var uv_px: Vector2 = uv_list[i]
            uvs.append(Vector2(uv_px.x / tex_size.x, uv_px.y / tex_size.y))
            colors.append(Color(shade, shade, shade, 1.0))
        indices.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))
    var arrays: Array = []
    arrays.resize(Mesh.ARRAY_MAX)
    arrays[Mesh.ARRAY_VERTEX] = vertices
    arrays[Mesh.ARRAY_NORMAL] = normals
    arrays[Mesh.ARRAY_TEX_UV] = uvs
    arrays[Mesh.ARRAY_COLOR] = colors
    arrays[Mesh.ARRAY_INDEX] = indices
    var mesh := ArrayMesh.new()
    mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
    return mesh

# ------------------------------------------------------------------ construction

func setup(skin_texture: Texture2D) -> void:
    skin = skin_texture
    slim = is_slim(skin)
    material = make_material(skin)

    upper = Node3D.new()
    upper.name = "Upper"
    upper.position = Vector3(0.0, 12.0 * PX, 0.0)
    add_child(upper)

    _add_part(upper, "Body", Vector3(0, 0, 0), Vector3(8, 12, 4), Vector2(16, 16), Vector2(16, 32), 0.25, Vector3(0, 6, 0))
    head = _add_part(upper, "Head", Vector3(0, 12, 0), Vector3(8, 8, 8), Vector2(0, 0), Vector2(32, 0), 0.5, Vector3(0, 4, 0))

    var arm_w: float = 3.0 if slim else 4.0
    var arm_pivot_y: float = 9.5 if slim else 10.0
    var arm_off_x: float = 0.5 if slim else 1.0
    right_arm = _add_part(upper, "RightArm", Vector3(5, arm_pivot_y, 0), Vector3(arm_w, 12, 4), Vector2(40, 16), Vector2(40, 32), 0.25, Vector3(arm_off_x, -4, 0))
    left_arm = _add_part(upper, "LeftArm", Vector3(-5, arm_pivot_y, 0), Vector3(arm_w, 12, 4), Vector2(32, 48), Vector2(48, 48), 0.25, Vector3(-arm_off_x, -4, 0))

    right_leg = _add_part(self, "RightLeg", Vector3(1.9, 12, 0), Vector3(4, 12, 4), Vector2(0, 16), Vector2(0, 32), 0.25, Vector3(0, -6, 0))
    left_leg = _add_part(self, "LeftLeg", Vector3(-1.9, 12, 0), Vector3(4, 12, 4), Vector2(16, 48), Vector2(0, 48), 0.25, Vector3(0, -6, 0))

    hand_holder = Node3D.new()
    hand_holder.name = "HandHolder"
    hand_holder.position = Vector3(arm_off_x * PX, -9.5 * PX, -1.0 * PX)
    right_arm.add_child(hand_holder)

func _add_part(parent: Node3D, part_name: String, pivot_px: Vector3, size: Vector3, uv_base: Vector2, uv_over: Vector2, grow_over: float, mesh_offset_px: Vector3) -> Node3D:
    var pivot := Node3D.new()
    pivot.name = part_name
    pivot.position = pivot_px * PX
    parent.add_child(pivot)
    var base := MeshInstance3D.new()
    base.name = part_name + "Base"
    base.mesh = make_box_mesh(size, uv_base, 0.0, PX)
    base.material_override = material
    base.position = mesh_offset_px * PX
    base.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    pivot.add_child(base)
    var over := MeshInstance3D.new()
    over.name = part_name + "Layer"
    over.mesh = make_box_mesh(size, uv_over, grow_over, PX)
    over.material_override = material
    over.position = mesh_offset_px * PX
    over.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    pivot.add_child(over)
    return pivot

# ------------------------------------------------------------------ state

func set_light(color: Color) -> void:
    light_color = color
    if material != null:
        material.albedo_color = color
    if hand_holder != null:
        for child in hand_holder.get_children():
            ItemModels.apply_light(child, color)

func set_held_item(item_id: String) -> void:
    if hand_holder == null or item_id == held_item_id:
        return
    held_item_id = item_id
    for child in hand_holder.get_children():
        child.queue_free()
    if item_id == "":
        return
    var node: Node3D = ItemModels.build(item_id)
    if node == null:
        return
    if ItemModels.is_flat(item_id):
        node.rotation_degrees = Vector3(0.0, 20.0, 0.0)
        node.scale = Vector3.ONE * 0.62
        node.position = Vector3(0.0, 0.2, -0.2)
    else:
        node.scale = Vector3.ONE * 0.3
        node.position = Vector3(0.0, 0.02, -0.16)
    hand_holder.add_child(node)
    ItemModels.apply_light(node, light_color)

func swing() -> void:
    swing_active = true
    swing_t = 0.0

func update_pose(delta: float, player_yaw: float, pitch: float, horizontal_speed: float, sneaking: bool, grounded: bool) -> void:
    if upper == null:
        return
    if not yaw_initialised:
        last_yaw = player_yaw
        yaw_initialised = true
    var dyaw: float = angle_difference(last_yaw, player_yaw)
    last_yaw = player_yaw
    body_offset = wrapf(body_offset - dyaw, -PI, PI)
    var moving: bool = horizontal_speed > 0.3
    if moving or swing_active:
        body_offset = lerp_angle(body_offset, 0.0, minf(1.0, 12.0 * delta))
    var limit: float = deg_to_rad(50.0)
    body_offset = clampf(body_offset, -limit, limit)
    rotation.y = body_offset

    anim_time += delta
    var target_amt: float = clampf(horizontal_speed / 5.0, 0.0, 1.0)
    if not grounded:
        target_amt *= 0.4
    limb_amt = lerpf(limb_amt, target_amt, minf(1.0, 12.0 * delta))
    limb_pos += limb_amt * 20.0 * delta
    var s: float = cos(limb_pos * 0.6662)
    right_arm.rotation.x = s * limb_amt + sin(anim_time * 1.2) * 0.03
    left_arm.rotation.x = -s * limb_amt - sin(anim_time * 1.2) * 0.03
    right_arm.rotation.z = cos(anim_time * 1.8) * 0.05 + 0.05
    left_arm.rotation.z = -(cos(anim_time * 1.8 + 1.5) * 0.05 + 0.05)
    right_leg.rotation.x = -s * 1.4 * limb_amt
    left_leg.rotation.x = s * 1.4 * limb_amt

    if held_item_id != "":
        right_arm.rotation.x = right_arm.rotation.x * 0.5 + 0.314

    if swing_active:
        swing_t += delta / SWING_TIME
        if swing_t >= 1.0:
            swing_active = false
            swing_t = 0.0
        else:
            var f: float = 1.0 - swing_t
            f = f * f * f * f
            f = 1.0 - f
            var g: float = sin(f * PI)
            var h: float = sin(swing_t * PI) * (0.7 + pitch) * 0.75
            right_arm.rotation.x += g * 1.2 + h

    var target_lean: float = -0.45 if sneaking else 0.0
    lean = lerpf(lean, target_lean, minf(1.0, 12.0 * delta))
    upper.rotation.x = lean
    head.rotation.y = -body_offset
    head.rotation.x = clampf(pitch, -1.5, 1.5) - lean * 0.8
