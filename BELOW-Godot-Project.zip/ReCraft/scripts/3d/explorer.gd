extends Node3D
# Игрок от первого лица. Физика не использует движок: AABB 0.6x1.8 двигается по воксельным данным
# с шагом 20 тиков в секунду и константами Minecraft Bedrock (гравитация 0.08, сопротивление 0.98,
# прыжок 0.42, трение 0.546 на земле / 0.91 в воздухе), поэтому прыжки, бег и спуск работают точно.
# Origin узла = центр тела: ноги на 0.9 ниже origin, глаза на 1.62 выше ног.

const Catalog = preload("res://scripts/3d/item_catalog.gd")
const BlockData = preload("res://scripts/3d/block_data.gd")
const BlockRegistry = preload("res://scripts/3d/block_registry.gd")
const PlayerModelScript = preload("res://scripts/3d/player_model.gd")
const HandScript = preload("res://scripts/3d/first_person_hand.gd")
const EffectsScript = preload("res://scripts/3d/block_effects.gd")
const Settings = preload("res://scripts/3d/settings.gd")
const Crafting = preload("res://scripts/3d/crafting.gd")
const I = preload("res://scripts/3d/item_registry.gd")

const TICK: float = 0.05
const GRAVITY_TICK: float = 0.08
const AIR_DRAG_Y: float = 0.98
const JUMP_VELOCITY: float = 0.42
const JUMP_DELAY_TICKS: int = 10
const JUMP_BUFFER_TICKS: int = 3
const GROUND_FRICTION: float = 0.546
const AIR_FRICTION: float = 0.91
const WALK_ACCEL: float = 0.1
const SPRINT_MULT: float = 1.3
const SNEAK_MULT: float = 0.3
const AIR_ACCEL: float = 0.02
const FLY_ACCEL: float = 0.05
const HALF_WIDTH: float = 0.3
const STAND_HEIGHT: float = 1.8
const SNEAK_HEIGHT: float = 1.65
const EYE_STAND: float = 1.62
const EYE_SNEAK: float = 1.27
const FEET_OFFSET: float = 0.9
const EPS: float = 0.00001
const REACH: float = 5.0
const DOUBLE_TAP_SECONDS: float = 0.30

const MOUSE_SENSITIVITY: float = 0.0022
const BREAK_COOLDOWN: float = 0.25
const CREATIVE_BREAK_INTERVAL: float = 0.2
const PLACE_INTERVAL: float = 0.25
const ATTACK_INTERVAL: float = 0.5
const SPRINT_FOV_BONUS: float = 7.0
const THIRD_PERSON_DISTANCE: float = 4.0
const EYE_OFFSET: float = 0.17
const VIEW_NAMES: Array = ["Вид: от первого лица", "Вид: от второго лица (спереди)", "Вид: от третьего лица (сзади)"]
const INV_SIZE: int = 36
const ARMOR_SLOTS: Array = ["helmet", "chestplate", "leggings", "boots"]

var game
var health: float = 20.0
var max_health: float = 20.0
var hunger: float = 20.0
var xp: int = 0
var selected_slot: int = 0
var groups_ids: Dictionary = {}
var groups_counts: Dictionary = {}
var cursor_id: String = ""
var cursor_count: int = 0
var mine_repeat_timer: float = 0.0
var view_mode: int = 0 # 0 = от первого лица, 1 = спереди, 2 = сзади
var hand
var player_model
var effects
var skin_texture: Texture2D
var has_target: bool = false
var target_is_enemy: bool = false
var target_collider: Node
var target_cell: Vector3i = Vector3i.ZERO
var target_kind: String = ""
var target_point: Vector3 = Vector3.ZERO
var target_normal: Vector3 = Vector3.UP
var mining_active: bool = false
var mine_cell: Vector3i = Vector3i.ZERO
var mine_kind: String = ""
var mine_fraction: float = 0.0
var mine_hit_timer: float = 0.0
var break_cooldown: float = 0.0
var place_cooldown: float = 0.0
var attack_timer: float = 0.0
var sprinting_now: bool = false
var message_cooldown: float = 0.0
var is_sneaking: bool = false
var is_dead: bool = false
var regen_timer: float = 0.0
var starve_timer: float = 0.0
var last_hunger_shown: int = 20

# Состояние симуляции (координаты ног, блоки; скорость в блоках за тик)
var pos: Vector3 = Vector3.ZERO
var prev_pos: Vector3 = Vector3.ZERO
var velocity: Vector3 = Vector3.ZERO
var on_ground: bool = false
var tick_acc: float = 0.0
var jump_delay: int = 0
var jump_buffer: int = 0
var fall_distance: float = 0.0
var creative: bool = false
var flying: bool = false
var sprint_latched: bool = false
var last_space_press: float = -10.0
var last_w_press: float = -10.0
var eye_height: float = EYE_STAND
var in_water: bool = false
var head_in_water: bool = false
var position_ready: bool = false

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D

func _ready() -> void:
    add_to_group("explorer")
    _init_inventory()
    _give_starting_items()
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
    camera.current = true
    _create_view_models()

# Телепорт: принимает позицию центра тела (как раньше global_position).
func teleport(origin_position: Vector3) -> void:
    pos = origin_position - Vector3(0.0, FEET_OFFSET, 0.0)
    prev_pos = pos
    velocity = Vector3.ZERO
    fall_distance = 0.0
    on_ground = false
    tick_acc = 0.0
    position_ready = true
    global_position = origin_position

func feet_position() -> Vector3:
    return pos

func _create_view_models() -> void:
    skin_texture = PlayerModelScript.load_skin_texture()
    hand = HandScript.new()
    add_child(hand)
    hand.setup(skin_texture)
    player_model = PlayerModelScript.new()
    player_model.name = "PlayerModel"
    player_model.position = Vector3(0.0, -FEET_OFFSET, 0.0)
    add_child(player_model)
    player_model.setup(skin_texture)
    effects = EffectsScript.new()
    effects.top_level = true
    add_child(effects)
    _apply_view_mode()

func get_skin_texture() -> Texture2D:
    return skin_texture

func set_world_light(color: Color) -> void:
    if hand != null:
        hand.set_light(color)
    if player_model != null:
        player_model.set_light(color)
    if effects != null:
        effects.set_light(color)

# ---------------------------------------------------------------- creative mode

func set_creative(value: bool) -> void:
    creative = value
    if not creative:
        flying = false
    fall_distance = 0.0
    if creative:
        health = max_health
        hunger = 20.0
    _reset_mining()
    if game != null:
        game.on_creative_changed(creative)

func toggle_creative() -> void:
    set_creative(not creative)
    if game != null:
        game.notify("Творческий режим включён" if creative else "Режим выживания", 2.0)

# ---------------------------------------------------------------- view modes (F5)

func _cycle_view_mode() -> void:
    view_mode = (view_mode + 1) % 3
    _apply_view_mode()
    if game != null:
        game.notify(str(VIEW_NAMES[view_mode]), 1.6)

var hud_hidden: bool = false

func on_hud_hidden(hidden: bool) -> void:
    hud_hidden = hidden
    _apply_view_mode()

func _apply_view_mode() -> void:
    if hand != null:
        hand.set_active(view_mode == 0 and not hud_hidden)
    if player_model != null:
        player_model.visible = view_mode != 0
    if game != null and is_instance_valid(game.hud):
        game.hud.set_crosshair_visible(view_mode == 0)

func _eye_global() -> Vector3:
    return head.to_global(Vector3(0.0, EYE_OFFSET, 0.0))

func _update_camera(delta: float) -> void:
    var eye_local := Vector3(0.0, EYE_OFFSET, 0.0)
    var target_fov: float = Settings.fov + (SPRINT_FOV_BONUS if sprinting_now else 0.0)
    if flying and sprinting_now:
        target_fov += 4.0
    camera.fov = lerpf(camera.fov, target_fov, minf(1.0, 10.0 * delta))
    if view_mode == 0:
        camera.position = eye_local
        camera.rotation = Vector3.ZERO
        return
    var offset_dir: Vector3 = Vector3(0.0, 0.0, 1.0) if view_mode == 2 else Vector3(0.0, 0.0, -1.0)
    var eye_global: Vector3 = head.to_global(eye_local)
    var desired_global: Vector3 = head.to_global(eye_local + offset_dir * THIRD_PERSON_DISTANCE)
    var distance: float = THIRD_PERSON_DISTANCE
    if game != null and game.world != null:
        var hit: Dictionary = game.world.raycast(eye_global, desired_global - eye_global, THIRD_PERSON_DISTANCE)
        if hit.get("hit", false):
            distance = maxf(0.25, float(hit["distance"]) - 0.25)
    camera.position = eye_local + offset_dir * distance
    camera.rotation = Vector3(0.0, 0.0 if view_mode == 2 else PI, 0.0)

func _process(delta: float) -> void:
    if game == null or not position_ready:
        return
    var inputs_on: bool = not game.is_paused and not game.inventory_open and not is_dead and not game.loading
    if not game.is_paused and not game.loading and not is_dead:
        _simulate(delta, inputs_on)
    var alpha: float = clampf(tick_acc / TICK, 0.0, 1.0)
    var shown: Vector3 = prev_pos.lerp(pos, alpha)
    global_position = shown + Vector3(0.0, FEET_OFFSET, 0.0)
    # плавная высота глаз при приседании
    var eye_target: float = EYE_SNEAK if is_sneaking else EYE_STAND
    eye_height = lerpf(eye_height, eye_target, minf(1.0, delta * 14.0))
    head.position.y = eye_height - FEET_OFFSET - EYE_OFFSET
    var horizontal_speed: float = Vector2(velocity.x, velocity.z).length() / TICK
    var held_id: String = ""
    if get_slot_count("inv", selected_slot) > 0:
        held_id = I.base_id(selected_item_id())
    if hand != null:
        hand.update_hand(delta, horizontal_speed, on_ground, held_id)
    if player_model != null:
        player_model.set_held_item(held_id)
        player_model.update_pose(delta, rotation.y, head.rotation.x, horizontal_speed, is_sneaking, on_ground)
    _update_camera(delta)
    if inputs_on:
        _update_mining(delta)
        _update_place_repeat(delta)
    else:
        _reset_mining()
    message_cooldown = maxf(0.0, message_cooldown - delta)
    if not creative and not game.is_paused and not game.loading and not is_dead:
        _update_hunger(delta, horizontal_speed > 0.3, sprinting_now)


# ---------------------------------------------------------------- inventory

func _blank_ids(amount: int) -> Array:
    var arr: Array = []
    for i in range(amount):
        arr.append("")
    return arr

func _zero_counts(amount: int) -> Array:
    var arr: Array = []
    for i in range(amount):
        arr.append(0)
    return arr

func _init_inventory() -> void:
    groups_ids = {
        "inv": _blank_ids(INV_SIZE),
        "armor": _blank_ids(4),
        "offhand": _blank_ids(1),
        "craft": _blank_ids(9),
        "result": _blank_ids(1)
    }
    groups_counts = {
        "inv": _zero_counts(INV_SIZE),
        "armor": _zero_counts(4),
        "offhand": _zero_counts(1),
        "craft": _zero_counts(9),
        "result": _zero_counts(1)
    }
    cursor_id = ""
    cursor_count = 0

func _give_starting_items() -> void:
    add_item("wood_pickaxe", 1, false)
    add_item("wood_axe", 1, false)
    add_item("wood_shovel", 1, false)
    add_item("wood_sword", 1, false)
    add_item("dirt", 24, false)
    add_item("cobblestone", 16, false)
    add_item("oak_log", 8, false)
    add_item("torch", 8, false)
    add_item("salve", 2, false)
    add_item("berries", 5, false)

func get_slot_id(group: String, index: int) -> String:
    var ids: Array = groups_ids[group]
    if index < 0 or index >= ids.size():
        return ""
    return str(ids[index])

func get_slot_count(group: String, index: int) -> int:
    var counts: Array = groups_counts[group]
    if index < 0 or index >= counts.size():
        return 0
    return int(counts[index])

func set_slot(group: String, index: int, item_id: String, amount: int) -> void:
    var ids: Array = groups_ids[group]
    var counts: Array = groups_counts[group]
    if index < 0 or index >= ids.size():
        return
    if amount <= 0 or item_id == "":
        ids[index] = ""
        counts[index] = 0
    else:
        ids[index] = item_id
        counts[index] = amount

func selected_item_id() -> String:
    return get_slot_id("inv", selected_slot)

func get_armor_points() -> int:
    var points: int = 0
    for i in range(4):
        var armor_id: String = get_slot_id("armor", i)
        if armor_id != "":
            points += I.defense(armor_id)
    return mini(points, 20)

func get_level() -> int:
    return floori(float(xp) / 10.0)

func get_level_progress() -> float:
    return float(xp % 10) / 10.0

func add_xp(amount: int) -> void:
    var before: int = get_level()
    xp += amount
    if get_level() > before and game != null:
        game.notify("Уровень опыта: %d" % get_level())
    _refresh_hud()

func _refresh_hud() -> void:
    if game != null:
        game.refresh_hud()

func can_accept(item_id: String) -> bool:
    var max_stack: int = Catalog.max_stack(item_id)
    for i in range(INV_SIZE):
        var slot_id: String = get_slot_id("inv", i)
        if slot_id == "":
            return true
        if slot_id == item_id and get_slot_count("inv", i) < max_stack:
            return true
    return false

func add_item(item_id: String, amount: int = 1, announce: bool = true) -> int:
    var left: int = amount
    var max_stack: int = Catalog.max_stack(item_id)
    for i in range(INV_SIZE):
        if left <= 0:
            break
        if get_slot_id("inv", i) == item_id:
            var space: int = max_stack - get_slot_count("inv", i)
            var moved: int = mini(space, left)
            if moved > 0:
                set_slot("inv", i, item_id, get_slot_count("inv", i) + moved)
                left -= moved
    for i in range(INV_SIZE):
        if left <= 0:
            break
        if get_slot_id("inv", i) == "":
            var moved_new: int = mini(max_stack, left)
            set_slot("inv", i, item_id, moved_new)
            left -= moved_new
    if left > 0 and announce and game != null:
        game.notify("Рюкзак полон.")
    _refresh_hud()
    return left

# Подбор выпавшего предмета: возвращает, сколько осталось (не поместилось).
func pickup_item(item_id: String, amount: int) -> int:
    var left: int = add_item(item_id, amount, false)
    if left < amount:
        AudioManager.play("pickup")
    return left

func get_count(item_id: String) -> int:
    var total: int = 0
    for i in range(INV_SIZE):
        if get_slot_id("inv", i) == item_id:
            total += get_slot_count("inv", i)
    return total

func remove_item(item_id: String, amount: int = 1) -> bool:
    if get_count(item_id) < amount:
        return false
    var left: int = amount
    for i in range(INV_SIZE):
        if left <= 0:
            break
        if get_slot_id("inv", i) == item_id:
            var taken: int = mini(get_slot_count("inv", i), left)
            set_slot("inv", i, item_id, get_slot_count("inv", i) - taken)
            left -= taken
    return true

func _consume_selected(amount: int) -> void:
    if creative:
        return
    var item_id: String = selected_item_id()
    set_slot("inv", selected_slot, item_id, get_slot_count("inv", selected_slot) - amount)

func slot_accepts(group: String, item_id: String, index: int = 0) -> bool:
    if group == "result":
        return false
    if group == "armor":
        return I.is_armor(item_id) and I.armor_slot(item_id) == ARMOR_SLOTS[clampi(index, 0, 3)]
    return item_id != ""

func slot_click(group: String, index: int, right_click: bool) -> void:
    if group == "result":
        _click_result()
        return
    var slot_id: String = get_slot_id(group, index)
    var slot_count: int = get_slot_count(group, index)
    if not right_click:
        if cursor_id == "":
            if slot_id != "":
                cursor_id = slot_id
                cursor_count = slot_count
                set_slot(group, index, "", 0)
        elif slot_id == "":
            if slot_accepts(group, cursor_id, index):
                set_slot(group, index, cursor_id, cursor_count)
                cursor_id = ""
                cursor_count = 0
        elif slot_id == cursor_id:
            if slot_accepts(group, cursor_id, index):
                var space: int = Catalog.max_stack(slot_id) - slot_count
                var moved: int = mini(space, cursor_count)
                set_slot(group, index, slot_id, slot_count + moved)
                cursor_count -= moved
                if cursor_count <= 0:
                    cursor_id = ""
                    cursor_count = 0
        elif slot_accepts(group, cursor_id, index):
            set_slot(group, index, cursor_id, cursor_count)
            cursor_id = slot_id
            cursor_count = slot_count
    else:
        if cursor_id == "":
            if slot_id != "":
                var take: int = int(ceil(float(slot_count) / 2.0))
                cursor_id = slot_id
                cursor_count = take
                set_slot(group, index, slot_id, slot_count - take)
        elif slot_accepts(group, cursor_id, index):
            if slot_id == "":
                set_slot(group, index, cursor_id, 1)
                cursor_count -= 1
            elif slot_id == cursor_id:
                if slot_count < Catalog.max_stack(slot_id):
                    set_slot(group, index, slot_id, slot_count + 1)
                    cursor_count -= 1
            else:
                set_slot(group, index, cursor_id, cursor_count)
                cursor_id = slot_id
                cursor_count = slot_count
            if cursor_count <= 0:
                cursor_id = ""
                cursor_count = 0
    if group == "craft":
        update_craft_result()

func _click_result() -> void:
    var result_id: String = get_slot_id("result", 0)
    if result_id == "":
        return
    var result_count: int = get_slot_count("result", 0)
    if cursor_id != "":
        if cursor_id != result_id:
            return
        if cursor_count + result_count > Catalog.max_stack(result_id):
            return
    else:
        cursor_id = result_id
        cursor_count = 0
    cursor_count += result_count
    _consume_craft_inputs()
    update_craft_result()

func _craft_grid() -> Array:
    var grid: Array = []
    for i in range(9):
        grid.append(get_slot_id("craft", i))
    return grid

func _consume_craft_inputs() -> void:
    var found: Dictionary = Crafting.find(_craft_grid())
    var consume: Array = found.get("consume", [])
    for index_variant in consume:
        var index: int = int(index_variant)
        var craft_id: String = get_slot_id("craft", index)
        if craft_id != "":
            set_slot("craft", index, craft_id, get_slot_count("craft", index) - 1)

func update_craft_result() -> void:
    set_slot("result", 0, "", 0)
    var found: Dictionary = Crafting.find(_craft_grid())
    if found.is_empty():
        return
    set_slot("result", 0, str(found["id"]), int(found["count"]))

func return_loose_items() -> void:
    if creative:
        cursor_id = ""
        cursor_count = 0
        for i in range(9):
            set_slot("craft", i, "", 0)
        set_slot("result", 0, "", 0)
        return
    if cursor_id != "":
        add_item(cursor_id, cursor_count)
        cursor_id = ""
        cursor_count = 0
    for i in range(9):
        var craft_id: String = get_slot_id("craft", i)
        if craft_id != "":
            add_item(craft_id, get_slot_count("craft", i))
            set_slot("craft", i, "", 0)
    set_slot("result", 0, "", 0)

# ---------------------------------------------------------------- input

func _is_typing() -> bool:
    var owner_control: Control = get_viewport().gui_get_focus_owner()
    return owner_control is LineEdit

func _input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
        var motion := event as InputEventMouseMotion
        if game != null and not game.is_paused and not game.inventory_open:
            var sens: float = MOUSE_SENSITIVITY * Settings.sensitivity
            var invert: float = -1.0 if Settings.invert_y else 1.0
            rotate_y(-motion.relative.x * sens)
            head.rotation.x = clampf(head.rotation.x - motion.relative.y * sens * invert, deg_to_rad(-89.0), deg_to_rad(89.0))
            if hand != null:
                hand.add_look(motion.relative)
        return

    var key_event := event as InputEventKey
    if key_event != null and key_event.pressed and not key_event.echo:
        if key_event.keycode == KEY_ESCAPE:
            if game != null:
                if game.inventory_open:
                    game.toggle_inventory(false)
                else:
                    game.toggle_pause()
            get_viewport().set_input_as_handled()
            return
        if _is_typing():
            return
        if game == null or game.is_paused:
            return
        var now: float = float(Time.get_ticks_msec()) / 1000.0
        if Settings.pressed(event, "jump") and not game.inventory_open:
            jump_buffer = JUMP_BUFFER_TICKS
            if creative:
                if now - last_space_press < DOUBLE_TAP_SECONDS:
                    flying = not flying
                    if flying:
                        velocity.y = 0.0
                    last_space_press = -10.0
                else:
                    last_space_press = now
        if Settings.pressed(event, "forward") and not game.inventory_open:
            if now - last_w_press < DOUBLE_TAP_SECONDS:
                sprint_latched = true
            last_w_press = now
        if Settings.pressed(event, "inventory"):
            game.toggle_inventory(not game.inventory_open)
            get_viewport().set_input_as_handled()
            return
        if Settings.pressed(event, "hide_hud"):
            game.toggle_hud_hidden()
            get_viewport().set_input_as_handled()
            return
        if game.inventory_open:
            if Settings.pressed(event, "drop"):
                game.hud.drop_hovered(Input.is_key_pressed(KEY_CTRL))
                get_viewport().set_input_as_handled()
            return
        if game.loading:
            return
        if Settings.pressed(event, "creative"):
            toggle_creative()
            get_viewport().set_input_as_handled()
        elif Settings.pressed(event, "view"):
            _cycle_view_mode()
            get_viewport().set_input_as_handled()
        elif Settings.pressed(event, "debug"):
            game.toggle_debug()
            get_viewport().set_input_as_handled()
        elif Settings.pressed(event, "drop"):
            drop_selected(Input.is_key_pressed(KEY_CTRL))
            get_viewport().set_input_as_handled()
        elif Settings.pressed(event, "heal"):
            use_healing_item()
            get_viewport().set_input_as_handled()
        else:
            var slot: int = Settings.slot_from_event(event)
            if slot >= 0:
                selected_slot = slot
                game.refresh_hud()
                get_viewport().set_input_as_handled()

    var mouse_event := event as InputEventMouseButton
    if mouse_event != null and mouse_event.pressed:
        if game == null or game.is_paused or game.inventory_open:
            return
        if Input.get_mouse_mode() != Input.MOUSE_MODE_CAPTURED:
            Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
            return
        if Settings.pressed(event, "attack"):
            _swing_if_idle()
            get_viewport().set_input_as_handled()
        elif Settings.pressed(event, "use"):
            _use_selected_item()
            get_viewport().set_input_as_handled()
        elif Settings.pressed(event, "pick"):
            _pick_block()
            get_viewport().set_input_as_handled()
        elif mouse_event.button_index == MOUSE_BUTTON_WHEEL_UP:
            selected_slot = (selected_slot + 8) % 9
            game.refresh_hud()
        elif mouse_event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
            selected_slot = (selected_slot + 1) % 9
            game.refresh_hud()

# ---------------------------------------------------------------- physics (20 ticks per second)

func _simulate(delta: float, inputs_on: bool) -> void:
    tick_acc += delta
    var count: int = 0
    while tick_acc >= TICK and count < 6:
        tick_acc -= TICK
        _tick(inputs_on)
        count += 1
    if count >= 6:
        tick_acc = 0.0

func _box_collides(p: Vector3, height: float) -> bool:
    var world = game.world
    var x0: int = floori(p.x - HALF_WIDTH + 0.5 + EPS)
    var x1: int = floori(p.x + HALF_WIDTH + 0.5 - EPS)
    var y0: int = floori(p.y + 0.5 + EPS)
    var y1: int = floori(p.y + height + 0.5 - EPS)
    var z0: int = floori(p.z - HALF_WIDTH + 0.5 + EPS)
    var z1: int = floori(p.z + HALF_WIDTH + 0.5 - EPS)
    for cx in range(x0, x1 + 1):
        for cy in range(y0, y1 + 1):
            for cz in range(z0, z1 + 1):
                if world.is_solid_cell(cx, cy, cz):
                    return true
    return false

# Расстояние, на которое можно сдвинуться по оси axis (0 x, 1 y, 2 z) до упора в блок.
func _sweep_axis(axis: int, delta: float, height: float) -> float:
    if delta == 0.0:
        return 0.0
    var world = game.world
    var mn := Vector3(pos.x - HALF_WIDTH, pos.y, pos.z - HALF_WIDTH)
    var mx := Vector3(pos.x + HALF_WIDTH, pos.y + height, pos.z + HALF_WIDTH)
    var lo: Vector3 = mn
    var hi: Vector3 = mx
    if delta > 0.0:
        hi[axis] += delta
    else:
        lo[axis] += delta
    var x0: int = floori(lo.x + 0.5 + EPS)
    var x1: int = floori(hi.x + 0.5 - EPS)
    var y0: int = floori(lo.y + 0.5 + EPS)
    var y1: int = floori(hi.y + 0.5 - EPS)
    var z0: int = floori(lo.z + 0.5 + EPS)
    var z1: int = floori(hi.z + 0.5 - EPS)
    var result: float = delta
    for cx in range(x0, x1 + 1):
        for cy in range(y0, y1 + 1):
            for cz in range(z0, z1 + 1):
                if not world.is_solid_cell(cx, cy, cz):
                    continue
                var cell_axis: int = cx if axis == 0 else (cy if axis == 1 else cz)
                if delta > 0.0:
                    var cell_min: float = float(cell_axis) - 0.5
                    if cell_min >= mx[axis] - EPS:
                        result = minf(result, maxf(0.0, cell_min - mx[axis]))
                else:
                    var cell_max: float = float(cell_axis) + 0.5
                    if cell_max <= mn[axis] + EPS:
                        result = maxf(result, minf(0.0, cell_max - mn[axis]))
    return result

func _shrink(value: float) -> float:
    if absf(value) < 0.05:
        return 0.0
    return value - signf(value) * 0.05

# Приседание на земле не даёт упасть с края (как в Minecraft).
func _edge_clip(d: Vector3, height: float) -> Vector3:
    var dx: float = d.x
    var dz: float = d.z
    while dx != 0.0 and not _box_collides(pos + Vector3(dx, -0.6, 0.0), height):
        dx = _shrink(dx)
    while dz != 0.0 and not _box_collides(pos + Vector3(0.0, -0.6, dz), height):
        dz = _shrink(dz)
    while dx != 0.0 and dz != 0.0 and not _box_collides(pos + Vector3(dx, -0.6, dz), height):
        dx = _shrink(dx)
        dz = _shrink(dz)
    return Vector3(dx, d.y, dz)

# Возвращает true, если было столкновение по горизонтали.
func _move_entity(height: float, edge_safe: bool) -> bool:
    var d: Vector3 = velocity
    if edge_safe and on_ground:
        d = _edge_clip(d, height)
    var dy: float = _sweep_axis(1, d.y, height)
    var hit_y: bool = absf(dy - d.y) > 0.0000001
    pos.y += dy
    var dx: float = _sweep_axis(0, d.x, height)
    var hit_x: bool = absf(dx - d.x) > 0.0000001
    pos.x += dx
    var dz: float = _sweep_axis(2, d.z, height)
    var hit_z: bool = absf(dz - d.z) > 0.0000001
    pos.z += dz
    var was_falling: bool = d.y < 0.0
    on_ground = hit_y and was_falling
    if hit_y:
        velocity.y = 0.0
    if hit_x:
        velocity.x = 0.0
    if hit_z:
        velocity.z = 0.0
    # падение
    if dy < 0.0 and not on_ground:
        fall_distance -= dy
    if on_ground:
        if fall_distance > 3.0 and not creative and not in_water:
            take_damage(float(ceili(fall_distance - 3.0)), true)
        fall_distance = 0.0
    return hit_x or hit_z

func _add_input(strafe: float, fwd: float, accel: float) -> void:
    var yaw: float = rotation.y
    var forward := Vector3(-sin(yaw), 0.0, -cos(yaw))
    var right := Vector3(cos(yaw), 0.0, -sin(yaw))
    var input := Vector2(strafe, fwd)
    var length: float = input.length()
    if length < 0.01:
        return
    var factor: float = accel / maxf(length, 1.0)
    velocity += right * (strafe * factor) + forward * (fwd * factor)

func _tick(inputs_on: bool) -> void:
    prev_pos = pos
    var world = game.world
    var fwd: float = 0.0
    var strafe: float = 0.0
    var jump_held: bool = false
    var want_sneak: bool = false
    if inputs_on:
        if Settings.is_down("forward"):
            fwd += 1.0
        if Settings.is_down("back"):
            fwd -= 1.0
        if Settings.is_down("right"):
            strafe += 1.0
        if Settings.is_down("left"):
            strafe -= 1.0
        jump_held = Settings.is_down("jump")
        want_sneak = Settings.is_down("sneak")
    else:
        jump_buffer = 0
    if is_sneaking and not want_sneak and _box_collides(pos, STAND_HEIGHT):
        want_sneak = true
    var descend: bool = want_sneak and flying
    is_sneaking = want_sneak and not flying
    var height: float = SNEAK_HEIGHT if is_sneaking else STAND_HEIGHT

    in_water = world.is_position_in_water(pos + Vector3(0.0, 0.4, 0.0))
    head_in_water = world.is_position_in_water(pos + Vector3(0.0, eye_height, 0.0))

    var moving_forward: bool = fwd > 0.0
    if not moving_forward:
        sprint_latched = false
    var can_sprint: bool = (not is_sneaking) and moving_forward and (creative or hunger > 6.0) and not in_water
    sprinting_now = ((inputs_on and Settings.is_down("sprint")) or sprint_latched) and can_sprint

    if jump_delay > 0:
        jump_delay -= 1
    var buffered: bool = jump_buffer > 0
    if jump_buffer > 0:
        jump_buffer -= 1
    var wants_jump: bool = jump_held or buffered

    var in_x: float = strafe * 0.98
    var in_z: float = fwd * 0.98
    if is_sneaking:
        in_x *= SNEAK_MULT
        in_z *= SNEAK_MULT

    if flying:
        _add_input(in_x, in_z, FLY_ACCEL * (2.0 if sprinting_now else 1.0))
        if jump_held:
            velocity.y += FLY_ACCEL * 3.0
        if descend:
            velocity.y -= FLY_ACCEL * 3.0
        _move_entity(height, false)
        velocity.y *= 0.6
        velocity.x *= AIR_FRICTION
        velocity.z *= AIR_FRICTION
        fall_distance = 0.0
        if on_ground:
            flying = false
    elif in_water:
        _add_input(in_x, in_z, AIR_ACCEL)
        if wants_jump:
            velocity.y += 0.04
            jump_buffer = 0
        var blocked: bool = _move_entity(height, false)
        velocity *= 0.8
        velocity.y -= 0.02
        if blocked and not _box_collides(pos + Vector3(velocity.x, 0.6, velocity.z), height):
            velocity.y = 0.3
        fall_distance = 0.0
    else:
        var was_ground: bool = on_ground
        if wants_jump and on_ground and jump_delay == 0:
            velocity.y = JUMP_VELOCITY
            jump_delay = JUMP_DELAY_TICKS
            jump_buffer = 0
            on_ground = false
            if sprinting_now:
                var yaw: float = rotation.y
                velocity.x += -sin(yaw) * 0.2
                velocity.z += -cos(yaw) * 0.2
        var friction: float = GROUND_FRICTION if was_ground else AIR_FRICTION
        var accel: float = AIR_ACCEL
        if was_ground:
            accel = WALK_ACCEL
        if sprinting_now:
            accel *= SPRINT_MULT
        _add_input(in_x, in_z, accel)
        _move_entity(height, is_sneaking)
        velocity.y = (velocity.y - GRAVITY_TICK) * AIR_DRAG_Y
        velocity.x *= friction
        velocity.z *= friction

    if pos.y < float(world.MIN_Y) - 40.0:
        teleport(world.get_spawn_position())

# ---------------------------------------------------------------- actions

func _swing() -> void:
    if hand != null:
        hand.swing()
    if player_model != null:
        player_model.swing()

func _swing_if_idle() -> void:
    if hand != null and hand.is_swinging():
        return
    _swing()

func _scan_target() -> void:
    has_target = false
    target_is_enemy = false
    target_collider = null
    if game == null or game.world == null:
        return
    var origin: Vector3 = _eye_global()
    var dir: Vector3 = -head.global_transform.basis.z
    var hit: Dictionary = game.world.raycast(origin, dir, REACH)
    if not hit.get("hit", false):
        return
    target_cell = hit["cell"]
    var normal_cell: Vector3i = hit["normal"]
    target_normal = Vector3(float(normal_cell.x), float(normal_cell.y), float(normal_cell.z))
    target_point = origin + dir.normalized() * float(hit["distance"])
    target_kind = BlockRegistry.names[int(hit["id"])]
    has_target = true

func _reset_mining() -> void:
    mining_active = false
    mine_fraction = 0.0
    if effects != null:
        effects.clear_crack()
    if is_dead or game == null or game.is_paused or game.inventory_open:
        if effects != null:
            effects.hide_outline()

func _play_block_sound(kind: String, action: String) -> void:
    # action: "dig" (удар при добыче), "break" или "place"
    AudioManager.play(action + "_" + BlockData.sound_group(kind))

# Удержание ЛКМ: время добычи как в Minecraft, стадии трещин, частицы, пауза между блоками.
func _update_mining(delta: float) -> void:
    _scan_target()
    break_cooldown = maxf(0.0, break_cooldown - delta)
    if effects != null:
        if has_target:
            effects.show_outline(target_cell)
        else:
            effects.hide_outline()
    var holding: bool = Settings.is_down("attack") and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED
    attack_timer = maxf(0.0, attack_timer - delta)
    if not holding:
        _reset_mining()
        return
    if not has_target:
        _reset_mining()
        _swing_if_idle()
        return
    var tool_id: String = selected_item_id()
    if get_slot_count("inv", selected_slot) <= 0:
        tool_id = ""
    if not mining_active or target_cell != mine_cell:
        mining_active = true
        mine_cell = target_cell
        mine_kind = target_kind
        mine_fraction = 0.0
        mine_hit_timer = 0.0
        if effects != null:
            effects.clear_crack()
    var required: float = BlockData.break_time(mine_kind, tool_id)
    if creative and not is_inf(required):
        required = 0.0
    _swing_if_idle()
    if is_inf(required):
        _notify_limited("Эту породу нельзя сломать.")
        return
    if break_cooldown > 0.0:
        return
    mine_hit_timer -= delta
    if mine_hit_timer <= 0.0 and required > 0.0:
        mine_hit_timer = 0.25
        _play_block_sound(mine_kind, "dig")
        if effects != null:
            effects.hit_effect(mine_kind, target_point, target_normal)
    if required <= 0.0:
        mine_fraction = 1.0
    else:
        mine_fraction += delta / required
    if mine_fraction >= 1.0:
        _complete_break(tool_id)
    elif effects != null:
        effects.set_crack(mine_cell, clampi(int(mine_fraction * 10.0), 0, 9))

func _complete_break(tool_id: String) -> void:
    var result: Dictionary = game.world.mine_cell(mine_cell)
    if effects != null:
        effects.clear_crack()
    mining_active = false
    mine_fraction = 0.0
    if not result.get("ok", false):
        _notify_limited(str(result.get("message", "Нельзя добыть этот блок.")))
        return
    var kind: String = str(result.get("kind", mine_kind))
    if effects != null:
        effects.break_effect(kind, mine_cell)
    _play_block_sound(kind, "break")
    break_cooldown = CREATIVE_BREAK_INTERVAL if creative else BREAK_COOLDOWN
    if not creative:
        if BlockData.can_harvest(kind, tool_id):
            var center := Vector3(float(mine_cell.x), float(mine_cell.y), float(mine_cell.z))
            for drop_variant in Catalog.drops_for_block(kind):
                var drop: Array = drop_variant
                spawn_drop(str(drop[0]), int(drop[1]), center)
            if game.world.is_ore(kind):
                add_xp(3)
                _notify_limited("Найдена руда: %s." % Catalog.item_name(kind))
        else:
            _notify_limited("Для этого блока нужен подходящий инструмент.")
        if BlockData.hardness(kind) > 0.0:
            damage_selected_tool(1)
    game.refresh_hud()

func spawn_drop(item_id: String, count: int, center: Vector3) -> void:
    if game == null or game.drops == null:
        return
    var velocity_out := Vector3(randf_range(-1.3, 1.3), randf_range(2.2, 3.4), randf_range(-1.3, 1.3))
    game.drops.spawn(item_id, count, center + Vector3(0.0, -0.15, 0.0), velocity_out, 0.45)

# Износ инструмента в руке; при нуле прочности предмет ломается.
func damage_selected_tool(amount: int) -> void:
    var tool_id: String = selected_item_id()
    if creative or tool_id == "" or not I.has_durability(tool_id):
        return
    var wear: int = I.wear_of(tool_id) + amount
    if wear >= I.durability(tool_id):
        set_slot("inv", selected_slot, "", 0)
        if game != null:
            game.notify("%s сломался." % Catalog.item_name(tool_id))
        AudioManager.play("hit")
    else:
        set_slot("inv", selected_slot, I.with_wear(tool_id, wear), 1)

# Выбросить предмет в мир (по взгляду игрока).
func throw_item(item_id: String, count: int) -> void:
    if game == null or game.drops == null or item_id == "" or count <= 0:
        return
    var dir: Vector3 = -head.global_transform.basis.z
    var origin: Vector3 = _eye_global() + dir * 0.35 - Vector3(0.0, 0.2, 0.0)
    var velocity_out: Vector3 = dir * 5.5 + Vector3(0.0, 1.6, 0.0) + Vector3(randf_range(-0.2, 0.2), 0.0, randf_range(-0.2, 0.2))
    game.drops.spawn(item_id, count, origin, velocity_out, 1.6)

func drop_selected(whole: bool) -> void:
    drop_from_slot("inv", selected_slot, whole)

func drop_from_slot(group: String, index: int, whole: bool) -> void:
    var item_id: String = get_slot_id(group, index)
    var count: int = get_slot_count(group, index)
    if item_id == "" or group == "result":
        return
    var amount: int = count if whole else 1
    throw_item(item_id, amount)
    set_slot(group, index, item_id, count - amount)
    if group == "craft":
        update_craft_result()
    _refresh_hud()

func drop_cursor(whole: bool) -> void:
    if cursor_id == "":
        return
    var amount: int = cursor_count if whole else 1
    throw_item(cursor_id, amount)
    cursor_count -= amount
    if cursor_count <= 0:
        cursor_id = ""
        cursor_count = 0
    _refresh_hud()

# Быстрое перемещение (Shift + клик) между разделами инвентаря.
func shift_click(group: String, index: int) -> void:
    if group == "result":
        for guard in range(64):
            var result_id: String = get_slot_id("result", 0)
            if result_id == "" or not can_accept(result_id):
                break
            var result_count: int = get_slot_count("result", 0)
            add_item(result_id, result_count, false)
            _consume_craft_inputs()
            update_craft_result()
        return
    var item_id: String = get_slot_id(group, index)
    var count: int = get_slot_count(group, index)
    if item_id == "":
        return
    var left: int = count
    if group == "inv":
        if I.is_armor(item_id):
            var slot_index: int = ARMOR_SLOTS.find(I.armor_slot(item_id))
            if slot_index >= 0 and get_slot_id("armor", slot_index) == "":
                set_slot("armor", slot_index, item_id, 1)
                set_slot("inv", index, item_id, count - 1)
                _refresh_hud()
                return
        left = _move_into_range(item_id, count, 9, 36) if index < 9 else _move_into_range(item_id, count, 0, 9)
        set_slot("inv", index, item_id, left)
    else:
        left = _move_into_range(item_id, count, 0, 36)
        set_slot(group, index, item_id, left)
        if group == "craft":
            update_craft_result()
    _refresh_hud()

func _move_into_range(item_id: String, amount: int, first: int, last: int) -> int:
    var left: int = amount
    var max_stack: int = Catalog.max_stack(item_id)
    for i in range(first, last):
        if left <= 0:
            return 0
        if get_slot_id("inv", i) == item_id and get_slot_count("inv", i) < max_stack:
            var moved: int = mini(max_stack - get_slot_count("inv", i), left)
            set_slot("inv", i, item_id, get_slot_count("inv", i) + moved)
            left -= moved
    for i in range(first, last):
        if left <= 0:
            return 0
        if get_slot_id("inv", i) == "":
            var moved2: int = mini(max_stack, left)
            set_slot("inv", i, item_id, moved2)
            left -= moved2
    return left

# Правый клик по броне в руке надевает её.
func _equip_selected_armor() -> bool:
    var item_id: String = selected_item_id()
    if get_slot_count("inv", selected_slot) <= 0 or not I.is_armor(item_id):
        return false
    var slot_index: int = ARMOR_SLOTS.find(I.armor_slot(item_id))
    if slot_index < 0:
        return false
    var previous_id: String = get_slot_id("armor", slot_index)
    set_slot("armor", slot_index, item_id, 1)
    set_slot("inv", selected_slot, previous_id, 1 if previous_id != "" else 0)
    if game != null:
        game.notify("Надето: %s" % Catalog.item_name(item_id))
    _refresh_hud()
    return true

func _pick_block() -> void:
    if not creative:
        return
    _scan_target()
    if not has_target:
        return
    var item_id: String = target_kind
    if not Catalog.is_known_item(item_id):
        return
    for i in range(9):
        if get_slot_id("inv", i) == item_id:
            selected_slot = i
            game.refresh_hud()
            return
    set_slot("inv", selected_slot, item_id, Catalog.max_stack(item_id))
    game.refresh_hud()

func _use_selected_item() -> void:
    if place_cooldown > 0.0:
        return
    var item_id: String = selected_item_id()
    if get_slot_count("inv", selected_slot) <= 0:
        return
    var base: String = I.base_id(item_id)
    if I.is_armor(base):
        _equip_selected_armor()
        place_cooldown = 0.4
        _swing_if_idle()
    elif base == "berries":
        _eat_berries()
        place_cooldown = 0.4
        _swing_if_idle()
    elif base == "salve":
        use_healing_item()
        place_cooldown = 0.4
        _swing_if_idle()
    elif I.has(base):
        place_cooldown = 0.2
    else:
        if _try_place_block():
            place_cooldown = CREATIVE_BREAK_INTERVAL if creative else PLACE_INTERVAL
            _swing()
            _play_block_sound(Catalog.block_kind(item_id), "place")
        else:
            place_cooldown = 0.1

func _update_place_repeat(delta: float) -> void:
    place_cooldown = maxf(0.0, place_cooldown - delta)
    if place_cooldown > 0.0:
        return
    if not Settings.is_down("use") or Input.get_mouse_mode() != Input.MOUSE_MODE_CAPTURED:
        return
    if Catalog.block_kind(selected_item_id()) == "" or get_slot_count("inv", selected_slot) <= 0:
        return
    _use_selected_item()

func _eat_berries() -> void:
    if hunger >= 20.0:
        _notify_limited("Ты не голоден.")
        return
    if get_slot_count("inv", selected_slot) <= 0:
        return
    _consume_selected(1)
    hunger = minf(20.0, hunger + 3.0)
    last_hunger_shown = int(ceil(hunger))
    game.refresh_hud()

func _box_overlaps_cell(cell: Vector3i) -> bool:
    var height: float = SNEAK_HEIGHT if is_sneaking else STAND_HEIGHT
    return (pos.x + HALF_WIDTH > float(cell.x) - 0.5 + EPS and pos.x - HALF_WIDTH < float(cell.x) + 0.5 - EPS
        and pos.y + height > float(cell.y) - 0.5 + EPS and pos.y < float(cell.y) + 0.5 - EPS
        and pos.z + HALF_WIDTH > float(cell.z) - 0.5 + EPS and pos.z - HALF_WIDTH < float(cell.z) + 0.5 - EPS)

func _try_place_block() -> bool:
    if game == null:
        return false
    var item_id: String = selected_item_id()
    var block_kind: String = Catalog.block_kind(item_id)
    if block_kind == "":
        return false
    if get_slot_count("inv", selected_slot) <= 0:
        _notify_limited("В этом слоте ничего не осталось.")
        return false
    _scan_target()
    if not has_target:
        return false
    var target_id: int = BlockRegistry.id_of(target_kind)
    var place_cell: Vector3i = target_cell
    if BlockRegistry.render[target_id] != BlockRegistry.R_CROSS:
        if target_normal == Vector3.ZERO:
            return false
        place_cell = target_cell + Vector3i(roundi(target_normal.x), roundi(target_normal.y), roundi(target_normal.z))
    var new_id: int = BlockRegistry.id_of(block_kind)
    if BlockRegistry.solid[new_id] == 1 and _box_overlaps_cell(place_cell):
        _notify_limited("Нельзя поставить блок внутри персонажа.")
        return false
    if game.world.place_block(place_cell, block_kind):
        _consume_selected(1)
        game.refresh_hud()
        return true
    _notify_limited("Здесь нельзя разместить блок.")
    return false

func use_healing_item() -> void:
    if health >= max_health:
        _notify_limited("Здоровье уже полное.")
        return
    if remove_item("salve", 1):
        health = minf(max_health, health + 6.0)
        game.refresh_hud()
        game.notify("Аптечка восстановила 6 HP.")
    else:
        _notify_limited("Аптечки закончились.")

func take_damage(amount: float, ignore_armor: bool = false) -> void:
    if creative or is_dead or game == null or game.is_paused:
        return
    var taken: float = amount
    if not ignore_armor:
        taken = amount * (1.0 - float(get_armor_points()) * 0.04)
    health = maxf(0.0, health - taken)
    game.refresh_hud()
    game.notify("Получен урон: %.0f HP" % taken)
    if health <= 0.0:
        is_dead = true
        game.player_died()

func _update_hunger(delta: float, moving: bool, sprinting: bool) -> void:
    var rate: float = 0.022
    if moving:
        rate += 0.01
    if sprinting:
        rate += 0.06
    hunger = maxf(0.0, hunger - rate * delta)
    if hunger >= 18.0 and health < max_health:
        regen_timer += delta
        if regen_timer >= 3.0:
            regen_timer = 0.0
            health = minf(max_health, health + 1.0)
            hunger = maxf(0.0, hunger - 0.6)
            _refresh_hud()
    else:
        regen_timer = 0.0
    if hunger <= 0.0:
        starve_timer += delta
        if starve_timer >= 4.0:
            starve_timer = 0.0
            health = maxf(1.0, health - 1.0)
            if game != null:
                game.notify("Ты голодаешь. Найди еду (ягоды с листвы).")
            _refresh_hud()
    else:
        starve_timer = 0.0
    var shown: int = int(ceil(hunger))
    if shown != last_hunger_shown:
        last_hunger_shown = shown
        _refresh_hud()

func _notify_limited(message: String) -> void:
    if message_cooldown <= 0.0 and game != null:
        game.notify(message)
        message_cooldown = 1.0

# ---------------------------------------------------------------- saving

func _pack_group(group: String) -> Array:
    var out: Array = []
    var ids: Array = groups_ids[group]
    var counts: Array = groups_counts[group]
    for i in range(ids.size()):
        out.append([str(ids[i]), int(counts[i])])
    return out

func _unpack_group(group: String, data: Variant) -> void:
    if not data is Array:
        return
    var list: Array = data
    for i in range(list.size()):
        var entry: Variant = list[i]
        if entry is Array and entry.size() >= 2:
            var item_id: String = Catalog.normalize_item(str(entry[0]))
            if item_id == "" or Catalog.is_known_item(item_id):
                set_slot(group, i, item_id, int(entry[1]))

func make_save_data() -> Dictionary:
    return {
        "position": [global_position.x, global_position.y, global_position.z],
        "health": health,
        "hunger": hunger,
        "xp": xp,
        "creative": creative,
        "flying": flying,
        "slots": _pack_group("inv"),
        "armor": _pack_group("armor"),
        "offhand": _pack_group("offhand"),
        "selected_slot": selected_slot
    }

func load_save_data(data: Dictionary) -> void:
    health = clampf(float(data.get("health", max_health)), 1.0, max_health)
    hunger = clampf(float(data.get("hunger", 20.0)), 0.0, 20.0)
    last_hunger_shown = int(ceil(hunger))
    xp = maxi(0, int(data.get("xp", 0)))
    creative = bool(data.get("creative", false))
    flying = bool(data.get("flying", false)) and creative
    if data.has("slots"):
        _init_inventory()
        _unpack_group("inv", data.get("slots", []))
        _unpack_group("armor", data.get("armor", []))
        _unpack_group("offhand", data.get("offhand", []))
    selected_slot = clampi(int(data.get("selected_slot", 0)), 0, 8)
