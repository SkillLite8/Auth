extends Node3D

const WorldScript = preload("res://scripts/3d/voxel_world.gd")
const ExplorerScene: PackedScene = preload("res://scenes/3d/explorer.tscn")
const HudScript = preload("res://scripts/3d/voxel_hud.gd")
const SkinPreviewScript = preload("res://scripts/3d/skin_preview.gd")

const SAVE_PATH: String = "user://recraft_save.json"
const DAY_LENGTH_SECONDS: float = 1200.0
const DEFAULT_SKIN_PATH: String = "res://assets/skins/default_skin.png"

var world
var player
var hud
var title_layer: CanvasLayer
var is_paused: bool = false
var inventory_open: bool = false
var game_started: bool = false
var world_seed: int = 0
var autosave_timer: float = 0.0
var preferred_view_distance: int = 2
var day_phase: float = 0.08
var cloud_clock: float = 0.0
var sky_shader_material: ShaderMaterial
var scene_environment: Environment
var sun_light: DirectionalLight3D
var menu_popup: PanelContainer
var loading_layer: CanvasLayer
var loading_status: Label
var loading_anchor: Node3D
var pending_start_data: Dictionary = {}
var pending_player_position: Vector3 = Vector3.ZERO
var loading_elapsed: float = 0.0
var loading_timeout_reported: bool = false
var world_loading: bool = false
var world_spawn_ready: bool = false
var startup_log_path: String = "user://recraft_startup.log"

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    var reset_log := FileAccess.open(startup_log_path, FileAccess.WRITE)
    if reset_log != null:
        reset_log.close()
    _write_startup_log("Application ready; initializing menu and environment")
    _load_settings()
    _create_environment()
    _show_title_menu()

func _load_settings() -> void:
    var config := ConfigFile.new()
    if config.load("user://recraft_settings.cfg") == OK:
        preferred_view_distance = clampi(int(config.get_value("graphics", "view_distance_chunks", 2)), 2, 3)

func _save_settings() -> void:
    var config := ConfigFile.new()
    config.set_value("graphics", "view_distance_chunks", preferred_view_distance)
    config.save("user://recraft_settings.cfg")

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        _write_startup_log("Window close request received")
        save_game(false)
        get_tree().quit()

func _create_environment() -> void:
    var world_environment := WorldEnvironment.new()
    world_environment.name = "ReCraftWorldEnvironment"
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    sky_shader_material = ShaderMaterial.new()
    sky_shader_material.shader = load("res://shaders/recraft_sky.gdshader") as Shader
    sky_shader_material.set_shader_parameter("cloud_texture", load("res://assets/sky/clouds.png"))
    sky_shader_material.set_shader_parameter("sun_texture", load("res://assets/sky/sun.png"))
    sky_shader_material.set_shader_parameter("moon_texture", load("res://assets/sky/moon.png"))
    sky_shader_material.set_shader_parameter("stars_texture", load("res://assets/sky/stars.png"))
    sky_shader_material.set_shader_parameter("cloud_strength", 0.68)
    sky_shader_material.set_shader_parameter("day_phase", day_phase)
    sky_shader_material.set_shader_parameter("cloud_time", cloud_clock)
    sky.process_mode = Sky.PROCESS_MODE_INCREMENTAL
    sky.sky_material = sky_shader_material
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("a5b7d2")
    env.ambient_light_energy = 0.78
    env.background_energy_multiplier = 1.0
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    # The stylized water uses textured highlights; disabling sky-reflection IBL avoids
    # compiling/rendering the custom sky into a cubemap during first world startup.
    env.reflected_light_source = Environment.REFLECTION_SOURCE_DISABLED
    env.glow_enabled = false
    env.ssao_enabled = false
    env.ssil_enabled = false
    env.sdfgi_enabled = false
    scene_environment = env
    world_environment.environment = env
    add_child(world_environment)

    sun_light = DirectionalLight3D.new()
    sun_light.name = "ReCraftSunlight"
    sun_light.rotation_degrees = Vector3(-55.0, -32.0, 0.0)
    sun_light.light_color = Color("ffe0b0")
    sun_light.light_energy = 0.9
    # Dynamic shadows over a streamed voxel world are a disproportionate performance cost.
    sun_light.shadow_enabled = false
    add_child(sun_light)

func _update_sky(delta: float) -> void:
    cloud_clock += delta
    day_phase = fposmod(day_phase + delta / DAY_LENGTH_SECONDS, 1.0)
    var phase_angle := day_phase * TAU
    var sun_height := sin(phase_angle)
    var daylight := smoothstep(-0.12, 0.22, sun_height)
    var twilight := 1.0 - smoothstep(0.015, 0.42, absf(sun_height))

    if is_instance_valid(sky_shader_material):
        sky_shader_material.set_shader_parameter("day_phase", day_phase)
        sky_shader_material.set_shader_parameter("cloud_time", cloud_clock)
    if is_instance_valid(sun_light):
        # Orbit along the forward/back axis so dawn is visible from the default spawn view.
        var solar_direction := Vector3(0.0, sun_height, -cos(phase_angle)).normalized()
        var light_up := Vector3.UP
        if absf(solar_direction.dot(light_up)) > 0.98:
            light_up = Vector3.FORWARD
        sun_light.look_at(-solar_direction, light_up)
        sun_light.light_energy = lerpf(0.0, 1.15, daylight)
        var daylight_color := Color("fff2d7")
        var twilight_color := Color("ff9a61")
        sun_light.light_color = twilight_color.lerp(daylight_color, smoothstep(0.01, 0.38, sun_height))
    if is_instance_valid(scene_environment):
        var night_ambient := Color("1d294c")
        var daylight_ambient := Color("b5c9e4")
        var sunset_ambient := Color("d99a86")
        scene_environment.ambient_light_color = night_ambient.lerp(daylight_ambient, daylight).lerp(sunset_ambient, twilight * 0.26)
        scene_environment.ambient_light_energy = lerpf(0.20, 0.82, daylight)

func _show_title_menu() -> void:
    if is_instance_valid(title_layer):
        title_layer.queue_free()
    menu_popup = null
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    title_layer = CanvasLayer.new()
    title_layer.name = "ReCraftMainMenu"
    title_layer.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(title_layer)

    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    title_layer.add_child(root)

    var background := TextureRect.new()
    background.texture = load("res://assets/sprites/recraft_menu_background.png") as Texture2D
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    background.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    root.add_child(background)

    var tint := ColorRect.new()
    tint.color = Color(0.035, 0.055, 0.10, 0.18)
    tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(tint)

    var brand := Label.new()
    brand.text = "+   RECRAFT"
    brand.position = Vector2(34, 22)
    brand.size = Vector2(270, 30)
    brand.add_theme_font_size_override("font_size", 14)
    brand.add_theme_color_override("font_color", Color("e2eafa"))
    root.add_child(brand)

    var status := Label.new()
    status.text = "●  ОДИНОЧНЫЙ МИР"
    status.anchor_left = 1.0
    status.anchor_right = 1.0
    status.offset_left = -300
    status.offset_right = -32
    status.offset_top = 22
    status.offset_bottom = 50
    status.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    status.add_theme_font_size_override("font_size", 13)
    status.add_theme_color_override("font_color", Color("eef2ff"))
    root.add_child(status)

    var title := Label.new()
    title.text = "ReCraft"
    title.anchor_left = 0.0
    title.anchor_right = 1.0
    title.offset_top = 116
    title.offset_bottom = 190
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 58)
    title.add_theme_color_override("font_color", Color("f5f8ff"))
    title.add_theme_color_override("font_shadow_color", Color(0.05, 0.08, 0.18, 0.7))
    title.add_theme_constant_override("shadow_offset_x", 2)
    title.add_theme_constant_override("shadow_offset_y", 3)
    root.add_child(title)

    var subtitle := Label.new()
    subtitle.text = "ИГРАЙ  ·  СОЗДАВАЙ  ·  ИССЛЕДУЙ"
    subtitle.anchor_left = 0.0
    subtitle.anchor_right = 1.0
    subtitle.offset_top = 190
    subtitle.offset_bottom = 225
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.add_theme_font_size_override("font_size", 14)
    subtitle.add_theme_color_override("font_color", Color("e2e9f6"))
    root.add_child(subtitle)

    var menu_box := VBoxContainer.new()
    menu_box.name = "MenuButtons"
    menu_box.anchor_left = 0.5
    menu_box.anchor_right = 0.5
    menu_box.anchor_top = 0.5
    menu_box.anchor_bottom = 0.5
    menu_box.offset_left = -180
    menu_box.offset_right = 180
    menu_box.offset_top = -18
    menu_box.offset_bottom = 244
    menu_box.add_theme_constant_override("separation", 10)
    root.add_child(menu_box)
    menu_box.add_child(_make_menu_button("ИГРАТЬ    ›", _open_play_panel, true))
    menu_box.add_child(_make_menu_button("ПРОФИЛЬ    ›", _open_profile_panel))
    menu_box.add_child(_make_menu_button("НАСТРОЙКИ    ›", _open_settings_panel))
    menu_box.add_child(_make_menu_button("ВЫХОД    ›", func(): get_tree().quit()))

    var version := Label.new()
    version.text = "v1.3.0"
    version.position = Vector2(34, -39)
    version.anchor_top = 1.0
    version.anchor_bottom = 1.0
    version.size = Vector2(120, 26)
    version.add_theme_font_size_override("font_size", 12)
    version.add_theme_color_override("font_color", Color("ecf0ff"))
    root.add_child(version)

    var footer := Label.new()
    footer.text = "ReCraft"
    footer.anchor_left = 1.0
    footer.anchor_right = 1.0
    footer.offset_left = -200
    footer.offset_right = -34
    footer.anchor_top = 1.0
    footer.anchor_bottom = 1.0
    footer.offset_top = -39
    footer.offset_bottom = -13
    footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    footer.add_theme_font_size_override("font_size", 12)
    footer.add_theme_color_override("font_color", Color("ecf0ff"))
    root.add_child(footer)

func _make_panel_style(background_color: Color, border_color: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = background_color
    style.border_color = border_color
    style.set_border_width_all(1)
    style.set_corner_radius_all(2)
    style.content_margin_left = 18
    style.content_margin_right = 18
    style.content_margin_top = 12
    style.content_margin_bottom = 12
    return style

func _make_menu_button(caption: String, callback: Callable, primary: bool = false) -> Button:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(360, 48)
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size", 15)
    button.add_theme_color_override("font_color", Color("f5f7ff"))
    var normal_color: Color = Color("657df0", 0.94) if primary else Color(0.035, 0.07, 0.15, 0.77)
    var hover_color: Color = Color("7891ff", 0.98) if primary else Color(0.10, 0.16, 0.27, 0.93)
    button.add_theme_stylebox_override("normal", _make_panel_style(normal_color, Color(0.64, 0.74, 1.0, 0.28)))
    button.add_theme_stylebox_override("hover", _make_panel_style(hover_color, Color("dce5ff")))
    button.add_theme_stylebox_override("pressed", _make_panel_style(Color("4f65cc"), Color("eff3ff")))
    button.pressed.connect(callback)
    return button

func _make_popup(title_text: String, width: float = 390.0) -> VBoxContainer:
    if is_instance_valid(menu_popup):
        menu_popup.queue_free()
    menu_popup = PanelContainer.new()
    menu_popup.name = "MenuPopup"
    menu_popup.anchor_left = 0.5
    menu_popup.anchor_right = 0.5
    menu_popup.anchor_top = 0.5
    menu_popup.anchor_bottom = 0.5
    menu_popup.offset_left = -width * 0.5
    menu_popup.offset_right = width * 0.5
    menu_popup.offset_top = -145
    menu_popup.offset_bottom = 145
    menu_popup.custom_minimum_size = Vector2(width, 290)
    menu_popup.add_theme_stylebox_override("panel", _make_panel_style(Color(0.035, 0.055, 0.105, 0.92), Color(0.76, 0.83, 1.0, 0.55)))
    title_layer.add_child(menu_popup)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    menu_popup.add_child(box)
    var heading := Label.new()
    heading.text = title_text
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    heading.add_theme_font_size_override("font_size", 24)
    heading.add_theme_color_override("font_color", Color("f4f7ff"))
    box.add_child(heading)
    return box

func _open_play_panel() -> void:
    var box := _make_popup("ИГРАТЬ")
    box.add_child(_make_menu_button("НОВЫЙ МИР", func(): _start_game(false), true))
    var continue_button := _make_menu_button("ПРОДОЛЖИТЬ", func(): _start_game(true))
    continue_button.disabled = not FileAccess.file_exists(SAVE_PATH)
    box.add_child(continue_button)
    box.add_child(_make_menu_button("НАЗАД", _close_menu_popup))

func _open_profile_panel() -> void:
    var box := _make_popup("ПРОФИЛЬ")
    var skin_preview = SkinPreviewScript.new()
    skin_preview.name = "ProfileSkinPreview"
    skin_preview.setup_skin(load(DEFAULT_SKIN_PATH) as Texture2D, Vector2i(84, 120))
    skin_preview.custom_minimum_size = Vector2(84, 120)
    skin_preview.size = Vector2(84, 120)
    skin_preview.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    box.add_child(skin_preview)
    var label := Label.new()
    label.text = "ТВОЙ СКИН\nМодель ReCraft"
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 15)
    label.add_theme_color_override("font_color", Color("e2eafa"))
    box.add_child(label)
    box.add_child(_make_menu_button("ГОТОВО", _close_menu_popup, true))

func _open_settings_panel() -> void:
    var box := _make_popup("НАСТРОЙКИ")
    var label := Label.new()
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 15)
    label.add_theme_color_override("font_color", Color("e2eafa"))
    label.name = "RenderDistanceLabel"
    _update_render_distance_label(label)
    box.add_child(label)
    var controls := HBoxContainer.new()
    controls.add_theme_constant_override("separation", 8)
    var less := _make_menu_button("−", func(): _change_render_distance(-1))
    less.custom_minimum_size = Vector2(70, 42)
    var more := _make_menu_button("+", func(): _change_render_distance(1))
    more.custom_minimum_size = Vector2(70, 42)
    controls.add_child(less)
    controls.add_child(more)
    box.add_child(controls)
    box.add_child(_make_menu_button("ГОТОВО", _close_menu_popup, true))

func _update_render_distance_label(label: Label) -> void:
    if is_instance_valid(label):
        label.text = "Дальность прорисовки: %d чанка" % preferred_view_distance

func _change_render_distance(delta_value: int) -> void:
    preferred_view_distance = clampi(preferred_view_distance + delta_value, 2, 3)
    _save_settings()
    if not is_instance_valid(menu_popup):
        return
    var label := menu_popup.find_child("RenderDistanceLabel", true, false) as Label
    _update_render_distance_label(label)

func _close_menu_popup() -> void:
    if is_instance_valid(menu_popup):
        menu_popup.queue_free()
    menu_popup = null

func _start_game(continue_save: bool) -> void:
    # Keep the menu responsive while setup proceeds in several frames. In the
    # previous path, terrain generation, first collision creation, the player
    # model, the skin preview viewport and the entire HUD all initialized in the
    # same button callback, creating a high-risk startup spike.
    if game_started or world_loading:
        return
    world_loading = true
    world_spawn_ready = false
    game_started = false
    loading_elapsed = 0.0
    loading_timeout_reported = false
    pending_start_data.clear()
    _write_startup_log("Create-world requested; continue_save=%s" % str(continue_save))

    if continue_save:
        pending_start_data = _read_save()
        if pending_start_data.is_empty():
            _write_startup_log("Save missing/invalid; falling back to a new world")

    if is_instance_valid(title_layer):
        title_layer.queue_free()
        title_layer = null
    _show_world_loading_screen()
    _update_loading_status()

    # Let Godot present the loading UI before creating terrain resources.
    await get_tree().process_frame
    if not is_inside_tree() or not world_loading:
        return

    if continue_save and not pending_start_data.is_empty():
        day_phase = fposmod(float(pending_start_data.get("day_phase", 0.08)), 1.0)
    else:
        day_phase = 0.08
        cloud_clock = 0.0
    _update_sky(0.0)

    var random := RandomNumberGenerator.new()
    random.randomize()
    world_seed = int(pending_start_data.get("world_seed", random.randi_range(100000, 2000000000)))
    _write_startup_log("Creating world node; seed=%d" % world_seed)
    world = WorldScript.new()
    world.name = "ReCraftWorld"
    world.view_distance_chunks = preferred_view_distance
    add_child(world)
    var saved_changes: Variant = pending_start_data.get("world_changes", {})
    _write_startup_log("Calling World.generate()")
    world.generate(world_seed, saved_changes if saved_changes is Dictionary else {})
    _write_startup_log("Terrain generator initialized; awaiting frame before spawn streaming")

    # Resolve a validated spawn position now, but do not create a camera or
    # avatar yet. The first chunk and its collider will be prepared off-screen.
    pending_player_position = world.get_spawn_position()
    var saved_player: Variant = pending_start_data.get("player", {})
    if saved_player is Dictionary:
        var raw_position: Variant = saved_player.get("position", [])
        if raw_position is Array and raw_position.size() >= 3:
            var saved_x := clampf(float(raw_position[0]), -1000000.0, 1000000.0)
            var saved_z := clampf(float(raw_position[2]), -1000000.0, 1000000.0)
            var saved_y := clampf(float(raw_position[1]), float(WorldScript.MIN_Y) + 1.5, float(WorldScript.MAX_Y) + 8.0)
            pending_player_position = Vector3(saved_x, saved_y, saved_z)

    await get_tree().process_frame
    if not is_inside_tree() or not world_loading or not is_instance_valid(world):
        return

    loading_anchor = Node3D.new()
    loading_anchor.name = "WorldSpawnStreamAnchor"
    loading_anchor.global_position = pending_player_position
    add_child(loading_anchor)
    world.set_stream_target(loading_anchor)
    _write_startup_log("Spawn chunk queued; waiting for its mesh and collision")
    _update_loading_status()

func _process(delta: float) -> void:
    if game_started and not is_paused:
        _update_sky(delta)
    if world_loading:
        loading_elapsed += delta
        if not loading_timeout_reported:
            _update_loading_status()
        if is_instance_valid(world) and is_instance_valid(loading_anchor) and world.is_chunk_ready_for_position(loading_anchor.global_position):
            _finish_world_start()
        elif loading_elapsed >= 45.0 and not loading_timeout_reported:
            loading_timeout_reported = true
            _write_startup_log("Startup timeout: spawn chunk did not become collision-ready in 45 seconds")
            if is_instance_valid(loading_status):
                loading_status.text = "Мир загружается слишком долго.\nПерезапусти игру и проверь recraft_startup.log."
        return
    if not game_started or is_paused or inventory_open:
        return
    autosave_timer += delta
    if autosave_timer >= 90.0:
        autosave_timer = 0.0
        save_game(false)

func _finish_world_start() -> void:
    if not world_loading or not is_instance_valid(world) or not is_instance_valid(loading_anchor):
        return
    _write_startup_log("Spawn collision ready; creating player model and HUD")
    player = ExplorerScene.instantiate()
    player.game = self
    player.name = "Explorer"
    add_child(player)
    player.set_physics_process(false)
    var saved_player: Variant = pending_start_data.get("player", {})
    if saved_player is Dictionary:
        player.load_save_data(saved_player)
    player.global_position = pending_player_position
    _write_startup_log("Player scene initialized")

    world.set_stream_target(player)
    if is_instance_valid(loading_anchor):
        loading_anchor.queue_free()
    loading_anchor = null

    _write_startup_log("Initializing HUD controls")
    hud = HudScript.new()
    add_child(hud)
    hud.setup(self, player, world)
    _write_startup_log("HUD initialized")

    game_started = true
    world_loading = false
    world_spawn_ready = true
    is_paused = false
    inventory_open = false
    autosave_timer = 0.0
    _write_startup_log("Activating gameplay camera; next frame renders the 3D world and sky")
    if player.has_method("activate_game_camera"):
        player.call("activate_game_camera")
    player.set_physics_process(true)
    _hide_world_loading_screen()
    _update_sky(0.0)
    _write_startup_log("World startup complete; gameplay camera is active")
    # New worlds overwrite an old save only after the first chunk exists.
    save_game(false)
    notify("Добро пожаловать в ReCraft. Исследуй мир и строй что захочешь.")

func _show_world_loading_screen() -> void:
    _hide_world_loading_screen()
    loading_layer = CanvasLayer.new()
    loading_layer.name = "WorldLoadingScreen"
    loading_layer.layer = 80
    loading_layer.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(loading_layer)

    var backdrop := ColorRect.new()
    backdrop.color = Color(0.025, 0.04, 0.075, 0.96)
    backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    loading_layer.add_child(backdrop)

    var panel := PanelContainer.new()
    panel.anchor_left = 0.5
    panel.anchor_right = 0.5
    panel.anchor_top = 0.5
    panel.anchor_bottom = 0.5
    panel.offset_left = -230
    panel.offset_right = 230
    panel.offset_top = -82
    panel.offset_bottom = 82
    panel.add_theme_stylebox_override("panel", _make_panel_style(Color(0.045, 0.065, 0.11, 0.98), Color(0.30, 0.48, 0.78, 0.8)))
    loading_layer.add_child(panel)

    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    panel.add_child(box)
    var title := Label.new()
    title.text = "СОЗДАНИЕ МИРА RECRAFT"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 21)
    title.add_theme_color_override("font_color", Color("f3f6ff"))
    box.add_child(title)
    loading_status = Label.new()
    loading_status.text = "Подготовка генератора..."
    loading_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    loading_status.add_theme_font_size_override("font_size", 14)
    loading_status.add_theme_color_override("font_color", Color("c9d8f5"))
    box.add_child(loading_status)

func _update_loading_status() -> void:
    if not is_instance_valid(loading_status):
        return
    var loaded_count := 0
    var total_count := 1
    if is_instance_valid(world):
        loaded_count = world.chunk_cache.size()
        var diameter := world.view_distance_chunks * 2 + 1
        total_count = diameter * diameter
    loading_status.text = "Загрузка чанков: %d / %d\nПодготавливаем точку появления..." % [loaded_count, total_count]

func _hide_world_loading_screen() -> void:
    if is_instance_valid(loading_layer):
        loading_layer.queue_free()
    loading_layer = null
    loading_status = null

func _write_startup_log(stage: String) -> void:
    var file := FileAccess.open(startup_log_path, FileAccess.WRITE if not FileAccess.file_exists(startup_log_path) else FileAccess.READ_WRITE)
    if file == null:
        return
    file.seek_end()
    file.store_line("[%d ms] %s" % [Time.get_ticks_msec(), stage])
    file.close()

func interact() -> void:
    if not game_started or is_paused or inventory_open:
        return
    notify("Здесь нечего использовать.")

func toggle_pause(force_value: Variant = null) -> void:
    if not game_started or inventory_open:
        return
    if force_value == null:
        is_paused = not is_paused
    else:
        is_paused = bool(force_value)
    if is_paused:
        Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
        hud.set_pause_visible(true)
    else:
        hud.set_pause_visible(false)
        Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func toggle_inventory(show_now: bool) -> void:
    if not game_started or is_paused:
        return
    inventory_open = show_now
    if not show_now and is_instance_valid(player):
        player.return_loose_items()
    hud.set_inventory_visible(inventory_open)
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE if inventory_open else Input.MOUSE_MODE_CAPTURED)
    refresh_hud()

func refresh_hud() -> void:
    if is_instance_valid(hud):
        hud.refresh()

func notify(message: String, duration: float = 3.2) -> void:
    if is_instance_valid(hud):
        hud.notify(message, duration)

func save_game(show_notification: bool = true) -> bool:
    if not game_started or world_loading or not world_spawn_ready or not is_instance_valid(player) or not is_instance_valid(world):
        return false
    var data := {
        "version": 4,
        "world_seed": world_seed,
        "day_phase": day_phase,
        "player": player.make_save_data(),
        "world_changes": world.export_changes()
    }
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        notify("Не удалось сохранить игру: %s" % error_string(FileAccess.get_open_error()))
        return false
    file.store_string(JSON.stringify(data, "\t"))
    file.close()
    if show_notification:
        notify("Мир сохранён.")
    return true

func _read_save() -> Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        return {}
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return {}
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    return parsed if parsed is Dictionary else {}

func player_died() -> void:
    if not is_instance_valid(hud):
        return
    is_paused = true
    inventory_open = false
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    hud.set_inventory_visible(false)
    hud.show_death()

func return_to_title() -> void:
    if game_started:
        save_game(false)
    game_started = false
    world_loading = false
    world_spawn_ready = false
    _hide_world_loading_screen()
    is_paused = false
    inventory_open = false
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    for node in [hud, player, world, loading_anchor]:
        if is_instance_valid(node):
            node.queue_free()
    hud = null
    player = null
    world = null
    loading_anchor = null
    pending_start_data.clear()
    _show_title_menu()

func respawn_player() -> void:
    if not is_instance_valid(player) or not is_instance_valid(world):
        return
    player.is_dead = false
    player.health = 10.0
    player.hunger = 20.0
    player.velocity = Vector3.ZERO
    player.global_position = world.get_spawn_position()
    is_paused = false
    hud.hide_ending()
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
    refresh_hud()
    notify("Ты возродился у точки появления.")
