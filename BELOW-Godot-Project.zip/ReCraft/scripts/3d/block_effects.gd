extends Node3D
# World-space effects around the targeted block: black selection outline, the 10-stage crack
# overlay while mining, and the small textured particles that burst out when a block breaks.
# The owner must set top_level = true so these live in world coordinates.

const Catalog = preload("res://scripts/3d/item_catalog.gd")
const B = preload("res://scripts/3d/block_registry.gd")
const BLOCK_TEX_DIR: String = "res://assets/textures/blocks/"
const OUTLINE_THICKNESS: float = 0.014
const CRACK_STAGES: int = 10

var outline: MeshInstance3D
var crack: MeshInstance3D
var crack_materials: Array = []
var particle_materials: Dictionary = {}
var light_color: Color = Color.WHITE

func _ready() -> void:
    name = "BlockEffects"
    outline = MeshInstance3D.new()
    outline.name = "SelectionOutline"
    outline.mesh = _build_outline_mesh()
    outline.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var outline_material := StandardMaterial3D.new()
    outline_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    outline_material.albedo_color = Color(0.0, 0.0, 0.0, 0.62)
    outline_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    outline_material.cull_mode = BaseMaterial3D.CULL_DISABLED
    outline.material_override = outline_material
    outline.visible = false
    add_child(outline)

    crack = MeshInstance3D.new()
    crack.name = "CrackOverlay"
    crack.mesh = _build_crack_mesh()
    crack.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    crack.visible = false
    add_child(crack)
    for stage in range(CRACK_STAGES):
        var mat := StandardMaterial3D.new()
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mat.albedo_texture = load(BLOCK_TEX_DIR + "destroy_%d.png" % stage) as Texture2D
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
        mat.cull_mode = BaseMaterial3D.CULL_BACK
        mat.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
        crack_materials.append(mat)

func _box_into(data: Dictionary, mn: Vector3, mx: Vector3) -> void:
    var verts: PackedVector3Array = data["v"]
    var indices: PackedInt32Array = data["i"]
    var base: int = verts.size()
    for xi in range(2):
        for yi in range(2):
            for zi in range(2):
                verts.append(Vector3(mx.x if xi == 1 else mn.x, mx.y if yi == 1 else mn.y, mx.z if zi == 1 else mn.z))
    # corner index = xi * 4 + yi * 2 + zi
    var quads: Array = [[0, 1, 3, 2], [4, 6, 7, 5], [0, 4, 5, 1], [2, 3, 7, 6], [0, 2, 6, 4], [1, 5, 7, 3]]
    for quad in quads:
        indices.append_array(PackedInt32Array([base + int(quad[0]), base + int(quad[1]), base + int(quad[2]), base + int(quad[0]), base + int(quad[2]), base + int(quad[3])]))
    data["v"] = verts
    data["i"] = indices

func _build_outline_mesh() -> ArrayMesh:
    var half: float = 0.502
    var t: float = OUTLINE_THICKNESS * 0.5
    var data: Dictionary = {"v": PackedVector3Array(), "i": PackedInt32Array()}
    for axis in range(3):
        for a in [-1.0, 1.0]:
            for b in [-1.0, 1.0]:
                var mn := Vector3.ZERO
                var mx := Vector3.ZERO
                for k in range(3):
                    if k == axis:
                        mn[k] = -half - t
                        mx[k] = half + t
                    else:
                        var sign_value: float = float(a) if k == (axis + 1) % 3 else float(b)
                        mn[k] = sign_value * half - t
                        mx[k] = sign_value * half + t
                _box_into(data, mn, mx)
    var arrays: Array = []
    arrays.resize(Mesh.ARRAY_MAX)
    arrays[Mesh.ARRAY_VERTEX] = data["v"]
    arrays[Mesh.ARRAY_INDEX] = data["i"]
    var mesh := ArrayMesh.new()
    mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
    return mesh

func _build_crack_mesh() -> ArrayMesh:
    var h: float = 0.5015
    var faces: Array = [
        [Vector3(h, h, h), Vector3(-h, h, h), Vector3(-h, h, -h), Vector3(h, h, -h), Vector3.UP],
        [Vector3(h, -h, -h), Vector3(-h, -h, -h), Vector3(-h, -h, h), Vector3(h, -h, h), Vector3.DOWN],
        [Vector3(h, h, -h), Vector3(-h, h, -h), Vector3(-h, -h, -h), Vector3(h, -h, -h), Vector3(0, 0, -1)],
        [Vector3(-h, h, h), Vector3(h, h, h), Vector3(h, -h, h), Vector3(-h, -h, h), Vector3(0, 0, 1)],
        [Vector3(h, h, h), Vector3(h, h, -h), Vector3(h, -h, -h), Vector3(h, -h, h), Vector3(1, 0, 0)],
        [Vector3(-h, h, -h), Vector3(-h, h, h), Vector3(-h, -h, h), Vector3(-h, -h, -h), Vector3(-1, 0, 0)]
    ]
    var vertices := PackedVector3Array()
    var normals := PackedVector3Array()
    var uvs := PackedVector2Array()
    var indices := PackedInt32Array()
    var uv_list: Array = [Vector2(0, 0), Vector2(1, 0), Vector2(1, 1), Vector2(0, 1)]
    for face_variant in faces:
        var face: Array = face_variant
        var base: int = vertices.size()
        for i in range(4):
            vertices.append(face[i])
            normals.append(face[4])
            uvs.append(uv_list[i])
        indices.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))
    var arrays: Array = []
    arrays.resize(Mesh.ARRAY_MAX)
    arrays[Mesh.ARRAY_VERTEX] = vertices
    arrays[Mesh.ARRAY_NORMAL] = normals
    arrays[Mesh.ARRAY_TEX_UV] = uvs
    arrays[Mesh.ARRAY_INDEX] = indices
    var mesh := ArrayMesh.new()
    mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
    return mesh

# ------------------------------------------------------------------ public API

func show_outline(cell: Vector3i) -> void:
    if outline == null:
        return
    outline.position = Vector3(cell.x, cell.y, cell.z)
    outline.visible = true

func hide_outline() -> void:
    if outline != null:
        outline.visible = false

func set_crack(cell: Vector3i, stage: int) -> void:
    if crack == null:
        return
    crack.position = Vector3(cell.x, cell.y, cell.z)
    crack.material_override = crack_materials[clampi(stage, 0, CRACK_STAGES - 1)] as Material
    crack.visible = true

func clear_crack() -> void:
    if crack != null:
        crack.visible = false

func set_light(color: Color) -> void:
    light_color = color
    for key in particle_materials.keys():
        var mat: StandardMaterial3D = particle_materials[key]
        mat.albedo_color = color

func _particle_material(texture_name: String) -> StandardMaterial3D:
    if particle_materials.has(texture_name):
        return particle_materials[texture_name] as StandardMaterial3D
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_texture = Catalog.tile_texture(texture_name)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
    mat.albedo_color = light_color
    mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
    mat.billboard_keep_scale = true
    mat.particles_anim_h_frames = 4
    mat.particles_anim_v_frames = 4
    mat.particles_anim_loop = false
    particle_materials[texture_name] = mat
    return mat

func _texture_for_kind(kind: String) -> String:
    var block_id: int = B.id_of(kind)
    if block_id <= 0:
        return "stone"
    if kind == "grass":
        return B.tile_name(block_id, 2)
    return B.tile_name(block_id, 1)

func spawn_particles(kind: String, center: Vector3, extents: Vector3, amount: int, speed: float) -> void:
    var particles := CPUParticles3D.new()
    particles.emitting = false
    particles.one_shot = true
    particles.amount = amount
    particles.lifetime = 0.85
    particles.explosiveness = 1.0
    particles.randomness = 0.6
    particles.local_coords = false
    particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    particles.emission_box_extents = extents
    particles.direction = Vector3.UP
    particles.spread = 180.0
    particles.gravity = Vector3(0.0, -14.0, 0.0)
    particles.initial_velocity_min = speed * 0.35
    particles.initial_velocity_max = speed
    particles.scale_amount_min = 0.5
    particles.scale_amount_max = 1.1
    particles.anim_offset_min = 0.0
    particles.anim_offset_max = 1.0
    var quad := QuadMesh.new()
    quad.size = Vector2(0.14, 0.14)
    quad.material = _particle_material(_texture_for_kind(kind))
    particles.mesh = quad
    add_child(particles)
    particles.global_position = center
    particles.emitting = true
    var timer: SceneTreeTimer = get_tree().create_timer(1.5)
    timer.timeout.connect(func() -> void:
        if is_instance_valid(particles):
            particles.queue_free()
    )

func break_effect(kind: String, cell: Vector3i) -> void:
    spawn_particles(kind, Vector3(cell.x, cell.y, cell.z), Vector3(0.42, 0.42, 0.42), 30, 3.2)

func hit_effect(kind: String, point: Vector3, normal: Vector3) -> void:
    spawn_particles(kind, point + normal * 0.06, Vector3(0.12, 0.12, 0.12), 3, 1.8)
