extends RefCounted
# Builds the 3D models used for items in the hand (first and third person):
#  - blocks become textured cubes (1 unit wide, centred on the origin),
#  - tools/food become extruded 3D sprites like Minecraft's "generated" items.

const Catalog = preload("res://scripts/3d/item_catalog.gd")
const B = preload("res://scripts/3d/block_registry.gd")
const Atlas = preload("res://scripts/3d/atlas_data.gd")
const ATLAS_PATH: String = "res://assets/atlas/blocks_atlas.png"

static func is_flat(item_id: String) -> bool:
    # Equipment catalog entries are real 3D GLB scenes, not generated flat sprites.
    # Keep the legacy flat transform only for 2D-style items and cross-shaped blocks.
    if Catalog.has_item_model(item_id):
        return false
    return Catalog.is_flat_item(item_id)

static func build(item_id: String) -> Node3D:
    if item_id == "":
        return null
    if Catalog.has_item_model(item_id):
        var equipment_model: Node3D = Catalog.instantiate_item_model(item_id)
        if equipment_model != null:
            equipment_model.scale *= Vector3(1.0, 1.0, 1.0)
            return equipment_model
    if is_flat(item_id):
        return _build_flat(item_id)
    return _build_cube(item_id)

static func apply_light(node: Node, color: Color) -> void:
    var mesh_instance := node as MeshInstance3D
    if mesh_instance != null and mesh_instance.mesh != null:
        for i in range(mesh_instance.mesh.get_surface_count()):
            var mat := mesh_instance.mesh.surface_get_material(i) as StandardMaterial3D
            if mat != null:
                mat.albedo_color = color
                mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
                mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
                mat.cull_mode = BaseMaterial3D.CULL_DISABLED
                mat.vertex_color_use_as_albedo = true
    for child in node.get_children():
        apply_light(child, color)

static func _make_material(tex: Texture2D, double_sided: bool) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_texture = tex
    mat.vertex_color_use_as_albedo = true
    mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED if double_sided else BaseMaterial3D.CULL_BACK
    return mat

static func _new_arrays() -> Dictionary:
    return {
        "v": PackedVector3Array(),
        "n": PackedVector3Array(),
        "uv": PackedVector2Array(),
        "c": PackedColorArray(),
        "i": PackedInt32Array()
    }

static func _add_quad(data: Dictionary, a: Vector3, b: Vector3, c: Vector3, d: Vector3, uv_a: Vector2, uv_b: Vector2, uv_c: Vector2, uv_d: Vector2, shade: float, normal: Vector3) -> void:
    var verts: PackedVector3Array = data["v"]
    var normals: PackedVector3Array = data["n"]
    var uvs: PackedVector2Array = data["uv"]
    var colors: PackedColorArray = data["c"]
    var indices: PackedInt32Array = data["i"]
    var base: int = verts.size()
    verts.append(a)
    verts.append(b)
    verts.append(c)
    verts.append(d)
    uvs.append(uv_a)
    uvs.append(uv_b)
    uvs.append(uv_c)
    uvs.append(uv_d)
    for k in range(4):
        normals.append(normal)
        colors.append(Color(shade, shade, shade, 1.0))
    indices.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))
    data["v"] = verts
    data["n"] = normals
    data["uv"] = uvs
    data["c"] = colors
    data["i"] = indices

static func _commit(mesh: ArrayMesh, data: Dictionary, mat: Material) -> void:
    var verts: PackedVector3Array = data["v"]
    if verts.is_empty():
        return
    var arrays: Array = []
    arrays.resize(Mesh.ARRAY_MAX)
    arrays[Mesh.ARRAY_VERTEX] = data["v"]
    arrays[Mesh.ARRAY_NORMAL] = data["n"]
    arrays[Mesh.ARRAY_TEX_UV] = data["uv"]
    arrays[Mesh.ARRAY_COLOR] = data["c"]
    arrays[Mesh.ARRAY_INDEX] = data["i"]
    mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
    mesh.surface_set_material(mesh.get_surface_count() - 1, mat)

static func _build_cube(item_id: String) -> Node3D:
    var kind: String = Catalog.block_kind(item_id)
    if kind == "":
        kind = item_id
    var block_id: int = maxi(1, B.id_of(kind))
    var h: float = 0.5
    var data := _new_arrays()
    # (грань, оттенок, углы a b c d, нормаль): top, bottom, north, south, east, west
    var faces: Array = [
        [0, 1.0, Vector3(h, h, h), Vector3(-h, h, h), Vector3(-h, h, -h), Vector3(h, h, -h), Vector3.UP],
        [2, 0.5, Vector3(h, -h, -h), Vector3(-h, -h, -h), Vector3(-h, -h, h), Vector3(h, -h, h), Vector3.DOWN],
        [1, 0.8, Vector3(h, h, -h), Vector3(-h, h, -h), Vector3(-h, -h, -h), Vector3(h, -h, -h), Vector3(0, 0, -1)],
        [1, 0.8, Vector3(-h, h, h), Vector3(h, h, h), Vector3(h, -h, h), Vector3(-h, -h, h), Vector3(0, 0, 1)],
        [1, 0.6, Vector3(h, h, h), Vector3(h, h, -h), Vector3(h, -h, -h), Vector3(h, -h, h), Vector3(1, 0, 0)],
        [1, 0.6, Vector3(-h, h, -h), Vector3(-h, h, h), Vector3(-h, -h, h), Vector3(-h, -h, -h), Vector3(-1, 0, 0)]
    ]
    var inset: float = 0.0004
    for face_variant in faces:
        var face: Array = face_variant
        var kind_index: int = int(face[0])
        var u0: float = B.uv_u[block_id * 3 + kind_index] + inset
        var v0: float = B.uv_v[block_id * 3 + kind_index] + inset
        var u1: float = u0 + B.uv_w - inset * 2.0
        var v1: float = v0 + B.uv_h - inset * 2.0
        _add_quad(data, face[2], face[3], face[4], face[5], Vector2(u0, v0), Vector2(u1, v0), Vector2(u1, v1), Vector2(u0, v1), float(face[1]), face[6])
    var mesh := ArrayMesh.new()
    var atlas_tex: Texture2D = load(ATLAS_PATH) as Texture2D
    var mat := _make_material(atlas_tex, false)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
    mat.alpha_scissor_threshold = 0.5
    _commit(mesh, data, mat)
    var root := Node3D.new()
    root.name = "HeldBlock"
    var mesh_instance := MeshInstance3D.new()
    mesh_instance.mesh = mesh
    mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(mesh_instance)
    return root

static func _build_flat(item_id: String) -> Node3D:
    var root := Node3D.new()
    root.name = "HeldItem"
    var img: Image = Catalog.flat_image(item_id)
    if img == null:
        return root
    var tex: Texture2D = ImageTexture.create_from_image(img)
    var w: int = img.get_width()
    var h: int = img.get_height()
    var unit: float = 1.0 / float(w)
    var thickness: float = unit
    var zf: float = thickness * 0.5
    var data := _new_arrays()
    for py in range(h):
        for px in range(w):
            if img.get_pixel(px, py).a <= 0.5:
                continue
            var uv := Vector2((float(px) + 0.5) / float(w), (float(py) + 0.5) / float(h))
            var x0: float = float(px) * unit - 0.5
            var x1: float = x0 + unit
            var y1: float = 0.5 - float(py) * unit
            var y0: float = y1 - unit
            # front and back faces
            _add_quad(data, Vector3(x0, y1, zf), Vector3(x1, y1, zf), Vector3(x1, y0, zf), Vector3(x0, y0, zf), uv, uv, uv, uv, 1.0, Vector3(0, 0, 1))
            _add_quad(data, Vector3(x1, y1, -zf), Vector3(x0, y1, -zf), Vector3(x0, y0, -zf), Vector3(x1, y0, -zf), uv, uv, uv, uv, 1.0, Vector3(0, 0, -1))
            # edge faces where the neighbouring pixel is empty
            if px == 0 or img.get_pixel(px - 1, py).a <= 0.5:
                _add_quad(data, Vector3(x0, y1, -zf), Vector3(x0, y1, zf), Vector3(x0, y0, zf), Vector3(x0, y0, -zf), uv, uv, uv, uv, 0.75, Vector3(-1, 0, 0))
            if px == w - 1 or img.get_pixel(px + 1, py).a <= 0.5:
                _add_quad(data, Vector3(x1, y1, zf), Vector3(x1, y1, -zf), Vector3(x1, y0, -zf), Vector3(x1, y0, zf), uv, uv, uv, uv, 0.75, Vector3(1, 0, 0))
            if py == 0 or img.get_pixel(px, py - 1).a <= 0.5:
                _add_quad(data, Vector3(x0, y1, -zf), Vector3(x1, y1, -zf), Vector3(x1, y1, zf), Vector3(x0, y1, zf), uv, uv, uv, uv, 0.9, Vector3(0, 1, 0))
            if py == h - 1 or img.get_pixel(px, py + 1).a <= 0.5:
                _add_quad(data, Vector3(x0, y0, zf), Vector3(x1, y0, zf), Vector3(x1, y0, -zf), Vector3(x0, y0, -zf), uv, uv, uv, uv, 0.6, Vector3(0, -1, 0))
    var mesh := ArrayMesh.new()
    _commit(mesh, data, _make_material(tex, true))
    var mesh_instance := MeshInstance3D.new()
    mesh_instance.mesh = mesh
    mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(mesh_instance)
    return root
