extends MeshInstance3D
# Camera-following sky dome (sun, moon with phases, stars, clouds).

const DOME_SHADER_PATH: String = "res://shaders/recraft_sky_dome.gdshader"
const DOME_RADIUS: float = 500.0

var sky_material: ShaderMaterial
var cloud_clock: float = 0.0

func _ready() -> void:
    name = "ReCraftSkyDome"
    var sphere := SphereMesh.new()
    sphere.radius = DOME_RADIUS
    sphere.height = DOME_RADIUS * 2.0
    sphere.radial_segments = 40
    sphere.rings = 20
    mesh = sphere
    cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    extra_cull_margin = 16384.0
    sky_material = ShaderMaterial.new()
    sky_material.shader = load(DOME_SHADER_PATH) as Shader
    sky_material.set_shader_parameter("sun_texture", load("res://assets/sky/sun.png"))
    sky_material.set_shader_parameter("moon_texture", load("res://assets/sky/moon_phases.png"))
    sky_material.set_shader_parameter("cloud_texture", load("res://assets/sky/clouds.png"))
    material_override = sky_material

func apply_time(model) -> void:
    if sky_material == null:
        return
    var sun_dir: Vector3 = model.sun_direction()
    sky_material.set_shader_parameter("sun_dir", sun_dir)
    sky_material.set_shader_parameter("moon_dir", -sun_dir)
    sky_material.set_shader_parameter("star_matrix", model.star_basis())
    sky_material.set_shader_parameter("top_color", model.sky_top_color())
    sky_material.set_shader_parameter("horizon_color", model.sky_horizon_color())
    sky_material.set_shader_parameter("glow_color", model.TWILIGHT_GLOW)
    sky_material.set_shader_parameter("glow_strength", model.twilight() * 0.85)
    sky_material.set_shader_parameter("cloud_color", model.cloud_tint())
    sky_material.set_shader_parameter("star_visibility", model.star_visibility())
    sky_material.set_shader_parameter("moon_phase", float(model.moon_phase()))
    sky_material.set_shader_parameter("cloud_opacity", 0.0)

func advance_clouds(delta: float) -> void:
    cloud_clock += delta
    if sky_material != null:
        sky_material.set_shader_parameter("cloud_offset", 0.0)
        sky_material.set_shader_parameter("cloud_opacity", 0.0)

func follow(camera: Camera3D) -> void:
    if is_instance_valid(camera):
        global_position = camera.global_position
