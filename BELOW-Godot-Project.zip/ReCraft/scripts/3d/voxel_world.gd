extends Node3D

# Streamed, deterministic voxel world. Terrain is evaluated from the world seed;
# only nearby chunk meshes/colliders and player edits are kept in memory.
const CHUNK_SIZE: int = 16
const MIN_Y: int = -64
const MAX_Y: int = 320 # Exclusive top boundary: valid block levels are -64 through 319.
const BEDROCK_Y: int = -64
const SEA_LEVEL: int = 63
const WORLD_RADIUS: int = 1000000 # Kept for compatibility with older save helpers.
const VIEW_DISTANCE_CHUNKS: int = 3
const CHUNKS_PER_FRAME: int = 1
const HASH_MODULO: int = 2147483647

const TEX_DIR: String = "res://assets/textures/blocks/"
const FACE_OFFSETS: Dictionary = {
    "top": Vector3i(0, 1, 0),
    "bottom": Vector3i(0, -1, 0),
    "south": Vector3i(0, 0, 1),
    "north": Vector3i(0, 0, -1),
    "east": Vector3i(1, 0, 0),
    "west": Vector3i(-1, 0, 0)
}
const TEXTURED_BLOCKS: Dictionary = {
    "grass": ["grass_top", "grass_side", "dirt"],
    "dirt": ["dirt", "dirt", "dirt"],
    "sand": ["sand", "sand", "sand"],
    "wood": ["wood_top", "wood_side", "wood_top"],
    "leaves": ["leaves", "leaves", "leaves"],
    "stone": ["stone", "stone", "stone"],
    "cobblestone": ["cobblestone", "cobblestone", "cobblestone"],
    "coal_ore": ["coal_ore", "coal_ore_side", "coal_ore"],
    "iron_ore": ["iron_ore", "iron_ore_side", "iron_ore"],
    "copper_ore": ["copper_ore", "copper_ore_side", "copper_ore"],
    "hematite_ore": ["hematite_ore", "hematite_ore_side", "hematite_ore"],
    "cassiterite_ore": ["cassiterite_ore", "cassiterite_ore_side", "cassiterite_ore"],
    "pentlandite_ore": ["pentlandite_ore", "pentlandite_ore_side", "pentlandite_ore"],
    "garnierite_ore": ["garnierite_ore", "garnierite_ore_side", "garnierite_ore"],
    "sphalerite_ore": ["sphalerite_ore", "sphalerite_ore_side", "sphalerite_ore"],
    "gold_ore": ["gold_ore", "gold_ore_side", "gold_ore"],
    "lapis_ore": ["lapis_ore", "lapis_ore_side", "lapis_ore"],
    "redstone_ore": ["redstone_ore", "redstone_ore_side", "redstone_ore"],
    "diamond_ore": ["diamond_ore", "diamond_ore_side", "diamond_ore"],
    "titan_ore": ["titan_ore", "titan_ore_side", "titan_ore"],
    "uranium_ore": ["uranium_ore", "uranium_ore_side", "uranium_ore"]
}

# Bounds are inclusive. Peak/spread control the chance inside each allowed band.
const ORE_TABLE: Array = [
    {"kind": "coal_ore", "min_y": 0, "max_y": 320, "peak": 128, "spread": 46.0, "threshold": 0.43, "falloff": 0.16, "offset": 17, "mountain": true},
    {"kind": "iron_ore", "min_y": -64, "max_y": 320, "peak": 16, "spread": 42.0, "threshold": 0.49, "falloff": 0.14, "offset": 29, "mountain": true},
    {"kind": "copper_ore", "min_y": -16, "max_y": 112, "peak": 48, "spread": 27.0, "threshold": 0.53, "falloff": 0.19, "offset": 41},
    {"kind": "hematite_ore", "min_y": -32, "max_y": 96, "peak": 16, "spread": 17.0, "threshold": 0.56, "falloff": 0.20, "offset": 53},
    {"kind": "cassiterite_ore", "min_y": -32, "max_y": 48, "peak": -8, "spread": 17.0, "threshold": 0.59, "falloff": 0.20, "offset": 67},
    {"kind": "pentlandite_ore", "min_y": -48, "max_y": 16, "peak": -24, "spread": 13.0, "threshold": 0.62, "falloff": 0.23, "offset": 79},
    {"kind": "garnierite_ore", "min_y": -32, "max_y": 32, "peak": -8, "spread": 13.0, "threshold": 0.61, "falloff": 0.23, "offset": 97, "wet_cave": true},
    {"kind": "sphalerite_ore", "min_y": -48, "max_y": 32, "peak": -16, "spread": 14.0, "threshold": 0.64, "falloff": 0.22, "offset": 109},
    {"kind": "gold_ore", "min_y": -64, "max_y": 32, "peak": -16, "spread": 18.0, "threshold": 0.68, "falloff": 0.20, "offset": 127},
    {"kind": "lapis_ore", "min_y": -32, "max_y": 64, "peak": 0, "spread": 21.0, "threshold": 0.60, "falloff": 0.18, "offset": 139},
    {"kind": "redstone_ore", "min_y": -64, "max_y": 16, "peak": -54, "spread": 7.0, "threshold": 0.68, "falloff": 0.28, "offset": 151},
    {"kind": "diamond_ore", "min_y": -64, "max_y": 16, "peak": -59, "spread": 7.0, "threshold": 0.74, "falloff": 0.28, "offset": 163},
    {"kind": "titan_ore", "min_y": -56, "max_y": -16, "peak": -40, "spread": 9.0, "threshold": 0.71, "falloff": 0.25, "offset": 179},
    {"kind": "uranium_ore", "min_y": -56, "max_y": -24, "peak": -40, "spread": 7.0, "threshold": 0.76, "falloff": 0.26, "offset": 193}
]

var seed_value: int = 0
var materials: Dictionary = {}
var tex_materials: Dictionary = {}
var removed_cells: Dictionary = {}
var added_cells: Dictionary = {}
var edit_cells_by_chunk: Dictionary = {} # chunk -> {cell: true}; bounded lookup when chunks load
var chunk_cache: Dictionary = {}       # Vector2i -> chunk data dictionary
var pending_chunks: Array[Vector2i] = []
var view_distance_chunks: int = VIEW_DISTANCE_CHUNKS
var height_cache: Dictionary = {}       # Vector2i -> surface Y; pruned as chunks stream
var tree_presence_cache: Dictionary = {} # Vector2i -> bool; avoids repeating tree noise checks
var cache_trim_tick: int = 0
var stream_target: Node3D
var stream_center: Vector2i = Vector2i(2147483647, 2147483647)
var stream_accumulator: float = 0.0
var cave_probe_timer: float = 0.0
var last_cave_probe_cell: Vector3i = Vector3i(2147483647, 2147483647, 2147483647)
var terrain_noise: FastNoiseLite
var detail_noise: FastNoiseLite
var mountain_noise: FastNoiseLite
var biome_noise: FastNoiseLite
var cave_noise_a: FastNoiseLite
var cave_noise_b: FastNoiseLite
var ore_noise: FastNoiseLite

func generate(new_seed: int = 0, saved_changes: Dictionary = {}) -> void:
    seed_value = new_seed if new_seed != 0 else randi()
    removed_cells.clear()
    added_cells.clear()
    edit_cells_by_chunk.clear()
    chunk_cache.clear()
    pending_chunks.clear()
    height_cache.clear()
    tree_presence_cache.clear()
    tex_materials.clear()
    stream_target = null
    stream_center = Vector2i(2147483647, 2147483647)
    stream_accumulator = 0.0
    cave_probe_timer = 0.0
    last_cave_probe_cell = Vector3i(2147483647, 2147483647, 2147483647)
    _configure_noise()
    _create_materials()
    _apply_saved_changes(saved_changes)

func _configure_noise() -> void:
    terrain_noise = FastNoiseLite.new()
    terrain_noise.seed = seed_value
    terrain_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    terrain_noise.frequency = 0.010
    terrain_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
    terrain_noise.fractal_octaves = 4
    terrain_noise.fractal_gain = 0.52

    detail_noise = FastNoiseLite.new()
    detail_noise.seed = seed_value + 101
    detail_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
    detail_noise.frequency = 0.045
    detail_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
    detail_noise.fractal_octaves = 2

    mountain_noise = FastNoiseLite.new()
    mountain_noise.seed = seed_value + 211
    mountain_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    mountain_noise.frequency = 0.008
    mountain_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
    mountain_noise.fractal_octaves = 3

    biome_noise = FastNoiseLite.new()
    biome_noise.seed = seed_value + 307
    biome_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
    biome_noise.frequency = 0.006
    biome_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
    biome_noise.fractal_octaves = 2

    cave_noise_a = FastNoiseLite.new()
    cave_noise_a.seed = seed_value + 401
    cave_noise_a.noise_type = FastNoiseLite.TYPE_SIMPLEX
    cave_noise_a.frequency = 0.039
    cave_noise_a.fractal_type = FastNoiseLite.FRACTAL_FBM
    cave_noise_a.fractal_octaves = 2

    cave_noise_b = FastNoiseLite.new()
    cave_noise_b.seed = seed_value + 503
    cave_noise_b.noise_type = FastNoiseLite.TYPE_SIMPLEX
    cave_noise_b.frequency = 0.043
    cave_noise_b.fractal_type = FastNoiseLite.FRACTAL_FBM
    cave_noise_b.fractal_octaves = 2

    ore_noise = FastNoiseLite.new()
    ore_noise.seed = seed_value + 601
    ore_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
    ore_noise.frequency = 0.105
    ore_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
    ore_noise.fractal_octaves = 2
    ore_noise.fractal_gain = 0.48

func _create_materials() -> void:
    materials.clear()
    materials["bedrock"] = _texture_material("stone", Color(0.24, 0.27, 0.30))
    materials["ancient"] = _texture_material("cobblestone", Color(0.62, 0.70, 0.86))
    materials["torch"] = _material(Color("d49a4b"), true, Color("ff9c3b"))
    materials["ore"] = _material(Color("4aa4a8"), true, Color("32e6ed"))

func _material(base_color: Color, glowing: bool = false, glow_color: Color = Color.BLACK) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = base_color
    material.roughness = 0.92
    if glowing:
        material.emission_enabled = true
        material.emission = glow_color
        material.emission_energy_multiplier = 1.4
    return material

func _texture_material(texture_name: String, tint: Color = Color.WHITE, glow: Color = Color.BLACK, glowing: bool = false) -> StandardMaterial3D:
    var key: String = "%s|%s|%s" % [texture_name, tint.to_html(), str(glowing)]
    if tex_materials.has(key):
        return tex_materials[key] as StandardMaterial3D
    var material := StandardMaterial3D.new()
    var path: String = TEX_DIR + texture_name + ".png"
    if ResourceLoader.exists(path):
        material.albedo_texture = load(path) as Texture2D
    material.albedo_color = tint
    material.roughness = 1.0
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    if texture_name.begins_with("water_"):
        material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_OPAQUE_ONLY
        material.cull_mode = BaseMaterial3D.CULL_DISABLED
        material.albedo_color = Color(material.albedo_color.r, material.albedo_color.g, material.albedo_color.b, 0.76)
        material.roughness = 0.24
    if glowing:
        material.emission_enabled = true
        material.emission = glow
        material.emission_energy_multiplier = 1.2
    tex_materials[key] = material
    return material

func height_at(x: int, z: int) -> int:
    var key := Vector2i(x, z)
    if height_cache.has(key):
        return int(height_cache[key])
    var broad: float = terrain_noise.get_noise_2d(float(x), float(z))
    var detail: float = detail_noise.get_noise_2d(float(x), float(z))
    var ridge_noise: float = mountain_noise.get_noise_2d(float(x), float(z))
    var ridge: float = maxf(0.0, (ridge_noise - 0.13) / 0.87)
    var height_value: float = 77.0 + broad * 14.0 + detail * 5.0 + pow(ridge, 1.7) * 85.0
    var result: int = clampi(roundi(height_value), 60, 192)
    # Keep a small dry landing area; the rest of the terrain remains procedural.
    if Vector2(float(x), float(z)).distance_to(Vector2(0.0, 4.0)) < 3.0:
        result = maxi(result, 68)
    height_cache[key] = result
    return result

func _is_sandy(x: int, z: int, surface_y: int) -> bool:
    if surface_y <= SEA_LEVEL + 2:
        return true
    return biome_noise.get_noise_2d(float(x) + 1900.0, float(z) - 4300.0) > 0.44

func _is_protected_area(x: int, z: int) -> bool:
    var point := Vector2(float(x), float(z))
    if point.distance_to(Vector2(0.0, 4.0)) < 3.2:
        return true
    return false

func _tree_exists(x: int, z: int) -> bool:
    var key := Vector2i(x, z)
    if tree_presence_cache.has(key):
        return bool(tree_presence_cache[key])
    var exists: bool = false
    var surface_y := height_at(x, z)
    if not _is_protected_area(x, z) and surface_y > SEA_LEVEL + 2 and not _is_sandy(x, z, surface_y):
        if biome_noise.get_noise_2d(float(x) - 620.0, float(z) + 870.0) >= -0.24:
            exists = _hash_cell(x, 0, z, 733) % 1000 < 66
    tree_presence_cache[key] = exists
    return exists

func _tree_kind_at(cell: Vector3i) -> String:
    # A tree is derived from its trunk coordinate, so neighbouring chunks agree on its shape.
    if cell.y < MIN_Y or cell.y >= MAX_Y:
        return ""
    for tx in range(cell.x - 2, cell.x + 3):
        for tz in range(cell.z - 2, cell.z + 3):
            if not _tree_exists(tx, tz):
                continue
            var base_y := height_at(tx, tz)
            var dx := cell.x - tx
            var dz := cell.z - tz
            var dy := cell.y - base_y
            if dx == 0 and dz == 0 and dy >= 1 and dy <= 4:
                return "wood"
            if dy < 2 or dy > 5:
                continue
            var radius: int = 2 if dy <= 4 else 1
            if abs(dx) <= radius and abs(dz) <= radius and abs(dx) + abs(dz) <= radius * 2:
                if not (dx == 0 and dz == 0 and dy <= 4):
                    return "leaves"
    return ""

func _is_cave_cell(cell: Vector3i) -> bool:
    if cell.y <= MIN_Y + 4 or cell.y >= height_at(cell.x, cell.z) - 4:
        return false
    var first: float = cave_noise_a.get_noise_3d(float(cell.x), float(cell.y), float(cell.z))
    if absf(first) > 0.105:
        return false
    var second: float = cave_noise_b.get_noise_3d(float(cell.x) + 173.0, float(cell.y) - 61.0, float(cell.z) + 329.0)
    return absf(second) < 0.20

func _near_cave(cell: Vector3i) -> bool:
    for offset_variant in FACE_OFFSETS.values():
        var offset: Vector3i = offset_variant
        if _is_cave_cell(cell + offset):
            return true
    return false

func _ore_kind_at(cell: Vector3i) -> String:
    var surface_y := height_at(cell.x, cell.z)
    var humidity: float = biome_noise.get_noise_2d(float(cell.x) + 4200.0, float(cell.z) + 6100.0)
    for ore_variant in ORE_TABLE:
        var ore: Dictionary = ore_variant
        var y: int = cell.y
        if y < int(ore["min_y"]) or y > int(ore["max_y"]):
            continue
        var peak: float = float(ore["peak"])
        var spread: float = maxf(1.0, float(ore["spread"]))
        var deviation: float = absf(float(y) - peak) / spread
        var threshold: float = float(ore["threshold"]) + deviation * float(ore["falloff"])
        var ore_kind: String = str(ore["kind"])
        if bool(ore.get("mountain", false)):
            if ore_kind == "coal_ore" and surface_y >= 96:
                threshold -= 0.08
            elif ore_kind == "iron_ore" and surface_y >= 108:
                threshold -= 0.11
        if threshold >= 0.98:
            continue
        var offset: float = float(ore["offset"])
        var value: float = ore_noise.get_noise_3d(
            float(cell.x) + offset * 7.3,
            float(cell.y) + offset * 3.1,
            float(cell.z) - offset * 5.9
        )
        if value <= threshold:
            continue
        if bool(ore.get("wet_cave", false)):
            if humidity < 0.02 or not _near_cave(cell):
                continue
        return ore_kind
    return ""

func get_block_kind(cell: Vector3i) -> String:
    if cell.y < MIN_Y or cell.y >= MAX_Y:
        return "air"
    if removed_cells.has(cell):
        return "air"
    if added_cells.has(cell):
        return str(added_cells[cell])

    var surface_y := height_at(cell.x, cell.z)
    if cell.y > surface_y:
        if surface_y < SEA_LEVEL and cell.y <= SEA_LEVEL:
            return "water"
        var tree_kind := _tree_kind_at(cell)
        if tree_kind != "":
            return tree_kind
        return "air"

    if cell.y == MIN_Y:
        return "bedrock"
    if cell.y <= MIN_Y + 4:
        var bedrock_chance: int = (MIN_Y + 4 - cell.y) * 24
        if _hash_cell(cell.x, cell.y, cell.z, 991) % 100 < bedrock_chance:
            return "bedrock"
    if cell.y == surface_y:
        return "sand" if _is_sandy(cell.x, cell.z, surface_y) else "grass"
    if cell.y >= surface_y - 3:
        return "sand" if _is_sandy(cell.x, cell.z, surface_y) else "dirt"
    if _is_cave_cell(cell):
        return "air"
    var ore_kind := _ore_kind_at(cell)
    if ore_kind != "":
        return ore_kind
    return "stone"

func get_spawn_position() -> Vector3:
    return Vector3(0.0, float(height_at(0, 4)) + 1.42, 4.0)

func set_stream_target(target: Node3D) -> void:
    stream_target = target
    if not is_instance_valid(stream_target):
        return
    var center := _world_to_chunk(stream_target.global_position)
    stream_center = center
    last_cave_probe_cell = Vector3i(2147483647, 2147483647, 2147483647)
    _ensure_chunk(center)
    _refresh_stream_queue(center)

func _process(delta: float) -> void:
    if not is_instance_valid(stream_target):
        return
    cave_probe_timer += delta
    if cave_probe_timer >= 0.75:
        cave_probe_timer = 0.0
        _probe_cave_near_player()
    stream_accumulator += delta
    if stream_accumulator >= 0.20:
        stream_accumulator = 0.0
        var new_center := _world_to_chunk(stream_target.global_position)
        if new_center != stream_center:
            stream_center = new_center
            last_cave_probe_cell = Vector3i(2147483647, 2147483647, 2147483647)
            _ensure_chunk(new_center)
            _refresh_stream_queue(new_center)
            _unload_distant_chunks(new_center)
            _trim_height_cache(new_center)
    var budget := CHUNKS_PER_FRAME
    while budget > 0 and not pending_chunks.is_empty():
        var coord: Vector2i = pending_chunks.pop_front()
        if _chunk_in_view(coord, stream_center) and not chunk_cache.has(coord):
            _load_chunk(coord)
        budget -= 1

func _probe_cave_near_player() -> void:
    if not is_instance_valid(stream_target):
        return
    var position: Vector3 = stream_target.global_position
    var center := Vector3i(roundi(position.x), roundi(position.y), roundi(position.z))
    var moved_blocks: int = absi(center.x - last_cave_probe_cell.x) + absi(center.y - last_cave_probe_cell.y) + absi(center.z - last_cave_probe_cell.z)
    if moved_blocks < 4:
        return
    last_cave_probe_cell = center
    if center.y <= MIN_Y + 4 or center.y >= height_at(center.x, center.z) - 4:
        return

    var near_cave: bool = _is_cave_cell(center)
    if not near_cave:
        for offset_variant in FACE_OFFSETS.values():
            var offset: Vector3i = offset_variant
            if _is_cave_cell(center + offset):
                near_cave = true
                break
    if not near_cave:
        return

    # Underground geometry is generated only near an explored cave, not for every
    # hidden voxel in every loaded chunk. This keeps initial chunk generation cheap.
    var affected_chunks: Dictionary = {}
    for x in range(center.x - 1, center.x + 2):
        for y in range(maxi(MIN_Y, center.y - 1), mini(MAX_Y, center.y + 2)):
            for z in range(center.z - 1, center.z + 2):
                var cell := Vector3i(x, y, z)
                var coord := _cell_to_chunk(cell)
                if not chunk_cache.has(coord):
                    continue
                _refresh_face_record(coord, cell)
                affected_chunks[coord] = true
    for coord_variant in affected_chunks.keys():
        _rebuild_chunk_mesh(coord_variant)

func _world_to_chunk(position: Vector3) -> Vector2i:
    return Vector2i(floori(position.x / float(CHUNK_SIZE)), floori(position.z / float(CHUNK_SIZE)))

func _cell_to_chunk(cell: Vector3i) -> Vector2i:
    return Vector2i(floori(float(cell.x) / float(CHUNK_SIZE)), floori(float(cell.z) / float(CHUNK_SIZE)))

func _chunk_in_view(coord: Vector2i, center: Vector2i, extra: int = 0) -> bool:
    return absi(coord.x - center.x) <= view_distance_chunks + extra and absi(coord.y - center.y) <= view_distance_chunks + extra

func _refresh_stream_queue(center: Vector2i) -> void:
    pending_chunks.clear()
    for ring in range(0, view_distance_chunks + 1):
        for dx in range(-ring, ring + 1):
            for dz in range(-ring, ring + 1):
                if maxi(absi(dx), absi(dz)) != ring:
                    continue
                var coord := Vector2i(center.x + dx, center.y + dz)
                if not chunk_cache.has(coord):
                    pending_chunks.append(coord)

func _unload_distant_chunks(center: Vector2i) -> void:
    var to_remove: Array[Vector2i] = []
    for key_variant in chunk_cache.keys():
        var coord: Vector2i = key_variant
        if not _chunk_in_view(coord, center, 1):
            to_remove.append(coord)
    for coord in to_remove:
        var data: Dictionary = chunk_cache[coord]
        var root: Node3D = data.get("root") as Node3D
        if is_instance_valid(root):
            root.queue_free()
        chunk_cache.erase(coord)
    if not to_remove.is_empty():
        _refresh_stream_queue(center)

func _trim_height_cache(center: Vector2i) -> void:
    cache_trim_tick += 1
    if cache_trim_tick < 2 and height_cache.size() < 70000 and tree_presence_cache.size() < 70000:
        return
    cache_trim_tick = 0
    var center_x: int = center.x * CHUNK_SIZE
    var center_z: int = center.y * CHUNK_SIZE
    var limit: int = (view_distance_chunks + 3) * CHUNK_SIZE
    var stale: Array[Vector2i] = []
    for key_variant in height_cache.keys():
        var key: Vector2i = key_variant
        if absi(key.x - center_x) > limit or absi(key.y - center_z) > limit:
            stale.append(key)
    for key in stale:
        height_cache.erase(key)
    var stale_trees: Array[Vector2i] = []
    for key_variant in tree_presence_cache.keys():
        var key: Vector2i = key_variant
        if absi(key.x - center_x) > limit or absi(key.y - center_z) > limit:
            stale_trees.append(key)
    for key in stale_trees:
        tree_presence_cache.erase(key)

func _ensure_chunk(coord: Vector2i) -> void:
    if not chunk_cache.has(coord):
        var pending_index := pending_chunks.find(coord)
        if pending_index >= 0:
            pending_chunks.remove_at(pending_index)
        _load_chunk(coord)

func _load_chunk(coord: Vector2i) -> void:
    if chunk_cache.has(coord):
        return
    var origin_x := coord.x * CHUNK_SIZE
    var origin_z := coord.y * CHUNK_SIZE
    var root := Node3D.new()
    root.name = "Chunk_%d_%d" % [coord.x, coord.y]
    root.position = Vector3(origin_x, 0.0, origin_z)
    add_child(root)

    var body := StaticBody3D.new()
    body.name = "TerrainCollision"
    body.collision_layer = 1
    body.collision_mask = 1
    body.add_to_group("voxel_chunks")
    body.set_meta("chunk_coord", coord)
    root.add_child(body)

    var collision := CollisionShape3D.new()
    collision.name = "TerrainShape"
    body.add_child(collision)

    var mesh_instance := MeshInstance3D.new()
    mesh_instance.name = "TerrainMesh"
    mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(mesh_instance)

    var water_instance := MeshInstance3D.new()
    water_instance.name = "WaterMesh"
    water_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    water_instance.sorting_offset = 1.0
    root.add_child(water_instance)

    var data: Dictionary = {
        "root": root,
        "body": body,
        "collision": collision,
        "mesh": mesh_instance,
        "water_mesh": water_instance,
        "faces": {}
    }
    chunk_cache[coord] = data
    _populate_initial_chunk_faces(coord)
    _rebuild_chunk_mesh(coord, true)

func _populate_initial_chunk_faces(coord: Vector2i) -> void:
    if not chunk_cache.has(coord):
        return
    var data: Dictionary = chunk_cache[coord]
    var faces: Dictionary = data["faces"]
    var origin_x := coord.x * CHUNK_SIZE
    var origin_z := coord.y * CHUNK_SIZE
    var heights: Dictionary = {}

    # Sample heights once. The old path called get_block_kind() for every face and all
    # neighbours, needlessly repeating tree and ore-noise evaluation during every chunk load.
    for local_x in range(CHUNK_SIZE):
        for local_z in range(CHUNK_SIZE):
            var x := origin_x + local_x
            var z := origin_z + local_z
            heights[Vector2i(x, z)] = height_at(x, z)

    for local_x in range(CHUNK_SIZE):
        for local_z in range(CHUNK_SIZE):
            var x := origin_x + local_x
            var z := origin_z + local_z
            var surface_y: int = int(heights[Vector2i(x, z)])
            var south_key := Vector2i(x, z + 1)
            var north_key := Vector2i(x, z - 1)
            var east_key := Vector2i(x + 1, z)
            var west_key := Vector2i(x - 1, z)
            var neighbor_heights: Dictionary = {
                "south": int(heights[south_key]) if heights.has(south_key) else height_at(x, z + 1),
                "north": int(heights[north_key]) if heights.has(north_key) else height_at(x, z - 1),
                "east": int(heights[east_key]) if heights.has(east_key) else height_at(x + 1, z),
                "west": int(heights[west_key]) if heights.has(west_key) else height_at(x - 1, z)
            }
            var lowest_neighbor: int = mini(mini(int(neighbor_heights["south"]), int(neighbor_heights["north"])), mini(int(neighbor_heights["east"]), int(neighbor_heights["west"])))
            var bottom_y: int = mini(surface_y, lowest_neighbor + 1)

            for y in range(bottom_y, surface_y + 1):
                var cell := Vector3i(x, y, z)
                var kind := get_block_kind(cell)
                if kind == "air" or kind == "water":
                    continue
                var visible_faces: Array[String] = []
                if y == surface_y:
                    visible_faces.append("top")
                for side_variant in ["south", "north", "east", "west"]:
                    if y > int(neighbor_heights[side_variant]):
                        visible_faces.append(side_variant)
                if not visible_faces.is_empty():
                    faces[cell] = {"kind": kind, "faces": visible_faces}

    # Re-apply sparse player edits to this chunk, including any newly exposed faces.
    for edit_chunk_x in range(coord.x - 1, coord.x + 2):
        for edit_chunk_z in range(coord.y - 1, coord.y + 2):
            var edit_key := Vector2i(edit_chunk_x, edit_chunk_z)
            var edit_map: Dictionary = edit_cells_by_chunk.get(edit_key, {})
            for cell_variant in edit_map.keys():
                var edit_cell: Vector3i = cell_variant
                if _cell_to_chunk(edit_cell) == coord:
                    _refresh_face_record(coord, edit_cell)
                for offset_variant in FACE_OFFSETS.values():
                    var offset: Vector3i = offset_variant
                    var nearby_cell: Vector3i = edit_cell + offset
                    if _cell_to_chunk(nearby_cell) == coord:
                        _refresh_face_record(coord, nearby_cell)

    # Trees are sparse; add their deterministically-derived trunks and canopies separately.
    for tx in range(origin_x - 2, origin_x + CHUNK_SIZE + 2):
        for tz in range(origin_z - 2, origin_z + CHUNK_SIZE + 2):
            if not _tree_exists(tx, tz):
                continue
            var base_y := height_at(tx, tz)
            for dx in range(-2, 3):
                for dz in range(-2, 3):
                    for dy in range(1, 6):
                        var cell := Vector3i(tx + dx, base_y + dy, tz + dz)
                        if _cell_to_chunk(cell) != coord:
                            continue
                        if _tree_kind_at(cell) != "":
                            _refresh_face_record(coord, cell)

func _refresh_face_record(coord: Vector2i, cell: Vector3i) -> void:
    if not chunk_cache.has(coord):
        return
    var data: Dictionary = chunk_cache[coord]
    var faces: Dictionary = data["faces"]
    if cell.y < MIN_Y or cell.y >= MAX_Y:
        faces.erase(cell)
        return
    var kind := get_block_kind(cell)
    if kind == "air" or kind == "water":
        faces.erase(cell)
        return
    var visible_faces: Array[String] = []
    for face_variant in FACE_OFFSETS.keys():
        var face := str(face_variant)
        var offset: Vector3i = FACE_OFFSETS[face]
        var neighbor_kind := get_block_kind(cell + offset)
        if neighbor_kind == "air" or neighbor_kind == "water":
            visible_faces.append(face)
    if visible_faces.is_empty():
        faces.erase(cell)
    else:
        faces[cell] = {"kind": kind, "faces": visible_faces}

func _new_builder() -> Dictionary:
    return {
        "vertices": PackedVector3Array(),
        "normals": PackedVector3Array(),
        "uvs": PackedVector2Array(),
        "indices": PackedInt32Array()
    }

func _face_corners(face: String) -> Array:
    match face:
        "top":
            return [Vector3(-0.5, 0.5, -0.5), Vector3(0.5, 0.5, -0.5), Vector3(0.5, 0.5, 0.5), Vector3(-0.5, 0.5, 0.5)]
        "bottom":
            return [Vector3(-0.5, -0.5, 0.5), Vector3(0.5, -0.5, 0.5), Vector3(0.5, -0.5, -0.5), Vector3(-0.5, -0.5, -0.5)]
        "south":
            return [Vector3(-0.5, 0.5, 0.5), Vector3(0.5, 0.5, 0.5), Vector3(0.5, -0.5, 0.5), Vector3(-0.5, -0.5, 0.5)]
        "north":
            return [Vector3(0.5, 0.5, -0.5), Vector3(-0.5, 0.5, -0.5), Vector3(-0.5, -0.5, -0.5), Vector3(0.5, -0.5, -0.5)]
        "east":
            return [Vector3(0.5, 0.5, 0.5), Vector3(0.5, 0.5, -0.5), Vector3(0.5, -0.5, -0.5), Vector3(0.5, -0.5, 0.5)]
        "west":
            return [Vector3(-0.5, 0.5, -0.5), Vector3(-0.5, 0.5, 0.5), Vector3(-0.5, -0.5, 0.5), Vector3(-0.5, -0.5, -0.5)]
    return []

func _face_normal(face: String) -> Vector3:
    match face:
        "top": return Vector3.UP
        "bottom": return Vector3.DOWN
        "south": return Vector3(0, 0, 1)
        "north": return Vector3(0, 0, -1)
        "east": return Vector3(1, 0, 0)
        "west": return Vector3(-1, 0, 0)
    return Vector3.UP

func _append_face(builders: Dictionary, surface_key: String, cell: Vector3i, face: String, origin_x: int, origin_z: int) -> void:
    var builder: Dictionary
    if builders.has(surface_key):
        builder = builders[surface_key]
    else:
        builder = _new_builder()
    var vertices: PackedVector3Array = builder["vertices"]
    var normals: PackedVector3Array = builder["normals"]
    var uvs: PackedVector2Array = builder["uvs"]
    var indices: PackedInt32Array = builder["indices"]
    var corners: Array = _face_corners(face)
    var normal: Vector3 = _face_normal(face)
    var local_center := Vector3(float(cell.x - origin_x), float(cell.y), float(cell.z - origin_z))
    var order: Array = [0, 1, 2, 3]
    var a: Vector3 = corners[0]
    var b: Vector3 = corners[1]
    var c: Vector3 = corners[2]
    if (b - a).cross(c - a).dot(normal) > 0.0:
        order = [0, 3, 2, 1]
    var uvs_by_corner: Array = [Vector2(0, 0), Vector2(1, 0), Vector2(1, 1), Vector2(0, 1)]
    var base_index: int = vertices.size()
    for corner_index in order:
        var index: int = int(corner_index)
        vertices.append(local_center + corners[index])
        normals.append(normal)
        uvs.append(uvs_by_corner[index])
    indices.append_array(PackedInt32Array([base_index, base_index + 1, base_index + 2, base_index, base_index + 2, base_index + 3]))
    builder["vertices"] = vertices
    builder["normals"] = normals
    builder["uvs"] = uvs
    builder["indices"] = indices
    builders[surface_key] = builder

func _surface_material_key(kind: String, face: String) -> String:
    if kind == "bedrock":
        return "bedrock"
    if kind == "ancient":
        return "ancient"
    if kind.begins_with("water_"):
        return kind + "|top"
    if TEXTURED_BLOCKS.has(kind):
        var texture_names: Array = TEXTURED_BLOCKS[kind]
        var material_index: int = 0 if face == "top" else (2 if face == "bottom" else 1)
        return str(texture_names[material_index])
    return kind

func _material_for_surface(surface_key: String) -> Material:
    var parts: PackedStringArray = surface_key.split("|")
    var texture_or_kind: String = str(parts[0])
    if texture_or_kind == "bedrock":
        return materials["bedrock"]
    if texture_or_kind == "ancient":
        return materials["ancient"]
    if texture_or_kind.begins_with("water_"):
        return _texture_material(texture_or_kind, Color.WHITE)
    if ResourceLoader.exists(TEX_DIR + texture_or_kind + ".png"):
        return _texture_material(texture_or_kind)
    return materials.get(texture_or_kind, _texture_material("stone")) as Material

func _mesh_from_builders(builders: Dictionary) -> ArrayMesh:
    var mesh := ArrayMesh.new()
    for surface_key_variant in builders.keys():
        var surface_key := str(surface_key_variant)
        var builder: Dictionary = builders[surface_key_variant]
        var vertices: PackedVector3Array = builder["vertices"]
        if vertices.is_empty():
            continue
        var arrays: Array = []
        arrays.resize(Mesh.ARRAY_MAX)
        arrays[Mesh.ARRAY_VERTEX] = vertices
        arrays[Mesh.ARRAY_NORMAL] = builder["normals"]
        arrays[Mesh.ARRAY_TEX_UV] = builder["uvs"]
        arrays[Mesh.ARRAY_INDEX] = builder["indices"]
        mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
        mesh.surface_set_material(mesh.get_surface_count() - 1, _material_for_surface(surface_key))
    return mesh

func _build_water_mesh(coord: Vector2i) -> ArrayMesh:
    var builders: Dictionary = {}
    var origin_x := coord.x * CHUNK_SIZE
    var origin_z := coord.y * CHUNK_SIZE
    for local_x in range(CHUNK_SIZE):
        for local_z in range(CHUNK_SIZE):
            var x := origin_x + local_x
            var z := origin_z + local_z
            if height_at(x, z) >= SEA_LEVEL:
                continue
            var cell := Vector3i(x, SEA_LEVEL, z)
            if get_block_kind(cell) != "water":
                continue
            var variant: int = _hash_cell(x, SEA_LEVEL, z, 1231) % 5
            _append_face(builders, "water_%d|top" % variant, cell, "top", origin_x, origin_z)
    return _mesh_from_builders(builders)

func _rebuild_chunk_mesh(coord: Vector2i, rebuild_water: bool = false) -> void:
    if not chunk_cache.has(coord):
        return
    var data: Dictionary = chunk_cache[coord]
    var builders: Dictionary = {}
    var origin_x := coord.x * CHUNK_SIZE
    var origin_z := coord.y * CHUNK_SIZE
    var faces: Dictionary = data["faces"]
    for cell_variant in faces.keys():
        var cell: Vector3i = cell_variant
        var record: Dictionary = faces[cell_variant]
        var kind: String = str(record.get("kind", "stone"))
        var face_list: Array = record.get("faces", [])
        for face_variant in face_list:
            var face := str(face_variant)
            _append_face(builders, _surface_material_key(kind, face), cell, face, origin_x, origin_z)
    var solid_mesh := _mesh_from_builders(builders)
    var mesh_instance: MeshInstance3D = data["mesh"] as MeshInstance3D
    mesh_instance.mesh = solid_mesh
    var collision: CollisionShape3D = data["collision"] as CollisionShape3D
    collision.shape = solid_mesh.create_trimesh_shape() if solid_mesh.get_surface_count() > 0 else null
    if rebuild_water:
        var water_instance: MeshInstance3D = data["water_mesh"] as MeshInstance3D
        water_instance.mesh = _build_water_mesh(coord)

func is_position_in_water(position: Vector3) -> bool:
    # This is called every physics tick. Avoid the full block resolver (trees, caves and ores)
    # and answer directly from the cached height map and sea level.
    var x: int = floori(position.x + 0.5)
    var y: int = floori(position.y + 0.5)
    var z: int = floori(position.z + 0.5)
    if y <= MIN_Y or y > SEA_LEVEL:
        return false
    return height_at(x, z) < y

func cell_from_hit(hit_position: Vector3, hit_normal: Vector3) -> Vector3i:
    var interior: Vector3 = hit_position - hit_normal * 0.02
    return Vector3i(
        floori(interior.x + 0.5),
        floori(interior.y + 0.5),
        floori(interior.z + 0.5)
    )

func mine_cell(cell: Vector3i) -> Dictionary:
    if cell.y <= MIN_Y:
        return {"ok": false, "message": "Коренная порода не поддаётся кирке."}
    var kind := get_block_kind(cell)
    if kind == "air" or kind == "water":
        return {"ok": false, "message": "Здесь нет блока."}
    if kind == "bedrock":
        return {"ok": false, "message": "Коренная порода не поддаётся кирке."}
    removed_cells[cell] = true
    added_cells.erase(cell)
    _index_edit_cell(cell)
    _refresh_cells_around(cell)
    return {"ok": true, "kind": kind, "cell": cell}

func mine_block(target: Node) -> Dictionary:
    # Compatibility bridge for older callers that use one StaticBody3D per block.
    if not is_instance_valid(target):
        return {"ok": false, "message": "Это нельзя добыть."}
    if target.has_meta("grid_cell"):
        var cell: Vector3i = target.get_meta("grid_cell", Vector3i.ZERO)
        return mine_cell(cell)
    return {"ok": false, "message": "Блок не определён."}

func place_block(cell: Vector3i, kind: String) -> bool:
    if cell.y <= MIN_Y or cell.y >= MAX_Y:
        return false
    var existing := get_block_kind(cell)
    if existing != "air" and existing != "water":
        return false
    if kind == "" or kind == "air" or kind == "water" or kind == "bedrock":
        return false
    added_cells[cell] = kind
    removed_cells.erase(cell)
    _index_edit_cell(cell)
    _refresh_cells_around(cell)
    return true

func _refresh_cells_around(changed_cell: Vector3i) -> void:
    var affected_chunks: Dictionary = {}
    _refresh_cell_if_loaded(changed_cell, affected_chunks)
    for offset_variant in FACE_OFFSETS.values():
        var offset: Vector3i = offset_variant
        _refresh_cell_if_loaded(changed_cell + offset, affected_chunks)
    var changed_chunk := _cell_to_chunk(changed_cell)
    for coord_variant in affected_chunks.keys():
        var coord: Vector2i = coord_variant
        _rebuild_chunk_mesh(coord, changed_cell.y == SEA_LEVEL and coord == changed_chunk)

func _refresh_cell_if_loaded(cell: Vector3i, affected_chunks: Dictionary) -> void:
    if cell.y < MIN_Y or cell.y >= MAX_Y:
        return
    var coord := _cell_to_chunk(cell)
    if not chunk_cache.has(coord):
        return
    _refresh_face_record(coord, cell)
    affected_chunks[coord] = true

func export_changes() -> Dictionary:
    var removed: Array = []
    for cell_variant in removed_cells.keys():
        var cell: Vector3i = cell_variant
        removed.append([cell.x, cell.y, cell.z])
    var added: Array = []
    for cell_variant in added_cells.keys():
        var cell: Vector3i = cell_variant
        added.append([cell.x, cell.y, cell.z, str(added_cells[cell_variant])])
    return {"removed": removed, "added": added}

func _apply_saved_changes(changes: Dictionary) -> void:
    for raw_cell in changes.get("removed", []):
        if raw_cell is Array and raw_cell.size() >= 3:
            var cell := Vector3i(int(raw_cell[0]), int(raw_cell[1]), int(raw_cell[2]))
            removed_cells[cell] = true
            added_cells.erase(cell)
            _index_edit_cell(cell)
    for raw_block in changes.get("added", []):
        if raw_block is Array and raw_block.size() >= 4:
            var cell := Vector3i(int(raw_block[0]), int(raw_block[1]), int(raw_block[2]))
            if cell.y < MIN_Y or cell.y >= MAX_Y:
                continue
            var kind := str(raw_block[3])
            added_cells[cell] = kind
            removed_cells.erase(cell)
            _index_edit_cell(cell)

func _index_edit_cell(cell: Vector3i) -> void:
    var coord := _cell_to_chunk(cell)
    if not edit_cells_by_chunk.has(coord):
        edit_cells_by_chunk[coord] = {}
    var edit_map: Dictionary = edit_cells_by_chunk[coord]
    edit_map[cell] = true
    edit_cells_by_chunk[coord] = edit_map

func is_ore(kind: String) -> bool:
    for ore_variant in ORE_TABLE:
        var ore: Dictionary = ore_variant
        if str(ore["kind"]) == kind:
            return true
    return false

func _positive_mod(value: int, divisor: int) -> int:
    var remainder: int = value % divisor
    return remainder + divisor if remainder < 0 else remainder

func _hash_cell(x: int, y: int, z: int, salt: int = 0) -> int:
    # Keep intermediate values bounded so hashing stays safe at large coordinates.
    var value: int = _positive_mod(x, HASH_MODULO) * 73856093
    value = _positive_mod(value + _positive_mod(y, HASH_MODULO) * 19349663, HASH_MODULO)
    value = _positive_mod(value + _positive_mod(z, HASH_MODULO) * 83492791, HASH_MODULO)
    value = _positive_mod(value + _positive_mod(seed_value, HASH_MODULO) * 40699, HASH_MODULO)
    value = _positive_mod(value + _positive_mod(salt, HASH_MODULO) * 65599, HASH_MODULO)
    value = value ^ (value >> 13)
    value = _positive_mod(value * 1274126177, HASH_MODULO)
    value = value ^ (value >> 16)
    return int(value)

