extends RefCounted
# Детерминированный генератор чанков 16x16x384. Не трогает сцену, поэтому безопасно
# работает в рабочих потоках: каждая задача создаёт свой экземпляр (свои шумы).
#
# Раскладка данных чанка: индекс = (z * 16 + x) * 384 + (y - MIN_Y), то есть столбец
# по высоте лежит в памяти непрерывно.

const B = preload("res://scripts/3d/block_registry.gd")

const CHUNK: int = 16
const MIN_Y: int = -64
const MAX_Y: int = 320
const COL_H: int = 384
const SEA_LEVEL: int = 63
const REGION_CHUNKS: int = 8
const ENTRANCE_T: float = 0.62

const BIOME_OCEAN: int = 0
const BIOME_DEEP_OCEAN: int = 1
const BIOME_BEACH: int = 2
const BIOME_PLAINS: int = 3
const BIOME_FOREST: int = 4
const BIOME_BIRCH_FOREST: int = 5
const BIOME_DARK_FOREST: int = 6
const BIOME_TAIGA: int = 7
const BIOME_SNOWY_TAIGA: int = 8
const BIOME_SEQUOIA: int = 9
const BIOME_JUNGLE: int = 10
const BIOME_SWAMP: int = 11
const BIOME_SAVANNA: int = 12
const BIOME_DESERT: int = 13
const BIOME_BADLANDS: int = 14
const BIOME_MOUNTAINS: int = 15
const BIOME_SNOWY_PEAKS: int = 16
const BIOME_CHERRY: int = 17
const BIOME_MAPLE: int = 18
const BIOME_ASPEN: int = 19
const BIOME_AZURE: int = 20
const BIOME_MUSHROOM: int = 21
const BIOME_ANCIENT: int = 22
const BIOME_RIVER: int = 23
const BIOME_WASTELAND: int = 24
const BIOME_ICE_PLAINS: int = 25
const BIOME_COUNT: int = 26

const BIOME_NAMES: Array = [
    "Океан", "Глубокий океан", "Пляж", "Равнины", "Лес", "Берёзовый лес", "Тёмный лес",
    "Тайга", "Снежная тайга", "Секвойный лес", "Джунгли", "Болото", "Саванна", "Пустыня",
    "Бесплодные земли", "Горы", "Снежные вершины", "Цветущая долина", "Осенний лес",
    "Горная роща", "Лазурная роща", "Грибной лес", "Первобытный лес", "Река", "Пустошь",
    "Ледяные равнины"
]

# Плотность деревьев (шанс на ячейку 4x4) и состав видов по биомам.
const TREE_TABLE: Dictionary = {
    3: [0.035, [["oak", 0.75], ["birch", 0.25]]],
    4: [0.30, [["oak", 0.70], ["birch", 0.30]]],
    5: [0.28, [["birch", 0.70], ["aspen", 0.20], ["oak", 0.10]]],
    6: [0.42, [["dark_oak", 0.80], ["oak", 0.10], ["mushroom", 0.10]]],
    7: [0.24, [["spruce", 1.0]]],
    8: [0.12, [["spruce", 0.85], ["dead", 0.15]]],
    9: [0.30, [["sequoia", 0.26], ["spruce", 0.74]]],
    10: [0.48, [["jungle", 0.92], ["ancient", 0.04], ["mangrove", 0.04]]],
    11: [0.20, [["mangrove", 0.45], ["willow", 0.45], ["oak", 0.10]]],
    12: [0.055, [["acacia", 0.84], ["baobab", 0.16]]],
    13: [0.012, [["dead", 1.0]]],
    14: [0.025, [["dead", 0.6], ["acacia", 0.4]]],
    15: [0.05, [["spruce", 0.55], ["aspen", 0.45]]],
    17: [0.24, [["cherry", 1.0]]],
    18: [0.32, [["maple", 0.80], ["oak", 0.20]]],
    19: [0.32, [["aspen", 0.80], ["spruce", 0.20]]],
    20: [0.26, [["azure", 0.85], ["crystal", 0.15]]],
    21: [0.22, [["mushroom", 1.0]]],
    22: [0.34, [["ancient", 0.22], ["dark_oak", 0.38], ["spruce", 0.20], ["oak", 0.20]]],
    24: [0.07, [["dead", 1.0]]],
    25: [0.012, [["spruce", 0.5], ["dead", 0.5]]]
}
const BIG_TREES: Array = ["ancient", "baobab", "sequoia"]

var seed_value: int = 0
var n_cont: FastNoiseLite
var n_ero: FastNoiseLite
var n_ridge: FastNoiseLite
var n_detail: FastNoiseLite
var n_river: FastNoiseLite
var n_temp: FastNoiseLite
var n_hum: FastNoiseLite
var n_sub: FastNoiseLite
var n_special: FastNoiseLite
var n_entr: FastNoiseLite
var n_cave_a: FastNoiseLite
var n_cave_b: FastNoiseLite
var n_cheese: FastNoiseLite
var n_rock_a: FastNoiseLite
var n_rock_b: FastNoiseLite

# Результат последнего вызова _terrain()
var t_h: int = 64
var t_c: float = 0.0
var t_mount: float = 0.0
var t_river: float = 0.0

# Рабочие данные текущего чанка
var _blocks: PackedByteArray
var _ox: int = 0
var _oz: int = 0
var _max_y: int = MIN_Y
var _trng := RandomNumberGenerator.new()
var _rng := RandomNumberGenerator.new()

var id_stone: int
var id_deep: int
var id_snow: int
var id_packed_snow: int
var id_podzol: int
var id_mud: int
var id_sandstone: int
var id_red_sand: int
var id_red_clay: int
var id_claystone: int
var id_packed_soil: int
var id_clay_stone: int
var id_silt: int
var id_granite: int
var id_diorite: int
var id_andesite: int
var id_slate: int
var id_tuff: int
var id_gneiss: int
var id_planks: int
var id_log: int
var id_torch: int

var rock_like: PackedByteArray
var render_of: PackedByteArray
var surf_top: PackedInt32Array
var surf_fill: PackedInt32Array
var surf_fill_d: PackedInt32Array
var surf_sub: PackedInt32Array
var surf_sub_d: PackedInt32Array
var ore_defs: Array = []
var pocket_defs: Array = []
var tree_ids: Dictionary = {}
var region_cache: Dictionary = {}

func _init(p_seed: int = 0) -> void:
    B.setup()
    seed_value = absi(p_seed) % 2000000000
    n_cont = _make_noise(11, 0.0016, 4, FastNoiseLite.TYPE_SIMPLEX_SMOOTH)
    n_ero = _make_noise(23, 0.0028, 3, FastNoiseLite.TYPE_SIMPLEX_SMOOTH)
    n_ridge = _make_noise(37, 0.0042, 3, FastNoiseLite.TYPE_SIMPLEX_SMOOTH)
    n_detail = _make_noise(41, 0.022, 3, FastNoiseLite.TYPE_SIMPLEX_SMOOTH)
    n_river = _make_noise(53, 0.0030, 2, FastNoiseLite.TYPE_SIMPLEX_SMOOTH)
    n_temp = _make_noise(61, 0.0013, 2, FastNoiseLite.TYPE_SIMPLEX_SMOOTH)
    n_hum = _make_noise(67, 0.0015, 2, FastNoiseLite.TYPE_SIMPLEX_SMOOTH)
    n_sub = _make_noise(71, 0.0040, 2, FastNoiseLite.TYPE_SIMPLEX_SMOOTH)
    n_special = _make_noise(73, 0.0024, 2, FastNoiseLite.TYPE_SIMPLEX_SMOOTH)
    n_entr = _make_noise(79, 0.025, 2, FastNoiseLite.TYPE_SIMPLEX_SMOOTH)
    n_cave_a = _make_noise(83, 0.021, 2, FastNoiseLite.TYPE_SIMPLEX)
    n_cave_b = _make_noise(89, 0.023, 2, FastNoiseLite.TYPE_SIMPLEX)
    n_cheese = _make_noise(97, 0.0075, 2, FastNoiseLite.TYPE_SIMPLEX)
    n_rock_a = _make_noise(101, 0.012, 2, FastNoiseLite.TYPE_SIMPLEX)
    n_rock_b = _make_noise(103, 0.016, 2, FastNoiseLite.TYPE_SIMPLEX)

    id_stone = B.STONE
    id_deep = B.id_of("deep_stone")
    id_snow = B.id_of("snow")
    id_packed_snow = B.id_of("packed_snow")
    id_podzol = B.id_of("podzol")
    id_mud = B.id_of("mud")
    id_sandstone = B.id_of("sandstone")
    id_red_sand = B.id_of("red_sand")
    id_red_clay = B.id_of("red_clay")
    id_claystone = B.id_of("claystone")
    id_packed_soil = B.id_of("packed_soil")
    id_clay_stone = B.id_of("clay_with_stone")
    id_silt = B.id_of("silt")
    id_granite = B.id_of("granite")
    id_diorite = B.id_of("diorite")
    id_andesite = B.id_of("andesite")
    id_slate = B.id_of("slate")
    id_tuff = B.id_of("tuff")
    id_gneiss = B.id_of("gneiss")
    id_planks = B.id_of("oak_planks")
    id_log = B.id_of("oak_log")
    id_torch = B.id_of("torch")
    render_of = B.render

    rock_like = PackedByteArray()
    rock_like.resize(256)
    for rock_id in [id_stone, id_deep, id_granite, id_diorite, id_andesite, id_slate, id_tuff, id_gneiss]:
        rock_like[rock_id] = 1

    _build_surface_table()
    _build_ore_tables()

func _make_noise(offset: int, freq: float, octaves: int, noise_type: int) -> FastNoiseLite:
    var n := FastNoiseLite.new()
    n.seed = seed_value + offset
    n.noise_type = noise_type
    n.frequency = freq
    n.fractal_type = FastNoiseLite.FRACTAL_FBM
    n.fractal_octaves = octaves
    n.fractal_gain = 0.5
    return n

func _build_surface_table() -> void:
    surf_top = PackedInt32Array()
    surf_fill = PackedInt32Array()
    surf_fill_d = PackedInt32Array()
    surf_sub = PackedInt32Array()
    surf_sub_d = PackedInt32Array()
    for i in range(BIOME_COUNT):
        surf_top.append(B.GRASS)
        surf_fill.append(B.DIRT)
        surf_fill_d.append(3)
        surf_sub.append(0)
        surf_sub_d.append(0)
    _surf(BIOME_OCEAN, B.SAND, B.SAND, 3, 0, 0)
    _surf(BIOME_DEEP_OCEAN, B.GRAVEL, B.GRAVEL, 3, 0, 0)
    _surf(BIOME_BEACH, B.SAND, B.SAND, 3, id_sandstone, 5)
    _surf(BIOME_SNOWY_TAIGA, id_snow, B.DIRT, 3, 0, 0)
    _surf(BIOME_ICE_PLAINS, id_snow, B.DIRT, 3, 0, 0)
    _surf(BIOME_SNOWY_PEAKS, id_snow, id_packed_snow, 2, 0, 0)
    _surf(BIOME_DESERT, B.SAND, B.SAND, 4, id_sandstone, 8)
    _surf(BIOME_BADLANDS, id_red_sand, id_red_clay, 3, id_claystone, 6)
    _surf(BIOME_RIVER, B.SAND, B.SAND, 2, 0, 0)
    _surf(BIOME_WASTELAND, id_packed_soil, id_clay_stone, 3, 0, 0)

func _surf(biome: int, top: int, fill: int, fill_d: int, sub: int, sub_d: int) -> void:
    surf_top[biome] = top
    surf_fill[biome] = fill
    surf_fill_d[biome] = fill_d
    surf_sub[biome] = sub
    surf_sub_d[biome] = sub_d

# [id, попыток на чанк, ymin, ymax, размер, требование биома(0 нет, 1 горы, 2 снег)]
func _ore(block_name: String, tries: int, ymin: int, ymax: int, size: int, req: int = 0) -> void:
    var block_id: int = B.id_of(block_name)
    if block_id > 0:
        ore_defs.append([block_id, tries, ymin, ymax, size, req])

func _pocket(block_name: String, tries: int, ymin: int, ymax: int, size: int) -> void:
    var block_id: int = B.id_of(block_name)
    if block_id > 0:
        pocket_defs.append([block_id, tries, ymin, ymax, size, 0])

func _build_ore_tables() -> void:
    ore_defs.clear()
    pocket_defs.clear()
    _ore("coal_ore", 16, 0, 200, 10)
    _ore("deep_coal_ore", 8, -64, -1, 10)
    _ore("iron_ore", 12, -8, 110, 8)
    _ore("deep_iron_ore", 10, -64, -9, 8)
    _ore("copper_ore", 9, -16, 112, 8)
    _ore("deep_copper_ore", 6, -64, -17, 8)
    _ore("gold_ore", 3, -8, 30, 6)
    _ore("deep_gold_ore", 4, -64, -9, 6)
    _ore("lapis_ore", 2, -40, 60, 5)
    _ore("redstone_ore", 6, -64, 16, 6)
    _ore("diamond_ore", 3, -64, 16, 4)
    _ore("hematite_ore", 5, -32, 96, 6)
    _ore("cassiterite_ore", 5, -32, 48, 6)
    _ore("pentlandite_ore", 3, -48, 16, 5)
    _ore("garnierite_ore", 3, -32, 32, 5)
    _ore("sphalerite_ore", 4, -48, 32, 5)
    _ore("titan_ore", 2, -56, -16, 4)
    _ore("uranium_ore", 1, -30, -8, 3)
    _ore("deep_uranium_ore", 2, -64, -31, 3)
    _ore("quartz_ore", 5, -20, 120, 6)
    _ore("flint_ore", 6, 20, 120, 6)
    _ore("emerald_ore", 4, 90, 200, 2, 1)
    _ore("ruby_ore", 2, -64, 0, 4)
    _ore("sapphire_ore", 2, -64, 0, 4)
    _ore("amethyst_ore", 3, -30, 50, 5)
    _ore("mixed_ore", 4, -64, 90, 7)
    _ore("silver_ore", 3, -50, 40, 5)
    _ore("tin_ore", 5, -30, 60, 6)
    _ore("nickel_ore", 3, -50, 10, 5)
    _ore("cobalt_ore", 2, -60, -10, 4)
    _ore("titanium_ore", 2, -60, -20, 4)
    _ore("echorite_ore", 1, -60, -30, 3)
    _ore("astralite_ore", 1, -60, -25, 3)
    _ore("void_ore", 1, -64, -50, 3)
    _ore("livingstone", 1, -20, 40, 5)
    _ore("shadow_ore", 1, -64, -40, 3)
    _ore("chronosteel_ore", 1, -64, -55, 2)
    _ore("blue_ice_ore", 5, 80, 220, 9, 2)
    _pocket("dirt", 7, -10, 150, 28)
    _pocket("gravel", 7, -64, 140, 22)
    _pocket("clay_with_stone", 3, 0, 70, 18)
    _pocket("basalt", 4, -64, -20, 22)
    _pocket("obsidian", 1, -64, -50, 8)
    _pocket("marble", 3, 10, 90, 22)
    _pocket("limestone_rock", 3, 0, 80, 20)
    _pocket("pale_rock", 3, -20, 60, 18)
    _pocket("gypsum", 2, 0, 60, 14)
    _pocket("salt_block", 1, -10, 30, 12)
    _pocket("dripstone", 3, -40, 30, 14)
    _pocket("stalactite_rock", 2, -50, 20, 12)
    _pocket("glowstone_rock", 2, -64, 0, 6)
    _pocket("lava_rock", 2, -64, -40, 12)
    _pocket("mossy_stone", 1, -10, 40, 8)
    _pocket("deep_rock", 3, -64, -20, 20)

# ------------------------------------------------------------------ utilities

static func mix(a: int, b: int, c: int, salt: int) -> int:
    var h: int = a * 374761393 + b * 668265263 + c * 2147483629 + salt * 1274126177
    h = (h ^ (h >> 13)) * 1274126177
    h = h ^ (h >> 16)
    return h & 0x7fffffff

static func floor_div(a: int, b: int) -> int:
    return int(floorf(float(a) / float(b)))

func rng_for(a: int, b: int, salt: int) -> RandomNumberGenerator:
    _rng.seed = mix(a, b, seed_value, salt)
    return _rng

# ------------------------------------------------------------------ terrain

func _terrain(x: int, z: int) -> void:
    var fx: float = float(x)
    var fz: float = float(z)
    var c: float = clampf(n_cont.get_noise_2d(fx, fz) * 1.5 + 0.18, -1.0, 1.0)
    var e: float = n_ero.get_noise_2d(fx, fz)
    var rough: float = clampf(0.55 - e * 0.9, 0.0, 1.0)
    var d: float = n_detail.get_noise_2d(fx, fz)
    var ridge: float = 1.0 - absf(n_ridge.get_noise_2d(fx, fz))
    var ch: float = 64.0 + c * 30.0
    if c < 0.0:
        ch = 64.0 + c * 52.0
    var mount_mask: float = smoothstep(0.10, 0.45, c) * smoothstep(0.30, 0.72, rough)
    var hills: float = d * (3.0 + 12.0 * rough)
    var mountain: float = pow(ridge, 2.2) * 125.0 * mount_mask
    var hv: float = ch + hills + mountain
    var river_f: float = 0.0
    var rv: float = absf(n_river.get_noise_2d(fx, fz))
    if c > -0.05 and rv < 0.035:
        river_f = 1.0 - rv / 0.035
        river_f = river_f * river_f * (3.0 - 2.0 * river_f)
        river_f *= 1.0 - smoothstep(0.35, 0.70, mount_mask)
        if hv > 59.0:
            hv = lerpf(hv, 59.0, river_f)
    t_c = c
    t_mount = mount_mask
    t_river = river_f
    t_h = clampi(roundi(hv), MIN_Y + 12, 285)

func _classify(x: int, z: int, h: int, c: float, mount: float, river: float) -> int:
    var fx: float = float(x)
    var fz: float = float(z)
    if river > 0.25 and h <= SEA_LEVEL + 1:
        return BIOME_RIVER
    if h < SEA_LEVEL:
        return BIOME_DEEP_OCEAN if h < 46 else BIOME_OCEAN
    var temp: float = clampf(n_temp.get_noise_2d(fx, fz) * 1.9, -1.0, 1.0) - maxf(0.0, float(h) - 90.0) * 0.006
    var hum: float = clampf(n_hum.get_noise_2d(fx + 5000.0, fz - 3000.0) * 1.9, -1.0, 1.0)
    var sub: float = n_sub.get_noise_2d(fx, fz) * 1.6
    if h <= SEA_LEVEL + 2 and mount < 0.2:
        if hum > 0.35 and temp > -0.1 and temp < 0.7:
            return BIOME_SWAMP
        return BIOME_BEACH
    if mount > 0.30 and h > 92:
        if h >= 150 or temp < -0.30:
            return BIOME_SNOWY_PEAKS
        if hum > 0.05 and h < 135:
            return BIOME_ASPEN
        return BIOME_MOUNTAINS
    var sp: float = n_special.get_noise_2d(fx + 9000.0, fz - 9000.0) * 1.6
    if sp > 0.62:
        return BIOME_AZURE
    if sp < -0.66:
        return BIOME_MUSHROOM
    if hum > 0.25 and temp > -0.2 and temp < 0.5 and sub > 0.85:
        return BIOME_ANCIENT
    if temp < -0.5:
        return BIOME_SNOWY_TAIGA if hum > 0.0 else BIOME_ICE_PLAINS
    if temp < -0.18:
        if hum > 0.35:
            return BIOME_SEQUOIA
        if hum > -0.15:
            return BIOME_TAIGA
        return BIOME_PLAINS
    if temp < 0.28:
        if hum < -0.35:
            return BIOME_WASTELAND if sub < -0.55 else BIOME_PLAINS
        if hum < 0.0:
            return BIOME_PLAINS if sub < 0.2 else BIOME_FOREST
        if hum < 0.4:
            if sub > 0.40:
                return BIOME_CHERRY
            if sub < -0.40:
                return BIOME_MAPLE
            if sub > 0.05:
                return BIOME_BIRCH_FOREST
            return BIOME_FOREST
        return BIOME_DARK_FOREST
    if temp < 0.55:
        if hum < -0.3:
            return BIOME_SAVANNA
        if hum < 0.25:
            return BIOME_FOREST if sub > 0.2 else BIOME_PLAINS
        if temp > 0.4:
            return BIOME_JUNGLE
        return BIOME_SWAMP if h <= 70 else BIOME_FOREST
    if hum < -0.3:
        return BIOME_BADLANDS if sub > 0.3 else BIOME_DESERT
    if hum < 0.1:
        return BIOME_SAVANNA
    return BIOME_JUNGLE

func _swamp_pond(wx: int, wz: int, h: int) -> bool:
    if h > SEA_LEVEL + 1 or h < SEA_LEVEL:
        return false
    return n_detail.get_noise_2d(float(wx) * 0.8 + 100.0, float(wz) * 0.8) > 0.15

# Публичные запросы для основного потока.
func height_at(x: int, z: int) -> int:
    _terrain(x, z)
    return t_h

func biome_at(x: int, z: int) -> int:
    _terrain(x, z)
    return _classify(x, z, t_h, t_c, t_mount, t_river)

func find_spawn(start_x: int = 0, start_z: int = 4) -> Vector3i:
    # Спираль вокруг точки: первая сухая суша вне океана и гор.
    for radius in range(0, 400, 4):
        for step in range(0, 16):
            var angle: float = float(step) / 16.0 * TAU
            var px: int = start_x + int(round(cos(angle) * float(radius)))
            var pz: int = start_z + int(round(sin(angle) * float(radius)))
            _terrain(px, pz)
            if t_h >= SEA_LEVEL + 2 and t_h <= 90 and t_river < 0.05:
                return Vector3i(px, t_h, pz)
    _terrain(start_x, start_z)
    return Vector3i(start_x, maxi(t_h, SEA_LEVEL + 1), start_z)

# ------------------------------------------------------------------ chunk

func generate_chunk(cx: int, cz: int) -> Dictionary:
    var ox: int = cx * CHUNK
    var oz: int = cz * CHUNK
    var blocks := PackedByteArray()
    blocks.resize(CHUNK * CHUNK * COL_H)
    _blocks = blocks
    _ox = ox
    _oz = oz

    # Карта высот с рамкой в 1 блок (для уклонов).
    var heights := PackedInt32Array()
    heights.resize(324)
    var conts := PackedFloat32Array()
    conts.resize(324)
    var mounts := PackedFloat32Array()
    mounts.resize(324)
    var rivers := PackedFloat32Array()
    rivers.resize(324)
    var max_h: int = MIN_Y
    for pz in range(18):
        for px in range(18):
            _terrain(ox + px - 1, oz + pz - 1)
            var pi: int = pz * 18 + px
            heights[pi] = t_h
            conts[pi] = t_c
            mounts[pi] = t_mount
            rivers[pi] = t_river
            if t_h > max_h:
                max_h = t_h
    _max_y = maxi(max_h, SEA_LEVEL)

    # Крупные породы и пещерные залы на сетке 2x2x2.
    var ncy: int = ((_max_y - MIN_Y) >> 1) + 2
    var rock := PackedByteArray()
    rock.resize(64 * ncy)
    var big := PackedByteArray()
    big.resize(64 * ncy)
    for cxl in range(8):
        for czl in range(8):
            var fwx: float = float(ox + cxl * 2)
            var fwz: float = float(oz + czl * 2)
            var cell_base: int = (cxl * 8 + czl) * ncy
            for cyl in range(ncy):
                var fy: float = float(MIN_Y + cyl * 2)
                var v1: float = n_rock_a.get_noise_3d(fwx, fy, fwz)
                var v2: float = n_rock_b.get_noise_3d(fwx + 311.0, fy - 97.0, fwz + 173.0)
                var r: int = id_stone
                if fy < -6.0 + v2 * 5.0:
                    r = id_deep
                    if v1 > 0.50:
                        r = id_slate
                    elif v1 < -0.52:
                        r = id_tuff
                    elif v2 > 0.55:
                        r = id_gneiss
                else:
                    if v1 > 0.52:
                        r = id_granite
                    elif v1 < -0.52:
                        r = id_diorite
                    elif v2 > 0.56:
                        r = id_andesite
                    elif fy < 36.0 and v2 < -0.62:
                        r = id_gneiss
                rock[cell_base + cyl] = r
                if fy > -54.0 and fy < 56.0:
                    if n_cheese.get_noise_3d(fwx, fy * 1.6, fwz) > 0.60:
                        big[cell_base + cyl] = 1

    var biome_col := PackedByteArray()
    biome_col.resize(256)
    var id_gravel: int = B.GRAVEL
    for lz in range(16):
        for lx in range(16):
            var wx: int = ox + lx
            var wz: int = oz + lz
            var hi: int = (lz + 1) * 18 + (lx + 1)
            var h: int = heights[hi]
            var biome: int = _classify(wx, wz, h, conts[hi], mounts[hi], rivers[hi])
            biome_col[lz * 16 + lx] = biome
            if biome == BIOME_SWAMP and _swamp_pond(wx, wz, h):
                h = SEA_LEVEL - 2
            var slope: int = maxi(maxi(absi(h - heights[hi + 1]), absi(h - heights[hi - 1])), maxi(absi(h - heights[hi + 18]), absi(h - heights[hi - 18])))
            var dn: float = n_detail.get_noise_2d(float(wx) * 0.8 + 100.0, float(wz) * 0.8)
            var rc_base: int = ((lx >> 1) * 8 + (lz >> 1)) * ncy

            var top_id: int = surf_top[biome]
            var fill_id: int = surf_fill[biome]
            var fill_d: int = surf_fill_d[biome]
            var sub_id: int = surf_sub[biome]
            var sub_d: int = surf_sub_d[biome]
            var surface_rock: int = rock[rc_base + ((h - MIN_Y) >> 1)]
            match biome:
                BIOME_OCEAN:
                    if dn > 0.30:
                        top_id = id_gravel
                        fill_id = id_gravel
                    elif dn < -0.40:
                        top_id = id_silt
                        fill_id = B.SAND
                BIOME_DEEP_OCEAN:
                    if dn < -0.25:
                        top_id = id_silt
                BIOME_RIVER:
                    if dn > 0.1:
                        top_id = id_gravel
                        fill_id = id_gravel
                BIOME_MOUNTAINS:
                    if slope >= 3:
                        top_id = surface_rock
                        fill_id = surface_rock
                    elif dn > 0.35:
                        top_id = id_gravel
                        fill_id = id_gravel
                BIOME_ASPEN:
                    if slope >= 4:
                        top_id = surface_rock
                        fill_id = surface_rock
                BIOME_SNOWY_PEAKS:
                    if slope >= 4:
                        top_id = surface_rock
                        fill_id = surface_rock
                        fill_d = 3
                BIOME_SWAMP:
                    if h <= SEA_LEVEL + 1:
                        top_id = id_mud
                        fill_id = id_mud
                        fill_d = 2
                BIOME_TAIGA, BIOME_SEQUOIA, BIOME_ANCIENT, BIOME_DARK_FOREST:
                    if dn > 0.05:
                        top_id = id_podzol
                BIOME_MUSHROOM:
                    top_id = id_podzol
                BIOME_WASTELAND:
                    if dn > 0.3:
                        top_id = id_gravel
            var entrance: bool = false
            if h > SEA_LEVEL + 3 and biome != BIOME_BEACH and n_entr.get_noise_2d(float(wx), float(wz)) > ENTRANCE_T:
                entrance = true
            var carve_top: int = h - 4
            if h < SEA_LEVEL:
                carve_top = h - 9
            elif entrance:
                carve_top = h
            var col_base: int = (lz * 16 + lx) * COL_H
            var fwx2: float = float(wx)
            var fwz2: float = float(wz)
            for y in range(MIN_Y, h + 1):
                var idx: int = col_base + (y - MIN_Y)
                if y <= MIN_Y + 4:
                    if y == MIN_Y or (mix(wx, y, wz, 991) % 100) < (MIN_Y + 5 - y) * 20:
                        blocks[idx] = B.BEDROCK
                        continue
                var depth: int = h - y
                if depth == 0:
                    blocks[idx] = top_id
                    continue
                if depth <= fill_d:
                    blocks[idx] = fill_id
                    continue
                if sub_d > 0 and depth <= fill_d + sub_d:
                    blocks[idx] = sub_id
                    continue
                var cell: int = rc_base + ((y - MIN_Y) >> 1)
                if y <= carve_top and y > MIN_Y + 5:
                    if big[cell] == 1:
                        continue
                    var fy2: float = float(y)
                    var na: float = n_cave_a.get_noise_3d(fwx2, fy2, fwz2)
                    if absf(na) < 0.075:
                        var nb: float = n_cave_b.get_noise_3d(fwx2 + 173.0, fy2 - 61.0, fwz2 + 329.0)
                        if absf(nb) < 0.085:
                            continue
                blocks[idx] = rock[cell]
            if h < SEA_LEVEL:
                for wy in range(h + 1, SEA_LEVEL + 1):
                    blocks[col_base + (wy - MIN_Y)] = B.WATER

    _place_ores(cx, cz, biome_col)
    _place_mineshafts(cx, cz)
    _place_crystal_caves(cx, cz, biome_col)
    _place_trees(cx, cz)
    _place_plants(cx, cz, biome_col, heights)

    # Карта верхних светонепроницаемых блоков для небесного света.
    var top := PackedInt32Array()
    top.resize(256)
    var blocks_sky: PackedByteArray = B.blocks_sky
    var scan_from: int = mini(_max_y + 1, MAX_Y - 1)
    for col in range(256):
        var base: int = col * COL_H
        var y2: int = scan_from
        while y2 > MIN_Y:
            if blocks_sky[blocks[base + (y2 - MIN_Y)]] == 1:
                break
            y2 -= 1
        top[col] = y2
    return {"blocks": blocks, "tops": top, "biomes": biome_col, "max_y": mini(_max_y + 2, MAX_Y - 1)}

# ------------------------------------------------------------------ ores

func _place_ores(cx: int, cz: int, biome_col: PackedByteArray) -> void:
    var rng := rng_for(cx, cz, 5501)
    for pocket_variant in pocket_defs:
        var pdef: Array = pocket_variant
        _run_vein_def(pdef, rng, biome_col)
    for ore_variant in ore_defs:
        var odef: Array = ore_variant
        _run_vein_def(odef, rng, biome_col)

func _run_vein_def(def: Array, rng: RandomNumberGenerator, biome_col: PackedByteArray) -> void:
    var block_id: int = int(def[0])
    var tries: int = int(def[1])
    var ymin: int = int(def[2])
    var ymax: int = int(def[3])
    var size: int = int(def[4])
    var req: int = int(def[5])
    for t in range(tries):
        var lx: int = rng.randi_range(2, 13)
        var lz: int = rng.randi_range(2, 13)
        var y: int = rng.randi_range(ymin, ymax)
        var skip_roll: float = rng.randf()
        if req != 0:
            var biome: int = biome_col[lz * 16 + lx]
            if req == 1 and not (biome == BIOME_MOUNTAINS or biome == BIOME_SNOWY_PEAKS or biome == BIOME_ASPEN):
                continue
            if req == 2 and not (biome == BIOME_SNOWY_PEAKS or biome == BIOME_SNOWY_TAIGA or biome == BIOME_ICE_PLAINS):
                continue
        if skip_roll > 0.92 and size <= 4:
            continue
        var vein_size: int = maxi(1, size + rng.randi_range(-size / 3, size / 3))
        for step in range(vein_size):
            if lx >= 0 and lx < 16 and lz >= 0 and lz < 16 and y > MIN_Y + 4 and y < MAX_Y:
                var idx: int = (lz * 16 + lx) * COL_H + (y - MIN_Y)
                if rock_like[_blocks[idx]] == 1:
                    _blocks[idx] = block_id
            lx += rng.randi_range(-1, 1)
            y += rng.randi_range(-1, 1)
            lz += rng.randi_range(-1, 1)

# ------------------------------------------------------------------ mineshafts

func _region_segments(rx: int, rz: int) -> Array:
    var key := Vector2i(rx, rz)
    if region_cache.has(key):
        return region_cache[key]
    var segments: Array = []
    var rng := rng_for(rx, rz, 7001)
    if rng.randf() < 0.42:
        var span: int = REGION_CHUNKS * CHUNK
        var rox: int = rx * span
        var roz: int = rz * span
        var level: int = rng.randi_range(-44, 24)
        var main_axis: int = rng.randi_range(0, 1)
        var length: int = rng.randi_range(44, 78)
        var cx0: int = rox + rng.randi_range(24, span - 24)
        var cz0: int = roz + rng.randi_range(24, span - 24)
        var start_a: int = (cx0 if main_axis == 0 else cz0) - length / 2
        var fixed: int = cz0 if main_axis == 0 else cx0
        segments.append([main_axis, start_a, fixed, level, length])
        var pos: int = rng.randi_range(8, 14)
        while pos < length - 8:
            if rng.randf() < 0.65:
                var branch_len: int = rng.randi_range(14, 34)
                var side: int = -1 if rng.randf() < 0.5 else 1
                var branch_axis: int = 1 - main_axis
                var b_start: int = (fixed - branch_len) if side < 0 else fixed
                segments.append([branch_axis, b_start, start_a + pos, level, branch_len])
                if rng.randf() < 0.35:
                    var b2_start: int = fixed if side < 0 else (fixed - branch_len)
                    segments.append([branch_axis, b2_start, start_a + pos, level, branch_len])
            pos += rng.randi_range(9, 16)
    region_cache[key] = segments
    return segments

func _place_mineshafts(cx: int, cz: int) -> void:
    var rx: int = floor_div(cx, REGION_CHUNKS)
    var rz: int = floor_div(cz, REGION_CHUNKS)
    var segments: Array = _region_segments(rx, rz)
    if segments.is_empty():
        return
    var min_x: int = _ox
    var max_x: int = _ox + 15
    var min_z: int = _oz
    var max_z: int = _oz + 15
    for seg_variant in segments:
        var seg: Array = seg_variant
        var axis: int = int(seg[0])
        var a0: int = int(seg[1])
        var fixed: int = int(seg[2])
        var level: int = int(seg[3])
        var length: int = int(seg[4])
        # сегмент как прямоугольник в плоскости XZ (ширина 3)
        var sx0: int = a0 if axis == 0 else fixed - 1
        var sx1: int = a0 + length if axis == 0 else fixed + 1
        var sz0: int = fixed - 1 if axis == 0 else a0
        var sz1: int = fixed + 1 if axis == 0 else a0 + length
        if sx1 < min_x or sx0 > max_x or sz1 < min_z or sz0 > max_z:
            continue
        for wx in range(maxi(sx0, min_x), mini(sx1, max_x) + 1):
            for wz in range(maxi(sz0, min_z), mini(sz1, max_z) + 1):
                var along: int = (wx - a0) if axis == 0 else (wz - a0)
                var across: int = (wz - fixed) if axis == 0 else (wx - fixed)
                var col_base: int = ((wz - _oz) * 16 + (wx - _ox)) * COL_H
                var is_support: bool = along % 4 == 0
                for dy in range(0, 3):
                    var y: int = level + dy
                    var idx: int = col_base + (y - MIN_Y)
                    var existing: int = _blocks[idx]
                    if existing == B.BEDROCK:
                        continue
                    var put: int = 0
                    if is_support:
                        if absi(across) == 1 and dy <= 1:
                            put = id_log
                        elif dy == 2:
                            put = id_planks
                    if put != 0:
                        _blocks[idx] = put
                    else:
                        _blocks[idx] = 0
                # пол: местами доски
                var floor_idx: int = col_base + (level - 1 - MIN_Y)
                if _blocks[floor_idx] == 0 or _blocks[floor_idx] == B.WATER:
                    _blocks[floor_idx] = id_planks
                elif along % 7 == 3 and absi(across) <= 1 and mix(wx, level, wz, 311) % 5 == 0:
                    _blocks[floor_idx] = id_planks
                if absi(across) == 0 and along % 8 == 2 and id_torch > 0:
                    var t_idx: int = col_base + (level - MIN_Y)
                    if _blocks[t_idx] == 0:
                        _blocks[t_idx] = id_torch

# ------------------------------------------------------------------ crystal caves

func _place_crystal_caves(cx: int, cz: int, biome_col: PackedByteArray) -> void:
    var rng := rng_for(cx, cz, 8101)
    var crystal_log: int = B.id_of("crystal_log")
    var crystal_leaves: int = B.id_of("crystal_leaves")
    if crystal_log < 0 or crystal_leaves < 0:
        return
    for attempt in range(6):
        var lx: int = rng.randi_range(3, 12)
        var lz: int = rng.randi_range(3, 12)
        var roll: float = rng.randf()
        if roll > 0.7:
            continue
        var biome: int = biome_col[lz * 16 + lx]
        if biome == BIOME_OCEAN or biome == BIOME_DEEP_OCEAN:
            continue
        var col_base: int = (lz * 16 + lx) * COL_H
        var y: int = 44
        while y > MIN_Y + 8:
            var below: int = _blocks[col_base + (y - 1 - MIN_Y)]
            if rock_like[below] == 1 and _blocks[col_base + (y - MIN_Y)] == 0:
                var clear: bool = true
                for k in range(0, 8):
                    if _blocks[col_base + (y + k - MIN_Y)] != 0:
                        clear = false
                        break
                if clear:
                    _trng.seed = mix(cx * 16 + lx, cz * 16 + lz, seed_value, 8123)
                    _tree_crystal(_ox + lx, y, _oz + lz, crystal_log, crystal_leaves)
                break
            y -= 1

# ------------------------------------------------------------------ plants

func _place_plants(cx: int, cz: int, biome_col: PackedByteArray, heights: PackedInt32Array) -> void:
    var rng := rng_for(cx, cz, 9101)
    for attempt in range(5):
        var lx: int = rng.randi_range(0, 15)
        var lz: int = rng.randi_range(0, 15)
        var roll: float = rng.randf()
        var pick: float = rng.randf()
        if roll > 0.55:
            continue
        var biome: int = biome_col[lz * 16 + lx]
        if not TREE_TABLE.has(biome):
            continue
        var h: int = heights[(lz + 1) * 18 + (lx + 1)]
        if h <= SEA_LEVEL or h + 1 >= MAX_Y:
            continue
        var col_base: int = (lz * 16 + lx) * COL_H
        var ground: int = _blocks[col_base + (h - MIN_Y)]
        if ground != B.GRASS and ground != id_podzol:
            continue
        if _blocks[col_base + (h + 1 - MIN_Y)] != 0:
            continue
        var species: String = _pick_species(biome, pick)
        var sapling: int = B.id_of(species + "_sapling")
        if sapling > 0:
            _blocks[col_base + (h + 1 - MIN_Y)] = sapling

func _pick_species(biome: int, pick: float) -> String:
    var entry: Array = TREE_TABLE[biome]
    var list: Array = entry[1]
    var acc: float = 0.0
    for item_variant in list:
        var item: Array = item_variant
        acc += float(item[1])
        if pick <= acc:
            return str(item[0])
    var last: Array = list[list.size() - 1]
    return str(last[0])

# ------------------------------------------------------------------ trees

func _species_ids(species: String) -> PackedInt32Array:
    if tree_ids.has(species):
        return tree_ids[species]
    var ids := PackedInt32Array()
    ids.append(B.id_of(species + "_log"))
    ids.append(B.id_of(species + "_leaves"))
    ids.append(B.id_of(species + "_roots"))
    tree_ids[species] = ids
    return ids

func _place_trees(cx: int, cz: int) -> void:
    var rng := RandomNumberGenerator.new()
    var min_x: int = _ox - 12
    var max_x: int = _ox + 27
    var min_z: int = _oz - 12
    var max_z: int = _oz + 27
    for ncz in range(cz - 1, cz + 2):
        for ncx in range(cx - 1, cx + 2):
            rng.seed = mix(ncx, ncz, seed_value, 6001)
            for cell in range(16):
                var cell_x: int = cell % 4
                var cell_z: int = cell / 4
                var jx: int = rng.randi_range(0, 3)
                var jz: int = rng.randi_range(0, 3)
                var roll: float = rng.randf()
                var pick: float = rng.randf()
                var tree_seed: int = rng.randi()
                var wx: int = ncx * 16 + cell_x * 4 + jx
                var wz: int = ncz * 16 + cell_z * 4 + jz
                if wx < min_x or wx > max_x or wz < min_z or wz > max_z:
                    continue
                _terrain(wx, wz)
                var h: int = t_h
                var biome: int = _classify(wx, wz, h, t_c, t_mount, t_river)
                if not TREE_TABLE.has(biome):
                    continue
                var entry: Array = TREE_TABLE[biome]
                if roll > float(entry[0]):
                    continue
                if biome == BIOME_SWAMP and _swamp_pond(wx, wz, h):
                    h = SEA_LEVEL - 2
                var species: String = _pick_species(biome, pick)
                var wet_ok: bool = species == "mangrove" or species == "willow"
                if h <= SEA_LEVEL and not (wet_ok and h >= SEA_LEVEL - 3):
                    continue
                if BIG_TREES.has(species) and (cell_x + cell_z) % 2 == 1:
                    continue
                if biome == BIOME_MOUNTAINS and h > 125:
                    continue
                if n_entr.get_noise_2d(float(wx), float(wz)) > ENTRANCE_T and h > SEA_LEVEL + 3:
                    continue
                _trng.seed = tree_seed
                var ids: PackedInt32Array = _species_ids(species)
                _grow_tree(species, wx, h + 1, wz, ids[0], ids[1], ids[2])

func _grow_tree(species: String, x: int, y0: int, z: int, lg: int, lf: int, rt: int) -> void:
    match species:
        "oak": _tree_oak(x, y0, z, lg, lf)
        "birch": _tree_birch(x, y0, z, lg, lf)
        "spruce": _tree_spruce(x, y0, z, lg, lf)
        "jungle": _tree_jungle(x, y0, z, lg, lf)
        "acacia": _tree_acacia(x, y0, z, lg, lf)
        "dark_oak": _tree_dark_oak(x, y0, z, lg, lf)
        "cherry": _tree_cherry(x, y0, z, lg, lf)
        "mangrove": _tree_mangrove(x, y0, z, lg, lf, rt)
        "ancient": _tree_ancient(x, y0, z, lg, lf, rt)
        "maple": _tree_maple(x, y0, z, lg, lf)
        "aspen": _tree_aspen(x, y0, z, lg, lf)
        "willow": _tree_willow(x, y0, z, lg, lf)
        "baobab": _tree_baobab(x, y0, z, lg, lf, rt)
        "sequoia": _tree_sequoia(x, y0, z, lg, lf)
        "azure": _tree_azure(x, y0, z, lg, lf)
        "crystal": _tree_crystal(x, y0, z, lg, lf)
        "dead": _tree_dead(x, y0, z, lg, lf, rt)
        "mushroom": _tree_mushroom(x, y0, z, lg, lf)
        _: _tree_oak(x, y0, z, lg, lf)

# Запись блока дерева в текущий чанк (с отсечением по границам).
func _put_log(x: int, y: int, z: int, block_id: int) -> void:
    var lx: int = x - _ox
    var lz: int = z - _oz
    if lx < 0 or lx > 15 or lz < 0 or lz > 15 or y < MIN_Y or y >= MAX_Y:
        return
    var idx: int = (lz * 16 + lx) * COL_H + (y - MIN_Y)
    var cur: int = _blocks[idx]
    var kind: int = render_of[cur]
    if cur == 0 or kind == B.R_LEAVES or kind == B.R_WATER or kind == B.R_CROSS:
        _blocks[idx] = block_id
        if y > _max_y:
            _max_y = y

func _put_leaf(x: int, y: int, z: int, block_id: int) -> void:
    var lx: int = x - _ox
    var lz: int = z - _oz
    if lx < 0 or lx > 15 or lz < 0 or lz > 15 or y < MIN_Y or y >= MAX_Y:
        return
    var idx: int = (lz * 16 + lx) * COL_H + (y - MIN_Y)
    var cur: int = _blocks[idx]
    if cur == 0 or render_of[cur] == B.R_CROSS:
        _blocks[idx] = block_id
        if y > _max_y:
            _max_y = y

func _column(x: int, y: int, z: int, height: int, block_id: int) -> void:
    for i in range(height):
        _put_log(x, y + i, z, block_id)

func _trunk2(x: int, y: int, z: int, height: int, block_id: int) -> void:
    for i in range(height):
        _put_log(x, y + i, z, block_id)
        _put_log(x + 1, y + i, z, block_id)
        _put_log(x, y + i, z + 1, block_id)
        _put_log(x + 1, y + i, z + 1, block_id)

func _trunk3(x: int, y: int, z: int, height: int, block_id: int) -> void:
    for i in range(height):
        for dx in range(-1, 2):
            for dz in range(-1, 2):
                _put_log(x + dx, y + i, z + dz, block_id)

func _blob(cx: int, cy: int, cz: int, rx: float, ry: float, rz: float, block_id: int, jitter: float = 0.3) -> void:
    var ix: int = int(ceil(rx))
    var iy: int = int(ceil(ry))
    var iz: int = int(ceil(rz))
    for dx in range(-ix, ix + 1):
        for dy in range(-iy, iy + 1):
            for dz in range(-iz, iz + 1):
                var d: float = (float(dx) / rx) * (float(dx) / rx) + (float(dy) / ry) * (float(dy) / ry) + (float(dz) / rz) * (float(dz) / rz)
                if d <= 1.0 + (_trng.randf() - 0.5) * jitter:
                    _put_leaf(cx + dx, cy + dy, cz + dz, block_id)

func _disk(cx: int, cy: int, cz: int, r: int, block_id: int, trim: float = 0.5) -> void:
    for dx in range(-r, r + 1):
        for dz in range(-r, r + 1):
            if float(dx * dx + dz * dz) <= float(r * r) + trim:
                _put_leaf(cx + dx, cy, cz + dz, block_id)

func _ring(cx: int, cy: int, cz: int, r_in: float, r_out: float, block_id: int) -> void:
    var ir: int = int(ceil(r_out))
    for dx in range(-ir, ir + 1):
        for dz in range(-ir, ir + 1):
            var d: float = sqrt(float(dx * dx + dz * dz))
            if d >= r_in and d <= r_out:
                _put_leaf(cx + dx, cy, cz + dz, block_id)

func _line_logs(x0: int, y0: int, z0: int, x1: int, y1: int, z1: int, block_id: int) -> void:
    var steps: int = maxi(maxi(absi(x1 - x0), absi(y1 - y0)), absi(z1 - z0))
    if steps == 0:
        _put_log(x0, y0, z0, block_id)
        return
    for i in range(steps + 1):
        var t: float = float(i) / float(steps)
        _put_log(roundi(lerpf(float(x0), float(x1), t)), roundi(lerpf(float(y0), float(y1), t)), roundi(lerpf(float(z0), float(z1), t)), block_id)

func _tree_oak(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    if _trng.randf() < 0.18:
        var h: int = _trng.randi_range(8, 12)
        _column(x, y0, z, h, lg)
        _blob(x, y0 + h, z, 3.6, 3.0, 3.6, lf)
        for k in range(3):
            var ang: float = _trng.randf() * TAU
            var bx: int = x + roundi(cos(ang) * 3.0)
            var bz: int = z + roundi(sin(ang) * 3.0)
            var by: int = y0 + h - 4 - k
            _line_logs(x, by, z, bx, by + 2, bz, lg)
            _blob(bx, by + 2, bz, 2.6, 2.2, 2.6, lf)
    else:
        var h2: int = _trng.randi_range(4, 6)
        _column(x, y0, z, h2, lg)
        _blob(x, y0 + h2 - 1, z, 2.7, 2.4, 2.7, lf)
        _put_leaf(x, y0 + h2 + 1, z, lf)

func _tree_birch(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(5, 8)
    _column(x, y0, z, h, lg)
    _blob(x, y0 + h - 1, z, 2.2, 2.4, 2.2, lf)
    _put_leaf(x, y0 + h + 1, z, lf)

func _tree_spruce(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(7, 14)
    _column(x, y0, z, h, lg)
    var max_r: int = clampi(h / 3, 2, 4)
    var layers: int = h - 2
    for k in range(layers + 2):
        var yy: int = y0 + h + 1 - k
        var r: int = (k * max_r) / maxi(1, layers)
        if k % 2 == 1:
            r = maxi(0, r - 1)
        if k == 0:
            r = 0
        _disk(x, yy, z, r, lf, 0.4)
    _put_leaf(x, y0 + h + 1, z, lf)

func _tree_jungle(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    if _trng.randf() < 0.14:
        var gh: int = _trng.randi_range(18, 26)
        _trunk2(x, y0, z, gh, lg)
        var top: int = y0 + gh
        _blob(x, top, z, 5.0, 2.4, 5.0, lf)
        _blob(x, top + 2, z, 3.2, 1.8, 3.2, lf)
        for k in range(4):
            var ang: float = float(k) * TAU / 4.0 + _trng.randf()
            var bx: int = x + roundi(cos(ang) * 3.0)
            var bz: int = z + roundi(sin(ang) * 3.0)
            _line_logs(x, top - 5 - k * 2, z, bx, top - 4 - k * 2, bz, lg)
            _blob(bx, top - 4 - k * 2, bz, 2.4, 1.6, 2.4, lf)
    else:
        var h: int = _trng.randi_range(9, 16)
        _column(x, y0, z, h, lg)
        _blob(x, y0 + h, z, 3.4, 1.9, 3.4, lf)
        _blob(x, y0 + h + 1, z, 2.0, 1.2, 2.0, lf)
        for k in range(2):
            var ang2: float = _trng.randf() * TAU
            var bx2: int = x + roundi(cos(ang2) * 2.0)
            var bz2: int = z + roundi(sin(ang2) * 2.0)
            var by: int = y0 + h - 3 - k * 2
            _put_log(bx2, by, bz2, lg)
            _blob(bx2, by + 1, bz2, 1.9, 1.3, 1.9, lf)

func _tree_acacia(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h1: int = _trng.randi_range(3, 4)
    _column(x, y0, z, h1, lg)
    var dirs: Array = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
    var d1: Vector2i = dirs[_trng.randi_range(0, 3)]
    var cx: int = x
    var cz: int = z
    var cy: int = y0 + h1
    var steps: int = _trng.randi_range(2, 3)
    for i in range(steps):
        cx += d1.x
        cz += d1.y
        _put_log(cx, cy, cz, lg)
        cy += 1
        _put_log(cx, cy, cz, lg)
    _disk(cx, cy + 1, cz, 3, lf, 0.8)
    _disk(cx, cy, cz, 2, lf, 0.3)
    if _trng.randf() < 0.6:
        var d2: Vector2i = -d1
        var bx: int = x
        var bz: int = z
        var by: int = y0 + h1 - 1
        for i in range(2):
            bx += d2.x
            bz += d2.y
            by += 1
            _put_log(bx, by, bz, lg)
        _disk(bx, by + 1, bz, 2, lf, 0.4)

func _tree_dark_oak(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(6, 9)
    _trunk2(x, y0, z, h, lg)
    _blob(x, y0 + h, z, 4.6, 2.7, 4.6, lf)
    _blob(x + 1, y0 + h + 1, z + 1, 3.4, 2.0, 3.4, lf)

func _tree_cherry(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(4, 6)
    _column(x, y0, z, h, lg)
    var top: int = y0 + h
    _blob(x, top, z, 3.6, 2.6, 3.6, lf)
    for k in range(_trng.randi_range(1, 2)):
        var ang: float = _trng.randf() * TAU
        var bx: int = x + roundi(cos(ang) * 3.0)
        var bz: int = z + roundi(sin(ang) * 3.0)
        _line_logs(x, top - 2, z, bx, top, bz, lg)
        _blob(bx, top + 1, bz, 2.6, 2.0, 2.6, lf)

func _tree_mangrove(x: int, y0: int, z: int, lg: int, lf: int, rt: int) -> void:
    var h: int = _trng.randi_range(5, 8)
    _column(x, y0 + 1, z, h, lg)
    _blob(x, y0 + h + 1, z, 3.2, 2.2, 3.2, lf)
    var roots: int = _trng.randi_range(4, 6)
    for k in range(roots):
        var ang: float = float(k) / float(roots) * TAU + _trng.randf() * 0.6
        for step in range(1, 5):
            var rx: int = x + roundi(cos(ang) * float(step) * 0.8)
            var rz: int = z + roundi(sin(ang) * float(step) * 0.8)
            _put_log(rx, y0 + 2 - step, rz, rt)
    _put_log(x, y0, z, lg)

func _tree_ancient(x: int, y0: int, z: int, lg: int, lf: int, rt: int) -> void:
    var h: int = _trng.randi_range(18, 26)
    var h3: int = h * 6 / 10
    _trunk3(x, y0, z, h3, lg)
    _trunk2(x, y0 + h3, z, h - h3, lg)
    _column(x, y0 + h, z, 2, lg)
    for k in range(8):
        var ang: float = float(k) / 8.0 * TAU
        for step in range(2, 6):
            var rx: int = x + roundi(cos(ang) * float(step))
            var rz: int = z + roundi(sin(ang) * float(step))
            var ry: int = y0 if step < 4 else y0 - 1
            _put_log(rx, ry, rz, rt)
            if step < 3:
                _put_log(rx, ry + 1, rz, rt)
    var top: int = y0 + h + 1
    _blob(x, top, z, 6.2, 3.4, 6.2, lf)
    for k in range(_trng.randi_range(4, 6)):
        var ang2: float = _trng.randf() * TAU
        var dist: int = _trng.randi_range(4, 6)
        var by: int = y0 + h3 + _trng.randi_range(0, h - h3 - 2)
        var bx: int = x + roundi(cos(ang2) * float(dist))
        var bz: int = z + roundi(sin(ang2) * float(dist))
        _line_logs(x, by, z, bx, by + 2, bz, lg)
        _blob(bx, by + 3, bz, 3.8, 2.6, 3.8, lf)

func _tree_maple(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(5, 7)
    _column(x, y0, z, h, lg)
    _blob(x, y0 + h, z, 3.5, 3.0, 3.5, lf)
    if _trng.randf() < 0.4:
        var ang: float = _trng.randf() * TAU
        var bx: int = x + roundi(cos(ang) * 2.0)
        var bz: int = z + roundi(sin(ang) * 2.0)
        _line_logs(x, y0 + h - 2, z, bx, y0 + h, bz, lg)

func _tree_aspen(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(8, 13)
    _column(x, y0, z, h, lg)
    _blob(x, y0 + h - 2, z, 1.9, 3.6, 1.9, lf, 0.4)
    _put_leaf(x, y0 + h + 2, z, lf)

func _tree_willow(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(5, 8)
    var cx: int = x
    for i in range(h):
        if i == h / 2:
            cx += 1 if _trng.randf() < 0.5 else 0
        _put_log(cx, y0 + i, z, lg)
    var top: int = y0 + h
    _blob(cx, top, z, 3.8, 1.9, 3.8, lf)
    for dx in range(-4, 5):
        for dz in range(-4, 5):
            var d: float = sqrt(float(dx * dx + dz * dz))
            if d >= 2.4 and d <= 3.9 and _trng.randf() < 0.7:
                var strand: int = _trng.randi_range(2, 5)
                for j in range(strand):
                    _put_leaf(cx + dx, top - 1 - j, z + dz, lf)

func _tree_baobab(x: int, y0: int, z: int, lg: int, lf: int, rt: int) -> void:
    var h: int = _trng.randi_range(8, 11)
    _trunk3(x, y0, z, h - 2, lg)
    _trunk2(x, y0 + h - 2, z, 2, lg)
    for k in range(4):
        var ang: float = float(k) / 4.0 * TAU + 0.4
        var rx: int = x + roundi(cos(ang) * 2.0)
        var rz: int = z + roundi(sin(ang) * 2.0)
        _put_log(rx, y0, rz, rt)
        _put_log(roundi(float(x) + cos(ang) * 3.0), y0 - 1, roundi(float(z) + sin(ang) * 3.0), rt)
    var branches: int = _trng.randi_range(4, 6)
    for k in range(branches):
        var ang2: float = float(k) / float(branches) * TAU + _trng.randf() * 0.5
        var bx: int = x + roundi(cos(ang2) * 4.0)
        var bz: int = z + roundi(sin(ang2) * 4.0)
        var by: int = y0 + h - 1
        _line_logs(x, by, z, bx, by + 1, bz, lg)
        _put_log(bx, by + 2, bz, lg)
        _blob(bx, by + 3, bz, 3.3, 1.8, 3.3, lf)
    _blob(x, y0 + h + 1, z, 3.0, 1.6, 3.0, lf)

func _tree_sequoia(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(22, 36)
    _trunk2(x, y0, z, h, lg)
    var start: int = h * 4 / 10
    var max_r: int = _trng.randi_range(4, 5)
    var span: int = h - start
    for k in range(span + 3):
        var yy: int = y0 + h + 2 - k
        var frac: float = float(k) / float(maxi(1, span))
        var r: int = int(frac * float(max_r) + 0.5)
        if yy % 3 == 0:
            r += 1
        if k < 2:
            r = 0
        _disk(x, yy, z, r, lf, 0.5)
        _disk(x + 1, yy, z + 1, r, lf, 0.5)

func _tree_azure(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(9, 14)
    var cx: int = x
    var cz: int = z
    for i in range(h):
        cx = x + roundi(sin(float(i) * 0.6) * 1.2)
        cz = z + roundi(cos(float(i) * 0.6) * 1.2)
        _put_log(cx, y0 + i, cz, lg)
    _blob(cx, y0 + h, cz, 4.0, 2.9, 4.0, lf)
    for k in range(5):
        var ang: float = float(k) / 5.0 * TAU
        var sx: int = cx + roundi(cos(ang) * 3.0)
        var sz: int = cz + roundi(sin(ang) * 3.0)
        for j in range(_trng.randi_range(2, 4)):
            _put_leaf(sx, y0 + h - 2 - j, sz, lf)

func _tree_crystal(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(3, 6)
    _column(x, y0, z, h, lg)
    _blob(x, y0 + h, z, 1.8, 1.8, 1.8, lf, 0.2)
    for k in range(5):
        var dx: int = _trng.randi_range(-1, 1)
        var dz: int = _trng.randi_range(-1, 1)
        var spike: int = _trng.randi_range(2, 4)
        for j in range(1, spike + 1):
            _put_leaf(x + dx * (j / 2 + 1), y0 + h + j, z + dz * (j / 2 + 1), lf)

func _tree_dead(x: int, y0: int, z: int, lg: int, lf: int, rt: int) -> void:
    var h: int = _trng.randi_range(5, 9)
    _column(x, y0, z, h, lg)
    for k in range(_trng.randi_range(3, 5)):
        var ang: float = _trng.randf() * TAU
        var reach: int = _trng.randi_range(2, 4)
        var by: int = y0 + h - _trng.randi_range(1, 4)
        var bx: int = x + roundi(cos(ang) * float(reach))
        var bz: int = z + roundi(sin(ang) * float(reach))
        _line_logs(x, by, z, bx, by + reach - 1, bz, lg)
        if _trng.randf() < 0.5:
            _put_leaf(bx, by + reach, bz, lf)
    if rt > 0:
        for k in range(4):
            var ang2: float = float(k) / 4.0 * TAU + 0.8
            _put_log(x + roundi(cos(ang2) * 1.5), y0, z + roundi(sin(ang2) * 1.5), rt)

func _tree_mushroom(x: int, y0: int, z: int, lg: int, lf: int) -> void:
    var h: int = _trng.randi_range(5, 9)
    _column(x, y0, z, h, lg)
    var top: int = y0 + h
    _disk(x, top, z, 3, lf, 1.5)
    _ring(x, top - 1, z, 2.2, 4.4, lf)
    _ring(x, top - 2, z, 3.2, 4.4, lf)
    _disk(x, top + 1, z, 1, lf, 0.3)
