extends RefCounted

const BLOCK_DIR: String = "res://assets/textures/blocks/"
const ITEM_DIR: String = "res://assets/textures/items/"
const UI_DIR: String = "res://assets/textures/ui/"

const NAMES: Dictionary = {
    "pickaxe": "Кирка",
    "grass": "Травяной блок",
    "dirt": "Земля",
    "stone": "Камень",
    "cobblestone": "Булыжник",
    "sand": "Песок",
    "wood": "Дерево",
    "leaves": "Листья",
    "torch": "Факел",
    "salve": "Аптечка",
    "berries": "Ягоды",
    "coal_ore": "Угольная руда",
    "iron_ore": "Железная руда",
    "copper_ore": "Медная руда",
    "hematite_ore": "Гематит / магнетит",
    "cassiterite_ore": "Касситерит (олово)",
    "pentlandite_ore": "Пентландит (никель)",
    "garnierite_ore": "Гарниерит (никель)",
    "sphalerite_ore": "Сфалерит (цинк)",
    "gold_ore": "Золотая руда",
    "lapis_ore": "Лазурит",
    "redstone_ore": "Редстоуновая руда",
    "diamond_ore": "Алмазная руда",
    "titan_ore": "Титановая руда",
    "uranium_ore": "Урановая руда",
    "granite": "Гранит",
    "diorite": "Диорит",
    "andesite": "Андезит",
    "slate": "Сланец",
    "limestone": "Известняк",
    "sandstone": "Песчаник",
    "claystone": "Глинистый камень",
    "tuff": "Туф",
    "gneiss": "Гнейс",
    "deep_stone": "Глубинный камень",
    "grass_soil": "Трава и почва",
    "podzol": "Подзол",
    "red_sand": "Красный песок",
    "red_clay": "Красная глина",
    "quartz_ore": "Кварцевая жила",
    "flint_ore": "Кремневая жила",
    "emerald_ore": "Зелёный минерал",
    "ruby_ore": "Красный минерал",
    "sapphire_ore": "Синий минерал",
    "amethyst_ore": "Фиолетовый минерал",
    "mixed_ore": "Смешанная руда",
    "silver_ore": "Серебряная руда",
    "tin_ore": "Оловянная руда",
    "nickel_ore": "Никелевая руда",
    "cobalt_ore": "Кобальтовая руда",
    "titanium_ore": "Титановая руда",
    "deep_rock": "Глубинная порода",
    "basalt": "Базальт",
    "obsidian": "Обсидиан",
    "glowstone_rock": "Светящийся камень",
    "dripstone": "Капельный камень",
    "stalactite_rock": "Камень сталактитов",
    "limestone_rock": "Известняковая порода",
    "pale_rock": "Светлая порода",
    "salt_block": "Соляной блок",
    "gypsum": "Гипс",
    "marble": "Мрамор",
    "echorite_ore": "Эхорит",
    "astralite_ore": "Астралит",
    "void_ore": "Пустотная руда",
    "livingstone": "Живокамень",
    "shadow_ore": "Сумрачная руда",
    "chronosteel_ore": "Хроносталь",
    "gravel": "Гравий",
    "cobble": "Галька",
    "clay_with_stone": "Глина с камнем",
    "loam": "Суглинок",
    "marl": "Мергель",
    "packed_soil": "Плотный грунт",
    "silt": "Ил",
    "mud": "Грязь",
    "snow": "Снег",
    "packed_snow": "Уплотнённый снег",
    "ice": "Лёд",
    "ice_blue": "Плотный лёд",
    "blue_ice_ore": "Синяя ледяная жила",
    "glassstone": "Стеклянный камень",
    "lava_rock": "Лавовый камень",
    "red_fungus_block": "Красный грибной блок",
    "mossy_stone": "Мшистый камень",
    "oak_log": "Бревно: Дуб",
    "oak_leaves": "Листва: Дуб",
    "oak_planks": "Доски: Дуб",
    "spruce_log": "Бревно: Ель",
    "spruce_leaves": "Листва: Ель",
    "spruce_planks": "Доски: Ель",
    "birch_log": "Бревно: Берёза",
    "birch_leaves": "Листва: Берёза",
    "birch_planks": "Доски: Берёза",
    "jungle_log": "Бревно: Тропическое дерево",
    "jungle_leaves": "Листва: Тропическое дерево",
    "jungle_planks": "Доски: Тропическое дерево",
    "acacia_log": "Бревно: Акация",
    "acacia_leaves": "Листва: Акация",
    "acacia_planks": "Доски: Акация",
    "dark_oak_log": "Бревно: Тёмный дуб",
    "dark_oak_leaves": "Листва: Тёмный дуб",
    "dark_oak_planks": "Доски: Тёмный дуб",
    "cherry_log": "Бревно: Сакура",
    "cherry_leaves": "Листва: Сакура",
    "cherry_planks": "Доски: Сакура",
    "mangrove_log": "Бревно: Мангровое дерево",
    "mangrove_leaves": "Листва: Мангровое дерево",
    "mangrove_planks": "Доски: Мангровое дерево",
    "ancient_log": "Бревно: Древнее дерево",
    "ancient_leaves": "Листва: Древнее дерево",
    "ancient_planks": "Доски: Древнее дерево",
    "maple_log": "Бревно: Клён",
    "maple_leaves": "Листва: Клён",
    "maple_planks": "Доски: Клён",
    "aspen_log": "Бревно: Осина",
    "aspen_leaves": "Листва: Осина",
    "aspen_planks": "Доски: Осина",
    "willow_log": "Бревно: Ива",
    "willow_leaves": "Листва: Ива",
    "willow_planks": "Доски: Ива",
    "baobab_log": "Бревно: Баобаб",
    "baobab_leaves": "Листва: Баобаб",
    "baobab_planks": "Доски: Баобаб",
    "sequoia_log": "Бревно: Секвойя",
    "sequoia_leaves": "Листва: Секвойя",
    "sequoia_planks": "Доски: Секвойя",
    "azure_log": "Бревно: Лазурное дерево",
    "azure_leaves": "Листва: Лазурное дерево",
    "azure_planks": "Доски: Лазурное дерево",
    "crystal_log": "Бревно: Кристальное дерево",
    "crystal_leaves": "Листва: Кристальное дерево",
    "crystal_planks": "Доски: Кристальное дерево",
    "dead_log": "Бревно: Мёртвое дерево",
    "dead_leaves": "Листва: Мёртвое дерево",
    "dead_planks": "Доски: Мёртвое дерево",
    "mushroom_log": "Бревно: Грибодерево",
    "mushroom_leaves": "Листва: Грибодерево",
    "mushroom_planks": "Доски: Грибодерево",
    "oak_stripped_log": "Очищенное бревно: Дуб",
    "spruce_stripped_log": "Очищенное бревно: Ель",
    "birch_stripped_log": "Очищенное бревно: Берёза",
    "jungle_stripped_log": "Очищенное бревно: Тропическое дерево",
    "acacia_stripped_log": "Очищенное бревно: Акация",
    "dark_oak_stripped_log": "Очищенное бревно: Тёмный дуб",
    "cherry_stripped_log": "Очищенное бревно: Вишня",
    "mangrove_stripped_log": "Очищенное бревно: Мангр",
    "ancient_stripped_log": "Очищенное бревно: Древнее дерево",
    "maple_stripped_log": "Очищенное бревно: Клён",
    "aspen_stripped_log": "Очищенное бревно: Осина",
    "willow_stripped_log": "Очищенное бревно: Ива",
    "baobab_stripped_log": "Очищенное бревно: Баобаб",
    "sequoia_stripped_log": "Очищенное бревно: Секвойя",
    "azure_stripped_log": "Очищенное бревно: Лазурное дерево",
    "crystal_stripped_log": "Очищенное бревно: Кристальное дерево",
    "dead_stripped_log": "Очищенное бревно: Мёртвое дерево",
    "mushroom_stripped_log": "Очищенное бревно: Грибодерево",
    "ancient_roots": "Корни: Древнее дерево",
    "baobab_roots": "Корни: Баобаб",
    "dead_roots": "Корни: Мёртвое дерево",
    "mangrove_roots": "Корни: Мангр",
    "mushroom_roots": "Корни: Грибодерево",
    "willow_roots": "Корни: Ива",
}

const ORE_ITEMS: Array = [
    "coal_ore", "iron_ore", "copper_ore", "hematite_ore", "cassiterite_ore",
    "pentlandite_ore", "garnierite_ore", "sphalerite_ore", "gold_ore", "lapis_ore",
    "redstone_ore", "diamond_ore", "titan_ore", "uranium_ore", "quartz_ore", "emerald_ore", "ruby_ore", "sapphire_ore", "amethyst_ore", "silver_ore", "cobalt_ore", "titanium_ore"
]
const BLOCK_ITEMS: Array = [
    "grass", "dirt", "stone", "cobblestone", "sand", "wood", "leaves", "torch", "coal_ore", "iron_ore", "copper_ore", "hematite_ore", "cassiterite_ore", "pentlandite_ore", "garnierite_ore", "sphalerite_ore", "gold_ore", "lapis_ore", "redstone_ore", "diamond_ore", "titan_ore", "uranium_ore", "granite", "diorite", "andesite", "slate", "limestone", "sandstone", "claystone", "tuff", "gneiss", "deep_stone", "grass_soil", "podzol", "red_sand", "red_clay", "quartz_ore", "flint_ore", "emerald_ore", "ruby_ore", "sapphire_ore", "amethyst_ore", "mixed_ore", "silver_ore", "tin_ore", "nickel_ore", "cobalt_ore", "titanium_ore", "deep_rock", "basalt", "obsidian", "glowstone_rock", "dripstone", "stalactite_rock", "limestone_rock", "pale_rock", "salt_block", "gypsum", "marble", "echorite_ore", "astralite_ore", "void_ore", "livingstone", "shadow_ore", "chronosteel_ore", "gravel", "cobble", "clay_with_stone", "loam", "marl", "packed_soil", "silt", "mud", "snow", "packed_snow", "ice", "ice_blue", "blue_ice_ore", "glassstone", "lava_rock", "red_fungus_block", "mossy_stone", "oak_log", "oak_leaves", "oak_planks", "spruce_log", "spruce_leaves", "spruce_planks", "birch_log", "birch_leaves", "birch_planks", "jungle_log", "jungle_leaves", "jungle_planks", "acacia_log", "acacia_leaves", "acacia_planks", "dark_oak_log", "dark_oak_leaves", "dark_oak_planks", "cherry_log", "cherry_leaves", "cherry_planks", "mangrove_log", "mangrove_leaves", "mangrove_planks", "ancient_log", "ancient_leaves", "ancient_planks", "maple_log", "maple_leaves", "maple_planks", "aspen_log", "aspen_leaves", "aspen_planks", "willow_log", "willow_leaves", "willow_planks", "baobab_log", "baobab_leaves", "baobab_planks", "sequoia_log", "sequoia_leaves", "sequoia_planks", "azure_log", "azure_leaves", "azure_planks", "crystal_log", "crystal_leaves", "crystal_planks", "dead_log", "dead_leaves", "dead_planks", "mushroom_log", "mushroom_leaves", "mushroom_planks", "oak_stripped_log", "spruce_stripped_log", "birch_stripped_log", "jungle_stripped_log", "acacia_stripped_log", "dark_oak_stripped_log", "cherry_stripped_log", "mangrove_stripped_log", "ancient_stripped_log", "maple_stripped_log", "aspen_stripped_log", "willow_stripped_log", "baobab_stripped_log", "sequoia_stripped_log", "azure_stripped_log", "crystal_stripped_log", "dead_stripped_log", "mushroom_stripped_log", "ancient_roots", "baobab_roots", "dead_roots", "mangrove_roots", "mushroom_roots", "willow_roots"
]


const ICON_PATHS: Dictionary = {
    "pickaxe": "res://assets/textures/items/pickaxe.png",
    "dirt": "res://assets/textures/blocks/dirt.png",
    "stone": "res://assets/textures/blocks/stone.png",
    "cobblestone": "res://assets/textures/blocks/cobblestone.png",
    "sand": "res://assets/textures/blocks/sand.png",
    "wood": "res://assets/textures/blocks/wood_side.png",
    "leaves": "res://assets/textures/blocks/leaves.png",
    "torch": "res://assets/textures/items/torch.png",
    "salve": "res://assets/textures/items/salve.png",
    "berries": "res://assets/textures/items/berries.png",
    "coal_ore": "res://assets/textures/blocks/coal_ore.png",
    "iron_ore": "res://assets/textures/blocks/iron_ore.png",
    "copper_ore": "res://assets/textures/blocks/copper_ore.png",
    "hematite_ore": "res://assets/textures/blocks/hematite_ore.png",
    "cassiterite_ore": "res://assets/textures/blocks/cassiterite_ore.png",
    "pentlandite_ore": "res://assets/textures/blocks/pentlandite_ore.png",
    "garnierite_ore": "res://assets/textures/blocks/garnierite_ore.png",
    "sphalerite_ore": "res://assets/textures/blocks/sphalerite_ore.png",
    "gold_ore": "res://assets/textures/blocks/gold_ore.png",
    "lapis_ore": "res://assets/textures/blocks/lapis_ore.png",
    "redstone_ore": "res://assets/textures/blocks/redstone_ore.png",
    "diamond_ore": "res://assets/textures/blocks/diamond_ore.png",
    "titan_ore": "res://assets/textures/blocks/titan_ore.png",
    "uranium_ore": "res://assets/textures/blocks/uranium_ore.png"
}

static func creative_items() -> Array:
    var items: Array = BLOCK_ITEMS.duplicate()
    items.append_array(["pickaxe", "salve", "berries"])
    return items

static func item_name(item_id: String) -> String:
    return str(NAMES.get(item_id, item_id))

static func icon(item_id: String) -> Texture2D:
    var path: String = str(ICON_PATHS.get(item_id, ""))
    if path != "" and ResourceLoader.exists(path):
        return load(path) as Texture2D
    path = BLOCK_DIR + item_id + ".png"
    if item_id == "grass" and not ResourceLoader.exists(path):
        path = BLOCK_DIR + "grass_top.png"
    if not ResourceLoader.exists(path) and item_id.ends_with("_log"):
        path = BLOCK_DIR + item_id + "_side.png"
    if not ResourceLoader.exists(path) and item_id.ends_with("_sapling"):
        path = "res://assets/textures/trees/" + item_id.trim_suffix("_sapling") + "/sapling.png"
    if not ResourceLoader.exists(path):
        return null
    return load(path) as Texture2D

static func ui_texture(texture_name: String) -> Texture2D:
    var path: String = UI_DIR + texture_name + ".png"
    if not ResourceLoader.exists(path):
        return null
    return load(path) as Texture2D

static func max_stack(item_id: String) -> int:
    if item_id == "pickaxe":
        return 1
    return 64

static func block_kind(item_id: String) -> String:
    if BLOCK_ITEMS.has(item_id):
        return item_id
    return ""

static func drop_for_block(kind: String) -> String:
    match kind:
        "grass", "dirt":
            return "dirt"
        "stone", "cobblestone", "ancient":
            return "cobblestone"
        "sand":
            return "sand"
        "wood":
            return "wood"
        "leaves":
            if randf() < 0.3:
                return "berries"
            return "leaves"
        "torch":
            return "torch"
        "coal_ore", "iron_ore", "copper_ore", "hematite_ore", "cassiterite_ore", \
        "pentlandite_ore", "garnierite_ore", "sphalerite_ore", "gold_ore", "lapis_ore", \
        "redstone_ore", "diamond_ore", "titan_ore", "uranium_ore":
            return kind
    if BLOCK_ITEMS.has(kind):
        return kind
    return ""
