extends RefCounted
# Каталог предметов для инвентаря: обычные предметы (item_registry) + все блоки (block_registry).
# Блоки хранятся в инвентаре под своим именем.

const B = preload("res://scripts/3d/block_registry.gd")
const I = preload("res://scripts/3d/item_registry.gd")
const Atlas = preload("res://scripts/3d/atlas_data.gd")
const ItemTable = preload("res://scripts/3d/item_table.gd")

const UI_DIR: String = "res://assets/textures/ui/"
const ATLAS_PATH: String = "res://assets/atlas/blocks_atlas.png"
const ITEMS_PATH: String = "res://assets/atlas/items_atlas.png"
const ICONS_PATH: String = "res://assets/atlas/icons_atlas.png"

static var _icon_cache: Dictionary = {}
static var _tile_cache: Dictionary = {}
static var _icons_texture: Texture2D = null
static var _items_texture: Texture2D = null
static var _atlas_image: Image = null
static var _items_image: Image = null

static func base_id(item_id: String) -> String:
    return I.base_id(item_id)

static func normalize_item(item_id: String) -> String:
    if item_id == "":
        return ""
    var fixed: String = I.normalize(item_id)
    if I.has(fixed):
        return fixed
    var block_id: int = B.id_of(I.base_id(fixed))
    if block_id > 0:
        return B.names[block_id]
    return fixed

static func is_known_item(item_id: String) -> bool:
    var base: String = I.base_id(item_id)
    return I.has(base) or B.is_placeable_name(base)

static func is_plain_item(item_id: String) -> bool:
    return I.has(I.base_id(item_id))

static func item_name(item_id: String) -> String:
    var base: String = I.base_id(item_id)
    if I.has(base):
        return I.item_name(base)
    return B.ru_name(base)

static func is_flat_item(item_id: String) -> bool:
    var base: String = I.base_id(item_id)
    if I.has(base):
        return true
    var block_id: int = B.id_of(base)
    return block_id > 0 and B.render[block_id] == B.R_CROSS

static func max_stack(item_id: String) -> int:
    var base: String = I.base_id(item_id)
    if I.has(base):
        return I.stack_size(base)
    return 64

static func block_kind(item_id: String) -> String:
    var base: String = I.base_id(item_id)
    if I.has(base):
        return ""
    if B.is_placeable_name(base):
        return B.names[B.id_of(base)]
    return ""

# ------------------------------------------------------------------ icons

static func _items_tex() -> Texture2D:
    if _items_texture == null:
        _items_texture = load(ITEMS_PATH) as Texture2D
    return _items_texture

static func icon(item_id: String) -> Texture2D:
    var base: String = I.base_id(item_id)
    if _icon_cache.has(base):
        return _icon_cache[base]
    var result: Texture2D = null
    if I.has(base):
        var index: int = int(Atlas.ITEM_TILES.get(I.tile(base), 0))
        var atlas_tex := AtlasTexture.new()
        atlas_tex.atlas = _items_tex()
        atlas_tex.region = Rect2(float((index % Atlas.ITEM_COLS) * Atlas.TILE_SIZE), float((index / Atlas.ITEM_COLS) * Atlas.TILE_SIZE), float(Atlas.TILE_SIZE), float(Atlas.TILE_SIZE))
        result = atlas_tex
    else:
        var block_id: int = B.id_of(base)
        if block_id > 0:
            if _icons_texture == null:
                _icons_texture = load(ICONS_PATH) as Texture2D
            var block_tex := AtlasTexture.new()
            block_tex.atlas = _icons_texture
            var cell: int = Atlas.ICON_SIZE
            block_tex.region = Rect2(float((block_id % Atlas.ICON_COLS) * cell), float((block_id / Atlas.ICON_COLS) * cell), float(cell), float(cell))
            result = block_tex
    _icon_cache[base] = result
    return result

static func _prepare(tex: Texture2D) -> Image:
    var img: Image = tex.get_image()
    if img.is_compressed():
        img.decompress()
    img.convert(Image.FORMAT_RGBA8)
    return img

static func _get_atlas_image() -> Image:
    if _atlas_image == null:
        _atlas_image = _prepare(load(ATLAS_PATH) as Texture2D)
    return _atlas_image

static func _get_items_image() -> Image:
    if _items_image == null:
        _items_image = _prepare(_items_tex())
    return _items_image

# Квадрат 16x16 из атласа блоков по имени тайла.
static func tile_image(tile_name: String) -> Image:
    var index: int = int(Atlas.TILES.get(tile_name, 0))
    var size: int = Atlas.TILE_SIZE
    return _get_atlas_image().get_region(Rect2i((index % Atlas.ATLAS_COLS) * size, (index / Atlas.ATLAS_COLS) * size, size, size))

static func tile_texture(tile_name: String) -> Texture2D:
    if _tile_cache.has(tile_name):
        return _tile_cache[tile_name]
    var tex: Texture2D = ImageTexture.create_from_image(tile_image(tile_name))
    _tile_cache[tile_name] = tex
    return tex

# Изображение для плоской модели в руке и для выпавших предметов.
static func flat_image(item_id: String) -> Image:
    var base: String = I.base_id(item_id)
    if I.has(base):
        var index: int = int(Atlas.ITEM_TILES.get(I.tile(base), 0))
        var size: int = Atlas.TILE_SIZE
        return _get_items_image().get_region(Rect2i((index % Atlas.ITEM_COLS) * size, (index / Atlas.ITEM_COLS) * size, size, size))
    var block_id: int = B.id_of(base)
    if block_id <= 0:
        return null
    return tile_image(B.tile_name(block_id, 1))

static func ui_texture(texture_name: String) -> Texture2D:
    var path: String = UI_DIR + texture_name + ".png"
    if not ResourceLoader.exists(path):
        return null
    return load(path) as Texture2D

# ------------------------------------------------------------------ drops

# Что выпадает при добыче блока: список [предмет, количество].
static func drops_for_block(kind: String) -> Array:
    if ItemTable.DROPS.has(kind):
        var entry: Array = ItemTable.DROPS[kind]
        return [[str(entry[0]), randi_range(int(entry[1]), int(entry[2]))]]
    match kind:
        "grass":
            return [["dirt", 1]]
        "stone":
            return [["cobblestone", 1]]
        "water", "air", "bedrock":
            return []
    if kind.ends_with("_leaves"):
        var out: Array = []
        var roll: float = randf()
        if roll < 0.08:
            out.append([kind.trim_suffix("_leaves") + "_sapling", 1])
        elif roll < 0.18:
            out.append(["berries", 1])
        if randf() < 0.08:
            out.append(["stick", randi_range(1, 2)])
        return out
    if B.is_placeable_name(kind):
        return [[kind, 1]]
    return []

# ------------------------------------------------------------------ creative

# Категория для творческого инвентаря.
static func creative_category(item_id: String) -> String:
    var base: String = I.base_id(item_id)
    if I.has(base):
        match I.kind(base):
            "tool":
                return "sword" if I.tool_type(base) == "sword" else "tools"
            "armor":
                return "armor"
            "material_block":
                return "build"
            _:
                return "items"
    var block_id: int = B.id_of(base)
    if block_id <= 0:
        return "items"
    var cat: String = B.categories[block_id]
    if base.ends_with("_planks") or base.ends_with("_stripped_log"):
        return "build"
    match cat:
        "stone":
            return "build"
        "ore":
            return "ores"
        "nature", "leaves", "wood":
            return "nature"
    return "items"

static func creative_entries() -> Array:
    I.setup()
    var out: Array = []
    for block_name in B.creative_items():
        out.append([str(block_name), creative_category(str(block_name))])
    for item_id in I.order:
        out.append([str(item_id), creative_category(str(item_id))])
    return out

static func tooltip_text(item_id: String) -> String:
    var base: String = I.base_id(item_id)
    var text: String = item_name(base)
    if I.has(base):
        match I.kind(base):
            "tool":
                text += "\nУрон: %d   Скорость: %.1f   Уровень: %d" % [I.damage(base), I.speed(base), I.tier(base)]
            "armor":
                text += "\nЗащита: %d" % I.defense(base)
        if I.has_durability(base):
            text += "\nПрочность: %d / %d" % [I.durability(base) - I.wear_of(item_id), I.durability(base)]
    return text
