extends RefCounted

const BLOCK_DIR: String = "res://assets/textures/blocks/"
const ITEM_DIR: String = "res://assets/textures/items/"
const UI_DIR: String = "res://assets/textures/ui/"

const NAMES: Dictionary = {
    "pickaxe": "Кирка",
    "dirt": "Земля",
    "stone": "Камень",
    "cobblestone": "Булыжник",
    "sand": "Песок",
    "wood": "Дерево",
    "leaves": "Листья",
    "torch": "Факел",
    "salve": "Аптечка",
    "berries": "Ягоды",
    "coal_ore": "Угольная руда",
    "iron_ore": "Железная руда",
    "copper_ore": "Медная руда",
    "hematite_ore": "Гематит / магнетит",
    "cassiterite_ore": "Касситерит (олово)",
    "pentlandite_ore": "Пентландит (никель)",
    "garnierite_ore": "Гарниерит (никель)",
    "sphalerite_ore": "Сфалерит (цинк)",
    "gold_ore": "Золотая руда",
    "lapis_ore": "Лазурит",
    "redstone_ore": "Редстоуновая руда",
    "diamond_ore": "Алмазная руда",
    "titan_ore": "Титановая руда",
    "uranium_ore": "Урановая руда"
}

const ORE_ITEMS: Array = [
    "coal_ore", "iron_ore", "copper_ore", "hematite_ore", "cassiterite_ore",
    "pentlandite_ore", "garnierite_ore", "sphalerite_ore", "gold_ore", "lapis_ore",
    "redstone_ore", "diamond_ore", "titan_ore", "uranium_ore"
]
const BLOCK_ITEMS: Array = [
    "dirt", "stone", "cobblestone", "sand", "wood", "leaves", "torch",
    "coal_ore", "iron_ore", "copper_ore", "hematite_ore", "cassiterite_ore",
    "pentlandite_ore", "garnierite_ore", "sphalerite_ore", "gold_ore", "lapis_ore",
    "redstone_ore", "diamond_ore", "titan_ore", "uranium_ore"
]

const ICON_PATHS: Dictionary = {
    "pickaxe": "res://assets/textures/items/pickaxe.png",
    "dirt": "res://assets/textures/blocks/dirt.png",
    "stone": "res://assets/textures/blocks/stone.png",
    "cobblestone": "res://assets/textures/blocks/cobblestone.png",
    "sand": "res://assets/textures/blocks/sand.png",
    "wood": "res://assets/textures/blocks/wood_side.png",
    "leaves": "res://assets/textures/blocks/leaves.png",
    "torch": "res://assets/textures/items/torch.png",
    "salve": "res://assets/textures/items/salve.png",
    "berries": "res://assets/textures/items/berries.png",
    "coal_ore": "res://assets/textures/blocks/coal_ore.png",
    "iron_ore": "res://assets/textures/blocks/iron_ore.png",
    "copper_ore": "res://assets/textures/blocks/copper_ore.png",
    "hematite_ore": "res://assets/textures/blocks/hematite_ore.png",
    "cassiterite_ore": "res://assets/textures/blocks/cassiterite_ore.png",
    "pentlandite_ore": "res://assets/textures/blocks/pentlandite_ore.png",
    "garnierite_ore": "res://assets/textures/blocks/garnierite_ore.png",
    "sphalerite_ore": "res://assets/textures/blocks/sphalerite_ore.png",
    "gold_ore": "res://assets/textures/blocks/gold_ore.png",
    "lapis_ore": "res://assets/textures/blocks/lapis_ore.png",
    "redstone_ore": "res://assets/textures/blocks/redstone_ore.png",
    "diamond_ore": "res://assets/textures/blocks/diamond_ore.png",
    "titan_ore": "res://assets/textures/blocks/titan_ore.png",
    "uranium_ore": "res://assets/textures/blocks/uranium_ore.png"
}

static func item_name(item_id: String) -> String:
    return str(NAMES.get(item_id, item_id))

static func icon(item_id: String) -> Texture2D:
    var path: String = str(ICON_PATHS.get(item_id, ""))
    if path == "" or not ResourceLoader.exists(path):
        return null
    return load(path) as Texture2D

static func ui_texture(texture_name: String) -> Texture2D:
    var path: String = UI_DIR + texture_name + ".png"
    if not ResourceLoader.exists(path):
        return null
    return load(path) as Texture2D

static func max_stack(item_id: String) -> int:
    if item_id == "pickaxe":
        return 1
    return 64

static func block_kind(item_id: String) -> String:
    if BLOCK_ITEMS.has(item_id):
        return item_id
    return ""

static func drop_for_block(kind: String) -> String:
    match kind:
        "grass", "dirt":
            return "dirt"
        "stone", "cobblestone", "ancient":
            return "cobblestone"
        "sand":
            return "sand"
        "wood":
            return "wood"
        "leaves":
            if randf() < 0.3:
                return "berries"
            return "leaves"
        "torch":
            return "torch"
        "coal_ore", "iron_ore", "copper_ore", "hematite_ore", "cassiterite_ore", \
        "pentlandite_ore", "garnierite_ore", "sphalerite_ore", "gold_ore", "lapis_ore", \
        "redstone_ore", "diamond_ore", "titan_ore", "uranium_ore":
            return kind
    return ""
