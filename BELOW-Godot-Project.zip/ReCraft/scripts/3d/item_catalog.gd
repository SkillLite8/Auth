extends RefCounted
# Единый каталог предметов. Сохраняет старые ID блоков и предметов, одновременно
# подключая полный комплект инструментов, оружия, брони и материалов из resource pack.

const B = preload("res://scripts/3d/block_registry.gd")
const Atlas = preload("res://scripts/3d/atlas_data.gd")

const ITEM_DIR: String = "res://assets/textures/items/"
const UI_DIR: String = "res://assets/textures/ui/"
const ATLAS_PATH: String = "res://assets/atlas/blocks_atlas.png"
const ICONS_PATH: String = "res://assets/atlas/icons_atlas.png"
const PACK_ROOT: String = "res://assets/block_texture_pack/"
const PACK_ITEMS_PATH: String = PACK_ROOT + "gameplay/items.json"
const PACK_MODELS_PATH: String = PACK_ROOT + "models/equipment_model_catalog.json"

const ITEM_NAMES: Dictionary = {
    "pickaxe": "Кирка",
    "salve": "Аптечка",
    "berries": "Ягоды"
}
const PLAIN_ITEMS: Array = ["pickaxe", "salve", "berries"]
const MODEL_ALIASES: Dictionary = {"pickaxe": "iron_pickaxe"}

static var _icon_cache: Dictionary = {}
static var _tile_cache: Dictionary = {}
static var _icons_texture: Texture2D = null
static var _atlas_image: Image = null
static var _pack_loaded: bool = false
static var _pack_items: Dictionary = {}
static var _equipment_models: Dictionary = {}
static var _model_scene_cache: Dictionary = {}

static func _ensure_pack_data() -> void:
    if _pack_loaded:
        return
    _pack_loaded = true
    if FileAccess.file_exists(PACK_ITEMS_PATH):
        var items_json: Variant = JSON.parse_string(FileAccess.get_file_as_string(PACK_ITEMS_PATH))
        if items_json is Dictionary:
            var definitions: Variant = items_json.get("items", [])
            if definitions is Array:
                for entry_variant in definitions:
                    if entry_variant is Dictionary:
                        var entry: Dictionary = entry_variant
                        var item_id: String = str(entry.get("id", ""))
                        if item_id != "":
                            _pack_items[item_id] = entry
    if FileAccess.file_exists(PACK_MODELS_PATH):
        var models_json: Variant = JSON.parse_string(FileAccess.get_file_as_string(PACK_MODELS_PATH))
        if models_json is Dictionary:
            _equipment_models = models_json

static func _pack_path(path_from_pack: String) -> String:
    if path_from_pack.begins_with("res://"):
        return PACK_ROOT + path_from_pack.trim_prefix("res://")
    return PACK_ROOT + path_from_pack.trim_prefix("/")

static func _canonical_model_id(item_id: String) -> String:
    return str(MODEL_ALIASES.get(item_id, item_id))

static func normalize_item(item_id: String) -> String:
    if item_id == "":
        return ""
    var block_id: int = B.id_of(item_id)
    if block_id > 0:
        return B.names[block_id]
    _ensure_pack_data()
    return item_id

static func is_known_item(item_id: String) -> bool:
    if item_id == "" or PLAIN_ITEMS.has(item_id):
        return true
    if B.is_placeable_name(item_id):
        return true
    _ensure_pack_data()
    return _pack_items.has(item_id) or has_item_model(item_id)

static func item_name(item_id: String) -> String:
    if ITEM_NAMES.has(item_id):
        return str(ITEM_NAMES[item_id])
    _ensure_pack_data()
    if _pack_items.has(item_id):
        return str(_pack_items[item_id].get("name_ru", item_id))
    return B.ru_name(item_id)

static func item_kind(item_id: String) -> String:
    if PLAIN_ITEMS.has(item_id):
        return "consumable" if item_id != "pickaxe" else "tool"
    if B.is_placeable_name(item_id):
        return "block"
    _ensure_pack_data()
    if _pack_items.has(item_id):
        return str(_pack_items[item_id].get("kind", "material"))
    if has_item_model(item_id):
        return "tool" if _has_model_in_section("tools", item_id) else "armor"
    return "unknown"

static func has_item_model(item_id: String) -> bool:
    _ensure_pack_data()
    var model_id: String = _canonical_model_id(item_id)
    var tools: Dictionary = _equipment_models.get("tools", {})
    var armor: Dictionary = _equipment_models.get("armor", {})
    return tools.has(model_id) or armor.has(model_id)

static func _has_model_in_section(section: String, item_id: String) -> bool:
    _ensure_pack_data()
    var section_data: Dictionary = _equipment_models.get(section, {})
    return section_data.has(_canonical_model_id(item_id))

static func instantiate_item_model(item_id: String) -> Node3D:
    _ensure_pack_data()
    var model_id: String = _canonical_model_id(item_id)
    var section: String = "tools" if _has_model_in_section("tools", item_id) else "armor"
    var section_data: Dictionary = _equipment_models.get(section, {})
    if not section_data.has(model_id):
        return null
    var entry: Dictionary = section_data[model_id]
    var scene_path: String = _pack_path(str(entry.get("scene", "")))
    var packed: PackedScene = _model_scene_cache.get(scene_path) as PackedScene
    if packed == null:
        if not ResourceLoader.exists(scene_path):
            push_warning("Не найдена 3D-модель предмета: %s" % scene_path)
            return null
        packed = load(scene_path) as PackedScene
        if packed == null:
            push_warning("Не удалось загрузить 3D-модель предмета: %s" % scene_path)
            return null
        _model_scene_cache[scene_path] = packed
    var instance: Node = packed.instantiate()
    if instance is Node3D:
        instance.name = "Held_%s" % item_id
        return instance as Node3D
    instance.free()
    return null

static func is_flat_item(item_id: String) -> bool:
    if has_item_model(item_id):
        return true
    if PLAIN_ITEMS.has(item_id):
        return true
    var block_id: int = B.id_of(item_id)
    if block_id > 0:
        return B.render[block_id] == B.R_CROSS
    _ensure_pack_data()
    if _pack_items.has(item_id):
        return true
    return false

static func icon(item_id: String) -> Texture2D:
    if _icon_cache.has(item_id):
        return _icon_cache[item_id] as Texture2D
    var result: Texture2D = null
    if PLAIN_ITEMS.has(item_id):
        var path: String = ITEM_DIR + item_id + ".png"
        if ResourceLoader.exists(path):
            result = load(path) as Texture2D
    else:
        var block_id: int = B.id_of(item_id)
        if block_id > 0:
            if _icons_texture == null:
                _icons_texture = load(ICONS_PATH) as Texture2D
            var atlas_tex := AtlasTexture.new()
            atlas_tex.atlas = _icons_texture
            var cell: int = Atlas.ICON_SIZE
            atlas_tex.region = Rect2(float((block_id % Atlas.ICON_COLS) * cell), float((block_id / Atlas.ICON_COLS) * cell), float(cell), float(cell))
            result = atlas_tex
        else:
            _ensure_pack_data()
            if _pack_items.has(item_id):
                var entry: Dictionary = _pack_items[item_id]
                var icon_path: String = _pack_path(str(entry.get("texture_16", entry.get("texture", ""))))
                if icon_path != PACK_ROOT and ResourceLoader.exists(icon_path):
                    result = load(icon_path) as Texture2D
            if result == null and has_item_model(item_id):
                var section: String = "tools" if _has_model_in_section("tools", item_id) else "armor"
                var model_data: Dictionary = _equipment_models.get(section, {}).get(_canonical_model_id(item_id), {})
                var fallback: String = _pack_path(str(model_data.get("icon_16", "")))
                if fallback != PACK_ROOT and ResourceLoader.exists(fallback):
                    result = load(fallback) as Texture2D
    _icon_cache[item_id] = result
    return result

static func _get_atlas_image() -> Image:
    if _atlas_image == null:
        var tex: Texture2D = load(ATLAS_PATH) as Texture2D
        _atlas_image = tex.get_image()
        if _atlas_image.is_compressed():
            _atlas_image.decompress()
        _atlas_image.convert(Image.FORMAT_RGBA8)
    return _atlas_image

# Квадрат 16x16 из атласа по имени тайла.
static func tile_image(tile_name: String) -> Image:
    var index: int = int(Atlas.TILES.get(tile_name, 0))
    var size: int = Atlas.TILE_SIZE
    return _get_atlas_image().get_region(Rect2i((index % Atlas.ATLAS_COLS) * size, (index / Atlas.ATLAS_COLS) * size, size, size))

static func tile_texture(tile_name: String) -> Texture2D:
    if _tile_cache.has(tile_name):
        return _tile_cache[tile_name] as Texture2D
    var tex: Texture2D = ImageTexture.create_from_image(tile_image(tile_name))
    _tile_cache[tile_name] = tex
    return tex

# Изображение для плоской модели в руке.
static func flat_image(item_id: String) -> Image:
    var block_id: int = B.id_of(item_id)
    if block_id > 0:
        return tile_image(B.tile_name(block_id, 1))
    var tex: Texture2D = icon(item_id)
    if tex == null:
        return null
    var img: Image = tex.get_image()
    if img.is_compressed():
        img.decompress()
    img.convert(Image.FORMAT_RGBA8)
    return img

static func ui_texture(texture_name: String) -> Texture2D:
    var path: String = UI_DIR + texture_name + ".png"
    if not ResourceLoader.exists(path):
        return null
    return load(path) as Texture2D

static func max_stack(item_id: String) -> int:
    if item_id == "pickaxe" or has_item_model(item_id):
        return 1
    _ensure_pack_data()
    if _pack_items.has(item_id):
        var entry: Dictionary = _pack_items[item_id]
        var kind: String = str(entry.get("kind", "material"))
        if kind == "tool" or kind == "armor":
            return 1
        return maxi(1, int(entry.get("stack_size", 64)))
    return 64

static func _item_definition(item_id: String) -> Dictionary:
    _ensure_pack_data()
    var entry: Variant = _pack_items.get(item_id, {})
    return entry if entry is Dictionary else {}

static func tool_type(item_id: String) -> String:
    if item_id == "pickaxe":
        return "pickaxe"
    return str(_item_definition(item_id).get("tool_type", ""))

static func mining_speed(item_id: String) -> float:
    if item_id == "pickaxe":
        return 6.0
    var speed: float = float(_item_definition(item_id).get("mining_speed", 1.0))
    return maxf(1.0, speed)

static func mining_tier(item_id: String) -> int:
    if item_id == "pickaxe":
        return 2
    return int(_item_definition(item_id).get("mining_tier", -1))

static func attack_damage(item_id: String) -> float:
    if item_id == "pickaxe":
        return 4.0
    return maxf(0.0, float(_item_definition(item_id).get("attack_damage", 1.0)))

static func durability(item_id: String) -> int:
    return maxi(0, int(_item_definition(item_id).get("durability", 0)))

static func is_armor_item(item_id: String) -> bool:
    return item_kind(item_id) == "armor" or _has_model_in_section("armor", item_id)

static func armor_slot(item_id: String) -> int:
    if not is_armor_item(item_id):
        return -1
    if item_id.ends_with("_helmet"):
        return 0
    if item_id.ends_with("_chestplate"):
        return 1
    if item_id.ends_with("_leggings"):
        return 2
    if item_id.ends_with("_boots"):
        return 3
    return -1

static func armor_points(item_id: String) -> int:
    if not is_armor_item(item_id):
        return 0
    var definition: Dictionary = _item_definition(item_id)
    if definition.has("defense"):
        return maxi(0, int(definition["defense"]))
    var material: String = item_id.trim_suffix("_helmet").trim_suffix("_chestplate").trim_suffix("_leggings").trim_suffix("_boots")
    match material:
        "leather": return 2
        "gold", "copper", "bronze", "silver", "nickel": return 3
        "chainmail", "iron", "steel", "titanium": return 4
        "diamond", "emerald", "cobalt", "sapphire", "ruby": return 5
        "netherite", "chronosteel", "astralite", "echorite", "void", "shadow": return 6
    return 2

static func block_kind(item_id: String) -> String:
    if B.is_placeable_name(item_id):
        return item_id
    return ""

static func drop_for_block(kind: String) -> String:
    match kind:
        "grass":
            return "dirt"
        "stone":
            return "cobblestone"
        "water", "air", "bedrock":
            return ""
    if kind.ends_with("_leaves"):
        var roll: float = randf()
        if roll < 0.12:
            return "berries"
        if roll < 0.20:
            return kind.trim_suffix("_leaves") + "_sapling"
        return kind
    if B.is_placeable_name(kind):
        return kind
    return ""

# Предметы для творческого инвентаря: [id, категория]. Порядок старых ID сохраняется.
static func creative_entries() -> Array:
    var out: Array = []
    var seen: Dictionary = {}
    for plain in PLAIN_ITEMS:
        out.append([plain, "misc"])
        seen[str(plain)] = true
    for block_name in B.creative_items():
        var block_id: int = B.id_of(str(block_name))
        out.append([str(block_name), B.categories[block_id]])
        seen[str(block_name)] = true
    _ensure_pack_data()
    for item_id_variant in _pack_items.keys():
        var item_id: String = str(item_id_variant)
        if seen.has(item_id) or B.is_placeable_name(item_id):
            continue
        var kind: String = str(_pack_items[item_id].get("kind", "material"))
        var category: String = "misc"
        if kind == "tool":
            category = "tools"
        elif kind == "armor":
            category = "armor"
        out.append([item_id, category])
        seen[item_id] = true
    return out
