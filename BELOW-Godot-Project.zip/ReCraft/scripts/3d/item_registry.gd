extends RefCounted
# Реестр обычных предметов (инструменты, броня, материалы, еда). Блоки живут в block_registry.gd.
# Данные сгенерированы tools/build_assets.py из набора текстур (item_table.gd).
#
# Инструмент с износом хранится в инвентаре как "iron_pickaxe@12" (12 - полученный износ).

const Table = preload("res://scripts/3d/item_table.gd")
const Atlas = preload("res://scripts/3d/atlas_data.gd")

const F_NAME: int = 1
const F_TILE: int = 2
const F_KIND: int = 3
const F_TOOL: int = 4
const F_MATERIAL: int = 5
const F_TIER: int = 6
const F_SPEED: int = 7
const F_DAMAGE: int = 8
const F_DURABILITY: int = 9
const F_SLOT: int = 10
const F_DEFENSE: int = 11
const F_STACK: int = 12

const LEGACY: Dictionary = {
    "pickaxe": "iron_pickaxe",
    "wood": "oak_log",
    "leaves": "oak_leaves",
    "planks": "oak_planks"
}

static var rows: Dictionary = {}
static var order: PackedStringArray = PackedStringArray()

static func setup() -> void:
    if not rows.is_empty():
        return
    for row_variant in Table.TABLE:
        var row: Array = row_variant
        rows[str(row[0])] = row
        order.append(str(row[0]))

static func base_id(item_id: String) -> String:
    var at: int = item_id.find("@")
    if at < 0:
        return item_id
    return item_id.substr(0, at)

static func wear_of(item_id: String) -> int:
    var at: int = item_id.find("@")
    if at < 0:
        return 0
    return int(item_id.substr(at + 1))

static func with_wear(item_id: String, wear: int) -> String:
    var base: String = base_id(item_id)
    if wear <= 0:
        return base
    return base + "@" + str(wear)

static func has(item_id: String) -> bool:
    setup()
    return rows.has(base_id(item_id))

static func normalize(item_id: String) -> String:
    setup()
    var base: String = base_id(item_id)
    if LEGACY.has(base) and not rows.has(base):
        return str(LEGACY[base]) + item_id.substr(base.length())
    return item_id

static func _field(item_id: String, field: int, fallback: Variant) -> Variant:
    setup()
    var row: Array = rows.get(base_id(item_id), [])
    if row.is_empty():
        return fallback
    return row[field]

static func item_name(item_id: String) -> String:
    return str(_field(item_id, F_NAME, item_id))

static func tile(item_id: String) -> String:
    return str(_field(item_id, F_TILE, ""))

static func kind(item_id: String) -> String:
    return str(_field(item_id, F_KIND, ""))

static func tool_type(item_id: String) -> String:
    return str(_field(item_id, F_TOOL, ""))

static func material(item_id: String) -> String:
    return str(_field(item_id, F_MATERIAL, ""))

static func tier(item_id: String) -> int:
    return int(_field(item_id, F_TIER, 0))

static func speed(item_id: String) -> float:
    return float(_field(item_id, F_SPEED, 1.0))

static func damage(item_id: String) -> int:
    return int(_field(item_id, F_DAMAGE, 1))

static func durability(item_id: String) -> int:
    return int(_field(item_id, F_DURABILITY, 0))

static func armor_slot(item_id: String) -> String:
    return str(_field(item_id, F_SLOT, ""))

static func defense(item_id: String) -> int:
    return int(_field(item_id, F_DEFENSE, 0))

static func stack_size(item_id: String) -> int:
    return int(_field(item_id, F_STACK, 64))

static func is_tool(item_id: String) -> bool:
    return kind(item_id) == "tool"

static func is_armor(item_id: String) -> bool:
    return kind(item_id) == "armor"

static func is_food(item_id: String) -> bool:
    return kind(item_id) == "food"

# Доля оставшейся прочности 0..1 (1 для предметов без износа).
static func durability_left(item_id: String) -> float:
    var total: int = durability(item_id)
    if total <= 0:
        return 1.0
    return clampf(1.0 - float(wear_of(item_id)) / float(total), 0.0, 1.0)

static func has_durability(item_id: String) -> bool:
    return durability(item_id) > 0
