extends RefCounted
# Day/night model with Minecraft's timeline: 24000 ticks per day.
# tick 0 = sunrise, 6000 = noon, 12000 = sunset, 18000 = midnight.
# Everything the renderer needs (sun/moon direction, sky and fog colours, block light tint)
# is derived continuously from the tick, so all transitions are smooth.

const TICKS_PER_DAY: float = 24000.0
const DAY_LENGTH_SECONDS: float = 1200.0 # 20 real minutes, like Minecraft. Lower it for faster days.
const START_TICK: float = 1000.0

const DAY_TOP := Color(0.42, 0.60, 1.0)
const DAY_HORIZON := Color(0.74, 0.85, 1.0)
const NIGHT_TOP := Color(0.012, 0.016, 0.050)
const NIGHT_HORIZON := Color(0.035, 0.045, 0.100)
const TWILIGHT_GLOW := Color(1.0, 0.46, 0.20)
const DAY_LIGHT := Color(1.0, 1.0, 1.0)
const NIGHT_LIGHT := Color(0.20, 0.25, 0.44)
const TWILIGHT_LIGHT := Color(1.0, 0.80, 0.66)
const CLOUD_DAY := Color(1.0, 1.0, 1.0)
const CLOUD_NIGHT := Color(0.10, 0.12, 0.22)
const CLOUD_TWILIGHT := Color(1.0, 0.70, 0.60)

var ticks: float = START_TICK
var day_count: int = 0

func advance(delta: float) -> void:
    ticks += delta * (TICKS_PER_DAY / DAY_LENGTH_SECONDS)
    while ticks >= TICKS_PER_DAY:
        ticks -= TICKS_PER_DAY
        day_count += 1

func set_time(new_ticks: float, new_day_count: int = 0) -> void:
    ticks = fposmod(new_ticks, TICKS_PER_DAY)
    day_count = maxi(0, new_day_count)

func sun_angle() -> float:
    return ticks / TICKS_PER_DAY * TAU

func sun_direction() -> Vector3:
    var angle: float = sun_angle()
    return Vector3(cos(angle), sin(angle), 0.0)

func sun_elevation() -> float:
    return sin(sun_angle())

func moon_phase() -> int:
    return day_count % 8

func daylight() -> float:
    # 0 = full night, 1 = full day; wide smooth transition around the horizon.
    return smoothstep(-0.20, 0.30, sun_elevation())

func twilight() -> float:
    var e: float = sun_elevation() / 0.24
    return exp(-e * e)

func star_visibility() -> float:
    return 1.0 - smoothstep(-0.26, 0.04, sun_elevation())

func sky_top_color() -> Color:
    var c: Color = NIGHT_TOP.lerp(DAY_TOP, daylight())
    return c.lerp(Color(0.28, 0.27, 0.52), twilight() * 0.30)

func sky_horizon_color() -> Color:
    var c: Color = NIGHT_HORIZON.lerp(DAY_HORIZON, daylight())
    return c.lerp(Color(0.95, 0.62, 0.45), twilight() * 0.38)

func fog_color() -> Color:
    return sky_horizon_color()

func sky_light_tint() -> Color:
    var c: Color = NIGHT_LIGHT.lerp(DAY_LIGHT, daylight())
    var warm: Color = Color(c.r * TWILIGHT_LIGHT.r, c.g * TWILIGHT_LIGHT.g, c.b * TWILIGHT_LIGHT.b)
    return c.lerp(warm, twilight() * 0.65)

func sky_brightness() -> float:
    # Scalar version of the light tint, used for cave dimming and effects.
    return lerpf(0.22, 1.0, daylight())

func cloud_tint() -> Color:
    var c: Color = CLOUD_NIGHT.lerp(CLOUD_DAY, daylight())
    return c.lerp(CLOUD_TWILIGHT, twilight() * 0.6)

func star_basis() -> Basis:
    return Basis(Vector3(0.0, 0.0, 1.0), -sun_angle())

func clock_text() -> String:
    # Minecraft clock: tick 0 is 06:00.
    var hours: float = fposmod(ticks / 1000.0 + 6.0, 24.0)
    var h: int = int(floor(hours))
    var m: int = int(floor((hours - float(h)) * 60.0))
    return "%02d:%02d" % [h, m]
