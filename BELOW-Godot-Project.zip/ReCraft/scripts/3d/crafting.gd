extends RefCounted
# Сетка крафта 3x3 с рецептами из набора (табличные, бесформенные), переплавкой сырья и улучшением до незерита.
# Ингредиент "planks" подходит для досок любого дерева.
# Переплавка: сырьё + уголь в сетке даёт слиток (отдельной печи в игре нет).
# Улучшение: шаблон + алмазный предмет + незеритовый слиток.

const I = preload("res://scripts/3d/item_registry.gd")
const B = preload("res://scripts/3d/block_registry.gd")
const T = preload("res://scripts/3d/item_table.gd")

static var _shaped: Array = []

static func _setup() -> void:
    if not _shaped.is_empty():
        return
    for recipe_variant in T.SHAPED:
        var recipe: Array = recipe_variant
        var pattern: Array = recipe[1]
        var key: Dictionary = recipe[2]
        var min_r: int = 3
        var max_r: int = -1
        var min_c: int = 3
        var max_c: int = -1
        for r in range(3):
            var line: String = str(pattern[r])
            for c in range(3):
                if line.substr(c, 1) != " ":
                    min_r = mini(min_r, r)
                    max_r = maxi(max_r, r)
                    min_c = mini(min_c, c)
                    max_c = maxi(max_c, c)
        if max_r < 0:
            continue
        var cells: Array = []
        for r in range(min_r, max_r + 1):
            var row: Array = []
            var line2: String = str(pattern[r])
            for c in range(min_c, max_c + 1):
                var ch: String = line2.substr(c, 1)
                row.append("" if ch == " " else str(key.get(ch, "?")))
            cells.append(row)
        _shaped.append({"id": str(recipe[0]), "h": max_r - min_r + 1, "w": max_c - min_c + 1, "cells": cells, "out": str(recipe[3]), "count": int(recipe[4])})

static func _token_matches(token: String, item_id: String) -> bool:
    var base: String = I.base_id(item_id)
    if token == "planks":
        return base.ends_with("_planks")
    return token == base

static func _output_exists(item_id: String) -> bool:
    return I.has(item_id) or B.is_placeable_name(item_id)

static func planks_for_log(item_id: String) -> String:
    var base: String = I.base_id(item_id)
    var species: String = ""
    if base.ends_with("_stripped_log"):
        species = base.trim_suffix("_stripped_log")
    elif base.ends_with("_log"):
        species = base.trim_suffix("_log")
    if species == "":
        return ""
    var planks: String = species + "_planks"
    return planks if B.id_of(planks) > 0 else ""

# grid: 9 идентификаторов предметов (пустая строка - пусто). Возвращает {} или
# {"id": предмет, "count": число, "consume": [индексы слотов, из каждого списывается 1]}.
static func find(grid: Array) -> Dictionary:
    _setup()
    var used: Array = []
    for i in range(9):
        if str(grid[i]) != "":
            used.append(i)
    if used.is_empty():
        return {}

    if used.size() == 1:
        var only: String = str(grid[used[0]])
        var planks: String = planks_for_log(only)
        if planks != "":
            return {"id": planks, "count": 4, "consume": used}

    # табличные рецепты (с зеркальным отражением по горизонтали)
    var min_r: int = 3
    var max_r: int = -1
    var min_c: int = 3
    var max_c: int = -1
    for index in used:
        var r: int = int(index) / 3
        var c: int = int(index) % 3
        min_r = mini(min_r, r)
        max_r = maxi(max_r, r)
        min_c = mini(min_c, c)
        max_c = maxi(max_c, c)
    var gh: int = max_r - min_r + 1
    var gw: int = max_c - min_c + 1
    for recipe_variant in _shaped:
        var recipe: Dictionary = recipe_variant
        if int(recipe["h"]) != gh or int(recipe["w"]) != gw or not _output_exists(str(recipe["out"])):
            continue
        for mirrored in [false, true]:
            if _shaped_matches(grid, recipe, min_r, min_c, mirrored):
                return {"id": str(recipe["out"]), "count": int(recipe["count"]), "consume": used}

    # бесформенные
    for recipe_variant2 in T.SHAPELESS:
        var recipe2: Array = recipe_variant2
        var ingredients: Array = recipe2[1]
        if ingredients.size() != used.size() or not _output_exists(str(recipe2[2])):
            continue
        var taken: Array = []
        var ok: bool = true
        for token in ingredients:
            var found: bool = false
            for index2 in used:
                if taken.has(index2):
                    continue
                if _token_matches(str(token), str(grid[index2])):
                    taken.append(index2)
                    found = true
                    break
            if not found:
                ok = false
                break
        if ok:
            return {"id": str(recipe2[2]), "count": int(recipe2[3]), "consume": used}

    # переплавка: сырьё + уголь
    if used.size() == 2:
        var a: String = I.base_id(str(grid[used[0]]))
        var b: String = I.base_id(str(grid[used[1]]))
        for smelt_variant in T.SMELTING:
            var smelt: Array = smelt_variant
            var raw: String = str(smelt[0])
            if (a == raw and b == "coal") or (b == raw and a == "coal"):
                return {"id": str(smelt[1]), "count": int(smelt[2]), "consume": used}

    # улучшение до незерита
    if used.size() == 3:
        for smith_variant in T.SMITHING:
            var smith: Array = smith_variant
            var picked: Array = []
            var parts: Array = [str(smith[0]), str(smith[1]), str(smith[2])]
            var good: bool = true
            for part in parts:
                var hit: bool = false
                for index3 in used:
                    if picked.has(index3):
                        continue
                    if I.base_id(str(grid[index3])) == str(part):
                        picked.append(index3)
                        hit = true
                        break
                if not hit:
                    good = false
                    break
            if good:
                return {"id": str(smith[3]), "count": 1, "consume": used}
    return {}

static func _shaped_matches(grid: Array, recipe: Dictionary, row0: int, col0: int, mirrored: bool) -> bool:
    var cells: Array = recipe["cells"]
    var h: int = int(recipe["h"])
    var w: int = int(recipe["w"])
    for r in range(h):
        var row: Array = cells[r]
        for c in range(w):
            var pc: int = (w - 1 - c) if mirrored else c
            var token: String = str(row[pc])
            var have: String = str(grid[(row0 + r) * 3 + (col0 + c)])
            if token == "":
                if have != "":
                    return false
            elif have == "" or not _token_matches(token, have):
                return false
    return true
