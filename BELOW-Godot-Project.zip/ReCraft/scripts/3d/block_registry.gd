extends RefCounted
# Реестр блоков: ID (байт в данных чанка), свойства, UV в атласе, названия.
# Источник данных - сгенерированный scripts/3d/block_table.gd (tools/build_assets.py).

const Table = preload("res://scripts/3d/block_table.gd")
const Atlas = preload("res://scripts/3d/atlas_data.gd")

const AIR: int = 0
const BEDROCK: int = 1
const STONE: int = 2
const COBBLESTONE: int = 3
const DIRT: int = 4
const GRASS: int = 5
const SAND: int = 6
const GRAVEL: int = 7
const WATER: int = 8

const R_NONE: int = 0
const R_SOLID: int = 1
const R_LEAVES: int = 2
const R_CROSS: int = 3
const R_WATER: int = 4

const LEGACY_ALIASES: Dictionary = {
    "wood": "oak_log",
    "leaves": "oak_leaves",
    "ancient": "cobblestone"
}

static var count: int = 0
static var names: PackedStringArray = PackedStringArray()
static var ru_names: PackedStringArray = PackedStringArray()
static var render: PackedByteArray = PackedByteArray()       # тип отрисовки
static var opaque: PackedByteArray = PackedByteArray()       # 1 = непрозрачный куб (скрывает соседние грани)
static var solid: PackedByteArray = PackedByteArray()        # 1 = блокирует движение
static var blocks_sky: PackedByteArray = PackedByteArray()   # 1 = гасит небесный свет (непрозрачные кубы и вода)
static var needs_pick: PackedByteArray = PackedByteArray()
static var hardness: PackedFloat32Array = PackedFloat32Array()
static var sounds: PackedStringArray = PackedStringArray()
static var categories: PackedStringArray = PackedStringArray()
static var tiles: PackedInt32Array = PackedInt32Array()      # 3 тайла на блок: верх, бок, низ
static var uv_u: PackedFloat32Array = PackedFloat32Array()   # 3 значения на блок: левый край верх/бок/низ
static var uv_v: PackedFloat32Array = PackedFloat32Array()
static var uv_w: float = 0.0
static var uv_h: float = 0.0
static var name_to_id: Dictionary = {}
static var tile_names: PackedStringArray = PackedStringArray()

static func setup() -> void:
    if count > 0:
        return
    var table: Array = Table.TABLE
    count = table.size()
    names.resize(count)
    ru_names.resize(count)
    render.resize(count)
    opaque.resize(count)
    solid.resize(count)
    blocks_sky.resize(count)
    needs_pick.resize(count)
    hardness.resize(count)
    sounds.resize(count)
    categories.resize(count)
    tiles.resize(count * 3)
    uv_u.resize(count * 3)
    uv_v.resize(count * 3)
    tile_names.resize(Atlas.TILES.size())
    for tile_key in Atlas.TILES.keys():
        tile_names[int(Atlas.TILES[tile_key])] = str(tile_key)
    var atlas_w: float = float(Atlas.ATLAS_COLS * Atlas.TILE_SIZE)
    var atlas_h: float = float(Atlas.ATLAS_ROWS * Atlas.TILE_SIZE)
    uv_w = float(Atlas.TILE_SIZE) / atlas_w
    uv_h = float(Atlas.TILE_SIZE) / atlas_h
    for i in range(count):
        var row: Array = table[i]
        names[i] = str(row[0])
        ru_names[i] = str(row[1])
        var kind: int = int(row[8])
        render[i] = kind
        opaque[i] = 1 if kind == R_SOLID else 0
        solid[i] = 1 if (kind == R_SOLID or kind == R_LEAVES) else 0
        blocks_sky[i] = 1 if (kind == R_SOLID or kind == R_WATER) else 0
        needs_pick[i] = int(row[6])
        hardness[i] = float(row[5])
        sounds[i] = str(row[7])
        categories[i] = str(row[9])
        name_to_id[names[i]] = i
        for f in range(3):
            var tile_index: int = int(Atlas.TILES[str(row[2 + f])])
            tiles[i * 3 + f] = tile_index
            uv_u[i * 3 + f] = float(tile_index % Atlas.ATLAS_COLS) * uv_w
            uv_v[i * 3 + f] = float(tile_index / Atlas.ATLAS_COLS) * uv_h

static func id_of(block_name: String) -> int:
    setup()
    if name_to_id.has(block_name):
        return int(name_to_id[block_name])
    var alias: String = str(LEGACY_ALIASES.get(block_name, ""))
    if alias != "" and name_to_id.has(alias):
        return int(name_to_id[alias])
    return -1

static func name_of(block_id: int) -> String:
    setup()
    if block_id < 0 or block_id >= count:
        return "air"
    return names[block_id]

static func ru_name(block_name: String) -> String:
    var block_id: int = id_of(block_name)
    if block_id < 0:
        return block_name
    return ru_names[block_id]

static func is_placeable_name(block_name: String) -> bool:
    var block_id: int = id_of(block_name)
    if block_id <= 0:
        return false
    var kind: int = render[block_id]
    return kind != R_NONE and kind != R_WATER and block_id != BEDROCK

static func is_ore_name(block_name: String) -> bool:
    var block_id: int = id_of(block_name)
    return block_id > 0 and categories[block_id] == "ore"

static func tile_name(block_id: int, face: int) -> String:
    setup()
    if block_id < 0 or block_id >= count:
        return "stone"
    return tile_names[tiles[block_id * 3 + face]]

# Все блоки, которые можно положить в инвентарь, для творческого режима.
static func creative_items() -> Array:
    setup()
    var out: Array = []
    for i in range(1, count):
        if i == BEDROCK:
            continue
        var kind: int = render[i]
        if kind == R_NONE or kind == R_WATER:
            continue
        out.append(names[i])
    return out
