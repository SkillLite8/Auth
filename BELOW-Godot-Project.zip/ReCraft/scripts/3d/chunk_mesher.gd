extends RefCounted
# Строит меши секций 16x16x16 из данных чанка. Работает в рабочем потоке: один экземпляр на задачу.
# Грани, закрытые непрозрачными соседями, не создаются; в вершинный цвет запекаются
#   RGB = оттенок грани * ambient occlusion,   A = небесный свет (1 на открытом небе, меньше под землёй).

const B = preload("res://scripts/3d/block_registry.gd")

const COL_H: int = 384
const DX: int = 324   # шаг по X в «подушке» 18x18x18
const DZ: int = 18
const DY: int = 1

const FACE_SHADE: Array = [1.0, 0.66, 0.84, 0.84, 0.72, 0.72]
const AO_LEVELS: Array = [0.66, 0.78, 0.90, 1.0]
const SKY_FALLOFF: float = 0.035

# Грани: 0 верх, 1 низ, 2 юг(+z), 3 север(-z), 4 восток(+x), 5 запад(-x)
const FACE_CORNERS: Array = [
    [Vector3(-0.5, 0.5, -0.5), Vector3(0.5, 0.5, -0.5), Vector3(0.5, 0.5, 0.5), Vector3(-0.5, 0.5, 0.5)],
    [Vector3(-0.5, -0.5, 0.5), Vector3(0.5, -0.5, 0.5), Vector3(0.5, -0.5, -0.5), Vector3(-0.5, -0.5, -0.5)],
    [Vector3(-0.5, 0.5, 0.5), Vector3(0.5, 0.5, 0.5), Vector3(0.5, -0.5, 0.5), Vector3(-0.5, -0.5, 0.5)],
    [Vector3(0.5, 0.5, -0.5), Vector3(-0.5, 0.5, -0.5), Vector3(-0.5, -0.5, -0.5), Vector3(0.5, -0.5, -0.5)],
    [Vector3(0.5, 0.5, 0.5), Vector3(0.5, 0.5, -0.5), Vector3(0.5, -0.5, -0.5), Vector3(0.5, -0.5, 0.5)],
    [Vector3(-0.5, 0.5, -0.5), Vector3(-0.5, 0.5, 0.5), Vector3(-0.5, -0.5, 0.5), Vector3(-0.5, -0.5, -0.5)]
]
const FACE_NORMAL_DELTA: Array = [1, -1, 18, -18, 324, -324]
const FACE_NORMAL_OFFSET: Array = [Vector3i(0, 1, 0), Vector3i(0, -1, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1), Vector3i(1, 0, 0), Vector3i(-1, 0, 0)]
const CORNER_UV: Array = [Vector2(0.0, 0.0), Vector2(1.0, 0.0), Vector2(1.0, 1.0), Vector2(0.0, 1.0)]

class Builder:
    extends RefCounted
    var v: PackedVector3Array = PackedVector3Array()
    var uv: PackedVector2Array = PackedVector2Array()
    var c: PackedColorArray = PackedColorArray()
    var i: PackedInt32Array = PackedInt32Array()

    func is_empty() -> bool:
        return v.is_empty()

    func to_dict() -> Dictionary:
        return {"v": v, "uv": uv, "c": c, "i": i}

# Для каждой грани и угла: смещения [сторона1, сторона2, угол] относительно воздушной клетки.
var ao_offsets: Array = []
var render: PackedByteArray
var opaque: PackedByteArray
var uv_u: PackedFloat32Array
var uv_v: PackedFloat32Array
var uv_w: float
var uv_h: float
var ob := Builder.new()
var cb := Builder.new()
var wb := Builder.new()

func _init() -> void:
    B.setup()
    render = B.render
    opaque = B.opaque
    uv_u = B.uv_u
    uv_v = B.uv_v
    uv_w = B.uv_w
    uv_h = B.uv_h
    for face in range(6):
        var per_corner: Array = []
        var n_off: Vector3i = FACE_NORMAL_OFFSET[face]
        for corner in range(4):
            var p: Vector3 = FACE_CORNERS[face][corner]
            var sx: int = 0 if n_off.x != 0 else (1 if p.x > 0.0 else -1)
            var sy: int = 0 if n_off.y != 0 else (1 if p.y > 0.0 else -1)
            var sz: int = 0 if n_off.z != 0 else (1 if p.z > 0.0 else -1)
            var n_delta: int = int(FACE_NORMAL_DELTA[face])
            var side1: int = 0
            var side2: int = 0
            if n_off.y != 0:
                side1 = n_delta + sx * DX
                side2 = n_delta + sz * DZ
            elif n_off.x != 0:
                side1 = n_delta + sy * DY
                side2 = n_delta + sz * DZ
            else:
                side1 = n_delta + sx * DX
                side2 = n_delta + sy * DY
            per_corner.append([side1, side2, side1 + side2 - n_delta])
        ao_offsets.append(per_corner)

# ------------------------------------------------------------------ padded copies

func _build_padded(blocks9: Array, sy: int) -> PackedByteArray:
    var pad := PackedByteArray()
    var y_lo: int = sy * 16 - 1
    var y_hi: int = sy * 16 + 17
    for px in range(-1, 17):
        var cdx: int = 0
        if px < 0:
            cdx = -1
        elif px > 15:
            cdx = 1
        var lx: int = px - cdx * 16
        for pz in range(-1, 17):
            var cdz: int = 0
            if pz < 0:
                cdz = -1
            elif pz > 15:
                cdz = 1
            var lz: int = pz - cdz * 16
            var src: PackedByteArray = blocks9[(cdx + 1) + (cdz + 1) * 3]
            var base: int = (lz * 16 + lx) * COL_H
            if y_lo < 0:
                pad.append(B.BEDROCK)
                pad.append_array(src.slice(base, base + y_hi))
            elif y_hi > COL_H:
                pad.append_array(src.slice(base + y_lo, base + COL_H))
                pad.append(0)
            else:
                pad.append_array(src.slice(base + y_lo, base + y_hi))
    return pad

func _build_tops(tops9: Array) -> PackedInt32Array:
    var out := PackedInt32Array()
    out.resize(324)
    for px in range(-1, 17):
        var cdx: int = 0
        if px < 0:
            cdx = -1
        elif px > 15:
            cdx = 1
        var lx: int = px - cdx * 16
        for pz in range(-1, 17):
            var cdz: int = 0
            if pz < 0:
                cdz = -1
            elif pz > 15:
                cdz = 1
            var lz: int = pz - cdz * 16
            var src: PackedInt32Array = tops9[(cdx + 1) + (cdz + 1) * 3]
            out[(px + 1) * 18 + (pz + 1)] = src[lz * 16 + lx]
    return out

# ------------------------------------------------------------------ public

# blocks9/tops9: массивы из 9 элементов, индекс (dx+1) + (dz+1)*3, центр = 4.
# sections: список индексов секций (0..23). Возвращает {секция: {"o":.., "c":.., "w":..}}.
func mesh_chunk(blocks9: Array, tops9: Array, sections: Array, max_y: int, min_y: int) -> Dictionary:
    var result: Dictionary = {}
    var tops: PackedInt32Array = _build_tops(tops9)
    for sy_variant in sections:
        var sy: int = int(sy_variant)
        var y0: int = min_y + sy * 16
        var entry: Dictionary = {}
        if y0 <= max_y + 1:
            var pad: PackedByteArray = _build_padded(blocks9, sy)
            _mesh_section(pad, tops, y0)
            if not ob.is_empty():
                entry["o"] = ob.to_dict()
            if not cb.is_empty():
                entry["c"] = cb.to_dict()
            if not wb.is_empty():
                entry["w"] = wb.to_dict()
            ob = Builder.new()
            cb = Builder.new()
            wb = Builder.new()
        result[sy] = entry
    return result

# ------------------------------------------------------------------ core

func _mesh_section(pad: PackedByteArray, tops: PackedInt32Array, y0: int) -> void:
    for lx in range(16):
        for lz in range(16):
            var col: int = (lx + 1) * DX + (lz + 1) * DZ
            var top_here: int = tops[(lx + 1) * 18 + (lz + 1)]
            for ly in range(16):
                var idx: int = col + ly + 1
                var b: int = pad[idx]
                if b == 0:
                    continue
                var kind: int = render[b]
                if kind == B.R_SOLID:
                    _solid_block(pad, tops, idx, b, lx, ly, lz, y0)
                elif kind == B.R_LEAVES:
                    _leaves_block(pad, tops, idx, b, lx, ly, lz, y0)
                elif kind == B.R_CROSS:
                    _cross_block(b, lx, ly, lz, y0, top_here)
                elif kind == B.R_WATER:
                    _water_block(pad, tops, idx, b, lx, ly, lz, y0)

func _sky_for(tops: PackedInt32Array, lx: int, lz: int, face: int, air_y: int) -> float:
    var px: int = lx
    var pz: int = lz
    if face == 2:
        pz += 1
    elif face == 3:
        pz -= 1
    elif face == 4:
        px += 1
    elif face == 5:
        px -= 1
    var depth: int = tops[(px + 1) * 18 + (pz + 1)] - air_y
    if depth <= 0:
        return 1.0
    return maxf(0.0, 1.0 - float(depth) * SKY_FALLOFF)

func _solid_block(pad: PackedByteArray, tops: PackedInt32Array, idx: int, b: int, lx: int, ly: int, lz: int, y0: int) -> void:
    for face in range(6):
        var n_delta: int = FACE_NORMAL_DELTA[face]
        var air_idx: int = idx + n_delta
        if opaque[pad[air_idx]] == 1:
            continue
        var shade: float = FACE_SHADE[face]
        var sky: float = _sky_for(tops, lx, lz, face, y0 + ly + FACE_NORMAL_OFFSET[face].y)
        var face_kind: int = 0 if face == 0 else (2 if face == 1 else 1)
        var u0: float = uv_u[b * 3 + face_kind]
        var v0: float = uv_v[b * 3 + face_kind]
        var offs: Array = ao_offsets[face]
        var ao: Array = [0, 0, 0, 0]
        for corner in range(4):
            var o: Array = offs[corner]
            var s1: int = opaque[pad[air_idx + int(o[0]) - n_delta]]
            var s2: int = opaque[pad[air_idx + int(o[1]) - n_delta]]
            var cc: int = opaque[pad[air_idx + int(o[2]) - n_delta]]
            if s1 == 1 and s2 == 1:
                ao[corner] = 0
            else:
                ao[corner] = 3 - (s1 + s2 + cc)
        _emit_quad(ob, face, lx, y0 + ly, lz, u0, v0, shade, sky, ao, 0.0)

func _leaves_block(pad: PackedByteArray, tops: PackedInt32Array, idx: int, b: int, lx: int, ly: int, lz: int, y0: int) -> void:
    for face in range(6):
        var n_delta: int = FACE_NORMAL_DELTA[face]
        var nb: int = pad[idx + n_delta]
        if opaque[nb] == 1 or render[nb] == B.R_LEAVES:
            continue
        var shade: float = FACE_SHADE[face]
        var sky: float = _sky_for(tops, lx, lz, face, y0 + ly + FACE_NORMAL_OFFSET[face].y)
        var face_kind: int = 0 if face == 0 else (2 if face == 1 else 1)
        _emit_quad(cb, face, lx, y0 + ly, lz, uv_u[b * 3 + face_kind], uv_v[b * 3 + face_kind], shade, sky, [3, 3, 3, 3], 0.0)

func _water_block(pad: PackedByteArray, tops: PackedInt32Array, idx: int, b: int, lx: int, ly: int, lz: int, y0: int) -> void:
    var above_water: bool = pad[idx + DY] == b
    var drop: float = 0.0 if above_water else -0.1
    for face in range(6):
        var n_delta: int = FACE_NORMAL_DELTA[face]
        var nb: int = pad[idx + n_delta]
        if nb == b or opaque[nb] == 1:
            continue
        var shade: float = FACE_SHADE[face]
        var sky: float = _sky_for(tops, lx, lz, face, y0 + ly + FACE_NORMAL_OFFSET[face].y)
        _emit_quad(wb, face, lx, y0 + ly, lz, uv_u[b * 3], uv_v[b * 3], shade, sky, [3, 3, 3, 3], drop)

func _cross_block(b: int, lx: int, ly: int, lz: int, y0: int, top_y: int) -> void:
    var depth: int = top_y - (y0 + ly)
    var sky: float = 1.0 if depth <= 0 else maxf(0.0, 1.0 - float(depth) * SKY_FALLOFF)
    var u0: float = uv_u[b * 3 + 1]
    var v0: float = uv_v[b * 3 + 1]
    var col := Color(0.95, 0.95, 0.95, sky)
    var cx: float = float(lx)
    var cy: float = float(y0 + ly)
    var cz: float = float(lz)
    var base: int = cb.v.size()
    # диагональ 1
    cb.v.append(Vector3(cx - 0.5, cy + 0.5, cz - 0.5))
    cb.v.append(Vector3(cx + 0.5, cy + 0.5, cz + 0.5))
    cb.v.append(Vector3(cx + 0.5, cy - 0.5, cz + 0.5))
    cb.v.append(Vector3(cx - 0.5, cy - 0.5, cz - 0.5))
    # диагональ 2
    cb.v.append(Vector3(cx + 0.5, cy + 0.5, cz - 0.5))
    cb.v.append(Vector3(cx - 0.5, cy + 0.5, cz + 0.5))
    cb.v.append(Vector3(cx - 0.5, cy - 0.5, cz + 0.5))
    cb.v.append(Vector3(cx + 0.5, cy - 0.5, cz - 0.5))
    for k in range(2):
        cb.uv.append(Vector2(u0, v0))
        cb.uv.append(Vector2(u0 + uv_w, v0))
        cb.uv.append(Vector2(u0 + uv_w, v0 + uv_h))
        cb.uv.append(Vector2(u0, v0 + uv_h))
    for k in range(8):
        cb.c.append(col)
    for k in range(2):
        var o: int = base + k * 4
        cb.i.append(o)
        cb.i.append(o + 1)
        cb.i.append(o + 2)
        cb.i.append(o)
        cb.i.append(o + 2)
        cb.i.append(o + 3)

func _emit_quad(target: Builder, face: int, lx: int, wy: int, lz: int, u0: float, v0: float, shade: float, sky: float, ao: Array, top_drop: float) -> void:
    var corners: Array = FACE_CORNERS[face]
    var base: int = target.v.size()
    var inset: float = 0.0004
    var center := Vector3(float(lx), float(wy), float(lz))
    for corner in range(4):
        var p: Vector3 = corners[corner]
        if top_drop != 0.0 and p.y > 0.0:
            p.y += top_drop
        target.v.append(center + p)
        var cu: Vector2 = CORNER_UV[corner]
        target.uv.append(Vector2(u0 + inset + cu.x * (uv_w - inset * 2.0), v0 + inset + cu.y * (uv_h - inset * 2.0)))
        var level: float = shade * float(AO_LEVELS[int(ao[corner])])
        target.c.append(Color(level, level, level, sky))
    if int(ao[0]) + int(ao[2]) < int(ao[1]) + int(ao[3]):
        target.i.append(base + 1)
        target.i.append(base + 2)
        target.i.append(base + 3)
        target.i.append(base + 1)
        target.i.append(base + 3)
        target.i.append(base)
    else:
        target.i.append(base)
        target.i.append(base + 1)
        target.i.append(base + 2)
        target.i.append(base)
        target.i.append(base + 2)
        target.i.append(base + 3)
