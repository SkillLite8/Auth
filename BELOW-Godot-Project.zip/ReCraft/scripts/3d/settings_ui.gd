extends PanelContainer
# Окно настроек: вкладки «Клавиатура и мышь», «Графика», «Звук».
# Все действия показаны списком; нажми на кнопку клавиши и затем на новую клавишу или кнопку мыши.

const Settings = preload("res://scripts/3d/settings.gd")

signal closed
signal changed

var tab_buttons: Dictionary = {}
var pages: Dictionary = {}
var binding_buttons: Dictionary = {}
var capturing: String = ""
var hint_label: Label
var view_label: Label
var fov_label: Label
var sens_label: Label
var volume_label: Label

func _make_style(bg: Color, border: Color, width: int = 1) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = bg
    style.border_color = border
    style.set_border_width_all(width)
    style.set_corner_radius_all(2)
    style.content_margin_left = 14
    style.content_margin_right = 14
    style.content_margin_top = 8
    style.content_margin_bottom = 8
    return style

func _button(caption: String, callback: Callable, width: float = 150.0, primary: bool = false) -> Button:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(width, 36)
    button.focus_mode = Control.FOCUS_NONE
    button.add_theme_font_size_override("font_size", 14)
    button.add_theme_color_override("font_color", Color("f5f7ff"))
    var normal: Color = Color("657df0", 0.94) if primary else Color(0.08, 0.12, 0.22, 0.95)
    button.add_theme_stylebox_override("normal", _make_style(normal, Color(0.64, 0.74, 1.0, 0.35)))
    button.add_theme_stylebox_override("hover", _make_style(Color("7891ff", 0.98) if primary else Color(0.16, 0.22, 0.38, 0.98), Color("dce5ff")))
    button.add_theme_stylebox_override("pressed", _make_style(Color("4f65cc"), Color("eff3ff")))
    button.pressed.connect(callback)
    return button

func _label(text_value: String, size: int = 14, color: Color = Color("e2eafa")) -> Label:
    var label := Label.new()
    label.text = text_value
    label.add_theme_font_size_override("font_size", size)
    label.add_theme_color_override("font_color", color)
    return label

func build() -> void:
    Settings.ensure_loaded()
    process_mode = Node.PROCESS_MODE_ALWAYS
    anchor_left = 0.5
    anchor_right = 0.5
    anchor_top = 0.5
    anchor_bottom = 0.5
    var w: float = 640.0
    var h: float = 560.0
    offset_left = -w * 0.5
    offset_right = w * 0.5
    offset_top = -h * 0.5
    offset_bottom = h * 0.5
    custom_minimum_size = Vector2(w, h)
    add_theme_stylebox_override("panel", _make_style(Color(0.035, 0.055, 0.105, 0.97), Color(0.76, 0.83, 1.0, 0.55)))

    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 8)
    add_child(box)
    var title := _label("НАСТРОЙКИ", 24, Color("f4f7ff"))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(title)

    var tabs := HBoxContainer.new()
    tabs.add_theme_constant_override("separation", 6)
    tabs.alignment = BoxContainer.ALIGNMENT_CENTER
    box.add_child(tabs)
    for tab in [["controls", "Клавиатура и мышь"], ["graphics", "Графика"], ["audio", "Звук"]]:
        var tab_id: String = str(tab[0])
        var tab_button := _button(str(tab[1]), _show_page.bind(tab_id), 190.0)
        tab_button.toggle_mode = true
        tabs.add_child(tab_button)
        tab_buttons[tab_id] = tab_button

    var holder := Control.new()
    holder.size_flags_vertical = Control.SIZE_EXPAND_FILL
    holder.custom_minimum_size = Vector2(0, 380)
    box.add_child(holder)
    _build_controls_page(holder)
    _build_graphics_page(holder)
    _build_audio_page(holder)

    hint_label = _label("", 13, Color("ffe6a7"))
    hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(hint_label)

    var bottom := HBoxContainer.new()
    bottom.alignment = BoxContainer.ALIGNMENT_CENTER
    bottom.add_theme_constant_override("separation", 10)
    box.add_child(bottom)
    bottom.add_child(_button("Сбросить управление", _on_reset, 230.0))
    bottom.add_child(_button("ГОТОВО", _on_done, 200.0, true))
    _show_page("controls")

func _page_holder(parent: Control) -> VBoxContainer:
    var scroll := ScrollContainer.new()
    parent.add_child(scroll)
    scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    var content := VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 6)
    scroll.add_child(content)
    return content

func _build_controls_page(parent: Control) -> void:
    var content := _page_holder(parent)
    pages["controls"] = content.get_parent()
    var current_group: String = ""
    for action_variant in Settings.ACTIONS:
        var action: Array = action_variant
        var group: String = str(action[2])
        if group != current_group:
            current_group = group
            var heading := _label(group, 15, Color("9fc0ff"))
            content.add_child(heading)
        var row := HBoxContainer.new()
        row.add_theme_constant_override("separation", 10)
        var name_label := _label(str(action[1]), 14)
        name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        row.add_child(name_label)
        var action_id: String = str(action[0])
        var button := _button(Settings.action_text(action_id), _begin_capture.bind(action_id), 190.0)
        row.add_child(button)
        content.add_child(row)
        binding_buttons[action_id] = button
        if action_id == "pick":
            var wheel := HBoxContainer.new()
            var wheel_label := _label("Колесо мыши — смена слота", 14, Color("b9c7e8"))
            wheel_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            wheel.add_child(wheel_label)
            wheel.add_child(_label("Колесо", 14, Color("b9c7e8")))
            content.add_child(wheel)
    content.add_child(_label("Мышь", 15, Color("9fc0ff")))
    var sens_row := HBoxContainer.new()
    sens_row.add_theme_constant_override("separation", 10)
    sens_label = _label("", 14)
    sens_label.custom_minimum_size = Vector2(250, 0)
    sens_row.add_child(sens_label)
    var sens := HSlider.new()
    sens.min_value = 10
    sens.max_value = 300
    sens.step = 5
    sens.value = Settings.sensitivity * 100.0
    sens.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sens.custom_minimum_size = Vector2(200, 24)
    sens.value_changed.connect(_on_sensitivity)
    sens_row.add_child(sens)
    content.add_child(sens_row)
    _update_sens_label()
    var invert := CheckBox.new()
    invert.text = "Инвертировать вертикальную ось мыши"
    invert.button_pressed = Settings.invert_y
    invert.add_theme_font_size_override("font_size", 14)
    invert.toggled.connect(_on_invert)
    content.add_child(invert)

func _build_graphics_page(parent: Control) -> void:
    var content := _page_holder(parent)
    pages["graphics"] = content.get_parent()
    view_label = _label("", 14)
    content.add_child(view_label)
    var view_slider := HSlider.new()
    view_slider.min_value = 2
    view_slider.max_value = 16
    view_slider.step = 1
    view_slider.value = Settings.view_distance
    view_slider.custom_minimum_size = Vector2(300, 24)
    view_slider.value_changed.connect(_on_view_distance)
    content.add_child(view_slider)
    _update_view_label()
    content.add_child(_label("Чем больше дальность, тем больше нагрузка на процессор. Мир строится в фоновых потоках.", 12, Color("b9c7e8")))
    fov_label = _label("", 14)
    content.add_child(fov_label)
    var fov_slider := HSlider.new()
    fov_slider.min_value = 50
    fov_slider.max_value = 110
    fov_slider.step = 1
    fov_slider.value = Settings.fov
    fov_slider.custom_minimum_size = Vector2(300, 24)
    fov_slider.value_changed.connect(_on_fov)
    content.add_child(fov_slider)
    _update_fov_label()

func _build_audio_page(parent: Control) -> void:
    var content := _page_holder(parent)
    pages["audio"] = content.get_parent()
    volume_label = _label("", 14)
    content.add_child(volume_label)
    var volume_slider := HSlider.new()
    volume_slider.min_value = 0
    volume_slider.max_value = 100
    volume_slider.step = 5
    volume_slider.value = Settings.volume * 100.0
    volume_slider.custom_minimum_size = Vector2(300, 24)
    volume_slider.value_changed.connect(_on_volume)
    content.add_child(volume_slider)
    _update_volume_label()

func _show_page(page_id: String) -> void:
    for key in ["controls", "graphics", "audio"]:
        var page: Control = pages[key]
        page.visible = key == page_id
        var button: Button = tab_buttons[key]
        button.button_pressed = key == page_id
    capturing = ""
    _refresh_bindings()
    hint_label.text = ""

func _update_view_label() -> void:
    view_label.text = "Дальность прорисовки: %d чанков (%d блоков)" % [Settings.view_distance, Settings.view_distance * 16]

func _update_fov_label() -> void:
    fov_label.text = "Угол обзора (FOV): %d°" % int(Settings.fov)

func _update_sens_label() -> void:
    sens_label.text = "Чувствительность мыши: %d%%" % int(Settings.sensitivity * 100.0)

func _update_volume_label() -> void:
    volume_label.text = "Общая громкость: %d%%" % int(Settings.volume * 100.0)

func _on_view_distance(value: float) -> void:
    Settings.view_distance = int(value)
    Settings.save_all()
    _update_view_label()
    changed.emit()

func _on_fov(value: float) -> void:
    Settings.fov = value
    Settings.save_all()
    _update_fov_label()
    changed.emit()

func _on_sensitivity(value: float) -> void:
    Settings.sensitivity = value / 100.0
    Settings.save_all()
    _update_sens_label()
    changed.emit()

func _on_invert(pressed: bool) -> void:
    Settings.invert_y = pressed
    Settings.save_all()
    changed.emit()

func _on_volume(value: float) -> void:
    Settings.volume = value / 100.0
    Settings.apply_audio()
    Settings.save_all()
    _update_volume_label()

func _begin_capture(action: String) -> void:
    capturing = action
    _refresh_bindings()
    hint_label.text = "Нажми клавишу или кнопку мыши. Esc — отмена."

func _refresh_bindings() -> void:
    for action_id in binding_buttons.keys():
        var button: Button = binding_buttons[action_id]
        button.text = "Нажми клавишу…" if str(action_id) == capturing else Settings.action_text(str(action_id))

func _input(event: InputEvent) -> void:
    if capturing == "" or not is_visible_in_tree():
        return
    var key_event := event as InputEventKey
    if key_event != null and key_event.pressed and key_event.keycode == KEY_ESCAPE:
        capturing = ""
        _refresh_bindings()
        hint_label.text = ""
        get_viewport().set_input_as_handled()
        return
    var code: String = Settings.code_from_event(event)
    if code == "":
        return
    Settings.set_binding(capturing, code)
    capturing = ""
    _refresh_bindings()
    hint_label.text = "Сохранено."
    changed.emit()
    get_viewport().set_input_as_handled()

func _on_reset() -> void:
    Settings.reset_bindings()
    capturing = ""
    _refresh_bindings()
    hint_label.text = "Управление сброшено по умолчанию."
    changed.emit()

func _on_done() -> void:
    capturing = ""
    closed.emit()
