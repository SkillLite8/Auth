extends Node3D

const CLOUD_ALTITUDE: float = 132.0
const CELL_SPACING: float = 88.0
const ACTIVE_RADIUS: int = 3
const WIND_SPEED: float = 0.72

var cloud_mesh: BoxMesh
var cloud_material: StandardMaterial3D
var cloud_cells: Dictionary = {}
var wind_offset: Vector3 = Vector3.ZERO
var update_timer: float = 0.0
var last_center: Vector2i = Vector2i(2147483647, 2147483647)
var initialized: bool = false

func _ready() -> void:
    name = "VolumetricCloudSystem"
    process_mode = Node.PROCESS_MODE_ALWAYS
    cloud_mesh = BoxMesh.new()
    cloud_mesh.size = Vector3.ONE
    cloud_material = StandardMaterial3D.new()
    cloud_material.albedo_color = Color("f3f6fa")
    cloud_material.roughness = 1.0
    cloud_material.metallic = 0.0
    cloud_material.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
    cloud_material.cull_mode = BaseMaterial3D.CULL_BACK
    cloud_mesh.material = cloud_material

func update_clouds(player_position: Vector3, delta: float, paused: bool = false) -> void:
    if not paused:
        wind_offset.x += WIND_SPEED * delta
        wind_offset.z += WIND_SPEED * delta * 0.13
    update_timer -= delta
    var effective_position := Vector2(player_position.x - wind_offset.x, player_position.z - wind_offset.z)
    var center := Vector2i(floori(effective_position.x / CELL_SPACING), floori(effective_position.y / CELL_SPACING))
    if not initialized or center != last_center or update_timer <= 0.0:
        initialized = true
        last_center = center
        update_timer = 1.0
        _sync_grid(center)
    for key_variant in cloud_cells.keys():
        var key: Vector2i = key_variant
        var node: MultiMeshInstance3D = cloud_cells[key]
        if is_instance_valid(node):
            node.position = Vector3(float(key.x) * CELL_SPACING + wind_offset.x, CLOUD_ALTITUDE, float(key.y) * CELL_SPACING + wind_offset.z)

func _sync_grid(center: Vector2i) -> void:
    var wanted: Dictionary = {}
    for dx in range(-ACTIVE_RADIUS, ACTIVE_RADIUS + 1):
        for dz in range(-ACTIVE_RADIUS, ACTIVE_RADIUS + 1):
            var key := center + Vector2i(dx, dz)
            wanted[key] = true
            if not cloud_cells.has(key) or not is_instance_valid(cloud_cells[key]):
                cloud_cells[key] = _make_cloud_cell(key)
    for key_variant in cloud_cells.keys().duplicate():
        var key: Vector2i = key_variant
        if not wanted.has(key):
            var old_node: Node = cloud_cells[key]
            if is_instance_valid(old_node):
                old_node.queue_free()
            cloud_cells.erase(key)

func _make_cloud_cell(key: Vector2i) -> MultiMeshInstance3D:
    var rng := RandomNumberGenerator.new()
    rng.seed = int(hash(Vector3i(key.x, 17, key.y))) & 0x7fffffff
    var transforms: Array[Transform3D] = []
    var base_x: float = rng.randf_range(-9.0, 9.0)
    var base_z: float = rng.randf_range(-8.0, 8.0)
    var radius_x: float = rng.randf_range(4.0, 6.0)
    var radius_z: float = rng.randf_range(3.3, 4.8)
    for layer in range(4):
        var scale_y: float = 0.8 if layer == 0 else (0.7 if layer == 3 else 1.0)
        for gx in range(-6, 7):
            for gz in range(-5, 6):
                var nx: float = float(gx) / radius_x
                var nz: float = float(gz) / radius_z
                var dist: float = nx * nx + nz * nz
                var threshold: float = 1.0 if layer < 2 else 0.66
                if dist > threshold + rng.randf_range(-0.18, 0.24):
                    continue
                if rng.randf() < (0.12 if layer == 0 else 0.28):
                    continue
                var scale_x: float = rng.randf_range(2.6, 5.8)
                var scale_z: float = rng.randf_range(2.8, 6.3)
                var scale_y_block: float = rng.randf_range(1.8, 3.8) * scale_y
                var local_pos := Vector3(base_x + gx * 4.1 + rng.randf_range(-0.8, 0.8), layer * 2.0 + rng.randf_range(-0.25, 0.25), base_z + gz * 4.1 + rng.randf_range(-0.8, 0.8))
                var basis := Basis.from_scale(Vector3(scale_x, scale_y_block, scale_z))
                transforms.append(Transform3D(basis, local_pos))
    if transforms.is_empty():
        transforms.append(Transform3D(Basis.from_scale(Vector3(4.0, 2.0, 4.0)), Vector3.ZERO))
    var multimesh := MultiMesh.new()
    multimesh.transform_format = MultiMesh.TRANSFORM_3D
    multimesh.mesh = cloud_mesh
    multimesh.instance_count = transforms.size()
    for i in range(transforms.size()):
        multimesh.set_instance_transform(i, transforms[i])
    var instance := MultiMeshInstance3D.new()
    instance.name = "Cloud_%d_%d" % [key.x, key.y]
    instance.multimesh = multimesh
    instance.material_override = cloud_material
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    instance.extra_cull_margin = 128.0
    instance.position = Vector3(float(key.x) * CELL_SPACING + wind_offset.x, CLOUD_ALTITUDE, float(key.y) * CELL_SPACING + wind_offset.z)
    add_child(instance)
    return instance
