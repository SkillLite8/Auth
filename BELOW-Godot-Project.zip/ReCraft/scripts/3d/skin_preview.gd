extends SubViewportContainer

const PlayerModelScript = preload("res://scripts/3d/minecraft_player_model.gd")

var preview_viewport: SubViewport
var preview_model: Node3D

func setup_skin(skin: Texture2D, viewport_size: Vector2i = Vector2i(140, 212)) -> void:
    stretch = true
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    custom_minimum_size = Vector2(viewport_size)
    size = Vector2(viewport_size)

    preview_viewport = SubViewport.new()
    preview_viewport.name = "SkinPreviewViewport"
    preview_viewport.size = viewport_size
    preview_viewport.own_world_3d = true
    preview_viewport.transparent_bg = false
    preview_viewport.render_target_update_mode = SubViewport.UPDATE_WHEN_VISIBLE
    preview_viewport.msaa_3d = Viewport.MSAA_DISABLED
    add_child(preview_viewport)

    var preview_root := Node3D.new()
    preview_root.name = "SkinPreviewScene"
    preview_viewport.add_child(preview_root)

    var world_environment := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color("171c29")
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color("b7c7ea")
    environment.ambient_light_energy = 0.85
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    world_environment.environment = environment
    preview_root.add_child(world_environment)

    var camera := Camera3D.new()
    camera.name = "SkinPreviewCamera"
    camera.position = Vector3(0.0, 0.02, -3.35)
    camera.fov = 38.0
    camera.rotation = Vector3(0.0, PI, 0.0) # camera sits in front of the avatar, looking toward +Z
    preview_root.add_child(camera)
    camera.current = true

    var key_light := DirectionalLight3D.new()
    key_light.name = "SkinPreviewKeyLight"
    key_light.rotation_degrees = Vector3(-22.0, -24.0, 0.0)
    key_light.light_color = Color("fff0da")
    key_light.light_energy = 1.2
    key_light.shadow_enabled = false
    preview_root.add_child(key_light)

    var fill_light := OmniLight3D.new()
    fill_light.name = "SkinPreviewFillLight"
    fill_light.position = Vector3(1.0, 0.25, -1.1)
    fill_light.light_color = Color("95b7ff")
    fill_light.light_energy = 0.35
    fill_light.omni_range = 5.0
    preview_root.add_child(fill_light)

    preview_model = PlayerModelScript.new()
    preview_model.name = "SkinPlayerModel"
    preview_model.call("build_player", skin)
    preview_root.add_child(preview_model)
