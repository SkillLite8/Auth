extends RefCounted
# Настройки игрока: управление (клавиатура и мышь), графика, звук. Хранятся в user://recraft_settings.cfg.
#
# Привязка записывается строкой: "k87" - физическая клавиша (код Key), "m1" - кнопка мыши.

const PATH: String = "user://recraft_settings.cfg"

# [id, название, группа]
const ACTIONS: Array = [
    ["forward", "Вперёд", "Движение"],
    ["back", "Назад", "Движение"],
    ["left", "Влево", "Движение"],
    ["right", "Вправо", "Движение"],
    ["jump", "Прыжок / полёт вверх", "Движение"],
    ["sneak", "Красться / лететь вниз", "Движение"],
    ["sprint", "Бег", "Движение"],
    ["attack", "Ломать / атаковать", "Мышь и действия"],
    ["use", "Поставить блок / использовать", "Мышь и действия"],
    ["pick", "Скопировать блок (творческий)", "Мышь и действия"],
    ["drop", "Выбросить предмет", "Мышь и действия"],
    ["inventory", "Инвентарь", "Мышь и действия"],
    ["heal", "Съесть аптечку", "Мышь и действия"],
    ["creative", "Творческий режим", "Режимы и экран"],
    ["view", "Смена вида (F5: 1-2-3)", "Режимы и экран"],
    ["hide_hud", "Скрыть интерфейс (F1)", "Режимы и экран"],
    ["debug", "Отладка (F3)", "Режимы и экран"],
    ["slot1", "Слот 1", "Панель быстрого доступа"],
    ["slot2", "Слот 2", "Панель быстрого доступа"],
    ["slot3", "Слот 3", "Панель быстрого доступа"],
    ["slot4", "Слот 4", "Панель быстрого доступа"],
    ["slot5", "Слот 5", "Панель быстрого доступа"],
    ["slot6", "Слот 6", "Панель быстрого доступа"],
    ["slot7", "Слот 7", "Панель быстрого доступа"],
    ["slot8", "Слот 8", "Панель быстрого доступа"],
    ["slot9", "Слот 9", "Панель быстрого доступа"]
]

static var view_distance: int = 6
static var fov: float = 70.0
static var sensitivity: float = 1.0
static var invert_y: bool = false
static var volume: float = 1.0
static var bindings: Dictionary = {}
static var loaded: bool = false

static func default_bindings() -> Dictionary:
    return {
        "forward": "k" + str(KEY_W), "back": "k" + str(KEY_S), "left": "k" + str(KEY_A), "right": "k" + str(KEY_D),
        "jump": "k" + str(KEY_SPACE), "sneak": "k" + str(KEY_SHIFT), "sprint": "k" + str(KEY_CTRL),
        "attack": "m" + str(MOUSE_BUTTON_LEFT), "use": "m" + str(MOUSE_BUTTON_RIGHT), "pick": "m" + str(MOUSE_BUTTON_MIDDLE),
        "drop": "k" + str(KEY_Q), "inventory": "k" + str(KEY_E), "heal": "k" + str(KEY_H),
        "creative": "k" + str(KEY_C), "view": "k" + str(KEY_F5), "hide_hud": "k" + str(KEY_F1), "debug": "k" + str(KEY_F3),
        "slot1": "k" + str(KEY_1), "slot2": "k" + str(KEY_2), "slot3": "k" + str(KEY_3), "slot4": "k" + str(KEY_4),
        "slot5": "k" + str(KEY_5), "slot6": "k" + str(KEY_6), "slot7": "k" + str(KEY_7), "slot8": "k" + str(KEY_8),
        "slot9": "k" + str(KEY_9)
    }

static func load_all() -> void:
    bindings = default_bindings()
    var config := ConfigFile.new()
    if config.load(PATH) == OK:
        view_distance = clampi(int(config.get_value("graphics", "view_distance_chunks", 6)), 2, 12)
        fov = clampf(float(config.get_value("graphics", "fov", 70.0)), 50.0, 110.0)
        sensitivity = clampf(float(config.get_value("mouse", "sensitivity", 1.0)), 0.1, 3.0)
        invert_y = bool(config.get_value("mouse", "invert_y", false))
        volume = clampf(float(config.get_value("audio", "volume", 1.0)), 0.0, 1.0)
        for action_variant in ACTIONS:
            var action: String = str(action_variant[0])
            var stored: String = str(config.get_value("keys", action, bindings[action]))
            if stored.length() >= 2 and (stored.begins_with("k") or stored.begins_with("m")):
                bindings[action] = stored
    loaded = true
    apply_audio()

static func ensure_loaded() -> void:
    if not loaded:
        load_all()

static func save_all() -> void:
    var config := ConfigFile.new()
    config.set_value("graphics", "view_distance_chunks", view_distance)
    config.set_value("graphics", "fov", fov)
    config.set_value("mouse", "sensitivity", sensitivity)
    config.set_value("mouse", "invert_y", invert_y)
    config.set_value("audio", "volume", volume)
    for action_variant in ACTIONS:
        var action: String = str(action_variant[0])
        config.set_value("keys", action, bindings[action])
    config.save(PATH)

static func reset_bindings() -> void:
    bindings = default_bindings()
    save_all()

static func apply_audio() -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(0.0001, volume)))

# ------------------------------------------------------------------ queries

static func binding(action: String) -> String:
    ensure_loaded()
    return str(bindings.get(action, ""))

static func is_down(action: String) -> bool:
    var code: String = binding(action)
    if code.length() < 2:
        return false
    var value: int = int(code.substr(1))
    if code.begins_with("k"):
        return Input.is_physical_key_pressed(value as Key)
    return Input.is_mouse_button_pressed(value as MouseButton)

# Событие нажатия (не повтор) для действия.
static func pressed(event: InputEvent, action: String) -> bool:
    var code: String = binding(action)
    if code.length() < 2:
        return false
    var value: int = int(code.substr(1))
    var key_event := event as InputEventKey
    if key_event != null:
        if not code.begins_with("k") or not key_event.pressed or key_event.echo:
            return false
        var physical: int = key_event.physical_keycode
        if physical == 0:
            physical = key_event.keycode
        return physical == value
    var mouse_event := event as InputEventMouseButton
    if mouse_event != null:
        return code.begins_with("m") and mouse_event.pressed and mouse_event.button_index == value
    return false

static func is_mouse_binding(action: String) -> bool:
    return binding(action).begins_with("m")

static func code_from_event(event: InputEvent) -> String:
    var key_event := event as InputEventKey
    if key_event != null and key_event.pressed and not key_event.echo:
        var physical: int = key_event.physical_keycode
        if physical == 0:
            physical = key_event.keycode
        return "k" + str(physical)
    var mouse_event := event as InputEventMouseButton
    if mouse_event != null and mouse_event.pressed:
        var button: int = mouse_event.button_index
        if button == MOUSE_BUTTON_LEFT or button == MOUSE_BUTTON_RIGHT or button == MOUSE_BUTTON_MIDDLE or button == MOUSE_BUTTON_XBUTTON1 or button == MOUSE_BUTTON_XBUTTON2:
            return "m" + str(button)
    return ""

static func set_binding(action: String, code: String) -> void:
    ensure_loaded()
    # если клавиша занята другим действием - меняемся местами
    for other_variant in ACTIONS:
        var other: String = str(other_variant[0])
        if other != action and str(bindings.get(other, "")) == code:
            bindings[other] = str(bindings.get(action, ""))
    bindings[action] = code
    save_all()

static func code_text(code: String) -> String:
    if code.length() < 2:
        return "—"
    var value: int = int(code.substr(1))
    if code.begins_with("m"):
        match value:
            MOUSE_BUTTON_LEFT:
                return "ЛКМ"
            MOUSE_BUTTON_RIGHT:
                return "ПКМ"
            MOUSE_BUTTON_MIDDLE:
                return "СКМ (колесо)"
            MOUSE_BUTTON_XBUTTON1:
                return "Кнопка мыши 4"
            MOUSE_BUTTON_XBUTTON2:
                return "Кнопка мыши 5"
        return "Мышь %d" % value
    var text: String = OS.get_keycode_string(value as Key)
    return text if text != "" else "Клавиша %d" % value

static func action_text(action: String) -> String:
    return code_text(binding(action))

# Номер слота 0..8, если событие нажимает одну из клавиш быстрого доступа, иначе -1.
static func slot_from_event(event: InputEvent) -> int:
    for i in range(9):
        if pressed(event, "slot" + str(i + 1)):
            return i
    return -1
