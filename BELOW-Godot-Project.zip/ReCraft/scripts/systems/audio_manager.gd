extends Node

var players: Dictionary = {}
var streams: Dictionary = {
    "mine": preload("res://assets/audio/mine.wav"),
    "pickup": preload("res://assets/audio/pickup.wav"),
    "hit": preload("res://assets/audio/hit.wav"),
    "ui": preload("res://assets/audio/ui.wav"),
    "dig_stone": preload("res://assets/audio/dig_stone.wav"),
    "dig_dirt": preload("res://assets/audio/dig_dirt.wav"),
    "dig_wood": preload("res://assets/audio/dig_wood.wav"),
    "dig_sand": preload("res://assets/audio/dig_sand.wav"),
    "break_stone": preload("res://assets/audio/break_stone.wav"),
    "break_dirt": preload("res://assets/audio/break_dirt.wav"),
    "break_wood": preload("res://assets/audio/break_wood.wav"),
    "break_sand": preload("res://assets/audio/break_sand.wav"),
    "place_stone": preload("res://assets/audio/place_stone.wav"),
    "place_dirt": preload("res://assets/audio/place_dirt.wav"),
    "place_wood": preload("res://assets/audio/place_wood.wav"),
    "place_sand": preload("res://assets/audio/place_sand.wav")
}

func _ready() -> void:
    for key in streams:
        var player := AudioStreamPlayer.new()
        player.name = "SFX_" + str(key)
        player.stream = streams[key]
        player.volume_db = -3.0
        add_child(player)
        players[key] = player

func play(sound_id: String) -> void:
    if not players.has(sound_id):
        return
    var player: AudioStreamPlayer = players[sound_id]
    player.stop()
    player.play()
