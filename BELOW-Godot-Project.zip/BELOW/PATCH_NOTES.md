# BELOW — fixes in this archive

This archive includes the following stability changes compared with the uploaded project:

- Renamed the item-display helper so it no longer conflicts with Godot's built-in `Node.get_name()` method; updated the UI call sites.
- Made Escape return to the title after death, instead of unpausing a dead player.
- Removed expedition nodes and cave lighting when returning to the title, preventing stacked ambient overlays between sessions.
- Refreshes viewport-culled terrain when the camera moves or the viewport changes.
- Keeps the player within the generated world's horizontal bounds and clamps restored positions.
- Validates saved tile modifications before applying them, ignores obviously invalid save files in the Continue button, and prevents hidden maps from redrawing continuously.
- Added checks for item display names, icon atlas indices, recipe ingredients, ItemDB method calls, and the CI export-template/smoke-test steps.
- Updated Windows CI to install Godot 4.7.2 export templates, run the static validator and headless gameplay smoke test, then export the Windows build.

## Verification status

The Python static project validator passes in the archive-creation environment. Godot itself is not installed in that environment and the engine download is unavailable there, so the Godot parser/runtime smoke test has not been executed locally. The included GitHub Actions workflow runs that smoke test and the real Windows export when the project is pushed to GitHub.
