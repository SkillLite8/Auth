# BELOW — 3D expedition upgrade

The default startup scene is now `scenes/main_3d.tscn`. The old 2D prototype and its data remain in the repository, but launching the project starts the new first-person 3D chapter.

## Gameplay changes

- Added a procedural block world with grass, dirt, stone, bedrock, trees, ruins, glowing ore and the Station Zero beacon.
- Added first-person mouse look, working physical-key WASD movement (independent of keyboard layout), jump, event-tracked Shift sprint with regenerating stamina, and pause/cursor controls.
- Added raycast mining and block placement, a nine-slot quick bar, a backpack screen, consumable healing and a health HUD with hearts. Block visuals are batched by material to reduce draw calls.
- Added a story objective: locate three Echo Shards, fight the Echo Guardians and return to the beacon to restore its signal.
- Added autosave/manual save/continue for seed, position, health, stamina, inventory, quest progress and modified blocks.
- Added headless smoke-test coverage for the new 3D project and a workflow step before Windows export.

## Earlier stability changes retained

- Renamed the item-display helper so it no longer conflicts with Godot's built-in `Node.get_name()` method.
- Preserved the original 2D scene and its previous stability improvements as a legacy prototype.
- Static validation still checks resource references, item/recipe JSON, ItemDB method calls, and CI safeguards.

## Verification status

`python3 tools/validate_project.py` passes in the archive-creation environment. Godot itself is not installed here and downloading the engine was not available, so I cannot honestly claim the GDScript runtime or rendered game was tested locally. The GitHub Actions workflow installs Godot 4.7.2, imports the project, runs both smoke tests, and exports the Windows EXE.

## Инвентарь, текстуры, приседание

- Инвентарь на E в стиле Minecraft: 27 слотов + хотбар 9, 4 слота брони (пока пустые, брони в игре нет), слот второй руки, крафт 2x2, перетаскивание ЛКМ/ПКМ.
- HUD: сердца, броня (видна при броне > 0), голод, полоса опыта и уровень.
- Shift — присесть (ниже, медленнее), Ctrl — бег, Space — прыжок, F — взаимодействие.
- Блоки с текстурами: трава (верх/бок), земля, песок, дерево, листва, камень, булыжник.

## Процедурный мир: чанки, высота и руды

- Мир разделён на чанки 16×16 по X/Z; радиус загрузки и бюджет подгрузки вынесены в константы `VIEW_DISTANCE_CHUNKS` и `CHUNKS_PER_FRAME`.
- Высота блока: Y=-64…319; Y=320 — исключительная верхняя граница, всего 384 уровня. Уровень моря — Y=63; поверхность обычно около Y=60–100, горы выше.
- Генерация руд привязана к высоте и шуму; гарниерит встречается во влажных зонах рядом с пещерами.
- Изменённые блоки индексируются по чанкам и сохраняются; сборная геометрия и коллизия пересчитываются только для затронутых чанков. Неисследованные подземные поверхности создаются по мере изучения пещер.
- Добавлены top/side текстуры новых руд и пять вариантов воды на основе предоставленной карты блоков.
