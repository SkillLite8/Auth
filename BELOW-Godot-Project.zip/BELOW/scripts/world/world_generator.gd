extends Node2D

const TILE_SIZE: int = 16
const WORLD_WIDTH: int = 180
const WORLD_HEIGHT: int = 150
const START_X: int = 90
const BASE_SURFACE: int = 14
const TILE_TEXTURE: Texture2D = preload("res://assets/sprites/tiles.png")
const LIGHT_TEXTURE: Texture2D = preload("res://assets/sprites/light.png")
const PickupScene: PackedScene = preload("res://scenes/pickup.tscn")

var seed_value: int = 1
var cells: Array = []
var modified_tiles: Dictionary = {}
var hit_points: Dictionary = {}
var row_bodies: Array = []
var torch_lights: Dictionary = {}
var noise := FastNoiseLite.new()
var rng := RandomNumberGenerator.new()
var _last_draw_camera_position := Vector2.ZERO
var _last_draw_zoom := Vector2.ZERO
var _last_draw_viewport_size := Vector2.ZERO
var _has_draw_camera_state := false

func _process(_delta: float) -> void:
    if not is_inside_tree():
        return
    var camera := get_viewport().get_camera_2d()
    var camera_position := to_local(camera.global_position) if camera != null else Vector2(START_X * TILE_SIZE, BASE_SURFACE * TILE_SIZE)
    var camera_zoom := camera.zoom if camera != null else Vector2.ONE
    var viewport_size := get_viewport_rect().size
    var moved := not _has_draw_camera_state or camera_position.distance_to(_last_draw_camera_position) >= float(TILE_SIZE) * 0.5
    var resized := viewport_size != _last_draw_viewport_size or camera_zoom != _last_draw_zoom
    if moved or resized:
        _last_draw_camera_position = camera_position
        _last_draw_zoom = camera_zoom
        _last_draw_viewport_size = viewport_size
        _has_draw_camera_state = true
        queue_redraw()

func generate(world_seed: int, modifications: Dictionary = {}) -> void:
    seed_value = world_seed
    rng.seed = world_seed
    noise.seed = world_seed
    noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
    noise.frequency = 0.052
    noise.fractal_octaves = 3
    cells.clear()
    for y in range(WORLD_HEIGHT):
        var row := PackedInt32Array()
        row.resize(WORLD_WIDTH)
        cells.append(row)
    for x in range(WORLD_WIDTH):
        var surface := get_surface_y(x)
        for y in range(surface, WORLD_HEIGHT):
            var depth := y - surface
            var tile_id := 1 if depth < 4 else 2
            if depth > 5:
                var roll := rng.randf()
                if depth > 80 and roll < 0.018:
                    tile_id = 7
                elif depth > 58 and roll < 0.045:
                    tile_id = 6
                elif depth > 42 and roll < 0.07:
                    tile_id = 5
                elif roll < 0.095:
                    tile_id = 4
                elif roll < 0.13:
                    tile_id = 3
                elif depth > 95 and roll < 0.16:
                    tile_id = 8
                elif roll < 0.19:
                    tile_id = 12 if depth > 35 else 1
            cells[y][x] = tile_id
    # Carve deterministic natural cave pockets.
    for y in range(BASE_SURFACE + 5, WORLD_HEIGHT - 4):
        for x in range(2, WORLD_WIDTH - 2):
            var surface := get_surface_y(x)
            if y > surface + 5 and noise.get_noise_2d(float(x), float(y)) > 0.34:
                cells[y][x] = 0
    # A guaranteed mine shaft and a starter cavern make the first descent playable.
    for y in range(BASE_SURFACE, BASE_SURFACE + 41):
        for x in range(START_X - 1, START_X + 2):
            cells[y][x] = 0
    for y in range(BASE_SURFACE + 28, BASE_SURFACE + 41):
        for x in range(START_X - 12, START_X + 13):
            cells[y][x] = 0
    # Guarantee a flat surface around the starter base and keep it safe.
    for x in range(START_X - 18, START_X + 19):
        cells[BASE_SURFACE][x] = 1
        for y in range(BASE_SURFACE + 1, BASE_SURFACE + 4):
            if abs(x - START_X) > 1:
                cells[y][x] = 1
    # Restore the shaft through the shallow dirt after creating the base terrain.
    for y in range(BASE_SURFACE, BASE_SURFACE + 41):
        for x in range(START_X - 1, START_X + 2):
            cells[y][x] = 0
    modified_tiles = modifications.duplicate(true)
    for key in modified_tiles:
        var parts: PackedStringArray = str(key).split(",")
        if parts.size() != 2:
            continue
        if not parts[0].is_valid_int() or not parts[1].is_valid_int():
            continue
        var tx := int(parts[0])
        var ty := int(parts[1])
        var raw_tile := str(modified_tiles[key])
        if not raw_tile.is_valid_int():
            continue
        var tile_id := int(raw_tile)
        if _inside(tx, ty) and tile_id >= 0 and tile_id <= 16:
            cells[ty][tx] = tile_id
    _rebuild_all_collisions()
    _rebuild_torch_lights()
    queue_redraw()

func get_surface_y(x: int) -> int:
    if abs(x - START_X) <= 18:
        return BASE_SURFACE
    var a := sin(float(x) * 0.061 + float(seed_value % 97) * 0.1)
    var b := cos(float(x) * 0.027 + float(seed_value % 61) * 0.2)
    return clampi(BASE_SURFACE + int(round(a * 2.2 + b * 1.4)), 9, 20)

func _inside(x: int, y: int) -> bool:
    return x >= 0 and x < WORLD_WIDTH and y >= 0 and y < WORLD_HEIGHT

func world_to_cell(world_position: Vector2) -> Vector2i:
    return Vector2i(floori(world_position.x / TILE_SIZE), floori(world_position.y / TILE_SIZE))

func get_tile(cell: Vector2i) -> int:
    if not _inside(cell.x, cell.y):
        return 0
    return int(cells[cell.y][cell.x])

func is_solid(cell: Vector2i) -> bool:
    if cell.x < 0 or cell.x >= WORLD_WIDTH or cell.y >= WORLD_HEIGHT:
        return true
    if cell.y < 0:
        return false
    var tile_id := int(cells[cell.y][cell.x])
    return tile_id != 0 and tile_id != 9

func has_line_of_sight(from_pos: Vector2, to_pos: Vector2) -> bool:
    var distance := from_pos.distance_to(to_pos)
    var steps := maxi(1, int(distance / 8.0))
    for i in range(1, steps):
        var point := from_pos.lerp(to_pos, float(i) / float(steps))
        if is_solid(world_to_cell(point)):
            return false
    return true

func block_required_tier(tile_id: int) -> int:
    match tile_id:
        5, 6, 13: return 1
        7, 8, 15, 16: return 2
        _: return 0

func block_hardness(tile_id: int) -> float:
    match tile_id:
        1: return 0.8
        2, 3: return 1.5
        4, 13: return 2.0
        5: return 2.7
        6, 12, 14: return 3.0
        7, 15: return 3.8
        8, 16: return 4.4
        9: return 0.45
        10, 11: return 1.2
        _: return 1.0

func damage_block(cell: Vector2i, amount: float, tool_tier: int) -> Dictionary:
    if not _inside(cell.x, cell.y):
        return {"status": "invalid"}
    var tile_id := int(cells[cell.y][cell.x])
    if tile_id == 0:
        return {"status": "air"}
    if tool_tier < block_required_tier(tile_id):
        return {"status": "too_hard"}
    var key := "%d,%d" % [cell.x, cell.y]
    if not hit_points.has(key):
        hit_points[key] = block_hardness(tile_id)
    hit_points[key] = float(hit_points[key]) - amount
    queue_redraw()
    if float(hit_points[key]) > 0.0:
        return {"status": "damaging", "remaining": float(hit_points[key])}
    hit_points.erase(key)
    cells[cell.y][cell.x] = 0
    modified_tiles[key] = 0
    if tile_id == 9 and torch_lights.has(key):
        var removed_light = torch_lights[key]
        if is_instance_valid(removed_light):
            removed_light.queue_free()
        torch_lights.erase(key)
    _rebuild_collision_row(cell.y)
    queue_redraw()
    AudioManager.play("mine")
    var item_id := _drop_for_tile(tile_id)
    if not item_id.is_empty():
        _spawn_pickup(item_id, 1, Vector2((cell.x + 0.5) * TILE_SIZE, (cell.y + 0.5) * TILE_SIZE))
    return {"status": "broken", "item": item_id}

func _drop_for_tile(tile_id: int) -> String:
    match tile_id:
        1: return "dirt"
        2, 13, 16: return "stone"
        3: return "coal"
        4: return "copper_ore"
        5: return "iron_ore"
        6: return "crystal"
        7, 15: return "ancient_shard"
        8: return "iron_ore"
        9: return "torch"
        10, 11: return "wood"
        12, 14: return "mushroom"
        _: return "stone"

func place_tile(cell: Vector2i, tile_id: int, player_position: Vector2) -> bool:
    if not _inside(cell.x, cell.y) or get_tile(cell) != 0:
        return false
    var center := Vector2((cell.x + 0.5) * TILE_SIZE, (cell.y + 0.5) * TILE_SIZE)
    if center.distance_to(player_position) > TILE_SIZE * 5.0:
        return false
    if center.distance_to(player_position) < 18.0:
        return false
    if tile_id == 9:
        var below := Vector2i(cell.x, cell.y + 1)
        if not is_solid(below):
            return false
    cells[cell.y][cell.x] = tile_id
    modified_tiles["%d,%d" % [cell.x, cell.y]] = tile_id
    if tile_id != 9:
        _rebuild_collision_row(cell.y)
    if tile_id == 9:
        _create_torch_light(cell)
    queue_redraw()
    return true

func _spawn_pickup(item_id: String, amount: int, at_position: Vector2) -> void:
    var pickup = PickupScene.instantiate()
    pickup.item_id = item_id
    pickup.amount = amount
    pickup.global_position = at_position
    add_child(pickup)

func _rebuild_all_collisions() -> void:
    for child in get_children():
        if child is StaticBody2D:
            child.free()
    row_bodies.clear()
    for y in range(WORLD_HEIGHT):
        row_bodies.append(null)
        _rebuild_collision_row(y)

func _rebuild_collision_row(y: int) -> void:
    if y < 0 or y >= WORLD_HEIGHT:
        return
    if row_bodies.size() <= y:
        return
    var old = row_bodies[y]
    if is_instance_valid(old):
        old.queue_free()
    var body := StaticBody2D.new()
    body.name = "TerrainRow_%03d" % y
    body.collision_layer = 1
    body.collision_mask = 0
    var x := 0
    while x < WORLD_WIDTH:
        while x < WORLD_WIDTH and not _is_collision_tile(int(cells[y][x])):
            x += 1
        if x >= WORLD_WIDTH:
            break
        var first := x
        while x < WORLD_WIDTH and _is_collision_tile(int(cells[y][x])):
            x += 1
        var run_width := x - first
        var shape := CollisionShape2D.new()
        var rect := RectangleShape2D.new()
        rect.size = Vector2(float(run_width * TILE_SIZE), float(TILE_SIZE))
        shape.shape = rect
        shape.position = Vector2((float(first) + float(run_width) / 2.0) * TILE_SIZE, (float(y) + 0.5) * TILE_SIZE)
        body.add_child(shape)
    add_child(body)
    row_bodies[y] = body

func _is_collision_tile(tile_id: int) -> bool:
    return tile_id != 0 and tile_id != 9

func _rebuild_torch_lights() -> void:
    for key in torch_lights.keys():
        var light = torch_lights[key]
        if is_instance_valid(light):
            light.queue_free()
    torch_lights.clear()
    for y in range(WORLD_HEIGHT):
        for x in range(WORLD_WIDTH):
            if int(cells[y][x]) == 9:
                _create_torch_light(Vector2i(x, y))

func _create_torch_light(cell: Vector2i) -> void:
    var key := "%d,%d" % [cell.x, cell.y]
    if torch_lights.has(key) and is_instance_valid(torch_lights[key]):
        return
    var light := PointLight2D.new()
    light.texture = LIGHT_TEXTURE
    light.color = Color(1.0, 0.72, 0.38, 1.0)
    light.energy = 1.05
    light.texture_scale = 1.35
    light.shadow_enabled = false
    light.position = Vector2((cell.x + 0.5) * TILE_SIZE, (cell.y + 0.5) * TILE_SIZE)
    add_child(light)
    torch_lights[key] = light

func spawn_enemy_loot(at_position: Vector2) -> void:
    var drop := "mushroom" if rng.randf() < 0.55 else "coal"
    _spawn_pickup(drop, 1, at_position)

func export_modifications() -> Dictionary:
    return modified_tiles.duplicate(true)

func _draw() -> void:
    var viewport_size := get_viewport_rect().size
    var camera := get_viewport().get_camera_2d()
    var cam_pos := to_local(camera.global_position) if camera != null else Vector2(START_X * TILE_SIZE, BASE_SURFACE * TILE_SIZE)
    var zoom := camera.zoom if camera != null else Vector2.ONE
    var half_w := viewport_size.x / maxf(zoom.x, 0.1) / 2.0
    var half_h := viewport_size.y / maxf(zoom.y, 0.1) / 2.0
    var left := cam_pos.x - half_w - TILE_SIZE
    var right := cam_pos.x + half_w + TILE_SIZE
    var top := cam_pos.y - half_h - TILE_SIZE
    var bottom := cam_pos.y + half_h + TILE_SIZE
    draw_rect(Rect2(left, top, right-left, bottom-top), Color("0a101b"), true)
    draw_rect(Rect2(left, top, right-left, maxf(0.0, BASE_SURFACE*TILE_SIZE-top)), Color("111d2a"), true)
    # Layered cave silhouettes behind terrain.
    for layer in range(3):
        var y_line := BASE_SURFACE * TILE_SIZE + 110 + layer * 115
        draw_line(Vector2(left, y_line), Vector2(right, y_line + 10 * sin(left * 0.01)), Color(0.08 + layer*0.015, 0.12 + layer*0.018, 0.18 + layer*0.02, 0.6), 18.0)
    var sx := clampi(floori(left / TILE_SIZE), 0, WORLD_WIDTH-1)
    var ex := clampi(ceili(right / TILE_SIZE), 0, WORLD_WIDTH)
    var sy := clampi(floori(top / TILE_SIZE), 0, WORLD_HEIGHT-1)
    var ey := clampi(ceili(bottom / TILE_SIZE), 0, WORLD_HEIGHT)
    for y in range(sy, ey):
        for x in range(sx, ex):
            var tile_id := int(cells[y][x])
            if tile_id == 0:
                continue
            var atlas_index := tile_id - 1
            var atlas_pos := Vector2((atlas_index % 8) * 16, int(atlas_index / 8) * 16)
            var dest := Rect2(x*TILE_SIZE, y*TILE_SIZE, TILE_SIZE, TILE_SIZE)
            draw_texture_rect_region(TILE_TEXTURE, dest, Rect2(atlas_pos, Vector2(16,16)), Color.WHITE, false)
            if tile_id == 1 and y == get_surface_y(x):
                draw_line(Vector2(x*TILE_SIZE, y*TILE_SIZE+1), Vector2((x+1)*TILE_SIZE, y*TILE_SIZE+1), Color("85a66a"), 2.0)
            var key := "%d,%d" % [x,y]
            if hit_points.has(key):
                var ratio := clampf(float(hit_points[key]) / block_hardness(tile_id), 0.0, 1.0)
                var alpha := (1.0-ratio)*0.8
                draw_line(Vector2(x*TILE_SIZE+3, y*TILE_SIZE+4), Vector2(x*TILE_SIZE+8, y*TILE_SIZE+8), Color(0.04,0.05,0.07,alpha), 1.3)
                draw_line(Vector2(x*TILE_SIZE+8, y*TILE_SIZE+8), Vector2(x*TILE_SIZE+6, y*TILE_SIZE+13), Color(0.04,0.05,0.07,alpha), 1.3)
