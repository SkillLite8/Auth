extends CanvasLayer

signal start_requested(continue_save: bool)
var settings_panel: PanelContainer
var main_buttons: VBoxContainer
var continue_button: Button

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)
    var bg := TextureRect.new()
    bg.texture = preload("res://assets/sprites/title_background.png")
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_SCALE
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(bg)
    var shade := ColorRect.new()
    shade.color = Color(0.025,0.035,0.055,0.56)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(shade)
    var title := Label.new()
    title.text = "B E L O W"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 58)
    title.add_theme_color_override("font_color", Color("d5e9f1"))
    title.add_theme_color_override("font_shadow_color", Color(0.0,0.0,0.0,0.9))
    title.add_theme_constant_override("shadow_offset_x", 3)
    title.add_theme_constant_override("shadow_offset_y", 4)
    title.position = Vector2(0,90)
    title.size = Vector2(1280,80)
    root.add_child(title)
    var subtitle := Label.new()
    subtitle.text = "ПОД ЗЕМЛЁЙ ЕЩЁ ОСТАЛОСЬ ЧТО-ТО ЖИВОЕ"
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.add_theme_font_size_override("font_size", 14)
    subtitle.add_theme_color_override("font_color", Color("88afbd"))
    subtitle.position = Vector2(0,166)
    subtitle.size = Vector2(1280,30)
    root.add_child(subtitle)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(center)
    main_buttons = VBoxContainer.new()
    main_buttons.custom_minimum_size = Vector2(300,0)
    main_buttons.add_theme_constant_override("separation", 10)
    center.add_child(main_buttons)
    _add_button(main_buttons,"НОВАЯ ЭКСПЕДИЦИЯ",_new_game)
    continue_button = _add_button(main_buttons,"ПРОДОЛЖИТЬ",_continue_game)
    continue_button.disabled = not SaveManager.has_save()
    _add_button(main_buttons,"НАСТРОЙКИ",_open_settings)
    _add_button(main_buttons,"ВЫХОД",_exit_game)
    var footer := Label.new()
    footer.text = "WASD / ← →  •  SPACE — ПРЫЖОК  •  ЛКМ — ДОБЫЧА  •  E — КРАФТ"
    footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    footer.add_theme_font_size_override("font_size", 13)
    footer.add_theme_color_override("font_color", Color("8296a5"))
    footer.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    footer.offset_top = -52
    footer.offset_bottom = -22
    root.add_child(footer)

func _add_button(parent: VBoxContainer, caption: String, callback: Callable) -> Button:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(300,48)
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size",16)
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.055,0.085,0.12,0.90)
    normal.border_color = Color("446678")
    normal.set_border_width_all(1)
    normal.set_corner_radius_all(3)
    normal.content_margin_left = 16
    normal.content_margin_right = 16
    button.add_theme_stylebox_override("normal",normal)
    var hover = normal.duplicate()
    hover.bg_color = Color(0.11,0.20,0.25,0.96)
    hover.border_color = Color("84cdd1")
    button.add_theme_stylebox_override("hover",hover)
    button.add_theme_stylebox_override("focus",hover)
    button.add_theme_color_override("font_color",Color("d9edf0"))
    parent.add_child(button)
    button.pressed.connect(callback)
    return button

func _new_game() -> void:
    AudioManager.play("ui")
    start_requested.emit(false)

func _continue_game() -> void:
    AudioManager.play("ui")
    start_requested.emit(true)

func _open_settings() -> void:
    if is_instance_valid(settings_panel):
        settings_panel.queue_free()
        settings_panel = null
        return
    settings_panel = PanelContainer.new()
    settings_panel.custom_minimum_size = Vector2(360,250)
    settings_panel.position = Vector2(460,250)
    var style := StyleBoxFlat.new()
    style.bg_color = Color("111d2a")
    style.border_color = Color("5d8795")
    style.set_border_width_all(2)
    style.set_corner_radius_all(5)
    style.content_margin_left = 22; style.content_margin_right = 22
    style.content_margin_top = 18; style.content_margin_bottom = 18
    settings_panel.add_theme_stylebox_override("panel",style)
    add_child(settings_panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation",12)
    settings_panel.add_child(box)
    var heading := Label.new(); heading.text = "НАСТРОЙКИ"; heading.add_theme_font_size_override("font_size",23); box.add_child(heading)
    var volume_label := Label.new(); volume_label.text = "Общая громкость"; box.add_child(volume_label)
    var volume := HSlider.new(); volume.min_value = 0; volume.max_value = 100; volume.value = db_to_linear(AudioServer.get_bus_volume_db(0))*100; volume.value_changed.connect(_set_volume); box.add_child(volume)
    var fullscreen := CheckButton.new(); fullscreen.text = "Полноэкранный режим"; fullscreen.button_pressed = DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN; fullscreen.toggled.connect(_set_fullscreen); box.add_child(fullscreen)
    _add_button(box,"ЗАКРЫТЬ",_close_settings)

func _close_settings() -> void:
    if is_instance_valid(settings_panel):
        settings_panel.queue_free()
    settings_panel = null

func _set_volume(value: float) -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(0.001,value/100.0)))

func _set_fullscreen(enabled: bool) -> void:
    DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if enabled else DisplayServer.WINDOW_MODE_WINDOWED)

func _exit_game() -> void:
    get_tree().quit()
