extends CanvasLayer

const InventoryModelScript = preload("res://scripts/systems/inventory_model.gd")
const CraftingSystemScript = preload("res://scripts/systems/crafting_system.gd")
const MapPanelScript = preload("res://scripts/ui/map_panel.gd")
var main_ref
var player
var world
var inventory: InventoryModel
var crafting: CraftingSystem
var root_control: Control
var stats_label: Label
var depth_label: Label
var hint_label: Label
var toast_label: Label
var hotbar_buttons: Array = []
var inventory_panel: PanelContainer
var slot_buttons: Array = []
var selected_source: int = -1
var map_panel: PanelContainer
var pause_panel: PanelContainer
var inventory_visible: bool = false
var paused_menu_visible: bool = false
var toast_time: float = 0.0

func setup(main_node: Node, player_node: CharacterBody2D, world_node: Node2D, inventory_model: InventoryModel) -> void:
    main_ref = main_node
    player = player_node
    world = world_node
    inventory = inventory_model
    crafting = CraftingSystemScript.new(inventory)
    if not inventory.changed.is_connected(refresh):
        inventory.changed.connect(refresh)
    _build_ui()
    refresh()

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    add_to_group("hud")

func _panel_style(color: Color = Color(0.035,0.06,0.09,0.92)) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = color
    style.border_color = Color("3c5e6d")
    style.set_border_width_all(1)
    style.set_corner_radius_all(3)
    style.content_margin_left = 12; style.content_margin_right = 12
    style.content_margin_top = 9; style.content_margin_bottom = 9
    return style

func _build_ui() -> void:
    root_control = Control.new()
    root_control.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root_control.mouse_filter = Control.MOUSE_FILTER_PASS
    add_child(root_control)
    var info := PanelContainer.new()
    info.position = Vector2(16,16); info.custom_minimum_size = Vector2(300,98)
    info.add_theme_stylebox_override("panel",_panel_style())
    root_control.add_child(info)
    var info_box := VBoxContainer.new(); info_box.add_theme_constant_override("separation",4); info.add_child(info_box)
    stats_label = Label.new(); stats_label.add_theme_font_size_override("font_size",16); stats_label.add_theme_color_override("font_color",Color("e7eff0")); info_box.add_child(stats_label)
    depth_label = Label.new(); depth_label.add_theme_font_size_override("font_size",13); depth_label.add_theme_color_override("font_color",Color("8fbbc2")); info_box.add_child(depth_label)
    hint_label = Label.new(); hint_label.text = "ЛКМ добыть/атаковать • ПКМ разместить • H лечение"; hint_label.add_theme_font_size_override("font_size",11); hint_label.add_theme_color_override("font_color",Color("96a8b1")); hint_label.position = Vector2(18,118); hint_label.size = Vector2(560,24); root_control.add_child(hint_label)
    toast_label = Label.new(); toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER; toast_label.add_theme_font_size_override("font_size",17); toast_label.add_theme_color_override("font_color",Color("ffe5ac")); toast_label.position = Vector2(300,26); toast_label.size = Vector2(680,40); root_control.add_child(toast_label)
    _build_hotbar()
    _build_inventory_panel()
    _build_map_panel()
    _build_pause_panel()

func _build_hotbar() -> void:
    var holder := PanelContainer.new()
    holder.name = "HotbarPanel"
    holder.add_theme_stylebox_override("panel",_panel_style(Color(0.035,0.06,0.09,0.82)))
    holder.custom_minimum_size = Vector2(8*58+24,68)
    root_control.add_child(holder)
    var hotbar := HBoxContainer.new(); hotbar.add_theme_constant_override("separation",3); holder.add_child(hotbar)
    for i in range(8):
        var index := i
        var button := Button.new()
        button.custom_minimum_size = Vector2(55,48)
        button.add_theme_font_size_override("font_size",11)
        button.pressed.connect(func(): _select_hotbar(index))
        hotbar.add_child(button)
        hotbar_buttons.append(button)
    holder.position = Vector2((get_viewport().get_visible_rect().size.x-holder.custom_minimum_size.x)/2.0, get_viewport().get_visible_rect().size.y-84.0)
    get_viewport().size_changed.connect(func(): holder.position = Vector2((get_viewport().get_visible_rect().size.x-holder.size.x)/2.0,get_viewport().get_visible_rect().size.y-84.0))

func _build_inventory_panel() -> void:
    inventory_panel = PanelContainer.new()
    inventory_panel.visible = false
    inventory_panel.custom_minimum_size = Vector2(770,480)
    inventory_panel.add_theme_stylebox_override("panel",_panel_style(Color(0.035,0.055,0.08,0.98)))
    inventory_panel.position = Vector2((get_viewport().get_visible_rect().size.x-770)/2.0,(get_viewport().get_visible_rect().size.y-480)/2.0)
    root_control.add_child(inventory_panel)
    var outer := VBoxContainer.new(); outer.add_theme_constant_override("separation",10); inventory_panel.add_child(outer)
    var heading := HBoxContainer.new(); outer.add_child(heading)
    var title := Label.new(); title.text = "ИНВЕНТАРЬ / СНАРЯЖЕНИЕ"; title.size_flags_horizontal = Control.SIZE_EXPAND_FILL; title.add_theme_font_size_override("font_size",22); heading.add_child(title)
    var close := Button.new(); close.text = "✕"; close.pressed.connect(func(): _toggle_inventory(false)); heading.add_child(close)
    var body := HBoxContainer.new(); body.add_theme_constant_override("separation",16); outer.add_child(body)
    var grid := GridContainer.new(); grid.columns = 6; grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL; grid.add_theme_constant_override("h_separation",5); grid.add_theme_constant_override("v_separation",5); body.add_child(grid)
    for i in range(InventoryModelScript.SLOT_COUNT):
        var index := i
        var button := Button.new(); button.custom_minimum_size = Vector2(62,58); button.add_theme_font_size_override("font_size",11); button.pressed.connect(func(): _slot_pressed(index)); grid.add_child(button); slot_buttons.append(button)
    var side := VBoxContainer.new(); side.custom_minimum_size = Vector2(235,0); side.add_theme_constant_override("separation",7); body.add_child(side)
    var craft_title := Label.new(); craft_title.text = "КРАФТ УБЕЖИЩА"; craft_title.add_theme_font_size_override("font_size",16); side.add_child(craft_title)
    var note := Label.new(); note.text = "Выбери рецепт. Материалы списываются только при успешном создании."; note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; note.add_theme_font_size_override("font_size",11); note.add_theme_color_override("font_color",Color("9db2bb")); side.add_child(note)
    for recipe_id in crafting.get_recipe_ids():
        var rid := str(recipe_id)
        var recipe: Dictionary = crafting.recipes[rid]
        var button := Button.new()
        button.text = str(recipe.get("name",rid))
        button.custom_minimum_size = Vector2(225,42)
        button.tooltip_text = _recipe_tooltip(recipe)
        button.add_theme_font_size_override("font_size",12)
        button.pressed.connect(func(): _craft(rid))
        side.add_child(button)
    var equipment := Label.new(); equipment.text = "Экипировка\nИнструмент: выбранный слот панели\nБроня: пока не найдена"; equipment.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; equipment.add_theme_font_size_override("font_size",12); equipment.add_theme_color_override("font_color",Color("b2c5ca")); side.add_child(equipment)
    var footer := Label.new(); footer.text = "Клик по двум слотам: поменять местами / объединить стаки. Tab или Esc — закрыть."; footer.add_theme_font_size_override("font_size",11); footer.add_theme_color_override("font_color",Color("8aa0ac")); outer.add_child(footer)

func _recipe_tooltip(recipe: Dictionary) -> String:
    var parts: Array[String] = []
    for id in recipe.get("ingredients",{}):
        parts.append("%s ×%d" % [ItemDB.get_name(str(id)),int(recipe["ingredients"][id])])
    return str(recipe.get("description","")) + "\nНужно: " + ", ".join(parts)

func _build_map_panel() -> void:
    map_panel = PanelContainer.new(); map_panel.visible = false; map_panel.custom_minimum_size = Vector2(320,350); map_panel.position = Vector2(get_viewport().get_visible_rect().size.x-345,100); map_panel.add_theme_stylebox_override("panel",_panel_style()); root_control.add_child(map_panel)
    var box := VBoxContainer.new(); map_panel.add_child(box)
    var title := Label.new(); title.text = "КАРТА ГЛУБИН"; title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",17); box.add_child(title)
    var map = MapPanelScript.new(); map.custom_minimum_size = Vector2(285,290); map.size_flags_vertical = Control.SIZE_EXPAND_FILL; map.world = world; map.player = player; box.add_child(map)
    var legend := Label.new(); legend.text = "Светлая точка — ты. Карта показывает структуру мира."; legend.add_theme_font_size_override("font_size",10); legend.add_theme_color_override("font_color",Color("9db2bb")); box.add_child(legend)

func _build_pause_panel() -> void:
    pause_panel = PanelContainer.new(); pause_panel.visible = false; pause_panel.custom_minimum_size = Vector2(330,300); pause_panel.position = Vector2((get_viewport().get_visible_rect().size.x-330)/2.0,(get_viewport().get_visible_rect().size.y-300)/2.0); pause_panel.add_theme_stylebox_override("panel",_panel_style(Color(0.025,0.04,0.06,0.98))); root_control.add_child(pause_panel)
    var box := VBoxContainer.new(); box.add_theme_constant_override("separation",10); pause_panel.add_child(box)
    var title := Label.new(); title.text = "ЭКСПЕДИЦИЯ ПРИОСТАНОВЛЕНА"; title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",17); box.add_child(title)
    _add_pause_button(box,"ПРОДОЛЖИТЬ",_resume)
    _add_pause_button(box,"СОХРАНИТЬ",_save)
    _add_pause_button(box,"В УБЕЖИЩЕ / МЕНЮ",_return_to_title)
    _add_pause_button(box,"ВЫХОД",_exit_from_pause)

func _add_pause_button(parent: VBoxContainer, text_value: String, action: Callable) -> void:
    var button := Button.new(); button.text = text_value; button.custom_minimum_size = Vector2(280,38); button.pressed.connect(action); parent.add_child(button)

func _process(delta: float) -> void:
    if player != null and is_instance_valid(player):
        stats_label.text = "ЗДОРОВЬЕ  %3.0f / %3.0f     ВЫНОСЛИВОСТЬ  %3.0f%%" % [player.health,player.max_health,player.stamina]
        var depth := maxi(0,int(player.global_position.y/16.0)-14)
        depth_label.text = "ГЛУБИНА  %d м    •    SEED %d" % [depth,world.seed_value]
        if toast_time > 0.0:
            toast_time -= delta
            if toast_time <= 0.0:
                toast_label.text = ""

func refresh() -> void:
    if not is_instance_valid(root_control) or inventory == null:
        return
    for i in range(hotbar_buttons.size()):
        var id := inventory.get_item_id(i)
        var count := inventory.get_count(i)
        var display := "%d\n%s" % [i+1,ItemDB.get_name(id)] if not id.is_empty() else str(i+1)+"\n—"
        if count > 1:
            display += " ×"+str(count)
        hotbar_buttons[i].text = display
        hotbar_buttons[i].tooltip_text = str(ItemDB.get_item(id).get("description",""))
        var style := _panel_style(Color(0.10,0.20,0.24,0.98) if player != null and player.selected_slot == i else Color(0.04,0.07,0.10,0.92))
        style.border_color = Color("a6e7df") if player != null and player.selected_slot == i else Color("3c5e6d")
        hotbar_buttons[i].add_theme_stylebox_override("normal",style)
    for i in range(slot_buttons.size()):
        var id := inventory.get_item_id(i); var count := inventory.get_count(i)
        var value := str(i+1)+"\n"+ItemDB.get_name(id) if not id.is_empty() else str(i+1)+"\n—"
        if count > 1: value += "\n×"+str(count)
        slot_buttons[i].text = value
        slot_buttons[i].tooltip_text = str(ItemDB.get_item(id).get("description",""))
        slot_buttons[i].add_theme_stylebox_override("normal",_panel_style(Color(0.12,0.22,0.25,0.98) if selected_source == i else Color(0.04,0.07,0.10,0.95)))

func _select_hotbar(index: int) -> void:
    if player != null and is_instance_valid(player):
        player.selected_slot = index
        refresh()
        AudioManager.play("ui")

func _slot_pressed(index: int) -> void:
    if selected_source < 0:
        selected_source = index
    else:
        inventory.move_slot(selected_source,index)
        selected_source = -1
    refresh()

func _craft(recipe_id: String) -> void:
    var result := crafting.craft(recipe_id)
    notify(str(result.get("message","")))
    AudioManager.play("ui")
    refresh()

func notify(message: String) -> void:
    toast_label.text = message
    toast_time = 2.8

func _unhandled_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    match event.keycode:
        KEY_ESCAPE:
            if paused_menu_visible: _resume()
            else: _pause()
            get_viewport().set_input_as_handled()
        KEY_TAB:
            if not paused_menu_visible: _toggle_inventory(not inventory_visible)
            get_viewport().set_input_as_handled()
        KEY_M:
            if not paused_menu_visible:
                map_panel.visible = not map_panel.visible
                AudioManager.play("ui")
            get_viewport().set_input_as_handled()
        KEY_E, KEY_C:
            if not paused_menu_visible: _toggle_inventory(not inventory_visible)
            get_viewport().set_input_as_handled()

func _toggle_inventory(enabled: bool) -> void:
    inventory_visible = enabled
    inventory_panel.visible = enabled
    if enabled:
        selected_source = -1
        refresh()
    AudioManager.play("ui")

func is_modal_open() -> bool:
    return inventory_visible or paused_menu_visible or map_panel.visible or (main_ref != null and main_ref.get_tree().paused)

func _pause() -> void:
    paused_menu_visible = true
    pause_panel.visible = true
    inventory_panel.visible = false
    map_panel.visible = false
    inventory_visible = false
    get_tree().paused = true
    AudioManager.play("ui")

func _resume() -> void:
    paused_menu_visible = false
    pause_panel.visible = false
    get_tree().paused = false

func _save() -> void:
    if main_ref != null and main_ref.has_method("save_game"):
        if main_ref.save_game(): notify("Игра сохранена.")
        else: notify("Не удалось сохранить игру.")
    AudioManager.play("ui")

func _exit_from_pause() -> void:
    _save()
    get_tree().quit()

func _return_to_title() -> void:
    _save()
    if main_ref != null and main_ref.has_method("return_to_title"):
        main_ref.return_to_title()

