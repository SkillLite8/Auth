extends Control

var world
var player: Node2D
var redraw_clock := 0.0

func _process(delta: float) -> void:
    if not is_visible_in_tree():
        return
    redraw_clock -= delta
    if redraw_clock <= 0.0:
        redraw_clock = 0.18
        queue_redraw()

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO,size),Color("080e16"),true)
    if world == null or not is_instance_valid(world) or world.cells.is_empty():
        return
    var sx := size.x / float(world.WORLD_WIDTH)
    var sy := size.y / float(world.WORLD_HEIGHT)
    var colors := {1:Color("76503b"),2:Color("586675"),3:Color("252c36"),4:Color("bb744b"),5:Color("9ca8b3"),6:Color("56b9da"),7:Color("a18ae8"),8:Color("ed7148"),9:Color("ffd184"),10:Color("8b5e3e"),12:Color("4e8069"),13:Color("3d8197"),14:Color("9b4b67"),15:Color("a99c80"),16:Color("404a5c")}
    for y in range(world.WORLD_HEIGHT):
        for x in range(world.WORLD_WIDTH):
            var tile := int(world.cells[y][x])
            if tile == 0:
                continue
            draw_rect(Rect2(x*sx,y*sy,maxf(1.0,sx),maxf(1.0,sy)),colors.get(tile,Color("586675")),true)
    if player != null and is_instance_valid(player):
        var px := player.global_position.x / float(world.WORLD_WIDTH*world.TILE_SIZE) * size.x
        var py := player.global_position.y / float(world.WORLD_HEIGHT*world.TILE_SIZE) * size.y
        draw_circle(Vector2(px,py),4.0,Color("f1f5f7"))
