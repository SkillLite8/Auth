extends Node

var players: Dictionary = {}
var streams: Dictionary = {
    "mine": preload("res://assets/audio/mine.wav"),
    "pickup": preload("res://assets/audio/pickup.wav"),
    "hit": preload("res://assets/audio/hit.wav"),
    "ui": preload("res://assets/audio/ui.wav")
}

func _ready() -> void:
    for key in streams:
        var player := AudioStreamPlayer.new()
        player.name = "SFX_" + str(key)
        player.stream = streams[key]
        player.volume_db = -3.0
        add_child(player)
        players[key] = player

func play(sound_id: String) -> void:
    if not players.has(sound_id):
        return
    var player: AudioStreamPlayer = players[sound_id]
    player.stop()
    player.play()
