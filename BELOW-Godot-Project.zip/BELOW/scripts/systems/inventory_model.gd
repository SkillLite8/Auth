class_name InventoryModel
extends RefCounted

signal changed
const SLOT_COUNT: int = 24
var slots: Array = []

func _init() -> void:
    for i in range(SLOT_COUNT):
        slots.append({"id": "", "count": 0})

func add_item(item_id: String, amount: int) -> int:
    if item_id.is_empty() or amount <= 0:
        return maxi(amount, 0)
    if ItemDB.get_item(item_id).is_empty():
        return amount
    var remaining := amount
    var max_stack := int(ItemDB.get_item(item_id).get("max_stack", 99))
    if max_stack < 1:
        max_stack = 1
    for slot in slots:
        if remaining <= 0:
            break
        if str(slot.get("id", "")) == item_id and int(slot.get("count", 0)) < max_stack:
            var add := mini(remaining, max_stack - int(slot["count"]))
            slot["count"] = int(slot["count"]) + add
            remaining -= add
    for slot in slots:
        if remaining <= 0:
            break
        if str(slot.get("id", "")).is_empty() or int(slot.get("count", 0)) <= 0:
            var add := mini(remaining, max_stack)
            slot["id"] = item_id
            slot["count"] = add
            remaining -= add
    if remaining != amount:
        changed.emit()
    return remaining

func count_item(item_id: String) -> int:
    var total := 0
    for slot in slots:
        if str(slot.get("id", "")) == item_id:
            total += int(slot.get("count", 0))
    return total

func remove_item(item_id: String, amount: int) -> bool:
    if amount <= 0 or count_item(item_id) < amount:
        return false
    var remaining := amount
    for slot in slots:
        if str(slot.get("id", "")) != item_id:
            continue
        var take := mini(remaining, int(slot.get("count", 0)))
        slot["count"] = int(slot["count"]) - take
        remaining -= take
        if int(slot["count"]) <= 0:
            slot["id"] = ""
            slot["count"] = 0
        if remaining <= 0:
            break
    changed.emit()
    return true

func move_slot(source: int, target: int) -> void:
    if source < 0 or target < 0 or source >= slots.size() or target >= slots.size() or source == target:
        return
    var a: Dictionary = slots[source]
    var b: Dictionary = slots[target]
    if str(a.get("id", "")).is_empty():
        return
    if str(a.get("id", "")) == str(b.get("id", "")) and not str(b.get("id", "")).is_empty():
        var max_stack := int(ItemDB.get_item(str(a["id"])).get("max_stack", 99))
        var moved := mini(int(a["count"]), max_stack - int(b["count"]))
        if moved > 0:
            b["count"] = int(b["count"]) + moved
            a["count"] = int(a["count"]) - moved
            if int(a["count"]) <= 0:
                a["id"] = ""
                a["count"] = 0
    else:
        slots[source] = b.duplicate(true)
        slots[target] = a.duplicate(true)
    changed.emit()

func get_item_id(index: int) -> String:
    if index < 0 or index >= slots.size():
        return ""
    return str(slots[index].get("id", ""))

func get_count(index: int) -> int:
    if index < 0 or index >= slots.size():
        return 0
    return int(slots[index].get("count", 0))

func to_dict() -> Dictionary:
    return {"slots": slots.duplicate(true)}

func from_dict(data: Dictionary) -> void:
    var raw_slots = data.get("slots", [])
    var source_slots: Array = raw_slots if raw_slots is Array else []
    slots.clear()
    for i in range(SLOT_COUNT):
        var entry: Dictionary = {}
        if i < source_slots.size() and source_slots[i] is Dictionary:
            entry = source_slots[i]
        var item_id := str(entry.get("id", ""))
        var count := maxi(0, int(entry.get("count", 0)))
        var item: Dictionary = ItemDB.get_item(item_id)
        if item_id.is_empty() or count == 0 or item.is_empty():
            slots.append({"id": "", "count": 0})
        else:
            var max_stack := maxi(1, int(item.get("max_stack", 99)))
            slots.append({"id": item_id, "count": mini(count, max_stack)})
    changed.emit()
