extends Node

var items: Dictionary = {}

func _ready() -> void:
    var file := FileAccess.open("res://data/items.json", FileAccess.READ)
    if file == null:
        push_error("Не удалось открыть data/items.json")
        return
    var parsed = JSON.parse_string(file.get_as_text())
    file.close()
    if parsed is Dictionary:
        items = parsed
    else:
        push_error("data/items.json имеет неверный формат")

func get_item(item_id: String) -> Dictionary:
    var value = items.get(item_id, {})
    return value if value is Dictionary else {}

func get_item_name(item_id: String) -> String:
    return str(get_item(item_id).get("name", item_id))
