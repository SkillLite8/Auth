extends Node

const SAVE_PATH := "user://below_save.json"
const SAVE_VERSION := 1

func has_save() -> bool:
    return FileAccess.file_exists(SAVE_PATH)

func save_game(payload: Dictionary) -> bool:
    var data := payload.duplicate(true)
    data["save_version"] = SAVE_VERSION
    data["saved_at"] = Time.get_datetime_string_from_system(false, true)
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        push_error("Не удалось открыть сохранение для записи: %s" % FileAccess.get_open_error())
        return false
    file.store_string(JSON.stringify(data, "  "))
    file.close()
    return true

func load_game() -> Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        return {}
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        push_warning("Сохранение не удалось открыть; будет создан новый мир.")
        return {}
    var parsed = JSON.parse_string(file.get_as_text())
    file.close()
    if not parsed is Dictionary:
        push_warning("Файл сохранения повреждён; будет создан новый мир.")
        return {}
    var version := int(parsed.get("save_version", 0))
    if version > SAVE_VERSION:
        push_warning("Сохранение создано более новой версией игры.")
        return {}
    return parsed
