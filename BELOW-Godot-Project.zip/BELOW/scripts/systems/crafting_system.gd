class_name CraftingSystem
extends RefCounted

var inventory: InventoryModel
var recipes: Dictionary = {}

func _init(inventory_ref: InventoryModel) -> void:
    inventory = inventory_ref
    var file := FileAccess.open("res://data/recipes.json", FileAccess.READ)
    if file != null:
        var parsed = JSON.parse_string(file.get_as_text())
        file.close()
        if parsed is Dictionary:
            recipes = parsed

func get_recipe_ids() -> Array:
    return recipes.keys()

func can_craft(recipe_id: String) -> bool:
    if not recipes.has(recipe_id):
        return false
    var recipe: Dictionary = recipes[recipe_id]
    var ingredients: Dictionary = recipe.get("ingredients", {})
    for item_id in ingredients:
        if inventory.count_item(str(item_id)) < int(ingredients[item_id]):
            return false
    return true

func craft(recipe_id: String) -> Dictionary:
    if not can_craft(recipe_id):
        return {"ok": false, "message": "Не хватает материалов."}
    var recipe: Dictionary = recipes[recipe_id]
    var ingredients: Dictionary = recipe.get("ingredients", {})
    var result: Dictionary = recipe.get("result", {})
    var inventory_backup: Dictionary = inventory.to_dict()
    for item_id in ingredients:
        if not inventory.remove_item(str(item_id), int(ingredients[item_id])):
            return {"ok": false, "message": "Не удалось списать материалы."}
    var item_id := str(result.get("id", ""))
    var amount := int(result.get("count", 1))
    var remaining := inventory.add_item(item_id, amount)
    if remaining > 0:
        # Roll back the complete inventory, including any partially inserted result.
        inventory.from_dict(inventory_backup)
        return {"ok": false, "message": "Освободи место в инвентаре."}
    return {"ok": true, "message": "Создано: %s" % str(recipe.get("name", item_id))}
