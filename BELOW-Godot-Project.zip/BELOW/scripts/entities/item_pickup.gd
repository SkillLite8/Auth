extends Area2D

var item_id: String = "stone"
var amount: int = 1
var bob_phase: float = 0.0
var life_time: float = 0.0
@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
    add_to_group("item_pickups")
    body_entered.connect(_on_body_entered)
    _update_icon()
    bob_phase = randf() * TAU

func _process(delta: float) -> void:
    life_time += delta
    sprite.position.y = sin(life_time * 3.2 + bob_phase) * 2.0

func _update_icon() -> void:
    var icon_index := int(ItemDB.get_item(item_id).get("icon", 1))
    sprite.region_rect = Rect2((icon_index % 8)*16, int(icon_index / 8)*16, 16, 16)

func _on_body_entered(body: Node2D) -> void:
    if not body.has_method("collect_pickup"):
        return
    var remaining: int = body.collect_pickup(item_id, amount)
    if remaining <= 0:
        AudioManager.play("pickup")
        queue_free()
    else:
        amount = remaining
