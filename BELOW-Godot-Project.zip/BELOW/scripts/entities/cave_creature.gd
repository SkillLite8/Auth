extends CharacterBody2D

signal died(position: Vector2)
enum State { IDLE, PATROL, CHASE, WINDUP, RECOVER, RETURN, DEAD }
const GRAVITY := 850.0
var state: State = State.PATROL
var player
var world
var home_position: Vector2
var health: float = 28.0
var patrol_direction: float = 1.0
var state_timer: float = 0.0
var attack_cooldown: float = 0.0
var hurt_flash: float = 0.0
var attack_damage: float = 10.0
@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
    add_to_group("enemies")
    home_position = global_position
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func _physics_process(delta: float) -> void:
    if state == State.DEAD:
        return
    state_timer = maxf(0.0, state_timer - delta)
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    hurt_flash = maxf(0.0, hurt_flash - delta)
    if hurt_flash > 0.0:
        sprite.modulate = Color(1.0, 0.55, 0.55)
    else:
        sprite.modulate = Color.WHITE
    if state == State.WINDUP:
        queue_redraw()
    if not is_on_floor():
        velocity.y += GRAVITY * delta
    if player == null or not is_instance_valid(player):
        _patrol(delta)
        move_and_slide()
        return
    var distance := global_position.distance_to(player.global_position)
    var visible := distance < 230.0 and (world == null or world.has_line_of_sight(global_position, player.global_position))
    match state:
        State.IDLE:
            velocity.x = move_toward(velocity.x, 0.0, 240.0*delta)
            if visible:
                state = State.CHASE
        State.PATROL:
            if visible:
                state = State.CHASE
            else:
                _patrol(delta)
        State.CHASE:
            if distance > 330.0:
                state = State.RETURN
            elif not visible and distance > 80.0:
                velocity.x = move_toward(velocity.x, 0.0, 140.0*delta)
            elif distance < 34.0 and attack_cooldown <= 0.0:
                state = State.WINDUP
                state_timer = 0.48
                velocity.x = 0.0
            else:
                var direction := signf(player.global_position.x - global_position.x)
                velocity.x = move_toward(velocity.x, direction * 68.0, 240.0*delta)
                if is_on_floor() and player.global_position.y < global_position.y - 16.0:
                    velocity.y = -245.0
        State.WINDUP:
            velocity.x = move_toward(velocity.x, 0.0, 300.0*delta)
            if state_timer <= 0.0:
                if distance < 44.0 and (world == null or world.has_line_of_sight(global_position, player.global_position)):
                    player.take_damage(attack_damage, signf(player.global_position.x-global_position.x))
                attack_cooldown = 1.0
                state = State.RECOVER
                state_timer = 0.55
        State.RECOVER:
            velocity.x = move_toward(velocity.x, 0.0, 180.0*delta)
            if state_timer <= 0.0:
                state = State.CHASE if distance < 250.0 else State.PATROL
        State.RETURN:
            var home_distance := global_position.distance_to(home_position)
            if home_distance < 10.0:
                state = State.PATROL
                velocity.x = 0.0
            else:
                velocity.x = move_toward(velocity.x, signf(home_position.x-global_position.x)*48.0, 150.0*delta)
        _:
            pass
    if absf(velocity.x) > 1.0:
        sprite.flip_h = velocity.x < 0.0
    move_and_slide()

func _patrol(delta: float) -> void:
    velocity.x = move_toward(velocity.x, patrol_direction * 28.0, 90.0*delta)
    if absf(global_position.x - home_position.x) > 65.0:
        patrol_direction *= -1.0

func take_damage(amount: float, source: Node = null) -> void:
    if state == State.DEAD:
        return
    health -= amount
    hurt_flash = 0.13
    AudioManager.play("hit")
    if source is Node2D:
        velocity.x = signf(global_position.x - source.global_position.x) * 100.0
        velocity.y = -100.0
    if health <= 0.0:
        state = State.DEAD
        died.emit(global_position)
        # Leave a small chance of useful drops on the cavern floor.
        if world != null and world.has_method("spawn_enemy_loot"):
            world.spawn_enemy_loot(global_position)
        queue_free()

func _draw() -> void:
    if state == State.WINDUP:
        draw_arc(Vector2(0,-19), 9.0, 0.0, TAU, 18, Color(1.0,0.24,0.32,0.9), 2.0)
