extends CharacterBody3D

const Catalog = preload("res://scripts/3d/item_catalog.gd")

const WALK_SPEED: float = 5.4
const SPRINT_SPEED: float = 8.0
const SNEAK_SPEED: float = 1.9
const JUMP_VELOCITY: float = 5.4
const GRAVITY: float = 18.0
const MOUSE_SENSITIVITY: float = 0.0022
const MINE_INTERVAL: float = 0.34
const STAND_HEIGHT: float = 1.8
const SNEAK_HEIGHT: float = 1.45
const STAND_HEAD_Y: float = 0.55
const SNEAK_HEAD_Y: float = 0.2
const INV_SIZE: int = 36

const RECIPES: Array = [
    {"needs": {"wood": 1, "echo_core": 1}, "id": "torch", "count": 4},
    {"needs": {"echo_core": 1, "berries": 2}, "id": "salve", "count": 2},
    {"needs": {"cobblestone": 4}, "id": "stone", "count": 4}
]

var game
var health: float = 20.0
var max_health: float = 20.0
var hunger: float = 20.0
var xp: int = 0
var selected_slot: int = 0
var groups_ids: Dictionary = {}
var groups_counts: Dictionary = {}
var cursor_id: String = ""
var cursor_count: int = 0
var mine_repeat_timer: float = 0.0
var message_cooldown: float = 0.0
var jump_was_down: bool = false
var sprint_held: bool = false
var sneak_held: bool = false
var is_sneaking: bool = false
var is_dead: bool = false
var regen_timer: float = 0.0
var starve_timer: float = 0.0
var last_hunger_shown: int = 20

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var interaction_ray: RayCast3D = $Head/Camera3D/InteractionRay
@onready var body_shape: CollisionShape3D = $CollisionShape3D

func _ready() -> void:
    add_to_group("explorer")
    _init_inventory()
    _give_starting_items()
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
    camera.current = true
    interaction_ray.enabled = true
    interaction_ray.add_exception(self)

# ---------------------------------------------------------------- inventory

func _blank_ids(amount: int) -> Array:
    var arr: Array = []
    for i in range(amount):
        arr.append("")
    return arr

func _zero_counts(amount: int) -> Array:
    var arr: Array = []
    for i in range(amount):
        arr.append(0)
    return arr

func _init_inventory() -> void:
    groups_ids = {
        "inv": _blank_ids(INV_SIZE),
        "armor": _blank_ids(4),
        "offhand": _blank_ids(1),
        "craft": _blank_ids(4),
        "result": _blank_ids(1)
    }
    groups_counts = {
        "inv": _zero_counts(INV_SIZE),
        "armor": _zero_counts(4),
        "offhand": _zero_counts(1),
        "craft": _zero_counts(4),
        "result": _zero_counts(1)
    }
    cursor_id = ""
    cursor_count = 0

func _give_starting_items() -> void:
    add_item("pickaxe", 1)
    add_item("dirt", 24)
    add_item("cobblestone", 16)
    add_item("wood", 8)
    add_item("torch", 4)
    add_item("salve", 2)
    add_item("berries", 5)

func get_slot_id(group: String, index: int) -> String:
    var ids: Array = groups_ids[group]
    if index < 0 or index >= ids.size():
        return ""
    return str(ids[index])

func get_slot_count(group: String, index: int) -> int:
    var counts: Array = groups_counts[group]
    if index < 0 or index >= counts.size():
        return 0
    return int(counts[index])

func set_slot(group: String, index: int, item_id: String, amount: int) -> void:
    var ids: Array = groups_ids[group]
    var counts: Array = groups_counts[group]
    if index < 0 or index >= ids.size():
        return
    if amount <= 0 or item_id == "":
        ids[index] = ""
        counts[index] = 0
    else:
        ids[index] = item_id
        counts[index] = amount

func selected_item_id() -> String:
    return get_slot_id("inv", selected_slot)

func get_armor_points() -> int:
    var points: int = 0
    for i in range(4):
        if get_slot_id("armor", i) != "":
            points += 2
    return points

func get_level() -> int:
    return floori(float(xp) / 10.0)

func get_level_progress() -> float:
    return float(xp % 10) / 10.0

func add_xp(amount: int) -> void:
    var before: int = get_level()
    xp += amount
    if get_level() > before and game != null:
        game.notify("Уровень опыта: %d" % get_level())
    _refresh_hud()

func _refresh_hud() -> void:
    if game != null:
        game.refresh_hud()

func add_item(item_id: String, amount: int = 1) -> int:
    var left: int = amount
    var max_stack: int = Catalog.max_stack(item_id)
    for i in range(INV_SIZE):
        if left <= 0:
            break
        if get_slot_id("inv", i) == item_id:
            var space: int = max_stack - get_slot_count("inv", i)
            var moved: int = mini(space, left)
            if moved > 0:
                set_slot("inv", i, item_id, get_slot_count("inv", i) + moved)
                left -= moved
    for i in range(INV_SIZE):
        if left <= 0:
            break
        if get_slot_id("inv", i) == "":
            var moved_new: int = mini(max_stack, left)
            set_slot("inv", i, item_id, moved_new)
            left -= moved_new
    if left > 0 and game != null:
        game.notify("Рюкзак полон.")
    _refresh_hud()
    return left

func get_count(item_id: String) -> int:
    var total: int = 0
    for i in range(INV_SIZE):
        if get_slot_id("inv", i) == item_id:
            total += get_slot_count("inv", i)
    return total

func remove_item(item_id: String, amount: int = 1) -> bool:
    if get_count(item_id) < amount:
        return false
    var left: int = amount
    for i in range(INV_SIZE):
        if left <= 0:
            break
        if get_slot_id("inv", i) == item_id:
            var taken: int = mini(get_slot_count("inv", i), left)
            set_slot("inv", i, item_id, get_slot_count("inv", i) - taken)
            left -= taken
    return true

func _consume_selected(amount: int) -> void:
    var item_id: String = selected_item_id()
    set_slot("inv", selected_slot, item_id, get_slot_count("inv", selected_slot) - amount)

func slot_accepts(group: String, item_id: String) -> bool:
    if group == "armor" or group == "result":
        return false
    return item_id != ""

func slot_click(group: String, index: int, right_click: bool) -> void:
    if group == "result":
        _click_result()
        return
    var slot_id: String = get_slot_id(group, index)
    var slot_count: int = get_slot_count(group, index)
    if not right_click:
        if cursor_id == "":
            if slot_id != "":
                cursor_id = slot_id
                cursor_count = slot_count
                set_slot(group, index, "", 0)
        elif slot_id == "":
            if slot_accepts(group, cursor_id):
                set_slot(group, index, cursor_id, cursor_count)
                cursor_id = ""
                cursor_count = 0
        elif slot_id == cursor_id:
            if slot_accepts(group, cursor_id):
                var space: int = Catalog.max_stack(slot_id) - slot_count
                var moved: int = mini(space, cursor_count)
                set_slot(group, index, slot_id, slot_count + moved)
                cursor_count -= moved
                if cursor_count <= 0:
                    cursor_id = ""
                    cursor_count = 0
        elif slot_accepts(group, cursor_id):
            set_slot(group, index, cursor_id, cursor_count)
            cursor_id = slot_id
            cursor_count = slot_count
    else:
        if cursor_id == "":
            if slot_id != "":
                var take: int = int(ceil(float(slot_count) / 2.0))
                cursor_id = slot_id
                cursor_count = take
                set_slot(group, index, slot_id, slot_count - take)
        elif slot_accepts(group, cursor_id):
            if slot_id == "":
                set_slot(group, index, cursor_id, 1)
                cursor_count -= 1
            elif slot_id == cursor_id:
                if slot_count < Catalog.max_stack(slot_id):
                    set_slot(group, index, slot_id, slot_count + 1)
                    cursor_count -= 1
            else:
                set_slot(group, index, cursor_id, cursor_count)
                cursor_id = slot_id
                cursor_count = slot_count
            if cursor_count <= 0:
                cursor_id = ""
                cursor_count = 0
    if group == "craft":
        update_craft_result()

func _click_result() -> void:
    var result_id: String = get_slot_id("result", 0)
    if result_id == "":
        return
    var result_count: int = get_slot_count("result", 0)
    if cursor_id != "":
        if cursor_id != result_id:
            return
        if cursor_count + result_count > Catalog.max_stack(result_id):
            return
    else:
        cursor_id = result_id
        cursor_count = 0
    cursor_count += result_count
    for i in range(4):
        var craft_id: String = get_slot_id("craft", i)
        if craft_id != "":
            set_slot("craft", i, craft_id, get_slot_count("craft", i) - 1)
    update_craft_result()

func update_craft_result() -> void:
    set_slot("result", 0, "", 0)
    var counts: Dictionary = {}
    for i in range(4):
        var craft_id: String = get_slot_id("craft", i)
        if craft_id != "":
            counts[craft_id] = int(counts.get(craft_id, 0)) + 1
    if counts.is_empty():
        return
    for recipe in RECIPES:
        var needs: Dictionary = recipe["needs"]
        if needs.size() != counts.size():
            continue
        var matches: bool = true
        for key in needs.keys():
            if int(counts.get(key, 0)) != int(needs[key]):
                matches = false
        if matches:
            set_slot("result", 0, str(recipe["id"]), int(recipe["count"]))
            return

func return_loose_items() -> void:
    if cursor_id != "":
        add_item(cursor_id, cursor_count)
        cursor_id = ""
        cursor_count = 0
    for i in range(4):
        var craft_id: String = get_slot_id("craft", i)
        if craft_id != "":
            add_item(craft_id, get_slot_count("craft", i))
            set_slot("craft", i, "", 0)
    set_slot("result", 0, "", 0)

# ---------------------------------------------------------------- input

func _input(event: InputEvent) -> void:
    var key_event := event as InputEventKey
    if key_event != null:
        if key_event.keycode == KEY_SHIFT or key_event.physical_keycode == KEY_SHIFT:
            sneak_held = key_event.pressed
        elif key_event.keycode == KEY_CTRL or key_event.physical_keycode == KEY_CTRL:
            sprint_held = key_event.pressed

    if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
        var motion := event as InputEventMouseMotion
        if game != null and not game.is_paused and not game.inventory_open:
            rotate_y(-motion.relative.x * MOUSE_SENSITIVITY)
            head.rotation.x = clampf(head.rotation.x - motion.relative.y * MOUSE_SENSITIVITY, deg_to_rad(-85.0), deg_to_rad(85.0))
        return

    if key_event != null and key_event.pressed and not key_event.echo:
        if key_event.keycode == KEY_ESCAPE:
            if game != null:
                if game.inventory_open:
                    game.toggle_inventory(false)
                else:
                    game.toggle_pause()
            get_viewport().set_input_as_handled()
            return
        if game == null or game.is_paused:
            return
        if key_event.keycode == KEY_E or key_event.keycode == KEY_TAB or key_event.keycode == KEY_I:
            game.toggle_inventory(not game.inventory_open)
            get_viewport().set_input_as_handled()
            return
        if game.inventory_open:
            return
        if key_event.keycode == KEY_F:
            game.interact()
            get_viewport().set_input_as_handled()
        elif key_event.keycode == KEY_H:
            use_healing_item()
            get_viewport().set_input_as_handled()
        elif key_event.keycode >= KEY_1 and key_event.keycode <= KEY_9:
            selected_slot = int(key_event.keycode - KEY_1)
            game.refresh_hud()
            get_viewport().set_input_as_handled()

    var mouse_event := event as InputEventMouseButton
    if mouse_event != null and mouse_event.pressed:
        if game == null or game.is_paused or game.inventory_open:
            return
        if Input.get_mouse_mode() != Input.MOUSE_MODE_CAPTURED:
            Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
            return
        if mouse_event.button_index == MOUSE_BUTTON_LEFT:
            _try_mine()
            mine_repeat_timer = MINE_INTERVAL
            get_viewport().set_input_as_handled()
        elif mouse_event.button_index == MOUSE_BUTTON_RIGHT:
            _use_selected_item()
            get_viewport().set_input_as_handled()
        elif mouse_event.button_index == MOUSE_BUTTON_WHEEL_UP:
            selected_slot = (selected_slot + 8) % 9
            game.refresh_hud()
        elif mouse_event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
            selected_slot = (selected_slot + 1) % 9
            game.refresh_hud()

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        sprint_held = false
        sneak_held = false

# ---------------------------------------------------------------- movement

func _has_headroom() -> bool:
    return not test_move(global_transform, Vector3(0.0, STAND_HEIGHT - SNEAK_HEIGHT + 0.02, 0.0))

func _apply_shape(sneaking: bool) -> void:
    var capsule := body_shape.shape as CapsuleShape3D
    if capsule == null:
        return
    if sneaking:
        capsule.height = SNEAK_HEIGHT
        body_shape.position.y = -(STAND_HEIGHT - SNEAK_HEIGHT) * 0.5
    else:
        capsule.height = STAND_HEIGHT
        body_shape.position.y = 0.0

func _physics_process(delta: float) -> void:
    if game == null or game.is_paused or game.inventory_open:
        velocity = Vector3.ZERO
        return
    if is_dead:
        velocity = Vector3.ZERO
        return

    var want_sneak: bool = sneak_held
    if is_sneaking and not want_sneak and not _has_headroom():
        want_sneak = true
    if want_sneak != is_sneaking:
        is_sneaking = want_sneak
        _apply_shape(is_sneaking)
    var head_target: float = SNEAK_HEAD_Y if is_sneaking else STAND_HEAD_Y
    head.position.y = lerpf(head.position.y, head_target, minf(1.0, delta * 14.0))

    var direction := Vector3.ZERO
    if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
        direction -= global_transform.basis.z
    if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
        direction += global_transform.basis.z
    if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
        direction -= global_transform.basis.x
    if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
        direction += global_transform.basis.x
    direction.y = 0.0
    if direction.length_squared() > 1.0:
        direction = direction.normalized()

    var moving: bool = direction.length_squared() > 0.01
    var in_water: bool = game.world != null and (game.world.is_position_in_water(global_position) or game.world.is_position_in_water(global_position - Vector3(0.0, 0.55, 0.0)))
    var sprinting: bool = sprint_held and not is_sneaking and moving and hunger > 6.0 and not in_water
    var speed: float = WALK_SPEED
    if is_sneaking:
        speed = SNEAK_SPEED
    elif sprinting:
        speed = SPRINT_SPEED
    if in_water:
        speed *= 0.68
    var acceleration: float = 14.0 if in_water else 25.0
    velocity.x = move_toward(velocity.x, direction.x * speed, acceleration * delta)
    velocity.z = move_toward(velocity.z, direction.z * speed, acceleration * delta)

    var jump_down: bool = Input.is_physical_key_pressed(KEY_SPACE)
    if in_water:
        if jump_down:
            velocity.y = move_toward(velocity.y, 3.5, 9.0 * delta)
        else:
            velocity.y = maxf(velocity.y - GRAVITY * 0.22 * delta, -2.5)
    else:
        if jump_down and not jump_was_down and is_on_floor():
            velocity.y = JUMP_VELOCITY
        if not is_on_floor():
            velocity.y -= GRAVITY * delta
        else:
            velocity.y = minf(velocity.y, 0.0)
    jump_was_down = jump_down

    mine_repeat_timer = maxf(0.0, mine_repeat_timer - delta)
    message_cooldown = maxf(0.0, message_cooldown - delta)
    if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and mine_repeat_timer <= 0.0 and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
        _try_mine()
        mine_repeat_timer = MINE_INTERVAL
    move_and_slide()
    _update_hunger(delta, moving, sprinting)

func _update_hunger(delta: float, moving: bool, sprinting: bool) -> void:
    var rate: float = 0.022
    if moving:
        rate += 0.01
    if sprinting:
        rate += 0.06
    hunger = maxf(0.0, hunger - rate * delta)
    if hunger >= 18.0 and health < max_health:
        regen_timer += delta
        if regen_timer >= 3.0:
            regen_timer = 0.0
            health = minf(max_health, health + 1.0)
            hunger = maxf(0.0, hunger - 0.6)
            _refresh_hud()
    else:
        regen_timer = 0.0
    if hunger <= 0.0:
        starve_timer += delta
        if starve_timer >= 4.0:
            starve_timer = 0.0
            health = maxf(1.0, health - 1.0)
            if game != null:
                game.notify("Ты голодаешь. Найди еду (ягоды с листвы).")
            _refresh_hud()
    else:
        starve_timer = 0.0
    var shown: int = int(ceil(hunger))
    if shown != last_hunger_shown:
        last_hunger_shown = shown
        _refresh_hud()

# ---------------------------------------------------------------- actions

func _try_mine() -> void:
    if game == null or not is_instance_valid(interaction_ray):
        return
    interaction_ray.force_raycast_update()
    if not interaction_ray.is_colliding():
        return
    var target := interaction_ray.get_collider() as Node
    if target == null:
        return
    if target.is_in_group("voxel_enemy"):
        var damage: float = 4.0 if selected_item_id() == "pickaxe" else 1.5
        target.call("take_damage", damage, self)
        mine_repeat_timer = 0.5
        return
    var result: Dictionary = {}
    if target.is_in_group("voxel_chunks"):
        var hit_cell: Vector3i = game.world.cell_from_hit(
            interaction_ray.get_collision_point(),
            _oriented_collision_normal()
        )
        result = game.world.mine_cell(hit_cell)
    elif target.is_in_group("voxel_blocks"):
        result = game.world.mine_block(target)
    else:
        return
    if not result.get("ok", false):
        _notify_limited(str(result.get("message", "Нельзя добыть этот блок.")))
        return
    var kind: String = str(result.get("kind", "stone"))
    var drop_id: String = Catalog.drop_for_block(kind)
    if drop_id != "":
        add_item(drop_id, 1)
    if game.world.is_ore(kind):
        add_xp(3)
        _notify_limited("Найдена руда: %s." % Catalog.item_name(kind))
    game.refresh_hud()

func _use_selected_item() -> void:
    var item_id: String = selected_item_id()
    if item_id == "berries":
        _eat_berries()
    elif item_id == "salve":
        use_healing_item()
    else:
        _try_place_block()

func _eat_berries() -> void:
    if hunger >= 20.0:
        _notify_limited("Ты не голоден.")
        return
    if get_slot_count("inv", selected_slot) <= 0:
        return
    _consume_selected(1)
    hunger = minf(20.0, hunger + 3.0)
    last_hunger_shown = int(ceil(hunger))
    game.refresh_hud()

func _oriented_collision_normal() -> Vector3:
    var normal: Vector3 = interaction_ray.get_collision_normal().normalized()
    var ray_start: Vector3 = interaction_ray.global_position
    var ray_end: Vector3 = interaction_ray.to_global(interaction_ray.target_position)
    var ray_direction: Vector3 = (ray_end - ray_start).normalized()
    # Mesh winding differs from physics back-face conventions on some renderers;
    # the usable placement normal must always point toward the ray origin.
    if normal.dot(ray_direction) > 0.0:
        normal = -normal
    return normal

func _try_place_block() -> void:
    if game == null or not is_instance_valid(interaction_ray):
        return
    var item_id: String = selected_item_id()
    var block_kind: String = Catalog.block_kind(item_id)
    if block_kind == "":
        return
    if get_slot_count("inv", selected_slot) <= 0:
        _notify_limited("В этом слоте ничего не осталось.")
        return
    interaction_ray.force_raycast_update()
    if not interaction_ray.is_colliding():
        return
    var target := interaction_ray.get_collider() as Node
    if target == null:
        return
    if not target.is_in_group("voxel_chunks") and not target.is_in_group("voxel_blocks"):
        return
    var normal: Vector3 = _oriented_collision_normal()
    var hit_cell: Vector3i
    if target.is_in_group("voxel_chunks"):
        hit_cell = game.world.cell_from_hit(interaction_ray.get_collision_point(), normal)
    else:
        hit_cell = target.get_meta("grid_cell", Vector3i.ZERO)
    var offset := Vector3i(roundi(normal.x), roundi(normal.y), roundi(normal.z))
    var place_cell: Vector3i = hit_cell + offset
    var place_position := Vector3(place_cell.x, place_cell.y, place_cell.z)
    var inside_player: bool = (
        absf(place_position.x - global_position.x) < 0.65
        and absf(place_position.z - global_position.z) < 0.65
        and absf(place_position.y - global_position.y) < 1.2
    )
    if inside_player:
        _notify_limited("Нельзя поставить блок внутри персонажа.")
        return
    if game.world.place_block(place_cell, block_kind):
        _consume_selected(1)
        game.refresh_hud()
    else:
        _notify_limited("Здесь нельзя разместить блок.")

func use_healing_item() -> void:
    if health >= max_health:
        _notify_limited("Здоровье уже полное.")
        return
    if remove_item("salve", 1):
        health = minf(max_health, health + 6.0)
        game.refresh_hud()
        game.notify("Аптечка восстановила 6 HP.")
    else:
        _notify_limited("Аптечки закончились.")

func take_damage(amount: float) -> void:
    if is_dead or game == null or game.is_paused:
        return
    health = maxf(0.0, health - amount)
    game.refresh_hud()
    game.notify("Получен урон: %.0f HP" % amount)
    if health <= 0.0:
        is_dead = true
        game.player_died()

func _notify_limited(message: String) -> void:
    if message_cooldown <= 0.0 and game != null:
        game.notify(message)
        message_cooldown = 1.0

# ---------------------------------------------------------------- saving

func _pack_group(group: String) -> Array:
    var out: Array = []
    var ids: Array = groups_ids[group]
    var counts: Array = groups_counts[group]
    for i in range(ids.size()):
        out.append([str(ids[i]), int(counts[i])])
    return out

func _unpack_group(group: String, data: Variant) -> void:
    if not data is Array:
        return
    var list: Array = data
    for i in range(list.size()):
        var entry: Variant = list[i]
        if entry is Array and entry.size() >= 2:
            set_slot(group, i, str(entry[0]), int(entry[1]))

func make_save_data() -> Dictionary:
    return {
        "position": [global_position.x, global_position.y, global_position.z],
        "health": health,
        "hunger": hunger,
        "xp": xp,
        "slots": _pack_group("inv"),
        "armor": _pack_group("armor"),
        "offhand": _pack_group("offhand"),
        "selected_slot": selected_slot
    }

func load_save_data(data: Dictionary) -> void:
    health = clampf(float(data.get("health", max_health)), 1.0, max_health)
    hunger = clampf(float(data.get("hunger", 20.0)), 0.0, 20.0)
    last_hunger_shown = int(ceil(hunger))
    xp = maxi(0, int(data.get("xp", 0)))
    if data.has("slots"):
        _init_inventory()
        _unpack_group("inv", data.get("slots", []))
        _unpack_group("armor", data.get("armor", []))
        _unpack_group("offhand", data.get("offhand", []))
    elif data.has("inventory_counts"):
        _init_inventory()
        _give_starting_items()
    selected_slot = clampi(int(data.get("selected_slot", 0)), 0, 8)
