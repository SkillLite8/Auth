extends CharacterBody3D

const WALK_SPEED: float = 5.4
const SPRINT_SPEED: float = 8.0
const JUMP_VELOCITY: float = 5.4
const GRAVITY: float = 18.0
const MOUSE_SENSITIVITY: float = 0.0022
const MINE_INTERVAL: float = 0.34

var game
var health: float = 20.0
var max_health: float = 20.0
var stamina: float = 100.0
var max_stamina: float = 100.0
var selected_slot: int = 0
var inventory_counts: Dictionary = {
    "dirt": 24,
    "stone": 16,
    "wood": 8,
    "torch": 4,
    "salve": 2,
    "echo_shard": 0,
    "echo_core": 0
}
var hotbar: Array[String] = ["pickaxe", "dirt", "stone", "wood", "torch", "salve", "empty", "empty", "empty"]
var mine_repeat_timer: float = 0.0
var message_cooldown: float = 0.0
var jump_was_down: bool = false
var sprint_held: bool = false
var is_dead: bool = false

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var interaction_ray: RayCast3D = $Head/Camera3D/InteractionRay

func _ready() -> void:
    add_to_group("explorer")
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
    camera.current = true
    interaction_ray.enabled = true
    interaction_ray.add_exception(self)

func _input(event: InputEvent) -> void:
    # Track modifier key events directly. This avoids relying on platform input-state
    # polling for Shift/Ctrl, while movement itself uses physical key positions.
    if event is InputEventKey and (event.keycode == KEY_SHIFT or event.physical_keycode == KEY_SHIFT):
        sprint_held = event.pressed

    if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
        if game != null and not game.is_paused and not game.inventory_open:
            rotate_y(-event.relative.x * MOUSE_SENSITIVITY)
            head.rotation.x = clampf(head.rotation.x - event.relative.y * MOUSE_SENSITIVITY, deg_to_rad(-85.0), deg_to_rad(85.0))
        return

    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ESCAPE:
            if game != null:
                if game.inventory_open:
                    game.toggle_inventory(false)
                else:
                    game.toggle_pause()
            get_viewport().set_input_as_handled()
            return
        if game == null or game.is_paused:
            return
        if event.keycode == KEY_E:
            game.interact()
            get_viewport().set_input_as_handled()
        elif event.keycode == KEY_I or event.keycode == KEY_TAB:
            game.toggle_inventory(not game.inventory_open)
            get_viewport().set_input_as_handled()
        elif event.keycode == KEY_H:
            use_healing_item()
            get_viewport().set_input_as_handled()
        elif event.keycode >= KEY_1 and event.keycode <= KEY_9:
            selected_slot = int(event.keycode - KEY_1)
            game.refresh_hud()
            get_viewport().set_input_as_handled()

    if event is InputEventMouseButton and event.pressed:
        if game == null or game.is_paused or game.inventory_open:
            return
        if Input.get_mouse_mode() != Input.MOUSE_MODE_CAPTURED:
            Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
            return
        if event.button_index == MOUSE_BUTTON_LEFT:
            _try_mine()
            mine_repeat_timer = MINE_INTERVAL
            get_viewport().set_input_as_handled()
        elif event.button_index == MOUSE_BUTTON_RIGHT:
            _try_place_block()
            get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        sprint_held = false

func _physics_process(delta: float) -> void:
    if game == null or game.is_paused or game.inventory_open:
        velocity = Vector3.ZERO
        return
    if is_dead:
        velocity = Vector3.ZERO
        return

    var direction := Vector3.ZERO
    if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
        direction -= global_transform.basis.z
    if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
        direction += global_transform.basis.z
    if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
        direction -= global_transform.basis.x
    if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
        direction += global_transform.basis.x
    direction.y = 0.0
    if direction.length_squared() > 1.0:
        direction = direction.normalized()

    var sprinting := sprint_held and stamina > 0.5 and direction.length_squared() > 0.01
    var speed := SPRINT_SPEED if sprinting else WALK_SPEED
    velocity.x = move_toward(velocity.x, direction.x * speed, 25.0 * delta)
    velocity.z = move_toward(velocity.z, direction.z * speed, 25.0 * delta)
    if sprinting:
        stamina = maxf(0.0, stamina - 25.0 * delta)
    else:
        stamina = minf(max_stamina, stamina + 16.0 * delta)

    var jump_down := Input.is_physical_key_pressed(KEY_SPACE)
    if jump_down and not jump_was_down and is_on_floor():
        velocity.y = JUMP_VELOCITY
    jump_was_down = jump_down
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    else:
        velocity.y = minf(velocity.y, 0.0)

    mine_repeat_timer = maxf(0.0, mine_repeat_timer - delta)
    message_cooldown = maxf(0.0, message_cooldown - delta)
    if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and mine_repeat_timer <= 0.0 and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
        _try_mine()
        mine_repeat_timer = MINE_INTERVAL
    move_and_slide()

func _try_mine() -> void:
    if game == null or not is_instance_valid(interaction_ray):
        return
    if hotbar[selected_slot] != "pickaxe":
        _notify_limited("Для добычи выбери кирку в первом слоте (клавиша 1).")
        return
    interaction_ray.force_raycast_update()
    if not interaction_ray.is_colliding():
        return
    var target := interaction_ray.get_collider() as Node
    if target == null:
        return
    if target.is_in_group("voxel_enemy"):
        target.call("take_damage", 4.0, self)
        mine_repeat_timer = 0.5
        return
    if not target.is_in_group("voxel_blocks"):
        return
    var result: Dictionary = game.world.mine_block(target)
    if not result.get("ok", false):
        _notify_limited(str(result.get("message", "Нельзя добыть этот блок.")))
        return
    var kind := str(result.get("kind", "stone"))
    var drop_id := "dirt"
    if kind == "stone" or kind == "ancient" or kind == "ore":
        drop_id = "stone" if kind != "ore" else "echo_core"
    elif kind == "wood":
        drop_id = "wood"
    elif kind == "leaves":
        if randf() < 0.25:
            drop_id = "wood"
        else:
            drop_id = "dirt"
    elif kind == "torch":
        drop_id = "torch"
    add_item(drop_id, 1)
    if kind == "ore":
        _notify_limited("В жилах камня найдено эхо-ядро.")
    game.refresh_hud()

func _try_place_block() -> void:
    if game == null or not is_instance_valid(interaction_ray):
        return
    var item_id := hotbar[selected_slot]
    var block_kind := ""
    match item_id:
        "dirt": block_kind = "dirt"
        "stone": block_kind = "stone"
        "wood": block_kind = "wood"
        "torch": block_kind = "torch"
        _:
            return
    if get_count(item_id) <= 0:
        _notify_limited("В этом слоте ничего не осталось.")
        return
    interaction_ray.force_raycast_update()
    if not interaction_ray.is_colliding():
        return
    var target := interaction_ray.get_collider() as Node
    if target == null or not target.is_in_group("voxel_blocks"):
        return
    var hit_cell: Vector3i = target.get_meta("grid_cell", Vector3i.ZERO)
    var normal: Vector3 = interaction_ray.get_collision_normal()
    var offset := Vector3i(roundi(normal.x), roundi(normal.y), roundi(normal.z))
    var place_cell := hit_cell + offset
    var place_position := Vector3(place_cell.x, place_cell.y, place_cell.z)
    var inside_player := (
        absf(place_position.x - global_position.x) < 0.65
        and absf(place_position.z - global_position.z) < 0.65
        and absf(place_position.y - global_position.y) < 1.2
    )
    if inside_player:
        _notify_limited("Нельзя поставить блок внутри персонажа.")
        return
    if game.world.place_block(place_cell, block_kind):
        remove_item(item_id, 1)
        game.refresh_hud()
    else:
        _notify_limited("Здесь нельзя разместить блок.")

func add_item(item_id: String, amount: int = 1) -> void:
    inventory_counts[item_id] = int(inventory_counts.get(item_id, 0)) + amount
    game.refresh_hud()

func get_count(item_id: String) -> int:
    return int(inventory_counts.get(item_id, 0))

func remove_item(item_id: String, amount: int = 1) -> bool:
    if get_count(item_id) < amount:
        return false
    inventory_counts[item_id] = get_count(item_id) - amount
    return true

func use_healing_item() -> void:
    if health >= max_health:
        _notify_limited("Здоровье уже полное.")
        return
    if remove_item("salve", 1):
        health = minf(max_health, health + 6.0)
        game.refresh_hud()
        game.notify("Аптечка восстановила 6 HP.")
    else:
        _notify_limited("Аптечки закончились.")

func take_damage(amount: float) -> void:
    if is_dead or game == null or game.is_paused:
        return
    health = maxf(0.0, health - amount)
    game.refresh_hud()
    game.notify("Получен урон: %.0f HP" % amount)
    if health <= 0.0:
        is_dead = true
        game.player_died()

func _notify_limited(message: String) -> void:
    if message_cooldown <= 0.0 and game != null:
        game.notify(message)
        message_cooldown = 1.0

func make_save_data() -> Dictionary:
    return {
        "position": [global_position.x, global_position.y, global_position.z],
        "health": health,
        "stamina": stamina,
        "inventory_counts": inventory_counts.duplicate(true),
        "hotbar": hotbar.duplicate(),
        "selected_slot": selected_slot
    }

func load_save_data(data: Dictionary) -> void:
    health = clampf(float(data.get("health", max_health)), 1.0, max_health)
    stamina = clampf(float(data.get("stamina", max_stamina)), 0.0, max_stamina)
    var counts: Variant = data.get("inventory_counts", {})
    if counts is Dictionary:
        for key in counts.keys():
            inventory_counts[str(key)] = maxi(0, int(counts[key]))
    var saved_hotbar: Variant = data.get("hotbar", [])
    if saved_hotbar is Array and saved_hotbar.size() == hotbar.size():
        for i in range(hotbar.size()):
            hotbar[i] = str(saved_hotbar[i])
    selected_slot = clampi(int(data.get("selected_slot", 0)), 0, hotbar.size() - 1)
