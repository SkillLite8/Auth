extends RefCounted

const BLOCK_DIR: String = "res://assets/textures/blocks/"
const ITEM_DIR: String = "res://assets/textures/items/"
const UI_DIR: String = "res://assets/textures/ui/"

const NAMES: Dictionary = {
    "pickaxe": "Кирка",
    "dirt": "Земля",
    "stone": "Камень",
    "cobblestone": "Булыжник",
    "sand": "Песок",
    "wood": "Дерево",
    "leaves": "Листья",
    "torch": "Факел",
    "salve": "Аптечка",
    "berries": "Ягоды",
    "echo_shard": "Осколок Эха",
    "echo_core": "Эхо-ядро"
}

const BLOCK_ITEMS: Array = ["dirt", "stone", "cobblestone", "sand", "wood", "leaves", "torch"]

const ICON_PATHS: Dictionary = {
    "pickaxe": "res://assets/textures/items/pickaxe.png",
    "dirt": "res://assets/textures/blocks/dirt.png",
    "stone": "res://assets/textures/blocks/stone.png",
    "cobblestone": "res://assets/textures/blocks/cobblestone.png",
    "sand": "res://assets/textures/blocks/sand.png",
    "wood": "res://assets/textures/blocks/wood_side.png",
    "leaves": "res://assets/textures/blocks/leaves.png",
    "torch": "res://assets/textures/items/torch.png",
    "salve": "res://assets/textures/items/salve.png",
    "berries": "res://assets/textures/items/berries.png",
    "echo_shard": "res://assets/textures/items/echo_shard.png",
    "echo_core": "res://assets/textures/items/echo_core.png"
}

static func item_name(item_id: String) -> String:
    return str(NAMES.get(item_id, item_id))

static func icon(item_id: String) -> Texture2D:
    var path: String = str(ICON_PATHS.get(item_id, ""))
    if path == "" or not ResourceLoader.exists(path):
        return null
    return load(path) as Texture2D

static func ui_texture(texture_name: String) -> Texture2D:
    var path: String = UI_DIR + texture_name + ".png"
    if not ResourceLoader.exists(path):
        return null
    return load(path) as Texture2D

static func max_stack(item_id: String) -> int:
    if item_id == "pickaxe":
        return 1
    return 64

static func block_kind(item_id: String) -> String:
    if BLOCK_ITEMS.has(item_id):
        return item_id
    return ""

static func drop_for_block(kind: String) -> String:
    match kind:
        "grass", "dirt":
            return "dirt"
        "stone", "cobblestone", "ancient":
            return "cobblestone"
        "sand":
            return "sand"
        "wood":
            return "wood"
        "leaves":
            if randf() < 0.3:
                return "berries"
            return "leaves"
        "torch":
            return "torch"
        "ore":
            return "echo_core"
    return ""
