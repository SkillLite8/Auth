extends Node3D

const WorldScript = preload("res://scripts/3d/voxel_world.gd")
const ExplorerScene: PackedScene = preload("res://scenes/3d/explorer.tscn")
const HudScript = preload("res://scripts/3d/voxel_hud.gd")

const SAVE_PATH: String = "user://below_3d_save.json"

var world
var player
var hud
var title_layer: CanvasLayer
var is_paused: bool = false
var inventory_open: bool = false
var game_started: bool = false
var victory: bool = false
var world_seed: int = 0
var shards_found: int = 0
var found_shards: Array[int] = []
var autosave_timer: float = 0.0

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _create_environment()
    _show_title_menu()

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_game(false)
        get_tree().quit()

func _create_environment() -> void:
    var world_environment := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_material := ProceduralSkyMaterial.new()
    sky_material.sky_top_color = Color("20374b")
    sky_material.sky_horizon_color = Color("9aa68f")
    sky_material.ground_bottom_color = Color("252b29")
    sky_material.ground_horizon_color = Color("798573")
    sky_material.sun_angle_max = 18.0
    sky.sky_material = sky_material
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("8a9b9d")
    env.ambient_light_energy = 0.7
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.reflected_light_source = Environment.REFLECTION_SOURCE_BG
    world_environment.environment = env
    add_child(world_environment)

    var sun := DirectionalLight3D.new()
    sun.name = "BrokenSunlight"
    sun.rotation_degrees = Vector3(-52.0, -32.0, 0.0)
    sun.light_color = Color("ffe0b0")
    sun.light_energy = 1.15
    sun.shadow_enabled = true
    add_child(sun)

func _show_title_menu() -> void:
    if is_instance_valid(title_layer):
        title_layer.queue_free()
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    title_layer = CanvasLayer.new()
    title_layer.name = "MainMenu"
    title_layer.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(title_layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    title_layer.add_child(root)
    var background := ColorRect.new()
    background.color = Color("111a20")
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(background)
    var horizon := ColorRect.new()
    horizon.color = Color(0.21, 0.29, 0.25, 0.6)
    horizon.anchor_top = 0.48
    horizon.anchor_bottom = 1.0
    horizon.offset_top = 0
    horizon.offset_bottom = 0
    root.add_child(horizon)
    var shade := ColorRect.new()
    shade.color = Color(0.015, 0.025, 0.035, 0.50)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(shade)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(590, 520)
    panel.add_theme_stylebox_override("panel", _make_panel_style(Color(0.025, 0.045, 0.052, 0.93), Color("839c89")))
    center.add_child(panel)
    var content := VBoxContainer.new()
    content.add_theme_constant_override("separation", 12)
    panel.add_child(content)

    var title := Label.new()
    title.text = "B E L O W"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 48)
    title.add_theme_color_override("font_color", Color("e7d9ac"))
    content.add_child(title)
    var subtitle := Label.new()
    subtitle.text = "ЭКСПЕДИЦИЯ: СТАНЦИЯ НОЛЬ"
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.add_theme_font_size_override("font_size", 18)
    subtitle.add_theme_color_override("font_color", Color("a1d0c8"))
    content.add_child(subtitle)
    var story := Label.new()
    story.text = "Семнадцать лет назад подземный маяк замолчал.\nИз глубины снова пришёл сигнал — три импульса, один за другим.\n\nНайди три осколка Эха среди руин и восстанови Маяк.\nСтражи станции всё ещё охраняют то, что осталось внизу."
    story.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    story.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    story.add_theme_font_size_override("font_size", 15)
    story.add_theme_color_override("font_color", Color("d4dfd9"))
    story.custom_minimum_size = Vector2(500, 122)
    content.add_child(story)

    var new_button := _make_menu_button("НОВАЯ ЭКСПЕДИЦИЯ", func(): _start_game(false))
    content.add_child(new_button)
    var continue_button := _make_menu_button("ПРОДОЛЖИТЬ", func(): _start_game(true))
    continue_button.disabled = not FileAccess.file_exists(SAVE_PATH)
    content.add_child(continue_button)
    var controls := Label.new()
    controls.text = "WASD — ходить   Мышь — смотреть   Space — прыжок   Shift — присесть   Ctrl — бег\nЛКМ — добывать / атаковать   ПКМ — поставить блок / съесть   F — действие\n1–9 / колесо — хотбар   E — инвентарь   H — аптечка   Esc — пауза"
    controls.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    controls.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    controls.add_theme_font_size_override("font_size", 12)
    controls.add_theme_color_override("font_color", Color("a7b6b4"))
    content.add_child(controls)

func _make_panel_style(background_color: Color, border_color: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = background_color
    style.border_color = border_color
    style.set_border_width_all(2)
    style.set_corner_radius_all(0)
    style.content_margin_left = 22
    style.content_margin_right = 22
    style.content_margin_top = 18
    style.content_margin_bottom = 18
    return style

func _make_menu_button(caption: String, callback: Callable) -> Button:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(500, 44)
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size", 15)
    button.add_theme_color_override("font_color", Color("e2e8df"))
    button.add_theme_stylebox_override("normal", _make_panel_style(Color("26332e"), Color("607c70")))
    button.add_theme_stylebox_override("hover", _make_panel_style(Color("37483b"), Color("e2cd8d")))
    button.add_theme_stylebox_override("disabled", _make_panel_style(Color("1f2523"), Color("424d48")))
    button.pressed.connect(callback)
    return button

func _start_game(continue_save: bool) -> void:
    var save_data: Dictionary = {}
    if continue_save:
        save_data = _read_save()
        if save_data.is_empty():
            notify("Сохранение не найдено или повреждено. Начинаем новую экспедицию.")
    if is_instance_valid(title_layer):
        title_layer.queue_free()
        title_layer = null

    var random := RandomNumberGenerator.new()
    random.randomize()
    world_seed = int(save_data.get("world_seed", random.randi_range(100000, 2000000000)))
    shards_found = clampi(int(save_data.get("shards_found", 0)), 0, 3)
    found_shards.clear()
    var saved_shards: Variant = save_data.get("found_shards", [])
    if saved_shards is Array:
        for shard_id in saved_shards:
            if int(shard_id) >= 0 and int(shard_id) <= 2 and not found_shards.has(int(shard_id)):
                found_shards.append(int(shard_id))
    shards_found = found_shards.size()
    victory = bool(save_data.get("victory", false))

    world = WorldScript.new()
    world.name = "VoxelExpedition"
    add_child(world)
    var saved_changes: Variant = save_data.get("world_changes", {})
    world.generate(world_seed, found_shards, saved_changes if saved_changes is Dictionary else {})

    player = ExplorerScene.instantiate()
    player.game = self
    player.name = "Explorer"
    add_child(player)
    var saved_player: Variant = save_data.get("player", {})
    if saved_player is Dictionary:
        player.load_save_data(saved_player)
        var raw_position: Variant = saved_player.get("position", [])
        if raw_position is Array and raw_position.size() >= 3:
            # Worlds stream indefinitely in X/Z; only sanity-limit malformed save coordinates.
            var saved_x := clampf(float(raw_position[0]), -1000000.0, 1000000.0)
            var saved_z := clampf(float(raw_position[2]), -1000000.0, 1000000.0)
            var saved_y := clampf(float(raw_position[1]), float(WorldScript.MIN_Y) + 1.5, float(WorldScript.MAX_Y) + 8.0)
            player.global_position = Vector3(saved_x, saved_y, saved_z)
        else:
            player.global_position = world.get_spawn_position()
    else:
        player.global_position = world.get_spawn_position()

    world.set_stream_target(player)
    world.spawn_guardians(player, self)
    hud = HudScript.new()
    add_child(hud)
    hud.setup(self, player, world)
    game_started = true
    is_paused = false
    inventory_open = false
    autosave_timer = 0.0
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
    notify("Экспедиция началась. Найди три осколка и вернись к Маяку.")
    if victory:
        is_paused = true
        Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
        hud.show_victory()

func _process(delta: float) -> void:
    if not game_started or is_paused or inventory_open:
        return
    autosave_timer += delta
    if autosave_timer >= 90.0:
        autosave_timer = 0.0
        save_game(false)

func interact() -> void:
    if not game_started or is_paused or inventory_open or player == null or world == null:
        return
    var nearby: Dictionary = world.find_nearby_story_object(player.global_position, 3.0)
    if nearby.is_empty():
        notify("Здесь нет ничего, с чем можно взаимодействовать.")
        return
    var kind := str(nearby.get("kind", ""))
    if kind == "shard":
        var shard_id := int(nearby.get("id", -1))
        if not found_shards.has(shard_id):
            found_shards.append(shard_id)
            shards_found = found_shards.size()
            world.collect_shard(shard_id)
            player.add_item("echo_shard", 1)
            player.add_xp(10)
            notify("Осколок Эха получен: %d/3. Кажется, Маяк помнит этот сигнал." % shards_found, 4.0)
            refresh_hud()
    elif kind == "beacon":
        if shards_found < 3:
            notify("Маяк не отвечает. Нужны осколки Эха: %d/3." % shards_found)
        else:
            victory = true
            save_game(false)
            is_paused = true
            Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
            hud.show_victory()

func toggle_pause(force_value: Variant = null) -> void:
    if not game_started or inventory_open:
        return
    if force_value == null:
        is_paused = not is_paused
    else:
        is_paused = bool(force_value)
    if is_paused:
        Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
        hud.set_pause_visible(true)
    else:
        hud.set_pause_visible(false)
        Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func toggle_inventory(show_now: bool) -> void:
    if not game_started or is_paused:
        return
    inventory_open = show_now
    if not show_now and is_instance_valid(player):
        player.return_loose_items()
    hud.set_inventory_visible(inventory_open)
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE if inventory_open else Input.MOUSE_MODE_CAPTURED)
    refresh_hud()

func refresh_hud() -> void:
    if is_instance_valid(hud):
        hud.refresh()

func notify(message: String, duration: float = 3.2) -> void:
    if is_instance_valid(hud):
        hud.notify(message, duration)

func save_game(show_notification: bool = true) -> bool:
    if not game_started or not is_instance_valid(player) or not is_instance_valid(world):
        return false
    var data := {
        "version": 2,
        "world_seed": world_seed,
        "shards_found": shards_found,
        "found_shards": found_shards.duplicate(),
        "victory": victory,
        "player": player.make_save_data(),
        "world_changes": world.export_changes()
    }
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        notify("Не удалось сохранить игру: %s" % error_string(FileAccess.get_open_error()))
        return false
    file.store_string(JSON.stringify(data, "\t"))
    file.close()
    if show_notification:
        notify("Экспедиция сохранена.")
    return true

func _read_save() -> Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        return {}
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return {}
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    return parsed if parsed is Dictionary else {}

func player_died() -> void:
    if not is_instance_valid(hud):
        return
    is_paused = true
    inventory_open = false
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    hud.set_inventory_visible(false)
    hud.show_death()

func return_to_title() -> void:
    if game_started:
        save_game(false)
    game_started = false
    is_paused = false
    inventory_open = false
    Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    for node in [hud, player, world]:
        if is_instance_valid(node):
            node.queue_free()
    hud = null
    player = null
    world = null
    _show_title_menu()

func respawn_player() -> void:
    if not is_instance_valid(player) or not is_instance_valid(world):
        return
    player.is_dead = false
    player.health = 10.0
    player.hunger = 20.0
    player.velocity = Vector3.ZERO
    player.global_position = world.get_spawn_position()
    is_paused = false
    hud.hide_ending()
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
    refresh_hud()
    notify("Ты вернулся к входу на Станцию Ноль. Будь осторожнее.")
