extends CanvasLayer

var game
var player
var world
var root: Control
var quest_panel: PanelContainer
var quest_label: Label
var story_label: Label
var health_label: Label
var hunger_label: Label
var hint_label: Label
var toast_label: Label
var hotbar_holder: PanelContainer
var hotbar_slots: Array[Dictionary] = []
var inventory_panel: PanelContainer
var inventory_text: Label
var pause_overlay: ColorRect
var pause_panel: PanelContainer
var ending_overlay: ColorRect
var ending_title: Label
var ending_message: Label
var ending_continue_button: Button
var toast_timer: float = 0.0

const ITEM_NAMES: Dictionary = {
    "pickaxe": "Кирка",
    "dirt": "Земля",
    "stone": "Камень",
    "wood": "Дерево",
    "torch": "Факел",
    "salve": "Аптечка",
    "echo_shard": "Осколок Эха",
    "echo_core": "Эхо-ядро",
    "empty": "Пусто"
}
const ITEM_SHORT: Dictionary = {
    "pickaxe": "⛏",
    "dirt": "DIR",
    "stone": "STN",
    "wood": "LOG",
    "torch": "LGT",
    "salve": "+",
    "echo_shard": "ECH",
    "echo_core": "CORE",
    "empty": "—"
}

func setup(game_ref: Node, player_ref: CharacterBody3D, world_ref: Node3D) -> void:
    game = game_ref
    player = player_ref
    world = world_ref
    _build_ui()
    refresh()

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS

func _process(delta: float) -> void:
    toast_timer = maxf(0.0, toast_timer - delta)
    if toast_timer <= 0.0 and is_instance_valid(toast_label):
        toast_label.visible = false

func _panel_style(background: Color = Color(0.035, 0.05, 0.065, 0.88), border: Color = Color("65717a")) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = background
    style.border_color = border
    style.set_border_width_all(2)
    style.set_corner_radius_all(0)
    style.content_margin_left = 12
    style.content_margin_right = 12
    style.content_margin_top = 9
    style.content_margin_bottom = 9
    return style

func _build_ui() -> void:
    root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_PASS
    add_child(root)

    quest_panel = PanelContainer.new()
    quest_panel.position = Vector2(18, 18)
    quest_panel.custom_minimum_size = Vector2(385, 116)
    quest_panel.size = Vector2(385, 116)
    quest_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.045, 0.052, 0.87), Color("718c75")))
    root.add_child(quest_panel)
    var quest_box := VBoxContainer.new()
    quest_box.add_theme_constant_override("separation", 4)
    quest_panel.add_child(quest_box)
    var heading := Label.new()
    heading.text = "BELOW  //  ЭКСПЕДИЦИЯ 01"
    heading.add_theme_font_size_override("font_size", 17)
    heading.add_theme_color_override("font_color", Color("e3c47d"))
    quest_box.add_child(heading)
    story_label = Label.new()
    story_label.text = "СТАНЦИЯ НОЛЬ · СИГНАЛ ПОТЕРЯН"
    story_label.add_theme_font_size_override("font_size", 12)
    story_label.add_theme_color_override("font_color", Color("a5c4d0"))
    quest_box.add_child(story_label)
    quest_label = Label.new()
    quest_label.text = "Найди 3 осколка Эха"
    quest_label.add_theme_font_size_override("font_size", 14)
    quest_label.add_theme_color_override("font_color", Color("f2f0e8"))
    quest_box.add_child(quest_label)

    var controls := Label.new()
    controls.text = "WASD движение  ·  Shift бег  ·  Space прыжок  ·  E взаимодействие"
    controls.position = Vector2(18, 145)
    controls.size = Vector2(620, 22)
    controls.add_theme_font_size_override("font_size", 12)
    controls.add_theme_color_override("font_color", Color("d2d5ce"))
    root.add_child(controls)

    var crosshair := Label.new()
    crosshair.name = "Crosshair"
    crosshair.text = "+"
    crosshair.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    crosshair.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    crosshair.add_theme_font_size_override("font_size", 24)
    crosshair.add_theme_color_override("font_color", Color("ffffff"))
    crosshair.add_theme_color_override("font_shadow_color", Color("151b20"))
    crosshair.add_theme_constant_override("shadow_offset_x", 1)
    crosshair.add_theme_constant_override("shadow_offset_y", 1)
    crosshair.size = Vector2(28, 28)
    root.add_child(crosshair)

    toast_label = Label.new()
    toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    toast_label.add_theme_font_size_override("font_size", 18)
    toast_label.add_theme_color_override("font_color", Color("ffe6a7"))
    toast_label.add_theme_color_override("font_shadow_color", Color("101820"))
    toast_label.add_theme_constant_override("shadow_offset_x", 2)
    toast_label.add_theme_constant_override("shadow_offset_y", 2)
    toast_label.size = Vector2(780, 38)
    toast_label.visible = false
    root.add_child(toast_label)

    health_label = Label.new()
    health_label.size = Vector2(420, 30)
    health_label.add_theme_font_size_override("font_size", 23)
    health_label.add_theme_color_override("font_color", Color("ff6863"))
    root.add_child(health_label)
    hunger_label = Label.new()
    hunger_label.text = "ЭНЕРГИЯ"
    hunger_label.size = Vector2(250, 22)
    hunger_label.add_theme_font_size_override("font_size", 14)
    hunger_label.add_theme_color_override("font_color", Color("d99a62"))
    root.add_child(hunger_label)

    _build_hotbar()
    _build_inventory_panel()
    _build_pause_panel()
    _build_ending_panel()
    _layout()
    get_viewport().size_changed.connect(_layout)

func _build_hotbar() -> void:
    hotbar_holder = PanelContainer.new()
    hotbar_holder.custom_minimum_size = Vector2(9 * 56 + 22, 65)
    hotbar_holder.size = Vector2(9 * 56 + 22, 65)
    hotbar_holder.add_theme_stylebox_override("panel", _panel_style(Color(0.025, 0.03, 0.035, 0.91), Color("90979a")))
    root.add_child(hotbar_holder)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 3)
    hotbar_holder.add_child(row)
    for index in range(9):
        var slot := PanelContainer.new()
        slot.custom_minimum_size = Vector2(54, 52)
        slot.add_theme_stylebox_override("panel", _panel_style(Color(0.14, 0.15, 0.15, 0.94), Color("6d7376")))
        row.add_child(slot)
        var column := VBoxContainer.new()
        column.add_theme_constant_override("separation", 0)
        slot.add_child(column)
        var item_label := Label.new()
        item_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        item_label.add_theme_font_size_override("font_size", 18)
        item_label.add_theme_color_override("font_color", Color("e3e7e0"))
        column.add_child(item_label)
        var count_label := Label.new()
        count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
        count_label.add_theme_font_size_override("font_size", 10)
        count_label.add_theme_color_override("font_color", Color("e8e3cb"))
        column.add_child(count_label)
        hotbar_slots.append({"panel": slot, "item": item_label, "count": count_label})

func _build_inventory_panel() -> void:
    inventory_panel = PanelContainer.new()
    inventory_panel.visible = false
    inventory_panel.custom_minimum_size = Vector2(430, 300)
    inventory_panel.size = Vector2(430, 300)
    inventory_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.045, 0.052, 0.98), Color("95a1a1")))
    inventory_panel.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(inventory_panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    inventory_panel.add_child(box)
    var title := Label.new()
    title.text = "РЮКЗАК ЭКСПЕДИЦИИ"
    title.add_theme_font_size_override("font_size", 22)
    title.add_theme_color_override("font_color", Color("e3c47d"))
    box.add_child(title)
    inventory_text = Label.new()
    inventory_text.add_theme_font_size_override("font_size", 16)
    inventory_text.add_theme_color_override("font_color", Color("e1e5df"))
    inventory_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(inventory_text)
    var footer := Label.new()
    footer.text = "1–9 — быстрый выбор · H — аптечка · I или Esc — закрыть"
    footer.add_theme_font_size_override("font_size", 12)
    footer.add_theme_color_override("font_color", Color("a0b0b3"))
    box.add_child(footer)

func _build_pause_panel() -> void:
    pause_overlay = ColorRect.new()
    pause_overlay.color = Color(0.015, 0.02, 0.025, 0.75)
    pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    pause_overlay.visible = false
    pause_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(pause_overlay)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    pause_overlay.add_child(center)
    pause_panel = PanelContainer.new()
    pause_panel.custom_minimum_size = Vector2(350, 290)
    pause_panel.add_theme_stylebox_override("panel", _panel_style(Color("222820"), Color("9aab88")))
    center.add_child(pause_panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    pause_panel.add_child(box)
    var title := Label.new()
    title.text = "ЭКСПЕДИЦИЯ ПРИОСТАНОВЛЕНА"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 18)
    title.add_theme_color_override("font_color", Color("e3c47d"))
    box.add_child(title)
    _add_menu_button(box, "ПРОДОЛЖИТЬ", func(): game.toggle_pause(false))
    _add_menu_button(box, "СОХРАНИТЬ", func(): game.save_game())
    _add_menu_button(box, "ВЕРНУТЬСЯ В УБЕЖИЩЕ", func(): game.return_to_title())

func _build_ending_panel() -> void:
    ending_overlay = ColorRect.new()
    ending_overlay.color = Color(0.012, 0.02, 0.03, 0.88)
    ending_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ending_overlay.visible = false
    ending_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(ending_overlay)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ending_overlay.add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(580, 310)
    panel.add_theme_stylebox_override("panel", _panel_style(Color("1c2829"), Color("8ac5bd")))
    center.add_child(panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    panel.add_child(box)
    ending_title = Label.new()
    ending_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ending_title.add_theme_font_size_override("font_size", 28)
    ending_title.add_theme_color_override("font_color", Color("e3c47d"))
    box.add_child(ending_title)
    ending_message = Label.new()
    ending_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    ending_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ending_message.add_theme_font_size_override("font_size", 16)
    ending_message.add_theme_color_override("font_color", Color("d6e4dd"))
    box.add_child(ending_message)
    ending_continue_button = Button.new()
    ending_continue_button.custom_minimum_size = Vector2(300, 42)
    ending_continue_button.add_theme_font_size_override("font_size", 15)
    ending_continue_button.add_theme_color_override("font_color", Color("e2e8df"))
    ending_continue_button.add_theme_stylebox_override("normal", _panel_style(Color("343e34"), Color("71876c")))
    ending_continue_button.add_theme_stylebox_override("hover", _panel_style(Color("4b5a43"), Color("d5c27e")))
    ending_continue_button.pressed.connect(_on_ending_continue)
    box.add_child(ending_continue_button)
    _add_menu_button(box, "ВЕРНУТЬСЯ В ГЛАВНОЕ МЕНЮ", func(): game.return_to_title())

func _add_menu_button(parent: VBoxContainer, caption: String, callback: Callable) -> void:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(300, 42)
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size", 15)
    button.add_theme_color_override("font_color", Color("e2e8df"))
    button.add_theme_stylebox_override("normal", _panel_style(Color("343e34"), Color("71876c")))
    button.add_theme_stylebox_override("hover", _panel_style(Color("4b5a43"), Color("d5c27e")))
    parent.add_child(button)
    button.pressed.connect(callback)

func _layout() -> void:
    if not is_instance_valid(root):
        return
    var size := get_viewport().get_visible_rect().size
    var crosshair := root.get_node_or_null("Crosshair") as Control
    if crosshair != null:
        crosshair.position = size * 0.5 - crosshair.size * 0.5
    if is_instance_valid(hotbar_holder):
        hotbar_holder.position = Vector2((size.x - hotbar_holder.custom_minimum_size.x) * 0.5, size.y - 82.0)
    if is_instance_valid(health_label):
        health_label.position = Vector2(24, size.y - 139.0)
    if is_instance_valid(hunger_label):
        hunger_label.position = Vector2(28, size.y - 109.0)
    if is_instance_valid(toast_label):
        toast_label.position = Vector2((size.x - toast_label.size.x) * 0.5, 75)
    if is_instance_valid(inventory_panel):
        inventory_panel.position = (size - inventory_panel.custom_minimum_size) * 0.5

func refresh() -> void:
    if not is_instance_valid(player):
        return
    var hearts := int(ceil(player.health / 2.0))
    var heart_string := ""
    for i in range(10):
        heart_string += "♥ " if i < hearts else "♡ "
    health_label.text = "%s  %02d/20 HP" % [heart_string, int(round(player.health))]
    var energy_symbols := ""
    var filled_energy := int(ceil(player.stamina / 10.0))
    for energy_index in range(10):
        energy_symbols += "◆ " if energy_index < filled_energy else "◇ "
    hunger_label.text = "ЭНЕРГИЯ  " + energy_symbols
    hunger_label.add_theme_color_override("font_color", Color("d99a62") if player.stamina >= 30.0 else Color("e07058"))
    quest_label.text = "Задача: найди 3 осколка Эха  [%d/3]" % int(game.shards_found)
    if int(game.shards_found) >= 3:
        quest_label.text = "Вернись к Маяку на Станции Ноль  [ГОТОВО]"
    var selected: int = player.selected_slot
    for index in range(hotbar_slots.size()):
        var slot: Dictionary = hotbar_slots[index]
        var item_id := str(player.hotbar[index])
        var item_label: Label = slot["item"]
        var count_label: Label = slot["count"]
        item_label.text = str(ITEM_SHORT.get(item_id, item_id.to_upper()))
        if item_id == "pickaxe":
            count_label.text = "∞"
        elif item_id == "empty":
            count_label.text = str(index + 1)
        else:
            count_label.text = str(player.get_count(item_id))
        var panel: PanelContainer = slot["panel"]
        var border_color := Color("efce72") if index == selected else Color("6d7376")
        var bg := Color(0.23, 0.24, 0.20, 1.0) if index == selected else Color(0.14, 0.15, 0.15, 0.94)
        panel.add_theme_stylebox_override("panel", _panel_style(bg, border_color))
    if is_instance_valid(inventory_panel):
        var lines: Array[String] = []
        for item_id in ["dirt", "stone", "wood", "torch", "salve", "echo_shard", "echo_core"]:
            lines.append("%s: %d" % [str(ITEM_NAMES[item_id]), player.get_count(item_id)])
        inventory_text.text = "\n".join(lines)

func notify(message: String, duration: float = 3.2) -> void:
    if not is_instance_valid(toast_label):
        return
    toast_label.text = message
    toast_label.visible = true
    toast_timer = duration

func set_inventory_visible(visible_now: bool) -> void:
    inventory_panel.visible = visible_now
    if visible_now:
        refresh()

func set_pause_visible(visible_now: bool) -> void:
    pause_overlay.visible = visible_now

func _on_ending_continue() -> void:
    if ending_title.text == "СИГНАЛ ВОССТАНОВЛЕН":
        game.return_to_title()
    else:
        game.respawn_player()

func show_victory() -> void:
    ending_title.text = "СИГНАЛ ВОССТАНОВЛЕН"
    ending_continue_button.text = "В УБЕЖИЩЕ"
    ending_message.text = "Три осколка запустили Маяк. В архиве Станции Ноль появляется запись последней экспедиции: люди не исчезли — они ушли глубже, туда, откуда всё ещё приходит ответ.\n\nЭто первая глава BELOW. Возвращайся в убежище, чтобы сохранить результат."
    ending_overlay.visible = true

func show_death() -> void:
    ending_title.text = "СВЯЗЬ ПОТЕРЯНА"
    ending_continue_button.text = "ПРОДОЛЖИТЬ ИЗ УБЕЖИЩА"
    ending_message.text = "Стражи Эха остановили экспедицию. Тебя эвакуировали к входу Станции Ноль. Ты можешь продолжить с половиной здоровья."
    ending_overlay.visible = true

func hide_ending() -> void:
    ending_overlay.visible = false
