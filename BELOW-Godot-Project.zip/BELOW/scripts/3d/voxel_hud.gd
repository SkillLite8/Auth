extends CanvasLayer

const Catalog = preload("res://scripts/3d/item_catalog.gd")

const SLOT_SIZE: int = 50
const SLOT_PITCH: int = 54
const ICON_PITCH: int = 17
const ICON_SIZE: int = 18

var game
var player
var world
var root: Control
var quest_panel: PanelContainer
var quest_label: Label
var story_label: Label
var hint_label: Label
var toast_label: Label
var crosshair: Label
var hotbar_holder: Panel
var hotbar_widgets: Array = []
var inv_widgets: Array = []
var heart_icons: Array = []
var armor_icons: Array = []
var food_icons: Array = []
var ui_textures: Dictionary = {}
var xp_back: ColorRect
var xp_fill: ColorRect
var level_label: Label
var inventory_dim: ColorRect
var inventory_panel: Panel
var tooltip_label: Label
var cursor_box: Control
var cursor_icon: TextureRect
var cursor_count_label: Label
var hover_group: String = ""
var hover_index: int = 0
var pause_overlay: ColorRect
var pause_panel: PanelContainer
var ending_overlay: ColorRect
var ending_title: Label
var ending_message: Label
var ending_continue_button: Button
var toast_timer: float = 0.0

func setup(game_ref: Node, player_ref: CharacterBody3D, world_ref: Node3D) -> void:
    game = game_ref
    player = player_ref
    world = world_ref
    _build_ui()
    refresh()

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS

func _process(delta: float) -> void:
    toast_timer = maxf(0.0, toast_timer - delta)
    if toast_timer <= 0.0 and is_instance_valid(toast_label):
        toast_label.visible = false
    if is_instance_valid(inventory_panel) and inventory_panel.visible:
        var mouse_position: Vector2 = get_viewport().get_mouse_position()
        cursor_box.position = mouse_position - Vector2(16, 16)
        tooltip_label.position = mouse_position + Vector2(16, -36)

# ------------------------------------------------------------------ styles

func _panel_style(background: Color = Color(0.035, 0.05, 0.065, 0.88), border: Color = Color("65717a")) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = background
    style.border_color = border
    style.set_border_width_all(2)
    style.set_corner_radius_all(0)
    style.content_margin_left = 12
    style.content_margin_right = 12
    style.content_margin_top = 9
    style.content_margin_bottom = 9
    return style

func _flat_style(background: Color, border: Color, border_width: int) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = background
    style.border_color = border
    style.set_border_width_all(border_width)
    style.set_corner_radius_all(0)
    return style

func _slot_style(dark: bool, selected: bool, hovered: bool) -> StyleBoxFlat:
    if dark:
        if selected:
            return _flat_style(Color(0.16, 0.16, 0.16, 0.85), Color("ffffff"), 3)
        return _flat_style(Color(0.06, 0.06, 0.06, 0.72), Color("3a3a3a"), 2)
    if hovered:
        return _flat_style(Color("b9b9b9"), Color("ffffff"), 2)
    return _flat_style(Color("8b8b8b"), Color("373737"), 2)

# ------------------------------------------------------------------ building

func _load_ui_textures() -> void:
    for texture_name in ["heart_full", "heart_half", "heart_empty", "armor_full", "armor_half", "armor_empty", "food_full", "food_half", "food_empty"]:
        ui_textures[texture_name] = Catalog.ui_texture(str(texture_name))

func _make_icon_rect() -> TextureRect:
    var rect := TextureRect.new()
    rect.size = Vector2(ICON_SIZE, ICON_SIZE)
    rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    rect.stretch_mode = TextureRect.STRETCH_SCALE
    rect.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return rect

func _build_ui() -> void:
    _load_ui_textures()
    root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_PASS
    add_child(root)

    quest_panel = PanelContainer.new()
    quest_panel.position = Vector2(18, 18)
    quest_panel.custom_minimum_size = Vector2(385, 116)
    quest_panel.size = Vector2(385, 116)
    quest_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.045, 0.052, 0.87), Color("718c75")))
    root.add_child(quest_panel)
    var quest_box := VBoxContainer.new()
    quest_box.add_theme_constant_override("separation", 4)
    quest_panel.add_child(quest_box)
    var heading := Label.new()
    heading.text = "BELOW  //  ЭКСПЕДИЦИЯ 01"
    heading.add_theme_font_size_override("font_size", 17)
    heading.add_theme_color_override("font_color", Color("e3c47d"))
    quest_box.add_child(heading)
    story_label = Label.new()
    story_label.text = "СТАНЦИЯ НОЛЬ · СИГНАЛ ПОТЕРЯН"
    story_label.add_theme_font_size_override("font_size", 12)
    story_label.add_theme_color_override("font_color", Color("a5c4d0"))
    quest_box.add_child(story_label)
    quest_label = Label.new()
    quest_label.text = "Найди 3 осколка Эха"
    quest_label.add_theme_font_size_override("font_size", 14)
    quest_label.add_theme_color_override("font_color", Color("f2f0e8"))
    quest_box.add_child(quest_label)

    hint_label = Label.new()
    hint_label.text = "WASD ходьба · Ctrl бег · Shift присесть · Space прыжок · E рюкзак · F действие"
    hint_label.position = Vector2(18, 145)
    hint_label.size = Vector2(760, 22)
    hint_label.add_theme_font_size_override("font_size", 12)
    hint_label.add_theme_color_override("font_color", Color("d2d5ce"))
    root.add_child(hint_label)

    crosshair = Label.new()
    crosshair.name = "Crosshair"
    crosshair.text = "+"
    crosshair.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    crosshair.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    crosshair.add_theme_font_size_override("font_size", 24)
    crosshair.add_theme_color_override("font_color", Color("ffffff"))
    crosshair.add_theme_color_override("font_shadow_color", Color("151b20"))
    crosshair.add_theme_constant_override("shadow_offset_x", 1)
    crosshair.add_theme_constant_override("shadow_offset_y", 1)
    crosshair.size = Vector2(28, 28)
    root.add_child(crosshair)

    toast_label = Label.new()
    toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    toast_label.add_theme_font_size_override("font_size", 18)
    toast_label.add_theme_color_override("font_color", Color("ffe6a7"))
    toast_label.add_theme_color_override("font_shadow_color", Color("101820"))
    toast_label.add_theme_constant_override("shadow_offset_x", 2)
    toast_label.add_theme_constant_override("shadow_offset_y", 2)
    toast_label.size = Vector2(780, 38)
    toast_label.visible = false
    root.add_child(toast_label)

    _build_status_bars()
    _build_hotbar()
    _build_inventory_panel()
    _build_pause_panel()
    _build_ending_panel()
    _layout()
    get_viewport().size_changed.connect(_layout)

func _build_status_bars() -> void:
    for i in range(10):
        var heart := _make_icon_rect()
        root.add_child(heart)
        heart_icons.append(heart)
        var armor := _make_icon_rect()
        root.add_child(armor)
        armor_icons.append(armor)
        var food := _make_icon_rect()
        root.add_child(food)
        food_icons.append(food)
    xp_back = ColorRect.new()
    xp_back.color = Color(0.05, 0.05, 0.05, 0.85)
    xp_back.size = Vector2(486, 8)
    xp_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(xp_back)
    xp_fill = ColorRect.new()
    xp_fill.color = Color("7ed321")
    xp_fill.size = Vector2(0, 8)
    xp_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(xp_fill)
    level_label = Label.new()
    level_label.size = Vector2(60, 24)
    level_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    level_label.add_theme_font_size_override("font_size", 18)
    level_label.add_theme_color_override("font_color", Color("80ff20"))
    level_label.add_theme_color_override("font_outline_color", Color("000000"))
    level_label.add_theme_constant_override("outline_size", 5)
    level_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(level_label)

func _make_slot(parent: Control, group: String, index: int, pos: Vector2, interactive: bool, dark: bool) -> Dictionary:
    var panel := Panel.new()
    panel.position = pos
    panel.size = Vector2(SLOT_SIZE, SLOT_SIZE)
    panel.add_theme_stylebox_override("panel", _slot_style(dark, false, false))
    parent.add_child(panel)
    var icon := TextureRect.new()
    icon.position = Vector2(9, 9)
    icon.size = Vector2(32, 32)
    icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    icon.stretch_mode = TextureRect.STRETCH_SCALE
    icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.add_child(icon)
    var count_label := Label.new()
    count_label.position = Vector2(0, 27)
    count_label.size = Vector2(SLOT_SIZE - 4, 20)
    count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    count_label.add_theme_font_size_override("font_size", 14)
    count_label.add_theme_color_override("font_color", Color("ffffff"))
    count_label.add_theme_color_override("font_outline_color", Color("1a1a1a"))
    count_label.add_theme_constant_override("outline_size", 4)
    count_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.add_child(count_label)
    if interactive:
        panel.gui_input.connect(_on_slot_gui_input.bind(group, index))
        panel.mouse_entered.connect(_on_slot_hover.bind(group, index))
        panel.mouse_exited.connect(_on_slot_unhover)
    else:
        panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return {"panel": panel, "icon": icon, "count": count_label, "group": group, "index": index, "dark": dark}

func _build_hotbar() -> void:
    hotbar_holder = Panel.new()
    hotbar_holder.size = Vector2(9 * SLOT_PITCH + 10, 62)
    hotbar_holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hotbar_holder.add_theme_stylebox_override("panel", _flat_style(Color(0.02, 0.02, 0.02, 0.45), Color(0, 0, 0, 0), 0))
    root.add_child(hotbar_holder)
    for index in range(9):
        var widget: Dictionary = _make_slot(hotbar_holder, "inv", index, Vector2(5 + index * SLOT_PITCH, 6), false, true)
        hotbar_widgets.append(widget)

func _add_label(parent: Control, text_value: String, pos: Vector2, font_size: int, color: Color) -> Label:
    var label := Label.new()
    label.text = text_value
    label.position = pos
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(label)
    return label

func _add_rect(parent: Control, pos: Vector2, rect_size: Vector2, color: Color) -> ColorRect:
    var rect := ColorRect.new()
    rect.position = pos
    rect.size = rect_size
    rect.color = color
    rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(rect)
    return rect

func _build_inventory_panel() -> void:
    inventory_dim = ColorRect.new()
    inventory_dim.color = Color(0, 0, 0, 0.5)
    inventory_dim.visible = false
    inventory_dim.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(inventory_dim)
    inventory_dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    inventory_panel = Panel.new()
    inventory_panel.visible = false
    inventory_panel.size = Vector2(522, 506)
    inventory_panel.mouse_filter = Control.MOUSE_FILTER_STOP
    inventory_panel.add_theme_stylebox_override("panel", _flat_style(Color("c6c6c6"), Color("1b1b1b"), 3))
    root.add_child(inventory_panel)

    # armour slots (decorative for now - no armour items exist yet)
    for i in range(4):
        inv_widgets.append(_make_slot(inventory_panel, "armor", i, Vector2(20, 22 + i * SLOT_PITCH), true, false))

    # character preview
    _add_rect(inventory_panel, Vector2(78, 22), Vector2(140, 212), Color(0.04, 0.04, 0.04))
    _add_rect(inventory_panel, Vector2(128, 40), Vector2(40, 12), Color("4b3320"))
    _add_rect(inventory_panel, Vector2(128, 52), Vector2(40, 30), Color("b98a68"))
    _add_rect(inventory_panel, Vector2(138, 62), Vector2(6, 5), Color("ffffff"))
    _add_rect(inventory_panel, Vector2(152, 62), Vector2(6, 5), Color("ffffff"))
    _add_rect(inventory_panel, Vector2(140, 63), Vector2(3, 4), Color("3a2a6a"))
    _add_rect(inventory_panel, Vector2(153, 63), Vector2(3, 4), Color("3a2a6a"))
    _add_rect(inventory_panel, Vector2(120, 82), Vector2(56, 84), Color("2c9a9b"))
    _add_rect(inventory_panel, Vector2(100, 82), Vector2(20, 84), Color("2c9a9b"))
    _add_rect(inventory_panel, Vector2(176, 82), Vector2(20, 84), Color("2c9a9b"))
    _add_rect(inventory_panel, Vector2(100, 130), Vector2(20, 36), Color("b98a68"))
    _add_rect(inventory_panel, Vector2(176, 130), Vector2(20, 36), Color("b98a68"))
    _add_rect(inventory_panel, Vector2(120, 166), Vector2(28, 44), Color("3c3a9a"))
    _add_rect(inventory_panel, Vector2(148, 166), Vector2(28, 44), Color("3c3a9a"))
    _add_rect(inventory_panel, Vector2(120, 210), Vector2(28, 8), Color("55555d"))
    _add_rect(inventory_panel, Vector2(148, 210), Vector2(28, 8), Color("55555d"))

    inv_widgets.append(_make_slot(inventory_panel, "offhand", 0, Vector2(228, 184), true, false))

    _add_label(inventory_panel, "Создание", Vector2(252, 18), 18, Color("404040"))
    for row in range(2):
        for column in range(2):
            var craft_index: int = row * 2 + column
            inv_widgets.append(_make_slot(inventory_panel, "craft", craft_index, Vector2(252 + column * SLOT_PITCH, 48 + row * SLOT_PITCH), true, false))
    _add_label(inventory_panel, "→", Vector2(372, 68), 40, Color("707070"))
    inv_widgets.append(_make_slot(inventory_panel, "result", 0, Vector2(424, 75), true, false))

    _add_label(inventory_panel, "Рюкзак", Vector2(22, 238), 15, Color("404040"))
    for row in range(3):
        for column in range(9):
            var main_index: int = 9 + row * 9 + column
            inv_widgets.append(_make_slot(inventory_panel, "inv", main_index, Vector2(20 + column * SLOT_PITCH, 262 + row * SLOT_PITCH), true, false))
    for column in range(9):
        inv_widgets.append(_make_slot(inventory_panel, "inv", column, Vector2(20 + column * SLOT_PITCH, 436), true, false))

    tooltip_label = Label.new()
    tooltip_label.visible = false
    tooltip_label.add_theme_font_size_override("font_size", 15)
    tooltip_label.add_theme_color_override("font_color", Color("ffffff"))
    var tip_style := _flat_style(Color(0.06, 0.0, 0.1, 0.94), Color("2b0a5c"), 2)
    tip_style.content_margin_left = 8
    tip_style.content_margin_right = 8
    tip_style.content_margin_top = 4
    tip_style.content_margin_bottom = 4
    tooltip_label.add_theme_stylebox_override("normal", tip_style)
    tooltip_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(tooltip_label)

    cursor_box = Control.new()
    cursor_box.visible = false
    cursor_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(cursor_box)
    cursor_icon = TextureRect.new()
    cursor_icon.size = Vector2(32, 32)
    cursor_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    cursor_icon.stretch_mode = TextureRect.STRETCH_SCALE
    cursor_icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    cursor_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cursor_box.add_child(cursor_icon)
    cursor_count_label = Label.new()
    cursor_count_label.position = Vector2(-4, 16)
    cursor_count_label.size = Vector2(40, 20)
    cursor_count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    cursor_count_label.add_theme_font_size_override("font_size", 14)
    cursor_count_label.add_theme_color_override("font_color", Color("ffffff"))
    cursor_count_label.add_theme_color_override("font_outline_color", Color("1a1a1a"))
    cursor_count_label.add_theme_constant_override("outline_size", 4)
    cursor_count_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cursor_box.add_child(cursor_count_label)

func _build_pause_panel() -> void:
    pause_overlay = ColorRect.new()
    pause_overlay.color = Color(0.015, 0.02, 0.025, 0.75)
    pause_overlay.visible = false
    pause_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(pause_overlay)
    pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var center := CenterContainer.new()
    pause_overlay.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    pause_panel = PanelContainer.new()
    pause_panel.custom_minimum_size = Vector2(350, 290)
    pause_panel.add_theme_stylebox_override("panel", _panel_style(Color("222820"), Color("9aab88")))
    center.add_child(pause_panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    pause_panel.add_child(box)
    var title := Label.new()
    title.text = "ЭКСПЕДИЦИЯ ПРИОСТАНОВЛЕНА"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 18)
    title.add_theme_color_override("font_color", Color("e3c47d"))
    box.add_child(title)
    _add_menu_button(box, "ПРОДОЛЖИТЬ", func(): game.toggle_pause(false))
    _add_menu_button(box, "СОХРАНИТЬ", func(): game.save_game())
    _add_menu_button(box, "ВЕРНУТЬСЯ В УБЕЖИЩЕ", func(): game.return_to_title())

func _build_ending_panel() -> void:
    ending_overlay = ColorRect.new()
    ending_overlay.color = Color(0.012, 0.02, 0.03, 0.88)
    ending_overlay.visible = false
    ending_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(ending_overlay)
    ending_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var center := CenterContainer.new()
    ending_overlay.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(580, 310)
    panel.add_theme_stylebox_override("panel", _panel_style(Color("1c2829"), Color("8ac5bd")))
    center.add_child(panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    panel.add_child(box)
    ending_title = Label.new()
    ending_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ending_title.add_theme_font_size_override("font_size", 28)
    ending_title.add_theme_color_override("font_color", Color("e3c47d"))
    box.add_child(ending_title)
    ending_message = Label.new()
    ending_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    ending_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ending_message.add_theme_font_size_override("font_size", 16)
    ending_message.add_theme_color_override("font_color", Color("d6e4dd"))
    box.add_child(ending_message)
    ending_continue_button = Button.new()
    ending_continue_button.custom_minimum_size = Vector2(300, 42)
    ending_continue_button.add_theme_font_size_override("font_size", 15)
    ending_continue_button.add_theme_color_override("font_color", Color("e2e8df"))
    ending_continue_button.add_theme_stylebox_override("normal", _panel_style(Color("343e34"), Color("71876c")))
    ending_continue_button.add_theme_stylebox_override("hover", _panel_style(Color("4b5a43"), Color("d5c27e")))
    ending_continue_button.pressed.connect(_on_ending_continue)
    box.add_child(ending_continue_button)
    _add_menu_button(box, "ВЕРНУТЬСЯ В ГЛАВНОЕ МЕНЮ", func(): game.return_to_title())

func _add_menu_button(parent: VBoxContainer, caption: String, callback: Callable) -> void:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(300, 42)
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size", 15)
    button.add_theme_color_override("font_color", Color("e2e8df"))
    button.add_theme_stylebox_override("normal", _panel_style(Color("343e34"), Color("71876c")))
    button.add_theme_stylebox_override("hover", _panel_style(Color("4b5a43"), Color("d5c27e")))
    parent.add_child(button)
    button.pressed.connect(callback)

# ------------------------------------------------------------------ layout

func _layout() -> void:
    if not is_instance_valid(root):
        return
    var view_size: Vector2 = get_viewport().get_visible_rect().size
    crosshair.position = view_size * 0.5 - crosshair.size * 0.5
    toast_label.position = Vector2((view_size.x - toast_label.size.x) * 0.5, 75)
    var holder_x: float = (view_size.x - hotbar_holder.size.x) * 0.5
    var holder_y: float = view_size.y - 74.0
    hotbar_holder.position = Vector2(holder_x, holder_y)
    xp_back.position = Vector2(holder_x + 5.0, holder_y - 14.0)
    xp_fill.position = xp_back.position
    level_label.position = Vector2(holder_x + hotbar_holder.size.x * 0.5 - 30.0, holder_y - 42.0)
    for i in range(10):
        var heart: TextureRect = heart_icons[i]
        heart.position = Vector2(holder_x + 5.0 + i * ICON_PITCH, holder_y - 36.0)
        var armor: TextureRect = armor_icons[i]
        armor.position = Vector2(holder_x + 5.0 + i * ICON_PITCH, holder_y - 58.0)
        var food: TextureRect = food_icons[i]
        food.position = Vector2(holder_x + hotbar_holder.size.x - 5.0 - ICON_SIZE - i * ICON_PITCH, holder_y - 36.0)
    inventory_panel.position = ((view_size - inventory_panel.size) * 0.5).floor()

# ------------------------------------------------------------------ refresh

func _tri_texture(value: int, index: int, prefix: String) -> Texture2D:
    var full_need: int = index * 2 + 2
    if value >= full_need:
        return ui_textures.get(prefix + "_full") as Texture2D
    if value == full_need - 1:
        return ui_textures.get(prefix + "_half") as Texture2D
    return ui_textures.get(prefix + "_empty") as Texture2D

func _update_slot_widget(widget: Dictionary, item_id: String, amount: int, selected: bool, hovered: bool) -> void:
    var icon: TextureRect = widget["icon"]
    var count_label: Label = widget["count"]
    var panel: Panel = widget["panel"]
    if item_id == "":
        icon.texture = null
        count_label.text = ""
    else:
        icon.texture = Catalog.icon(item_id)
        count_label.text = str(amount) if amount > 1 else ""
    var is_dark: bool = bool(widget["dark"])
    panel.add_theme_stylebox_override("panel", _slot_style(is_dark, selected, hovered))

func refresh() -> void:
    if not is_instance_valid(player):
        return
    var inventory_open: bool = inventory_panel.visible

    var hp: int = int(round(player.health))
    var hunger_points: int = int(ceil(player.hunger))
    var armor_points: int = int(player.get_armor_points())
    for i in range(10):
        var heart: TextureRect = heart_icons[i]
        heart.texture = _tri_texture(hp, i, "heart")
        heart.visible = not inventory_open
        var armor: TextureRect = armor_icons[i]
        armor.texture = _tri_texture(armor_points, i, "armor")
        armor.visible = (not inventory_open) and armor_points > 0
        var food: TextureRect = food_icons[i]
        food.texture = _tri_texture(hunger_points, i, "food")
        food.visible = not inventory_open
    var level: int = int(player.get_level())
    var progress: float = float(player.get_level_progress())
    xp_back.visible = not inventory_open
    xp_fill.visible = not inventory_open
    xp_fill.size = Vector2(xp_back.size.x * progress, xp_back.size.y)
    level_label.visible = (not inventory_open) and level > 0
    level_label.text = str(level)
    hotbar_holder.visible = not inventory_open
    crosshair.visible = not inventory_open

    quest_label.text = "Задача: найди 3 осколка Эха  [%d/3]" % int(game.shards_found)
    if int(game.shards_found) >= 3:
        quest_label.text = "Вернись к Маяку на Станции Ноль  [ГОТОВО]"

    var selected: int = int(player.selected_slot)
    for widget in hotbar_widgets:
        var hotbar_index: int = int(widget["index"])
        var hotbar_item: String = player.get_slot_id("inv", hotbar_index)
        var hotbar_amount: int = player.get_slot_count("inv", hotbar_index)
        _update_slot_widget(widget, hotbar_item, hotbar_amount, hotbar_index == selected, false)
    for widget in inv_widgets:
        var group_name: String = str(widget["group"])
        var slot_index: int = int(widget["index"])
        var slot_item: String = player.get_slot_id(group_name, slot_index)
        var slot_amount: int = player.get_slot_count(group_name, slot_index)
        var hovered: bool = group_name == hover_group and slot_index == hover_index
        _update_slot_widget(widget, slot_item, slot_amount, false, hovered)

    var cursor_item: String = str(player.cursor_id)
    cursor_box.visible = inventory_open and cursor_item != ""
    if cursor_item != "":
        cursor_icon.texture = Catalog.icon(cursor_item)
        var cursor_amount: int = int(player.cursor_count)
        cursor_count_label.text = str(cursor_amount) if cursor_amount > 1 else ""
    _update_tooltip()

func _update_tooltip() -> void:
    var show_tip: bool = false
    if hover_group != "" and is_instance_valid(player) and str(player.cursor_id) == "":
        var item_id: String = player.get_slot_id(hover_group, hover_index)
        if item_id != "":
            tooltip_label.text = Catalog.item_name(item_id)
            tooltip_label.reset_size()
            show_tip = true
    tooltip_label.visible = show_tip and inventory_panel.visible

# ------------------------------------------------------------------ interaction

func _on_slot_gui_input(event: InputEvent, group: String, index: int) -> void:
    var mouse_event := event as InputEventMouseButton
    if mouse_event == null or not mouse_event.pressed:
        return
    if mouse_event.button_index == MOUSE_BUTTON_LEFT:
        player.slot_click(group, index, false)
    elif mouse_event.button_index == MOUSE_BUTTON_RIGHT:
        player.slot_click(group, index, true)
    else:
        return
    refresh()

func _on_slot_hover(group: String, index: int) -> void:
    hover_group = group
    hover_index = index
    refresh()

func _on_slot_unhover() -> void:
    hover_group = ""
    refresh()

func notify(message: String, duration: float = 3.2) -> void:
    if not is_instance_valid(toast_label):
        return
    toast_label.text = message
    toast_label.visible = true
    toast_timer = duration

func set_inventory_visible(visible_now: bool) -> void:
    inventory_panel.visible = visible_now
    inventory_dim.visible = visible_now
    hover_group = ""
    refresh()

func set_pause_visible(visible_now: bool) -> void:
    pause_overlay.visible = visible_now

func _on_ending_continue() -> void:
    if ending_title.text == "СИГНАЛ ВОССТАНОВЛЕН":
        game.return_to_title()
    else:
        game.respawn_player()

func show_victory() -> void:
    ending_title.text = "СИГНАЛ ВОССТАНОВЛЕН"
    ending_continue_button.text = "В УБЕЖИЩЕ"
    ending_message.text = "Три осколка запустили Маяк. В архиве Станции Ноль появляется запись последней экспедиции: люди не исчезли — они ушли глубже, туда, откуда всё ещё приходит ответ.\n\nЭто первая глава BELOW. Возвращайся в убежище, чтобы сохранить результат."
    ending_overlay.visible = true

func show_death() -> void:
    ending_title.text = "СВЯЗЬ ПОТЕРЯНА"
    ending_continue_button.text = "ПРОДОЛЖИТЬ ИЗ УБЕЖИЩА"
    ending_message.text = "Стражи Эха остановили экспедицию. Тебя эвакуировали к входу Станции Ноль. Ты можешь продолжить с половиной здоровья."
    ending_overlay.visible = true

func hide_ending() -> void:
    ending_overlay.visible = false
