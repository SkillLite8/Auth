extends CharacterBody3D

const SPEED: float = 2.25
const GRAVITY: float = 18.0

var player
var game
var health: float = 12.0
var attack_cooldown: float = 0.0
var dead: bool = false

func _ready() -> void:
    add_to_group("voxel_enemy")
    collision_layer = 4
    collision_mask = 1
    var body_mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(0.8, 1.0, 0.65)
    body_mesh.mesh = box
    var body_mat := StandardMaterial3D.new()
    body_mat.albedo_color = Color("343c51")
    body_mat.roughness = 0.85
    body_mat.emission_enabled = true
    body_mat.emission = Color("1a283f")
    body_mat.emission_energy_multiplier = 0.6
    body_mesh.material_override = body_mat
    body_mesh.position.y = 0.15
    add_child(body_mesh)
    var head_mesh := MeshInstance3D.new()
    var head_box := BoxMesh.new()
    head_box.size = Vector3(0.58, 0.55, 0.58)
    head_mesh.mesh = head_box
    head_mesh.position = Vector3(0, 0.88, -0.02)
    head_mesh.material_override = body_mat
    add_child(head_mesh)
    var eyes := MeshInstance3D.new()
    var eye_box := BoxMesh.new()
    eye_box.size = Vector3(0.34, 0.1, 0.08)
    eyes.mesh = eye_box
    eyes.position = Vector3(0, 0.91, -0.33)
    var eye_mat := StandardMaterial3D.new()
    eye_mat.albedo_color = Color("ff6b62")
    eye_mat.emission_enabled = true
    eye_mat.emission = Color("ff3327")
    eye_mat.emission_energy_multiplier = 2.0
    eyes.material_override = eye_mat
    add_child(eyes)
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.36
    capsule.height = 1.8
    shape.shape = capsule
    shape.position.y = 0.12
    add_child(shape)

func _physics_process(delta: float) -> void:
    if dead or not is_instance_valid(player) or game == null or game.is_paused:
        return
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    var offset := player.global_position - global_position
    var flat := Vector3(offset.x, 0.0, offset.z)
    var distance := flat.length()
    if distance < 7.0 and distance > 1.35:
        var direction := flat.normalized()
        velocity.x = direction.x * SPEED
        velocity.z = direction.z * SPEED
        look_at(Vector3(player.global_position.x, global_position.y, player.global_position.z), Vector3.UP)
    else:
        velocity.x = move_toward(velocity.x, 0.0, 8.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 8.0 * delta)
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    else:
        velocity.y = minf(velocity.y, 0.0)
    move_and_slide()
    if distance <= 1.55 and attack_cooldown <= 0.0:
        player.call("take_damage", 2.0)
        attack_cooldown = 1.25

func take_damage(amount: float, _attacker: Node = null) -> void:
    if dead:
        return
    health -= amount
    if health <= 0.0:
        dead = true
        if game != null:
            game.notify("Страж рассыпался. Найдено эхо-ядро.")
            if is_instance_valid(player):
                player.add_item("echo_core", 1)
        queue_free()
    else:
        scale = Vector3(0.92, 0.92, 0.92)
        await get_tree().create_timer(0.09).timeout
        if is_instance_valid(self):
            scale = Vector3.ONE
