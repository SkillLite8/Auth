extends Node3D

const WORLD_RADIUS: int = 10
const BEDROCK_Y: int = -3
const SentinelScript = preload("res://scripts/3d/echo_sentinel.gd")

var seed_value: int = 0
var cube_mesh: BoxMesh
var materials: Dictionary = {}
var blocks: Dictionary = {}
var removed_cells: Dictionary = {}
var added_cells: Dictionary = {}
var story_objects: Array[Dictionary] = []
var visual_root: Node3D
var beacon_node: Node3D
var rng := RandomNumberGenerator.new()
var block_meshes: Dictionary = {}
var tex_materials: Dictionary = {}

const TEX_DIR: String = "res://assets/textures/blocks/"
# kind -> [top texture, side texture, bottom texture]
const TEXTURED_BLOCKS: Dictionary = {
    "grass": ["grass_top", "grass_side", "dirt"],
    "dirt": ["dirt", "dirt", "dirt"],
    "sand": ["sand", "sand", "sand"],
    "wood": ["wood_top", "wood_side", "wood_top"],
    "leaves": ["leaves", "leaves", "leaves"],
    "stone": ["stone", "stone", "stone"],
    "cobblestone": ["cobblestone", "cobblestone", "cobblestone"]
}

func generate(new_seed: int = 0, found_shards: Array = [], saved_changes: Dictionary = {}) -> void:
    seed_value = new_seed if new_seed != 0 else randi()
    rng.seed = seed_value
    cube_mesh = BoxMesh.new()
    cube_mesh.size = Vector3.ONE
    _create_materials()
    _generate_terrain()
    _generate_trees()
    _generate_ruins()
    _create_story_objects(found_shards)
    _apply_saved_changes(saved_changes)
    _rebuild_block_visuals()

func _create_materials() -> void:
    materials.clear()
    materials["grass"] = _material(Color("648a49"))
    materials["dirt"] = _material(Color("79543b"))
    materials["stone"] = _material(Color("777e86"))
    materials["bedrock"] = _material(Color("333b43"))
    materials["wood"] = _material(Color("79502f"))
    materials["leaves"] = _material(Color("3f7546"))
    materials["ancient"] = _material(Color("4b5968"))
    materials["torch"] = _material(Color("d49a4b"), true, Color("ff9c3b"))
    materials["ore"] = _material(Color("4aa4a8"), true, Color("32e6ed"))

func _material(base_color: Color, glowing: bool = false, glow_color: Color = Color.BLACK) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = base_color
    material.roughness = 0.92
    if glowing:
        material.emission_enabled = true
        material.emission = glow_color
        material.emission_energy_multiplier = 1.4
    return material

func height_at(x: int, z: int) -> int:
    var wave := sin(float(x) * 0.31) + cos(float(z) * 0.27) + sin(float(x + z) * 0.19)
    return 1 + clampi(roundi((wave + 3.0) / 6.0 * 2.0), 0, 2)

func get_spawn_position() -> Vector3:
    return Vector3(0.0, float(height_at(0, 4)) + 1.42, 4.0)

func _generate_terrain() -> void:
    for x in range(-WORLD_RADIUS, WORLD_RADIUS + 1):
        for z in range(-WORLD_RADIUS, WORLD_RADIUS + 1):
            var surface_y := height_at(x, z)
            for y in range(BEDROCK_Y, surface_y + 1):
                var kind := "stone"
                var sandy: bool = _is_sand(x, z, surface_y)
                if y == BEDROCK_Y:
                    kind = "bedrock"
                elif y == surface_y:
                    kind = "sand" if sandy else "grass"
                elif y >= surface_y - 2:
                    kind = "sand" if (sandy and y >= surface_y - 1) else "dirt"
                elif rng.randf() < 0.035:
                    kind = "ore"
                _add_block(Vector3i(x, y, z), kind)

    # A raised stone rim makes the small expedition region feel intentional and prevents easy fall-offs.
    for x in range(-WORLD_RADIUS, WORLD_RADIUS + 1):
        for z in [-WORLD_RADIUS, WORLD_RADIUS]:
            var base_y := height_at(x, z)
            for dy in range(1, 4):
                _add_block(Vector3i(x, base_y + dy, z), "ancient")
    for z in range(-WORLD_RADIUS + 1, WORLD_RADIUS):
        for x in [-WORLD_RADIUS, WORLD_RADIUS]:
            var base_y := height_at(x, z)
            for dy in range(1, 4):
                _add_block(Vector3i(x, base_y + dy, z), "ancient")

func _is_sand(x: int, z: int, surface_y: int) -> bool:
    if surface_y > 1:
        return false
    if Vector2(x, z).distance_to(Vector2(0, 4)) < 3.5:
        return false
    return sin(float(x) * 0.55 + 0.8) * cos(float(z) * 0.5 - 0.4) > 0.45

func _is_protected_area(x: int, z: int) -> bool:
    if Vector2(x, z).length() < 4.0 and z > 0:
        return true
    if Vector2(x, z).distance_to(Vector2(0, -7)) < 4.0:
        return true
    for point in [Vector2(-7, -5), Vector2(7, -6), Vector2(7, 7)]:
        if Vector2(x, z).distance_to(point) < 3.0:
            return true
    return false

func _generate_trees() -> void:
    for x in range(-9, 10, 3):
        for z in range(-9, 10, 3):
            if _is_protected_area(x, z):
                continue
            if abs(x * 7 + z * 11) % 5 > 1:
                continue
            var surface_y := height_at(x, z)
            for dy in range(1, 4):
                _add_block(Vector3i(x, surface_y + dy, z), "wood")
            for dx in range(-1, 2):
                for dz in range(-1, 2):
                    for dy in range(2, 5):
                        if abs(dx) + abs(dz) + abs(dy - 3) <= 3:
                            _add_block(Vector3i(x + dx, surface_y + dy, z + dz), "leaves")

func _generate_ruins() -> void:
    # Broken ring around Station Zero.
    var center_x := 0
    var center_z := -7
    for dx in range(-3, 4):
        for dz in range(-3, 4):
            if abs(dx) == 3 or abs(dz) == 3:
                var bx := center_x + dx
                var bz := center_z + dz
                var by := height_at(bx, bz)
                _add_block(Vector3i(bx, by + 1, bz), "cobblestone")
                if (dx + dz) % 2 == 0:
                    _add_block(Vector3i(bx, by + 2, bz), "cobblestone")
    # An old path leading from the landing area towards the ruin.
    for z in range(-4, 4):
        if z == 0:
            continue
        var y := height_at(0, z)
        _remove_block_at(Vector3i(0, y, z))
        _add_block(Vector3i(0, y, z), "stone")

func _add_block(cell: Vector3i, kind: String) -> StaticBody3D:
    if blocks.has(cell):
        return blocks[cell] as StaticBody3D
    var body := StaticBody3D.new()
    body.name = "Block_%s_%d_%d_%d" % [kind, cell.x, cell.y, cell.z]
    body.position = Vector3(cell.x, cell.y, cell.z)
    body.collision_layer = 1
    body.collision_mask = 1
    body.add_to_group("voxel_blocks")
    body.set_meta("grid_cell", cell)
    body.set_meta("block_kind", kind)
    body.set_meta("breakable", kind != "bedrock")

    # Rendered blocks are batched by material in MultiMesh instances below.
    # Each block keeps its own StaticBody/CollisionShape so mining and placement
    # remain grid-accurate without thousands of separate draw calls.
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3.ONE
    collision.shape = shape
    body.add_child(collision)
    add_child(body)
    blocks[cell] = body
    return body

func _remove_block_at(cell: Vector3i) -> void:
    if not blocks.has(cell):
        return
    var body: StaticBody3D = blocks[cell]
    blocks.erase(cell)
    if is_instance_valid(body):
        body.queue_free()

func mine_block(body: Node) -> Dictionary:
    if not is_instance_valid(body) or not body is StaticBody3D or not body.is_in_group("voxel_blocks"):
        return {"ok": false, "message": "Это нельзя добыть."}
    if not bool(body.get_meta("breakable", true)):
        return {"ok": false, "message": "Коренная порода не поддаётся кирке."}
    var cell: Vector3i = body.get_meta("grid_cell", Vector3i.ZERO)
    var kind := str(body.get_meta("block_kind", "stone"))
    _remove_block_at(cell)
    removed_cells[cell] = true
    added_cells.erase(cell)
    _rebuild_block_visuals()
    return {"ok": true, "kind": kind, "cell": cell}

func place_block(cell: Vector3i, kind: String) -> bool:
    if blocks.has(cell):
        return false
    if abs(cell.x) > WORLD_RADIUS or abs(cell.z) > WORLD_RADIUS or cell.y <= BEDROCK_Y or cell.y > 12:
        return false
    _add_block(cell, kind)
    added_cells[cell] = kind
    removed_cells.erase(cell)
    _rebuild_block_visuals()
    return true

func _rebuild_block_visuals() -> void:
    if is_instance_valid(visual_root):
        visual_root.free()

    visual_root = Node3D.new()
    visual_root.name = "BatchedBlockVisuals"
    add_child(visual_root)

    var cells_by_kind: Dictionary = {}
    for raw_cell in blocks.keys():
        var cell: Vector3i = raw_cell
        var body: StaticBody3D = blocks[raw_cell]
        var kind := str(body.get_meta("block_kind", "stone"))
        if not cells_by_kind.has(kind):
            cells_by_kind[kind] = []
        cells_by_kind[kind].append(cell)

    for kind_variant in cells_by_kind.keys():
        var kind := str(kind_variant)
        var cells: Array = cells_by_kind[kind_variant]
        if cells.is_empty():
            continue
        var multimesh := MultiMesh.new()
        multimesh.transform_format = MultiMesh.TRANSFORM_3D
        multimesh.mesh = _get_block_mesh(kind)
        multimesh.instance_count = cells.size()
        for index in range(cells.size()):
            var cell: Vector3i = cells[index]
            multimesh.set_instance_transform(index, Transform3D(Basis.IDENTITY, Vector3(cell.x, cell.y, cell.z)))

        var batch := MultiMeshInstance3D.new()
        batch.name = "Blocks_%s" % kind
        batch.multimesh = multimesh
        batch.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
        visual_root.add_child(batch)

func _texture_material(texture_name: String, tint: Color = Color.WHITE, glow: Color = Color.BLACK, glowing: bool = false) -> StandardMaterial3D:
    var key: String = "%s|%s|%s" % [texture_name, tint.to_html(), str(glowing)]
    if tex_materials.has(key):
        return tex_materials[key]
    var material := StandardMaterial3D.new()
    var path: String = TEX_DIR + texture_name + ".png"
    if ResourceLoader.exists(path):
        material.albedo_texture = load(path) as Texture2D
    material.albedo_color = tint
    material.roughness = 1.0
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
    if glowing:
        material.emission_enabled = true
        material.emission = glow
        material.emission_energy_multiplier = 1.2
    tex_materials[key] = material
    return material

func _block_materials(kind: String) -> Array:
    if TEXTURED_BLOCKS.has(kind):
        var names: Array = TEXTURED_BLOCKS[kind]
        return [_texture_material(str(names[0])), _texture_material(str(names[1])), _texture_material(str(names[2]))]
    if kind == "ancient":
        var ancient := _texture_material("cobblestone", Color(0.62, 0.70, 0.86))
        return [ancient, ancient, ancient]
    if kind == "bedrock":
        var bedrock := _texture_material("stone", Color(0.26, 0.28, 0.33))
        return [bedrock, bedrock, bedrock]
    if kind == "ore":
        var ore := _texture_material("stone", Color(0.55, 0.95, 1.0), Color("2fe0e8"), true)
        return [ore, ore, ore]
    var flat: Material = materials.get(kind, materials["stone"])
    return [flat, flat, flat]

func _face_corners(face: String) -> Array:
    match face:
        "top":
            return [Vector3(-0.5, 0.5, -0.5), Vector3(0.5, 0.5, -0.5), Vector3(0.5, 0.5, 0.5), Vector3(-0.5, 0.5, 0.5)]
        "bottom":
            return [Vector3(-0.5, -0.5, 0.5), Vector3(0.5, -0.5, 0.5), Vector3(0.5, -0.5, -0.5), Vector3(-0.5, -0.5, -0.5)]
        "south":
            return [Vector3(-0.5, 0.5, 0.5), Vector3(0.5, 0.5, 0.5), Vector3(0.5, -0.5, 0.5), Vector3(-0.5, -0.5, 0.5)]
        "north":
            return [Vector3(0.5, 0.5, -0.5), Vector3(-0.5, 0.5, -0.5), Vector3(-0.5, -0.5, -0.5), Vector3(0.5, -0.5, -0.5)]
        "east":
            return [Vector3(0.5, 0.5, 0.5), Vector3(0.5, 0.5, -0.5), Vector3(0.5, -0.5, -0.5), Vector3(0.5, -0.5, 0.5)]
        "west":
            return [Vector3(-0.5, 0.5, -0.5), Vector3(-0.5, 0.5, 0.5), Vector3(-0.5, -0.5, 0.5), Vector3(-0.5, -0.5, -0.5)]
    return []

func _face_normal(face: String) -> Vector3:
    match face:
        "top":
            return Vector3.UP
        "bottom":
            return Vector3.DOWN
        "south":
            return Vector3(0, 0, 1)
        "north":
            return Vector3(0, 0, -1)
        "east":
            return Vector3(1, 0, 0)
        "west":
            return Vector3(-1, 0, 0)
    return Vector3.UP

func _add_quad(st: SurfaceTool, corners: Array, normal: Vector3) -> void:
    var uvs: Array = [Vector2(0, 0), Vector2(1, 0), Vector2(1, 1), Vector2(0, 1)]
    var order: Array = [0, 1, 2, 3]
    var a: Vector3 = corners[0]
    var b: Vector3 = corners[1]
    var c: Vector3 = corners[2]
    # Godot treats clockwise triangles (seen from outside) as front faces.
    if (b - a).cross(c - a).dot(normal) > 0.0:
        order = [0, 3, 2, 1]
    var triangle_slots: Array = [0, 1, 2, 0, 2, 3]
    for slot in triangle_slots:
        var idx: int = int(order[int(slot)])
        st.set_normal(normal)
        st.set_uv(uvs[idx])
        st.add_vertex(corners[idx])

func _add_surface(mesh: ArrayMesh, faces: Array, material: Material) -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    st.set_material(material)
    for face in faces:
        _add_quad(st, _face_corners(str(face)), _face_normal(str(face)))
    st.commit(mesh)

func _get_block_mesh(kind: String) -> ArrayMesh:
    if block_meshes.has(kind):
        return block_meshes[kind]
    var mats: Array = _block_materials(kind)
    var mesh := ArrayMesh.new()
    _add_surface(mesh, ["top"], mats[0])
    _add_surface(mesh, ["south", "north", "east", "west"], mats[1])
    _add_surface(mesh, ["bottom"], mats[2])
    block_meshes[kind] = mesh
    return mesh

func _create_story_objects(found_shards: Array) -> void:
    story_objects.clear()
    var shards: Array[Vector2i] = [Vector2i(-7, -5), Vector2i(7, -6), Vector2i(7, 7)]
    for index in range(shards.size()):
        if found_shards.has(index):
            continue
        var point: Vector2i = shards[index]
        var node := Node3D.new()
        node.name = "EchoShard_%d" % index
        node.position = Vector3(point.x, float(height_at(point.x, point.y)) + 1.2, point.y)
        var mesh_instance := MeshInstance3D.new()
        var shard_mesh := BoxMesh.new()
        shard_mesh.size = Vector3(0.38, 0.72, 0.38)
        mesh_instance.mesh = shard_mesh
        var shard_material := StandardMaterial3D.new()
        shard_material.albedo_color = Color("79f3ee")
        shard_material.emission_enabled = true
        shard_material.emission = Color("35e5df")
        shard_material.emission_energy_multiplier = 2.0
        mesh_instance.material_override = shard_material
        mesh_instance.rotation_degrees = Vector3(0, 24, 14)
        node.add_child(mesh_instance)
        var glow := OmniLight3D.new()
        glow.light_color = Color("45d7d0")
        glow.light_energy = 0.65
        glow.omni_range = 4.0
        glow.position.y = 0.1
        node.add_child(glow)
        var label := Label3D.new()
        label.text = "ОСКОЛОК ЭХА"
        label.font_size = 22
        label.outline_size = 7
        label.position.y = 0.8
        label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        node.add_child(label)
        add_child(node)
        story_objects.append({"kind": "shard", "id": index, "node": node})

    beacon_node = Node3D.new()
    beacon_node.name = "StationZeroBeacon"
    beacon_node.position = Vector3(0.0, float(height_at(0, -7)) + 0.55, -7.0)
    var base := MeshInstance3D.new()
    var base_mesh := BoxMesh.new()
    base_mesh.size = Vector3(1.8, 0.3, 1.8)
    base.mesh = base_mesh
    base.position.y = -0.25
    base.material_override = materials["ancient"]
    beacon_node.add_child(base)
    var pillar := MeshInstance3D.new()
    var pillar_mesh := BoxMesh.new()
    pillar_mesh.size = Vector3(0.72, 1.4, 0.72)
    pillar.mesh = pillar_mesh
    pillar.position.y = 0.55
    pillar.material_override = materials["stone"]
    beacon_node.add_child(pillar)
    var orb := MeshInstance3D.new()
    var orb_mesh := SphereMesh.new()
    orb_mesh.radius = 0.32
    orb_mesh.height = 0.64
    orb.mesh = orb_mesh
    orb.position.y = 1.45
    var orb_material := StandardMaterial3D.new()
    orb_material.albedo_color = Color("f3c76a")
    orb_material.emission_enabled = true
    orb_material.emission = Color("ffad39")
    orb_material.emission_energy_multiplier = 2.0
    orb.material_override = orb_material
    beacon_node.add_child(orb)
    var beacon_light := OmniLight3D.new()
    beacon_light.light_color = Color("ffb85e")
    beacon_light.light_energy = 0.9
    beacon_light.omni_range = 6.0
    beacon_light.position.y = 1.4
    beacon_node.add_child(beacon_light)
    var beacon_label := Label3D.new()
    beacon_label.text = "СТАНЦИЯ НОЛЬ"
    beacon_label.font_size = 28
    beacon_label.outline_size = 8
    beacon_label.position.y = 2.1
    beacon_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    beacon_node.add_child(beacon_label)
    add_child(beacon_node)
    story_objects.append({"kind": "beacon", "id": -1, "node": beacon_node})

func find_nearby_story_object(world_position: Vector3, max_distance: float = 2.8) -> Dictionary:
    var best: Dictionary = {}
    var best_distance := max_distance
    for item in story_objects:
        var node: Node3D = item.get("node")
        if not is_instance_valid(node):
            continue
        var distance := world_position.distance_to(node.global_position)
        if distance < best_distance:
            best_distance = distance
            best = item
    return best

func collect_shard(shard_id: int) -> void:
    for i in range(story_objects.size()):
        var item: Dictionary = story_objects[i]
        if str(item.get("kind", "")) == "shard" and int(item.get("id", -1)) == shard_id:
            var node: Node3D = item.get("node")
            if is_instance_valid(node):
                node.queue_free()
            story_objects.remove_at(i)
            return

func export_changes() -> Dictionary:
    var removed: Array = []
    for cell in removed_cells.keys():
        removed.append([cell.x, cell.y, cell.z])
    var added: Array = []
    for cell in added_cells.keys():
        added.append([cell.x, cell.y, cell.z, str(added_cells[cell])])
    return {"removed": removed, "added": added}

func _apply_saved_changes(changes: Dictionary) -> void:
    for raw_cell in changes.get("removed", []):
        if raw_cell is Array and raw_cell.size() >= 3:
            var cell := Vector3i(int(raw_cell[0]), int(raw_cell[1]), int(raw_cell[2]))
            removed_cells[cell] = true
            _remove_block_at(cell)
    for raw_block in changes.get("added", []):
        if raw_block is Array and raw_block.size() >= 4:
            var cell := Vector3i(int(raw_block[0]), int(raw_block[1]), int(raw_block[2]))
            var kind := str(raw_block[3])
            _remove_block_at(cell)
            _add_block(cell, kind)
            added_cells[cell] = kind
            removed_cells.erase(cell)

func spawn_guardians(player: CharacterBody3D, game) -> void:
    for point in [Vector2i(-6, -4), Vector2i(6, 6)]:
        var enemy := CharacterBody3D.new()
        enemy.set_script(SentinelScript)
        enemy.set("player", player)
        enemy.set("game", game)
        var y := height_at(point.x, point.y)
        enemy.position = Vector3(point.x, float(y) + 1.3, point.y)
        add_child(enemy)
