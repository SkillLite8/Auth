extends CharacterBody2D

const GRAVITY := 900.0
const MAX_SPEED := 165.0
const SPRINT_SPEED := 235.0
const ACCELERATION := 900.0
const FRICTION := 1150.0
const WorldGeneratorScript = preload("res://scripts/world/world_generator.gd")
var world
var inventory: InventoryModel
var main_ref
var selected_slot: int = 0
var health: float = 100.0
var max_health: float = 100.0
var stamina: float = 100.0
var max_stamina: float = 100.0
var mining_target: Vector2i = Vector2i(-999,-999)
var mining_message_lock: float = 0.0
var invulnerability: float = 0.0
var attack_cooldown: float = 0.0
var was_jump_down: bool = false
var was_heal_down: bool = false
var damage_flash: float = 0.0
var is_dead: bool = false
@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
    add_to_group("player")
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func _physics_process(delta: float) -> void:
    if is_dead:
        return
    invulnerability = maxf(0.0, invulnerability-delta)
    attack_cooldown = maxf(0.0, attack_cooldown-delta)
    mining_message_lock = maxf(0.0, mining_message_lock-delta)
    damage_flash = maxf(0.0, damage_flash-delta)
    if damage_flash > 0.0:
        sprite.modulate = Color(1.0,0.55,0.55)
    elif invulnerability > 0.0 and int(Time.get_ticks_msec()/80)%2==0:
        sprite.modulate = Color(0.65,0.85,1.0)
    else:
        sprite.modulate = Color.WHITE
    if _game_input_blocked():
        velocity.x = move_toward(velocity.x, 0.0, FRICTION*delta)
        if not is_on_floor():
            velocity.y = minf(velocity.y + GRAVITY*delta, 720.0)
        move_and_slide()
        _keep_inside_world()
        return
    var direction := 0.0
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): direction -= 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): direction += 1.0
    var sprinting := Input.is_key_pressed(KEY_SHIFT) and stamina > 0.5 and absf(direction) > 0.1
    var target_speed := SPRINT_SPEED if sprinting else MAX_SPEED
    if direction != 0.0:
        velocity.x = move_toward(velocity.x, direction*target_speed, ACCELERATION*delta)
        sprite.flip_h = direction < 0.0
    else:
        velocity.x = move_toward(velocity.x, 0.0, FRICTION*delta)
    var jump_down := Input.is_key_pressed(KEY_SPACE) or Input.is_key_pressed(KEY_UP)
    if jump_down and not was_jump_down and is_on_floor():
        velocity.y = -340.0
        AudioManager.play("ui")
    was_jump_down = jump_down
    if sprinting:
        stamina = maxf(0.0, stamina - 28.0*delta)
    else:
        stamina = minf(max_stamina, stamina + 17.0*delta)
    if not is_on_floor():
        velocity.y = minf(velocity.y + GRAVITY*delta, 720.0)
    var heal_down := Input.is_key_pressed(KEY_H)
    if heal_down and not was_heal_down:
        use_healing_item()
    was_heal_down = heal_down
    _handle_primary_action(delta)
    _handle_secondary_action()
    move_and_slide()
    _keep_inside_world()

func _keep_inside_world() -> void:
    if world == null or not is_instance_valid(world):
        return
    var min_x := 5.0
    var max_x := float(WorldGeneratorScript.WORLD_WIDTH * WorldGeneratorScript.TILE_SIZE) - 5.0
    if global_position.x < min_x:
        global_position.x = min_x
        velocity.x = maxf(velocity.x, 0.0)
    elif global_position.x > max_x:
        global_position.x = max_x
        velocity.x = minf(velocity.x, 0.0)

func _game_input_blocked() -> bool:
    if main_ref == null or not is_instance_valid(main_ref):
        return false
    if main_ref.get("hud") != null and is_instance_valid(main_ref.hud):
        return main_ref.hud.is_modal_open()
    return false

func _handle_primary_action(delta: float) -> void:
    if not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) or _game_input_blocked():
        mining_target = Vector2i(-999,-999)
        return
    if world == null or inventory == null:
        return
    var mouse_world := get_global_mouse_position()
    var enemy := _enemy_under_mouse(mouse_world)
    if enemy != null:
        mining_target = Vector2i(-999,-999)
        if attack_cooldown <= 0.0 and global_position.distance_to(enemy.global_position) < 70.0 and world.has_line_of_sight(global_position, enemy.global_position):
            var item_id := inventory.get_item_id(selected_slot)
            var item: Dictionary = ItemDB.get_item(item_id)
            var damage := float(item.get("damage", 8.0 if str(item.get("category", "")) == "tool" else 5.0))
            enemy.take_damage(damage, self)
            attack_cooldown = 0.36
        return
    var cell: Vector2i = world.world_to_cell(mouse_world)
    var center := Vector2((cell.x+0.5)*16.0,(cell.y+0.5)*16.0)
    if center.distance_to(global_position) > 84.0 or world.get_tile(cell) == 0:
        mining_target = Vector2i(-999,-999)
        return
    var item_id := inventory.get_item_id(selected_slot)
    var item: Dictionary = ItemDB.get_item(item_id)
    if not item.has("mining_power"):
        if mining_message_lock <= 0.0:
            _notify("Выбери кирку на панели быстрого доступа.")
            mining_message_lock = 1.2
        return
    var tool_tier := int(item.get("tool_tier",0))
    var result: Dictionary = world.damage_block(cell, float(item.get("mining_power",1.0))*delta, tool_tier)
    if result.get("status", "") == "too_hard" and mining_message_lock <= 0.0:
        _notify("Эта порода слишком твёрдая. Нужна кирка получше.")
        mining_message_lock = 1.5

func _handle_secondary_action() -> void:
    if not Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        set_meta("right_click_latched", false)
        return
    if _game_input_blocked():
        return
    if not get_meta("right_click_latched", false):
        set_meta("right_click_latched", true)
        place_selected_item()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and not event.pressed:
        set_meta("right_click_latched", false)
    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_1: selected_slot = 0
            KEY_2: selected_slot = 1
            KEY_3: selected_slot = 2
            KEY_4: selected_slot = 3
            KEY_5: selected_slot = 4
            KEY_6: selected_slot = 5
            KEY_7: selected_slot = 6
            KEY_8: selected_slot = 7
            _: return
        if main_ref != null and is_instance_valid(main_ref.hud):
            main_ref.hud.refresh()

func _enemy_under_mouse(mouse_world: Vector2):
    for candidate in get_tree().get_nodes_in_group("enemies"):
        if is_instance_valid(candidate) and candidate.global_position.distance_to(mouse_world) < 18.0:
            return candidate
    return null

func place_selected_item() -> void:
    if world == null or inventory == null:
        return
    var item_id := inventory.get_item_id(selected_slot)
    var item: Dictionary = ItemDB.get_item(item_id)
    if not item.has("place_tile"):
        return
    var cell: Vector2i = world.world_to_cell(get_global_mouse_position())
    if world.place_tile(cell, int(item["place_tile"]), global_position):
        inventory.remove_item(item_id,1)
        AudioManager.play("ui")
    else:
        _notify("Здесь нельзя разместить предмет.")

func collect_pickup(item_id: String, amount: int) -> int:
    if inventory == null:
        return amount
    var remaining := inventory.add_item(item_id,amount)
    if remaining > 0:
        _notify("Инвентарь заполнен — часть добычи осталась на земле.")
    return remaining

func use_healing_item() -> void:
    if inventory == null or health >= max_health:
        return
    if inventory.remove_item("healing_salve",1):
        health = minf(max_health, health + 35.0)
        AudioManager.play("pickup")
        _notify("Здоровье восстановлено.")

func take_damage(amount: float, knockback_direction: float) -> void:
    if invulnerability > 0.0 or is_dead:
        return
    health = maxf(0.0, health-amount)
    invulnerability = 0.8
    damage_flash = 0.14
    velocity.x = knockback_direction * 145.0
    velocity.y = -175.0
    AudioManager.play("hit")
    _notify("Получен урон: %.0f" % amount)
    if main_ref != null and is_instance_valid(main_ref.hud):
        main_ref.hud.refresh()
    if health <= 0.0:
        is_dead = true
        _notify("Ты потерял сознание. Нажми Esc, чтобы вернуться в убежище.")
        if main_ref != null:
            main_ref.player_died()

func _notify(message: String) -> void:
    if main_ref != null and is_instance_valid(main_ref.hud):
        main_ref.hud.notify(message)
