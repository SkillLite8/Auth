extends Node2D

const WorldGeneratorScript = preload("res://scripts/world/world_generator.gd")
const InventoryModelScript = preload("res://scripts/systems/inventory_model.gd")
const PlayerScene: PackedScene = preload("res://scenes/player.tscn")
const EnemyScene: PackedScene = preload("res://scenes/enemy.tscn")
const MenuScene: PackedScene = preload("res://scenes/main_menu.tscn")
const HUDScene: PackedScene = preload("res://scenes/hud.tscn")

var world
var player
var enemy
var hud
var inventory: InventoryModel
var current_seed: int = 0
var autosave_clock: float = 0.0
var title_menu
var ambient_modulate: CanvasModulate
var saved_data: Dictionary = {}

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_PAUSABLE
    show_title_menu()

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_game()
        get_tree().quit()

func show_title_menu() -> void:
    if is_instance_valid(title_menu):
        title_menu.queue_free()
    title_menu = MenuScene.instantiate()
    add_child(title_menu)
    title_menu.start_requested.connect(_on_start_requested)

func _on_start_requested(continue_save: bool) -> void:
    if is_instance_valid(title_menu):
        title_menu.queue_free()
    title_menu = null
    saved_data = SaveManager.load_game() if continue_save else {}
    _start_game(saved_data)

func _start_game(data: Dictionary) -> void:
    get_tree().paused = false
    _clear_expedition()
    current_seed = int(data.get("world_seed", 0))
    if current_seed == 0:
        var random := RandomNumberGenerator.new()
        random.randomize()
        current_seed = random.randi_range(100000,999999999)
    inventory = InventoryModelScript.new()
    if data.has("inventory") and data["inventory"] is Dictionary:
        inventory.from_dict(data["inventory"])
    else:
        inventory.add_item("rusty_pickaxe",1)
        inventory.add_item("stone",10)
        inventory.add_item("wood",8)
        inventory.add_item("torch",3)
        inventory.add_item("healing_salve",2)
    world = WorldGeneratorScript.new()
    world.name = "ProceduralWorld"
    add_child(world)
    var raw_modifications = data.get("world_modifications", {})
    var world_modifications: Dictionary = raw_modifications if raw_modifications is Dictionary else {}
    world.generate(current_seed, world_modifications)
    ambient_modulate = CanvasModulate.new()
    ambient_modulate.name = "CaveAmbientDarkness"
    ambient_modulate.color = Color(0.26,0.33,0.43,1.0)
    add_child(ambient_modulate)
    # Keep the initial surface legible while cave light fades quickly below.
    player = PlayerScene.instantiate()
    player.name = "Explorer"
    player.world = world
    player.inventory = inventory
    player.main_ref = self
    add_child(player)
    var spawn_x := (WorldGeneratorScript.START_X-7)*WorldGeneratorScript.TILE_SIZE + 8
    var spawn_y := WorldGeneratorScript.BASE_SURFACE*WorldGeneratorScript.TILE_SIZE - 10
    player.global_position = Vector2(spawn_x,spawn_y)
    if data.has("player_position") and data["player_position"] is Array and data["player_position"].size() == 2:
        var saved_pos: Array = data["player_position"]
        var max_x := float(WorldGeneratorScript.WORLD_WIDTH * WorldGeneratorScript.TILE_SIZE) - 5.0
        var max_y := float(WorldGeneratorScript.WORLD_HEIGHT * WorldGeneratorScript.TILE_SIZE) - 16.0
        player.global_position = Vector2(
            clampf(float(saved_pos[0]), 5.0, max_x),
            clampf(float(saved_pos[1]), 0.0, max_y)
        )
    player.health = clampf(float(data.get("health",100.0)),1.0,100.0)
    player.stamina = clampf(float(data.get("stamina",100.0)),0.0,100.0)
    enemy = EnemyScene.instantiate()
    enemy.name = "CaveCreature"
    enemy.player = player
    enemy.world = world
    enemy.global_position = Vector2((WorldGeneratorScript.START_X+7)*16.0,(WorldGeneratorScript.BASE_SURFACE+41)*16.0-7.0)
    add_child(enemy)
    if data.has("enemy_health"):
        enemy.health = clampf(float(data.get("enemy_health",28.0)),0.0,28.0)
        if enemy.health <= 0.0:
            enemy.queue_free()
    hud = HUDScene.instantiate()
    add_child(hud)
    hud.setup(self,player,world,inventory)
    autosave_clock = 0.0
    hud.notify("Экспедиция началась. Шахта находится восточнее убежища.")

func _process(delta: float) -> void:
    if world == null or not is_instance_valid(world) or get_tree().paused:
        return
    autosave_clock += delta
    if autosave_clock >= 120.0:
        autosave_clock = 0.0
        save_game()

func save_game() -> bool:
    if world == null or not is_instance_valid(world) or player == null or not is_instance_valid(player) or inventory == null:
        return false
    var data := {
        "world_seed": current_seed,
        "player_position": [player.global_position.x,player.global_position.y],
        "health": player.health,
        "stamina": player.stamina,
        "inventory": inventory.to_dict(),
        "world_modifications": world.export_modifications(),
        "enemy_health": enemy.health if is_instance_valid(enemy) else 0.0
    }
    return SaveManager.save_game(data)

func player_died() -> void:
    if is_instance_valid(hud):
        hud.notify("Экспедиция прервана. В меню можно загрузить последнее сохранение.")
        hud._pause()

func _clear_expedition() -> void:
    for node in [hud, player, enemy, world, ambient_modulate]:
        if is_instance_valid(node):
            node.queue_free()
    hud = null
    player = null
    enemy = null
    world = null
    ambient_modulate = null
    inventory = null

func return_to_title() -> void:
    save_game()
    get_tree().paused = false
    _clear_expedition()
    show_title_menu()
