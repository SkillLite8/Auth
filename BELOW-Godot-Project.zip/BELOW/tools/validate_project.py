#!/usr/bin/env python3
"""Static integrity checks for the BELOW Godot project (does not replace a Godot runtime test)."""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

for rel in ("project.godot", "scenes/main.tscn", "scripts/main.gd", ".github/workflows/build-windows.yml", "export_presets.cfg"):
    if not (ROOT / rel).is_file():
        errors.append(f"Missing required file: {rel}")

for json_rel in ("data/items.json", "data/recipes.json"):
    try:
        with (ROOT / json_rel).open(encoding="utf-8") as f:
            json.load(f)
    except Exception as exc:
        errors.append(f"Invalid JSON {json_rel}: {exc}")

# Every explicit res:// reference in scene and script files must resolve.
for path in list(ROOT.rglob("*.tscn")) + list(ROOT.rglob("*.gd")) + [ROOT / "project.godot"]:
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8")
    for value in re.findall(r'res://([^"\']+)', text):
        target = ROOT / value
        if not target.exists():
            errors.append(f"Broken resource reference in {path.relative_to(ROOT)}: res://{value}")

try:
    items = json.loads((ROOT / "data/items.json").read_text(encoding="utf-8"))
    recipes = json.loads((ROOT / "data/recipes.json").read_text(encoding="utf-8"))
    for recipe_id, recipe in recipes.items():
        for item_id in recipe.get("ingredients", {}):
            if item_id not in items:
                errors.append(f"Recipe {recipe_id} refers to unknown ingredient {item_id}")
        result_id = recipe.get("result", {}).get("id")
        if result_id not in items:
            errors.append(f"Recipe {recipe_id} refers to unknown result {result_id}")
    for item_id, item in items.items():
        if int(item.get("max_stack", 0)) < 1:
            errors.append(f"Item {item_id} has invalid max_stack")
except Exception as exc:
    errors.append(f"Data validation error: {exc}")

if errors:
    print("BELOW static validation FAILED:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print("BELOW static validation passed: required files, resource paths, item data and recipes are consistent.")
print("Note: open/run the project in Godot 4.7.2 for parser and runtime validation.")
