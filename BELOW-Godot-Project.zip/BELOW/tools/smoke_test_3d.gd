extends SceneTree

const MainScene: PackedScene = preload("res://scenes/main_3d.tscn")

func _initialize() -> void:
    call_deferred("_run_test")

func _fail(message: String) -> void:
    push_error("BELOW 3D smoke test failed: " + message)
    quit(1)

func _run_test() -> void:
    var main = MainScene.instantiate()
    root.add_child(main)
    await process_frame
    if not is_instance_valid(main.title_layer):
        _fail("main menu did not initialize")
        return

    main._start_game(false)
    for _frame in range(12):
        await process_frame
    if not main.game_started or main.world == null or main.player == null or main.hud == null:
        _fail("world, player, or HUD did not initialize")
        return
    if main.world.chunk_cache.size() < 10:
        _fail("chunk streaming did not load the nearby terrain")
        return
    var surface_test: int = main.world.height_at(1234, -5678)
    if surface_test < 60 or surface_test > 192:
        _fail("surface height is outside the expected natural range")
        return
    if int(main.world.MAX_Y) - int(main.world.MIN_Y) != 384:
        _fail("world vertical range is not 384 block levels")
        return
    if main.world.get_block_kind(Vector3i(0, main.world.MIN_Y, 0)) != "bedrock":
        _fail("bedrock layer at Y=-64 is missing")
        return
    if main.world.get_block_kind(Vector3i(0, main.world.MAX_Y, 0)) != "air":
        _fail("the exclusive upper world boundary at Y=320 is not respected")
        return
    for ore_kind in ["coal_ore", "iron_ore", "copper_ore", "hematite_ore", "cassiterite_ore", "pentlandite_ore", "garnierite_ore", "sphalerite_ore", "gold_ore", "lapis_ore", "redstone_ore", "diamond_ore", "titan_ore", "uranium_ore"]:
        if not main.world.is_ore(ore_kind):
            _fail("ore catalog is missing " + ore_kind)
            return
    if main.player.groups_ids["inv"].size() != 36 or main.player.get_slot_id("inv", 0) != "pickaxe":
        _fail("36-slot Minecraft-style inventory with hotbar is missing")
        return
    if main.world.story_objects.size() != 4:
        _fail("three Echo Shards and the Station Zero beacon were not created")
        return

    var test_cell := Vector3i(4, main.world.height_at(4, 4), 4)
    if main.world.get_block_kind(test_cell) == "air":
        _fail("expected surface block does not exist")
        return
    var mine_result: Dictionary = main.world.mine_cell(test_cell)
    if not mine_result.get("ok", false) or main.world.get_block_kind(test_cell) != "air":
        _fail("block mining failed")
        return
    if not main.world.place_block(test_cell, "stone") or main.world.get_block_kind(test_cell) != "stone":
        _fail("block placement failed")
        return

    var shard: Dictionary = {}
    for item in main.world.story_objects:
        if str(item.get("kind", "")) == "shard":
            shard = item
            break
    if shard.is_empty():
        _fail("no shard available for interaction test")
        return
    main.player.global_position = shard["node"].global_position
    main.interact()
    await process_frame
    if main.shards_found != 1:
        _fail("Echo Shard interaction did not advance the quest")
        return

    if not main.save_game(false):
        _fail("save file could not be written")
        return
    var loaded: Dictionary = main._read_save()
    if int(loaded.get("shards_found", 0)) != 1:
        _fail("quest progress did not survive a save round-trip")
        return

    main.return_to_title()
    await process_frame
    if main.game_started or main.world != null or main.player != null:
        _fail("return to menu did not clean up the expedition")
        return

    print("BELOW 3D smoke test passed: startup, streamed chunks, world height, bedrock, hotbar, mining, placing, story interaction, saving and cleanup.")
    quit(0)
