extends SceneTree

const MainScene: PackedScene = preload("res://scenes/main.tscn")

func _initialize() -> void:
    call_deferred("_run_test")

func _run_test() -> void:
    if ItemDB.get_item_name("stone") != "Камень":
        push_error("Smoke test failed: ItemDB display-name API did not initialize correctly.")
        quit(1)
        return

    var main = MainScene.instantiate()
    root.add_child(main)
    await process_frame
    if is_instance_valid(main.title_menu):
        main.title_menu.queue_free()
        main.title_menu = null
    main._start_game({})
    await process_frame
    await process_frame
    if main.world == null or main.player == null or main.hud == null:
        push_error("Smoke test failed: world/player/HUD did not initialize.")
        quit(1)
        return
    if main.inventory.count_item("stone") != 10:
        push_error("Smoke test failed: starter inventory was not created correctly.")
        quit(1)
        return

    main.player.global_position.x = -100.0
    main.player._keep_inside_world()
    if main.player.global_position.x < 5.0:
        push_error("Smoke test failed: player was not kept inside the world bounds.")
        quit(1)
        return
    main.player.global_position.x = 99999.0
    main.player._keep_inside_world()
    if main.player.global_position.x > 180.0 * 16.0 - 5.0:
        push_error("Smoke test failed: player exceeded the right world boundary.")
        quit(1)
        return
    var craft_result: Dictionary = main.hud.crafting.craft("stone_pickaxe")
    if not craft_result.get("ok", false):
        push_error("Smoke test failed: stone pickaxe recipe did not craft: %s" % craft_result.get("message", "unknown"))
        quit(1)
        return
    if main.inventory.count_item("stone") != 4 or main.inventory.count_item("stone_pickaxe") != 1:
        push_error("Smoke test failed: crafting did not consume and produce exact quantities.")
        quit(1)
        return
    var mining_cell := Vector2i(94, 16)
    if main.world.get_tile(mining_cell) == 0:
        push_error("Smoke test failed: guaranteed starter wall cell is not solid.")
        quit(1)
        return
    var mining_result: Dictionary = main.world.damage_block(mining_cell, 10.0, 2)
    if mining_result.get("status", "") != "broken" or main.world.get_tile(mining_cell) != 0:
        push_error("Smoke test failed: terrain block did not break.")
        quit(1)
        return
    if not main.save_game():
        push_error("Smoke test failed: saving game returned false.")
        quit(1)
        return
    var loaded: Dictionary = SaveManager.load_game()
    if int(loaded.get("world_seed", 0)) != main.current_seed:
        push_error("Smoke test failed: saved seed did not round-trip.")
        quit(1)
        return
    var stored_modifications: Dictionary = loaded.get("world_modifications", {})
    if int(stored_modifications.get("94,16", -1)) != 0:
        push_error("Smoke test failed: mined terrain was not saved.")
        quit(1)
        return

    main.return_to_title()
    await process_frame
    if main.world != null or main.player != null or main.ambient_modulate != null:
        push_error("Smoke test failed: expedition nodes were not cleaned up on return to title.")
        quit(1)
        return

    print("BELOW smoke test passed: startup, ItemDB, bounds, inventory, crafting, mining, saving and cleanup.")
    quit(0)
