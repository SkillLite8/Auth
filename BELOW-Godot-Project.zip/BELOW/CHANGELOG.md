# BELOW — changelog

## 0.2.0 — 3D expedition chapter
- Switched the default project startup to a block-based first-person 3D world.
- Added working WASD/mouse movement, jumping, sprint stamina, mining, block placement, a nine-slot hotbar, hearts, backpack and healing.
- Added the Station Zero story objective, three Echo Shards, a beacon, and two chasing Echo Guardians.
- Added manual/autosave and continue support for player, inventory, terrain changes and quest progress.
- Added a separate headless smoke test for the 3D game and updated README/CI workflow.

## 0.1.1 — stability fixes
- Fixed ItemDB display-name API to avoid overriding Godot's native `Node.get_name()` method.
- Fixed Escape after player death so it returns to the title instead of resuming a dead character.
- Cleans up cave lighting between expeditions and safely bounds restored player/world data.
- Refreshes viewport-culled world drawing while the camera moves, prevents walking off the world edges, and avoids map redraws while hidden.
- Continue is disabled for missing or invalid save files; Windows CI installs export templates and runs gameplay smoke tests before exporting.

## 0.1.0 — 2D legacy prototype
- Original 2D procedural mine, drops, crafting, inventory, enemy, HUD, map and saves.
