# BELOW — changelog

## 0.1.0 — Vertical slice
- Стартовый игровой цикл, процедурная шахта, добыча, лут и инвентарь.
- Крафт, установка блоков/факелов, существо с AI, HUD, карта.
- JSON-сохранения с seed и изменёнными клетками.
- Windows export preset и GitHub Actions workflow.
