# BELOW — changelog

## 0.3.0 — streamed procedural voxel world
- Replaced the small bounded landscape with a deterministic 16×16 chunk world streamed around the player; distant chunks unload and player edits persist.
- Added a 384-level vertical range (Y=-64 to Y=319, upper bound Y=320), bedrock, sea level Y=63, variable terrain, shorelines, water, trees and leaves.
- Added height-biased ore generation for coal, iron, copper, hematite/magnetite, cassiterite, pentlandite, garnierite, sphalerite, gold, lapis, redstone, diamond, titanium and uranium.
- Added per-chunk combined meshes/colliders, on-demand cave wall geometry, block-face textures from the provided reference, and updated world-boundary/ore smoke assertions.

## 0.2.0 — 3D expedition chapter
- Switched the default project startup to a block-based first-person 3D world.
- Added working WASD/mouse movement, jumping, sprint stamina, mining, block placement, a nine-slot hotbar, hearts, backpack and healing.
- Added the Station Zero story objective, three Echo Shards, a beacon, and two chasing Echo Guardians.
- Added manual/autosave and continue support for player, inventory, terrain changes and quest progress.
- Added a separate headless smoke test for the 3D game and updated README/CI workflow.

## 0.1.1 — stability fixes
- Fixed ItemDB display-name API to avoid overriding Godot's native `Node.get_name()` method.
- Fixed Escape after player death so it returns to the title instead of resuming a dead character.
- Cleans up cave lighting between expeditions and safely bounds restored player/world data.
- Refreshes viewport-culled world drawing while the camera moves, prevents walking off the world edges, and avoids map redraws while hidden.
- Continue is disabled for missing or invalid save files; Windows CI installs export templates and runs gameplay smoke tests before exporting.

## 0.1.0 — 2D legacy prototype
- Original 2D procedural mine, drops, crafting, inventory, enemy, HUD, map and saves.
