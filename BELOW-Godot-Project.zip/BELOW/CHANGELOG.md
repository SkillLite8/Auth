# BELOW — changelog

## 0.1.0 — Vertical slice
- Стартовый игровой цикл, процедурная шахта, добыча, лут и инвентарь.
- Крафт, установка блоков/факелов, существо с AI, HUD, карта.
- JSON-сохранения с seed и изменёнными клетками.
- Windows export preset и GitHub Actions workflow.


## 0.1.1 — stability fixes
- Fixed ItemDB display-name API to avoid overriding Godot's native `Node.get_name()` method.
- Fixed Escape after player death so it returns to the title instead of resuming a dead character.
- Cleans up cave lighting between expeditions and safely bounds restored player/world data.
- Refreshes viewport-culled world drawing while the camera moves, prevents walking off the world edges, and avoids map redraws while hidden.
- Continue is disabled for missing or invalid save files; Windows CI installs export templates and runs the gameplay smoke test before exporting.
