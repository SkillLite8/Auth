import json
import threading

from endstone.form import ActionForm, ModalForm, TextInput


class FormManager:

    def __init__(self, plugin, cfg, data, session, security, log_mgr):
        self._plugin = plugin
        self._cfg = cfg
        self._data = data
        self._session = session
        self._security = security
        self._log = log_mgr

    def _ip(self, player) -> str:
        try:
            return str(player.address.hostname)
        except Exception:
            return "unknown"

    def _device_id(self, player) -> str:
        try:
            return str(player.device_id)
        except Exception:
            try:
                return str(player.unique_id)
            except Exception:
                return player.name

    def _play_sound(self, player, key: str):
        sound = self._cfg.get(f"sounds.{key}", "")
        if not sound:
            return
        try:
            player.play_sound(player.location, sound, 1.0, 1.0)
        except Exception:
            pass

    def _get(self, response, index: int) -> str:
        try:
            if isinstance(response, str):
                response = json.loads(response)
            val = response[index]
            if val is None:
                return ""
            s = str(val).strip()
            return "" if s == "None" else s
        except Exception:
            return ""

    def _reschedule(self, func, player, delay=10):
        self._plugin.server.scheduler.run_task(
            self._plugin, lambda: func(player), delay=delay
        )

    def show_auth_menu(self, player):
        self._play_sound(player, "form_open")
        form = ActionForm(
            title="§bZenAuth §7— Меню",
            content=f"§7Игрок: §f{player.name}",
        )
        form.add_button("§e✎ Сменить пароль", on_click=lambda p: self.show_changepass_form(p))
        form.add_button("§a★ Секретное слово", on_click=lambda p: self.show_secret_form(p))
        form.add_button("§7✔ Закрыть")
        player.send_form(form)

    def show_login_form(self, player):
        if not self._data.player_exists(player.name):
            self._open_register(player)
        else:
            self._open_login(player)

    def _open_login(self, player):
        self._session.pause_kick_timer(player.name)
        self._play_sound(player, "form_open")
        form = ModalForm(
            title=self._cfg.get_form("login", "title", "§bАвторизация"),
            on_submit=lambda p, r: self._on_login(p, r),
            on_close=lambda p: self._reschedule(self._open_login, p),
        )
        form.add_control(TextInput(
            label=self._cfg.get_form("login", "label", "§7Введите пароль:"),
            placeholder=self._cfg.get_form("login", "password_placeholder", "Пароль"),
        ))
        player.send_form(form)

    def _on_login(self, player, response):
        ip = self._ip(player)

        if self._security.get_bruteforce_ban(ip):
            player.kick(
                self._cfg.get_message("kick_banned").replace(
                    "{time}", self._security.get_bruteforce_remaining(ip)
                )
            )
            return

        password = self._get(response, 0)

        if self._data.has_null_password(player.name):
            player.send_message("§eВаш пароль сброшен. Зарегистрируйтесь заново.")
            self._open_register(player)
            return

        if self._data.check_password(player.name, password):
            self._security.reset_attempts(ip)
            self._session.mark_authenticated(player.name)
            self._session.cancel_kick_timer(player.name)
            self._session.save_session(player.name)
            self._data.update_ip(player.name, ip)
            self._plugin.remove_effects(player)
            self._play_sound(player, "login_success")
            player.send_message(
                self._cfg.get_message("login_success").replace("{player}", player.name)
            )
            self._log.log(player.name, ip, "login", "success")
            if not self._data.has_secret(player.name):
                player.send_message(self._cfg.get_message("secret_remind"))
        else:
            count = self._security.record_failed_attempt(ip)
            self._play_sound(player, "login_fail")
            self._log.log(player.name, ip, "failed_login", f"attempt_{count}")
            if self._security.is_bruteforce(ip):
                self._security.apply_bruteforce_ban(ip)
                mins = self._cfg.get("security.bruteforce_ban_minutes", 15)
                msg = self._cfg.get_message("bruteforce_ban").replace("{minutes}", str(mins))
                player.send_message(msg)
                player.kick(msg)
            else:
                remaining = self._security.get_remaining_attempts(ip)
                player.send_message(
                    self._cfg.get_message("login_fail").replace("{attempts}", str(remaining))
                )
                self._reschedule(self._open_login, player)

    def _open_register(self, player):
        device_id = self._device_id(player)
        max_acc = self._cfg.get("session.max_accounts_per_device", 3)

        if self._data.count_accounts_by_device(device_id) >= max_acc:
            player.send_message(self._cfg.get_message("too_many_accounts"))
            return

        if self._data.player_exists(player.name):
            player.send_message(self._cfg.get_message("account_exists"))
            self._open_login(player)
            return

        self._session.pause_kick_timer(player.name)
        self._play_sound(player, "form_open")
        form = ModalForm(
            title=self._cfg.get_form("register", "title", "§aРегистрация"),
            on_submit=lambda p, r: self._on_register(p, r),
            on_close=lambda p: self._reschedule(self._open_register, p),
        )
        form.add_control(TextInput(
            label=self._cfg.get_form("register", "password_label", "§7Пароль"),
            placeholder=self._cfg.get_form("register", "password_placeholder", "6-15 символов, a-z A-Z 0-9"),
        ))
        form.add_control(TextInput(
            label=self._cfg.get_form("register", "confirm_label", "§7Повторите пароль"),
            placeholder=self._cfg.get_form("register", "confirm_placeholder", "Повторите пароль"),
        ))
        form.add_control(TextInput(
            label="§7Секретное слово §8(необязательно, буквы рус/лат):",
            placeholder=self._cfg.get_form("register", "secret_placeholder", "Только буквы"),
        ))
        player.send_form(form)

    def show_register_form(self, player):
        self._open_register(player)

    def _on_register(self, player, response):
        ip = self._ip(player)
        device_id = self._device_id(player)

        password   = self._get(response, 0)
        confirm    = self._get(response, 1)
        secret_raw = self._get(response, 2)

        password_error = self._security.validate_password_reason(password)
        if password_error is not None:
            self._play_sound(player, "login_fail")
            player.send_message(password_error)
            self._reschedule(self._open_register, player)
            return

        if password != confirm:
            self._play_sound(player, "login_fail")
            player.send_message(self._cfg.get_message("passwords_not_match"))
            self._reschedule(self._open_register, player)
            return

        if self._data.player_exists(player.name):
            player.send_message(self._cfg.get_message("account_exists"))
            self._open_login(player)
            return

        if self._data.count_accounts_by_device(device_id) >= self._cfg.get("session.max_accounts_per_device", 3):
            player.send_message(self._cfg.get_message("too_many_accounts"))
            return

        secret_to_save = None
        if secret_raw:
            if not self._security.validate_secret_word(secret_raw):
                self._play_sound(player, "login_fail")
                player.send_message(self._cfg.get_message("secret_invalid"))
                self._reschedule(self._open_register, player)
                return
            secret_to_save = secret_raw

        self._data.register_player(player.name, password, ip, device_id, secret_to_save)
        self._session.mark_authenticated(player.name)
        self._session.cancel_kick_timer(player.name)
        self._session.save_session(player.name)
        self._plugin.remove_effects(player)
        self._play_sound(player, "login_success")
        player.send_message(
            self._cfg.get_message("register_success").replace("{player}", player.name)
        )
        self._log.log(player.name, ip, "register", "success")
        if not secret_to_save:
            player.send_message(self._cfg.get_message("secret_remind"))

    def show_changepass_form(self, player):
        self._play_sound(player, "form_open")
        form = ModalForm(
            title=self._cfg.get_form("changepass", "title", "§eСмена пароля"),
            on_submit=lambda p, r: self._on_changepass(p, r),
        )
        form.add_control(TextInput(
            label="§7Старый пароль или секретное слово",
            placeholder="Старый пароль или секретное слово",
        ))
        form.add_control(TextInput(
            label="§7Новый пароль",
            placeholder="Новый пароль",
        ))
        form.add_control(TextInput(
            label="§7Подтвердите новый пароль",
            placeholder="Подтвердите новый пароль",
        ))
        player.send_form(form)

    def _on_changepass(self, player, response):
        ip = self._ip(player)
        old_or_secret = self._get(response, 0)
        new_pass      = self._get(response, 1)
        confirm       = self._get(response, 2)

        password_error = self._security.validate_password_reason(new_pass)
        if password_error is not None:
            player.send_message(password_error)
            return
        if new_pass != confirm:
            player.send_message(self._cfg.get_message("passwords_not_match"))
            return
        valid = (
            self._data.check_password(player.name, old_or_secret) or
            self._data.check_secret(player.name, old_or_secret)
        )
        if not valid:
            player.send_message(self._cfg.get_message("old_password_wrong"))
            return
        self._data.change_password(player.name, new_pass)
        self._session.save_session(player.name)
        player.send_message(self._cfg.get_message("password_changed"))
        self._log.log(player.name, ip, "changepass", "success")

    def show_secret_form(self, player):
        if self._data.has_secret(player.name):
            self._play_sound(player, "login_fail")
            player.send_message(self._cfg.get_message("secret_already_set"))
            return
        self._play_sound(player, "form_open")
        form = ModalForm(
            title=self._cfg.get_form("secret", "title", "§eСекретное слово"),
            on_submit=lambda p, r: self._on_secret(p, r),
        )
        form.add_control(TextInput(
            label="§7Секретное слово (только буквы рус/лат)",
            placeholder="Только буквы",
        ))
        player.send_form(form)

    def _on_secret(self, player, response):
        ip = self._ip(player)
        secret = self._get(response, 0)
        if not self._security.validate_secret_word(secret):
            self._play_sound(player, "login_fail")
            player.send_message(self._cfg.get_message("secret_invalid"))
            return
        self._data.set_secret(player.name, secret)
        self._play_sound(player, "login_success")
        player.send_message(self._cfg.get_message("secret_set"))
        self._log.log(player.name, ip, "set_secret", "success")

    def show_change_secret_form(self, player):
        self._play_sound(player, "form_open")
        form = ModalForm(
            title="§eСмена секретного слова",
            on_submit=lambda p, r: self._on_change_secret(p, r),
        )
        form.add_control(TextInput(
            label="§7Старое секретное слово",
            placeholder="Текущее секретное слово",
        ))
        form.add_control(TextInput(
            label="§7Новое секретное слово (только буквы рус/лат)",
            placeholder="Только буквы",
        ))
        player.send_form(form)

    def _on_change_secret(self, player, response):
        ip = self._ip(player)
        old_secret = self._get(response, 0)
        new_secret  = self._get(response, 1)

        if not self._data.check_secret(player.name, old_secret):
            self._play_sound(player, "login_fail")
            player.send_message(self._cfg.get_message("old_secret_wrong"))
            return
        if not self._security.validate_secret_word(new_secret):
            self._play_sound(player, "login_fail")
            player.send_message(self._cfg.get_message("secret_invalid"))
            return
        self._data.set_secret(player.name, new_secret)
        self._play_sound(player, "login_success")
        player.send_message(self._cfg.get_message("secret_changed"))
        self._log.log(player.name, ip, "change_secret", "success")

    def show_admin_panel(self, player):
        self._play_sound(player, "form_open")
        form = ActionForm(
            title=self._cfg.get_form("admin", "title", "§4ZenAdmin §cPanel"),
            content="§7Выберите действие:",
        )
        online_players = []
        try:
            online_players = list(self._plugin.server.online_players)
        except Exception:
            pass
        if online_players:
            form.add_button("§a▶ Онлайн игроки", on_click=lambda p: self._show_online_list(p))
        form.add_button("§7✎ Найти по нику", on_click=lambda p: self._show_search_form(p))
        player.send_form(form)

    def _show_online_list(self, player):
        try:
            online = list(self._plugin.server.online_players)
        except Exception:
            online = []
        if not online:
            player.send_message("§cОнлайн игроков нет.")
            self.show_admin_panel(player)
            return
        form = ActionForm(title="§a▶ Онлайн игроки", content="§7Выберите игрока:")
        for p in online:
            reg  = "§a✔" if self._data.player_exists(p.name) else "§c✘"
            auth = "§a[авт]" if self._session.is_authenticated(p.name) else "§c[нет]"
            form.add_button(
                f"§f{p.name} {reg} {auth}",
                on_click=lambda adm, t=p.name: self._show_player_actions(adm, t),
            )
        form.add_button("§7← Назад", on_click=lambda p: self.show_admin_panel(p))
        player.send_form(form)

    def _show_search_form(self, player):
        form = ModalForm(
            title="§7Поиск игрока",
            on_submit=lambda p, r: self._handle_search(p, r),
            on_close=lambda p: self.show_admin_panel(p),
        )
        form.add_control(TextInput(label="§7Ник игрока", placeholder="Ник игрока"))
        player.send_form(form)

    def _handle_search(self, player, response):
        target_name = self._get(response, 0)
        if not target_name:
            player.send_message(self._cfg.get_message("provide_nick"))
            return
        self._show_player_actions(player, target_name)

    def _show_player_actions(self, player, target_name: str):
        exists  = self._data.player_exists(target_name)
        status  = "§aЗарегистрирован" if exists else "§cНе найден"
        has_sec = "§aДа" if exists and self._data.has_secret(target_name) else "§cНет"
        is_auth = "§aОнлайн" if self._session.is_authenticated(target_name) else "§7Оффлайн"
        content = (
            f"§eИгрок: §f{target_name}\n"
            f"§7Статус: {status}\n"
            f"§7Секрет: {has_sec}\n"
            f"§7Сессия: {is_auth}"
        )
        form = ActionForm(title=f"§c{target_name}", content=content)
        form.add_button("§e⚙ Сбросить пароль",        on_click=lambda p: self._admin_reset(p, target_name))
        form.add_button("§e⚙ Удалить секретное слово", on_click=lambda p: self._admin_del_secret(p, target_name))
        form.add_button("§c✘ Wipe",                    on_click=lambda p: self._admin_wipe(p, target_name))
        form.add_button("§b✦ Логи",                    on_click=lambda p: self.show_logs_form(p, target_name))
        form.add_button("§7← Назад",                   on_click=lambda p: self.show_admin_panel(p))
        player.send_form(form)

    def _admin_reset(self, player, target_name: str):
        ip = self._ip(player)
        self._data.reset_password(target_name)
        self._session.invalidate_session(target_name)
        player.send_message(
            self._cfg.get_message("admin_reset_success").replace("{player}", target_name)
        )
        self._log.log(target_name, ip, "admin_reset", f"by_{player.name}")
        target = self._get_online(target_name)
        if target:
            self._session.remove_authenticated(target_name)
            self._plugin.apply_effects(target)
            target.send_message(self._cfg.get_message("admin_kick_reset"))
            threading.Timer(0.5, lambda: self._open_register(target)).start()

    def _admin_del_secret(self, player, target_name: str):
        ip = self._ip(player)
        self._data.delete_secret(target_name)
        player.send_message(
            self._cfg.get_message("admin_secret_deleted").replace("{player}", target_name)
        )
        self._log.log(target_name, ip, "admin_delete_secret", f"by_{player.name}")

    def _admin_wipe(self, player, target_name: str):
        ip = self._ip(player)
        self._data.wipe_player(target_name)
        self._session.remove_authenticated(target_name)
        self._session.invalidate_session(target_name)
        player.send_message(
            self._cfg.get_message("admin_wipe_success").replace("{player}", target_name)
        )
        self._log.log(target_name, ip, "admin_wipe", f"by_{player.name}")
        target = self._get_online(target_name)
        if target:
            target.kick(self._cfg.get_message("admin_kick_wipe"))

    def show_zenlogs_search_form(self, player):
        self._play_sound(player, "form_open")
        form = ModalForm(
            title="§bZenAuth §7— Логи игрока",
            on_submit=lambda p, r: self._on_zenlogs_search(p, r),
            on_close=lambda p: None,
        )
        form.add_control(TextInput(
            label="§7Ник игрока",
            placeholder="Введите ник...",
        ))
        player.send_form(form)

    def _on_zenlogs_search(self, player, response):
        target_name = self._get(response, 0)
        if not target_name:
            player.send_message(self._cfg.get_message("provide_nick"))
            return
        self.show_logs_form(player, target_name)

    def show_logs_form(self, player, target_name: str):
        logs = self._log.format_for_display(target_name)
        if not logs:
            player.send_message(
                self._cfg.get_message("logs_no_data").replace("{player}", target_name)
            )
            return
        content_lines = []
        total = 0
        for line in logs:
            clean = line
            for code in ["§a","§c","§7","§b","§e","§8","§f"]:
                clean = clean.replace(code, "")
            total += len(clean) + 1
            if total > 1500:
                content_lines.append("§8... (показаны последние записи)")
                break
            content_lines.append(line)
        form = ActionForm(
            title=f"§bЛоги: {target_name}",
            content="\n".join(content_lines),
        )
        form.add_button("§7✔ Закрыть")
        form.add_button("§7← Назад", on_click=lambda p: self._show_player_actions(p, target_name))
        player.send_form(form)

    def _get_online(self, name: str):
        try:
            return self._plugin.server.get_player(name)
        except Exception:
            return None
