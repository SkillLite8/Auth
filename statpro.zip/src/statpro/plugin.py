from __future__ import annotations
import os
import time

from endstone.plugin import Plugin
from endstone.event import event_handler
from endstone.event import (
    PlayerJoinEvent,
    PlayerQuitEvent,
    PlayerDeathEvent,
    PlayerChatEvent,
    BlockBreakEvent,
)
from endstone.command import Command, CommandSender
from endstone.form import ActionForm

from .stats_manager import StatsManager
from .scoreboard_mgr import ScoreboardManager
from .antifaud import AnomalyDetector
from .config_loader import load_config, load_messages


class StatPro(Plugin):
    name = "StatPro"
    version = "1.0.0"
    api_version = "0.5"
    description = "Статистика игроков с HUD-скорбордом и анти-фродом"
    authors = ["Server"]

    commands = {
        "statfull": {
            "description": "Полная статистика игрока",
            "usages": ["/statfull [player]"],
            "permissions": ["statpro.statfull"],
        },
        "statlog": {
            "description": "Панель администратора",
            "usages": ["/statlog"],
            "permissions": ["statpro.admin"],
        },
        "statreload": {
            "description": "Перезагрузить конфиг плагина",
            "usages": ["/statreload"],
            "permissions": ["statpro.admin"],
        },
    }

    permissions = {
        "statpro.statfull": {
            "description": "Просмотр полной статистики",
            "default": True,
        },
        "statpro.admin": {
            "description": "Доступ к админ-панели",
            "default": "op",
        },
    }

    def on_enable(self) -> None:
        self._data_dir = self.data_folder
        self._load_all_configs()
        self._stats = StatsManager(self._data_dir)
        self._sb_mgr = ScoreboardManager(self._stats, self._messages)
        self._detector = AnomalyDetector(self._cfg.get("antifaud", {}))
        self._pending_alerts: list[str] = []
        self.register_events(self)
        self._start_scheduler()
        self.logger.info("StatPro включён!")

    def on_disable(self) -> None:
        for player in self.server.online_players:
            self._stats.flush_session(player.name)
        self._stats.save_all()
        self.logger.info("StatPro выключен, данные сохранены.")

    def _load_all_configs(self) -> None:
        self._cfg = load_config(os.path.join(self._data_dir, "config.yml"))
        self._messages = load_messages(os.path.join(self._data_dir, "messages.yml"))

    def _msg(self, key: str, default: str = "", **kwargs) -> str:
        text = self._messages.get(key, default)
        for k, v in kwargs.items():
            text = text.replace(f"{{{k}}}", str(v))
        return text

    # ── Events ────────────────────────────────────────────────────────────────

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent) -> None:
        player = event.player
        name = player.name
        stats = self._stats.get(name)
        stats.login_count += 1
        stats.session_start = time.time()
        if player.is_op and self._pending_alerts:
            prefix = self._msg("alert_offline_prefix", "§c[StatPro] §7Пока вас не было:")
            for alert in self._pending_alerts:
                player.send_message(f"{prefix} {alert}")
            self._pending_alerts.clear()
        self.server.scheduler.run_task_later(
            self, lambda: self._sb_mgr.update_player(player), 40
        )

    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent) -> None:
        player = event.player
        self._stats.flush_session(player.name)
        self._sb_mgr.remove_player(player)

    @event_handler
    def on_player_death(self, event: PlayerDeathEvent) -> None:
        player = event.player
        stats = self._stats.get(player.name)
        stats.deaths += 1
        killer = getattr(event, "killer", None)
        if killer and hasattr(killer, "name"):
            k_name = killer.name
            k_stats = self._stats.get(k_name)
            k_stats.kills += 1
            reason = self._detector.check_killfarm(k_stats, player.name)
            if reason:
                self._dispatch_alert(k_name, reason)

    @event_handler
    def on_player_chat(self, event: PlayerChatEvent) -> None:
        self._stats.get(event.player.name).messages_sent += 1

    @event_handler
    def on_block_break(self, event: BlockBreakEvent) -> None:
        player = event.player
        stats = self._stats.get(player.name)
        stats.blocks_mined += 1
        block_type = str(event.block.type).lower()
        ore_map = {
            "diamond": "diamonds_mined",
            "gold": "gold_mined",
            "ancient_debris": "netherite_mined",
        }
        for keyword, attr in ore_map.items():
            if keyword in block_type:
                setattr(stats, attr, getattr(stats, attr) + 1)
                reason = self._detector.check_fast_mine(stats, block_type)
                if reason:
                    self._dispatch_alert(player.name, reason)
                break

    # ── Scheduler ─────────────────────────────────────────────────────────────

    def _start_scheduler(self) -> None:
        interval = self._cfg.get("update_interval", 40)

        def tick():
            for player in self.server.online_players:
                self._sb_mgr.update_player(player)

        self.server.scheduler.run_task_timer(self, tick, interval, interval)

    # ── Alert dispatcher ──────────────────────────────────────────────────────

    def _dispatch_alert(self, player_name: str, reason: str) -> None:
        msg = self._msg(
            "alert_online",
            "§c[StatPro] §fАномалия у §e{player}§f: {reason}",
            player=player_name,
            reason=reason,
        )
        ops_online = [p for p in self.server.online_players if p.is_op]
        if ops_online:
            for op in ops_online:
                op.send_message(msg)
                try:
                    op.play_sound(op.location, "note.bass", 1.0, 0.5)
                except Exception:
                    pass
        else:
            self._pending_alerts.append(f"§e{player_name}§f — {reason}")

    # ── Commands ──────────────────────────────────────────────────────────────

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        cmd = command.name.lower()
        if cmd == "statfull":
            self._cmd_statfull(sender, args)
        elif cmd == "statlog":
            self._cmd_statlog(sender)
        elif cmd == "statreload":
            self._cmd_reload(sender)
        return True

    def _cmd_statfull(self, sender: CommandSender, args: list[str]) -> None:
        target_name = args[0] if args else getattr(sender, "name", None)
        if not target_name:
            sender.send_message("§cУкажите имя игрока.")
            return
        stats = self._stats.get(target_name)
        total_time = stats.total_playtime
        if hasattr(sender, "name") and sender.name == target_name:
            total_time += stats.session_time

        def fmt(s: float) -> str:
            s = int(s)
            h, rem = divmod(s, 3600)
            m, sec = divmod(rem, 60)
            return f"{h}ч {m:02d}м {sec:02d}с"

        lines = [
            f"§6§l═══ Статистика: §e{target_name} §6§l═══",
            "",
            "§c⚔ §lБоевые:",
            f"  §7Убийства (игроки): §f{stats.kills}",
            f"  §7Убийства (мобы):   §f{stats.mob_kills}",
            f"  §7Смерти:            §f{stats.deaths}",
            f"  §7K/D:               §e{stats.kd_ratio}",
            f"  §7Урон нанесён:      §f{int(stats.damage_dealt)}",
            "",
            "§a🌍 §lМир:",
            f"  §7Блоков пешком:     §f{int(stats.blocks_walked)}",
            f"  §7Блоков вплавь:     §f{int(stats.blocks_swum)}",
            f"  §7Блоков в полёте:   §f{int(stats.blocks_flown)}",
            f"  §7Прыжков:           §f{stats.jumps}",
            f"  §7Еды съедено:       §f{stats.food_eaten}",
            "",
            "§b⛏ §lРесурсы:",
            f"  §7Всего добыто:      §f{stats.blocks_mined}",
            f"  §7Алмазов:           §b{stats.diamonds_mined}",
            f"  §7Золота:            §6{stats.gold_mined}",
            f"  §7Незерита:          §5{stats.netherite_mined}",
            "",
            "§e⏱ §lАктивность:",
            f"  §7Сообщений в чате:  §f{stats.messages_sent}",
            f"  §7Входов на сервер:  §f{stats.login_count}",
            f"  §7Всего на сервере:  §f{fmt(total_time)}",
            "",
            "§6§l══════════════════════",
        ]
        sender.send_message("\n".join(lines))
        try:
            sender.play_sound(sender.location, "note.harp", 1.0, 1.0)
        except Exception:
            pass

    def _cmd_statlog(self, sender: CommandSender) -> None:
        if not getattr(sender, "is_op", False):
            sender.send_message("§cНет доступа.")
            return
        online_names = [p.name for p in self.server.online_players]
        all_names = self._stats.all_names()
        if not all_names:
            sender.send_message("§7Нет зарегистрированных игроков.")
            return

        def fmt(s: float) -> str:
            s = int(s)
            h, rem = divmod(s, 3600)
            m, _ = divmod(rem, 60)
            return f"{h}ч {m:02d}м"

        def show_player(player_name: str) -> None:
            stats = self._stats.get(player_name)
            is_online = player_name in online_names
            status = "§aОнлайн" if is_online else "§7Оффлайн"
            total = stats.total_playtime + (stats.session_time if is_online else 0)
            msg = "\n".join([
                f"§6§l[StatLog] §f{player_name} {status}",
                f"  §7Убийства: §f{stats.kills} | §7Смерти: §f{stats.deaths} | §7K/D: §e{stats.kd_ratio}",
                f"  §7Добыто: §f{stats.blocks_mined} | §7Алмазов: §b{stats.diamonds_mined}",
                f"  §7Сообщений: §f{stats.messages_sent} | §7Входов: §f{stats.login_count}",
                f"  §7Время: §f{fmt(total)}",
            ])
            sender.send_message(msg)

        if hasattr(sender, "show_form"):
            form = ActionForm(title="§6StatLog — Выбор игрока", content="Выберите игрока:")
            sorted_names = sorted(all_names)
            for n in sorted_names:
                status = "§a●" if n in online_names else "§7○"
                form.add_button(f"{status} {n}")

            def on_response(player, response):
                if response is None:
                    return
                try:
                    show_player(sorted_names[int(response)])
                except (ValueError, IndexError):
                    pass

            sender.show_form(form, on_response)
        else:
            for n in sorted(all_names):
                show_player(n)

    def _cmd_reload(self, sender: CommandSender) -> None:
        if not getattr(sender, "is_op", False):
            sender.send_message("§cНет доступа.")
            return
        self._load_all_configs()
        self._sb_mgr = ScoreboardManager(self._stats, self._messages)
        self._detector = AnomalyDetector(self._cfg.get("antifaud", {}))
        sender.send_message("§aStatPro: конфиг перезагружен.")
