import os
import time

from endstone.plugin import Plugin
from endstone.event import event_handler
from endstone.event import (
    PlayerJoinEvent,
    PlayerQuitEvent,
    PlayerDeathEvent,
    PlayerChatEvent,
    BlockBreakEvent,
)
from endstone.command import Command, CommandSender
from endstone.form import ActionForm

from .stats_manager import StatsManager
from .scoreboard_mgr import ScoreboardManager
from .antifaud import AnomalyDetector
from .config_loader import load_config, load_messages


class StatPro(Plugin):
    name = "stat_pro"
    version = "1.0.0"
    api_version = "0.5"
    description = "Статистика игроков с HUD-скорбордом и анти-фродом"
    authors = ["Server"]

    commands = {
        "statfull": {
            "description": "Полная статистика игрока",
            "usages": ["/statfull [player]"],
            "permissions": ["stat_pro.statfull"],
        },
        "statlog": {
            "description": "Панель администратора",
            "usages": ["/statlog"],
            "permissions": ["stat_pro.admin"],
        },
        "statreload": {
            "description": "Перезагрузить конфиг плагина",
            "usages": ["/statreload"],
            "permissions": ["stat_pro.admin"],
        },
    }

    permissions = {
        "stat_pro.statfull": {
            "description": "Просмотр полной статистики",
            "default": True,
        },
        "stat_pro.admin": {
            "description": "Доступ к админ-панели",
            "default": "op",
        },
    }

    def on_enable(self):
        self._data_dir = self.data_folder
        self._load_all_configs()
        self._stats = StatsManager(self._data_dir)
        self._sb_mgr = ScoreboardManager(self._stats, self._messages, self.logger)
        self._detector = AnomalyDetector(self._cfg.get("antifaud", {}))
        self._pending_alerts = []
        self.register_events(self)
        self._start_scheduler()
        self.logger.info("StatPro включён!")

    def on_disable(self):
        for player in self.server.online_players:
            self._stats.flush_session(player.name)
        self._stats.save_all()
        self.logger.info("StatPro выключен.")

    def _load_all_configs(self):
        self._cfg = load_config(os.path.join(self._data_dir, "config.yml"))
        self._messages = load_messages(os.path.join(self._data_dir, "messages.yml"))

    def _msg(self, key, default="", **kwargs):
        text = self._messages.get(key, default)
        for k, v in kwargs.items():
            text = text.replace("{" + k + "}", str(v))
        return text

    # ── Events ────────────────────────────────────────────────────────────────

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent):
        player = event.player
        name = player.name
        stats = self._stats.get(name)
        stats.login_count += 1
        stats.session_start = time.time()
        if player.is_op and self._pending_alerts:
            prefix = self._msg("alert_offline_prefix", "§c[StatPro] §7Пока вас не было:")
            for alert in self._pending_alerts:
                player.send_message(prefix + " " + alert)
            self._pending_alerts.clear()
        self.server.scheduler.run_task(self, lambda: self._sb_mgr.update_player(player), 40)

    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent):
        player = event.player
        self._stats.flush_session(player.name)
        self._sb_mgr.remove_player(player)

    @event_handler
    def on_player_death(self, event: PlayerDeathEvent):
        player = event.player
        stats = self._stats.get(player.name)
        stats.deaths += 1
        killer = getattr(event, "killer", None)
        if killer and hasattr(killer, "name"):
            k_name = killer.name
            k_stats = self._stats.get(k_name)
            k_stats.kills += 1
            reason = self._detector.check_killfarm(k_stats, player.name)
            if reason:
                self._dispatch_alert(k_name, reason)

    @event_handler
    def on_player_chat(self, event: PlayerChatEvent):
        self._stats.get(event.player.name).messages_sent += 1

    @event_handler
    def on_block_break(self, event: BlockBreakEvent):
        player = event.player
        stats = self._stats.get(player.name)
        stats.blocks_mined += 1
        block_type = str(event.block.type).lower()
        ore_map = {
            "diamond": "diamonds_mined",
            "gold": "gold_mined",
            "ancient_debris": "netherite_mined",
        }
        for keyword, attr in ore_map.items():
            if keyword in block_type:
                setattr(stats, attr, getattr(stats, attr) + 1)
                reason = self._detector.check_fast_mine(stats, block_type)
                if reason:
                    self._dispatch_alert(player.name, reason)
                break

    # ── Scheduler ─────────────────────────────────────────────────────────────

    def _start_scheduler(self):
        interval = self._cfg.get("update_interval", 40)

        def tick():
            for player in self.server.online_players:
                self._sb_mgr.update_player(player)

        self.server.scheduler.run_task(self, tick, interval, interval)

    # ── Alert dispatcher ──────────────────────────────────────────────────────

    def _dispatch_alert(self, player_name, reason):
        msg = self._msg(
            "alert_online",
            "§c[StatPro] §fАномалия у §e{player}§f: {reason}",
            player=player_name,
            reason=reason,
        )
        ops_online = [p for p in self.server.online_players if p.is_op]
        if ops_online:
            for op in ops_online:
                op.send_message(msg)
                try:
                    op.play_sound(op.location, "note.bass", 1.0, 0.5)
                except Exception:
                    pass
        else:
            self._pending_alerts.append("§e" + player_name + "§f — " + reason)

    # ── Commands ──────────────────────────────────────────────────────────────

    def on_command(self, sender: CommandSender, command: Command, args: list):
        cmd = command.name.lower()
        if cmd == "statfull":
            self._cmd_statfull(sender, args)
        elif cmd == "statlog":
            self._cmd_statlog(sender)
        elif cmd == "statreload":
            self._cmd_reload(sender)
        return True

    def _cmd_statfull(self, sender, args):
        target_name = args[0] if args else getattr(sender, "name", None)
        if not target_name:
            sender.send_message("§cУкажите имя игрока.")
            return
        stats = self._stats.get(target_name)
        total_time = stats.total_playtime
        if hasattr(sender, "name") and sender.name == target_name:
            total_time += stats.session_time

        def fmt(s):
            s = int(s)
            h, rem = divmod(s, 3600)
            m, sec = divmod(rem, 60)
            return str(h) + "ч " + str(m).zfill(2) + "м " + str(sec).zfill(2) + "с"

        lines = [
            "§6§l═══ Статистика: §e" + target_name + " §6§l═══",
            "",
            "§c⚔ §lБоевые:",
            "  §7Убийства (игроки): §f" + str(stats.kills),
            "  §7Убийства (мобы):   §f" + str(stats.mob_kills),
            "  §7Смерти:            §f" + str(stats.deaths),
            "  §7K/D:               §e" + str(stats.kd_ratio),
            "  §7Урон нанесён:      §f" + str(int(stats.damage_dealt)),
            "",
            "§a🌍 §lМир:",
            "  §7Блоков пешком:     §f" + str(int(stats.blocks_walked)),
            "  §7Блоков вплавь:     §f" + str(int(stats.blocks_swum)),
            "  §7Блоков в полёте:   §f" + str(int(stats.blocks_flown)),
            "  §7Прыжков:           §f" + str(stats.jumps),
            "  §7Еды съедено:       §f" + str(stats.food_eaten),
            "",
            "§b⛏ §lРесурсы:",
            "  §7Всего добыто:      §f" + str(stats.blocks_mined),
            "  §7Алмазов:           §b" + str(stats.diamonds_mined),
            "  §7Золота:            §6" + str(stats.gold_mined),
            "  §7Незерита:          §5" + str(stats.netherite_mined),
            "",
            "§e⏱ §lАктивность:",
            "  §7Сообщений в чате:  §f" + str(stats.messages_sent),
            "  §7Входов на сервер:  §f" + str(stats.login_count),
            "  §7Всего на сервере:  §f" + fmt(total_time),
            "",
            "§6§l══════════════════════",
        ]
        sender.send_message("\n".join(lines))
        try:
            sender.play_sound(sender.location, "note.harp", 1.0, 1.0)
        except Exception:
            pass

    def _cmd_statlog(self, sender):
        if not getattr(sender, "is_op", False):
            sender.send_message("§cНет доступа.")
            return
        online_names = [p.name for p in self.server.online_players]
        all_names = self._stats.all_names()
        if not all_names:
            sender.send_message("§7Нет зарегистрированных игроков.")
            return

        def fmt(s):
            s = int(s)
            h, rem = divmod(s, 3600)
            m, _ = divmod(rem, 60)
            return str(h) + "ч " + str(m).zfill(2) + "м"

        def show_player(player_name):
            stats = self._stats.get(player_name)
            is_online = player_name in online_names
            status = "§aОнлайн" if is_online else "§7Оффлайн"
            total = stats.total_playtime + (stats.session_time if is_online else 0)
            msg = "\n".join([
                "§6§l[StatLog] §f" + player_name + " " + status,
                "  §7Убийства: §f" + str(stats.kills) + " | §7Смерти: §f" + str(stats.deaths) + " | §7K/D: §e" + str(stats.kd_ratio),
                "  §7Добыто: §f" + str(stats.blocks_mined) + " | §7Алмазов: §b" + str(stats.diamonds_mined),
                "  §7Сообщений: §f" + str(stats.messages_sent) + " | §7Входов: §f" + str(stats.login_count),
                "  §7Время: §f" + fmt(total),
            ])
            sender.send_message(msg)

        if hasattr(sender, "show_form"):
            form = ActionForm(title="§6StatLog — Выбор игрока", content="Выберите игрока:")
            sorted_names = sorted(all_names)
            for n in sorted_names:
                status = "§a●" if n in online_names else "§7○"
                form.add_button(status + " " + n)

            def on_response(player, response):
                if response is None:
                    return
                try:
                    show_player(sorted_names[int(response)])
                except (ValueError, IndexError):
                    pass

            sender.show_form(form, on_response)
        else:
            for n in sorted(all_names):
                show_player(n)

    def _cmd_reload(self, sender):
        if not getattr(sender, "is_op", False):
            sender.send_message("§cНет доступа.")
            return
        self._load_all_configs()
        self._sb_mgr = ScoreboardManager(self._stats, self._messages, self.logger)
        self._detector = AnomalyDetector(self._cfg.get("antifaud", {}))
        sender.send_message("§aStatPro: конфиг перезагружен.")
