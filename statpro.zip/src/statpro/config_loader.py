import os

try:
    import yaml
    _YAML = True
except ImportError:
    _YAML = False


# ── Default config ────────────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "update_interval": 40,   # ticks between HUD refreshes (40t = 2s)

    # Иконки HUD — можно заменить на глифы из РП
    # Например когда добавите glyph_E1.png и glyph_E2.png:
    #   icon_kills:  "\uE100"   # первый символ glyph_E1.png
    #   icon_deaths: "\uE101"   # второй символ glyph_E1.png
    #   icon_streak: "\uE102"   # третий символ glyph_E1.png
    #   icon_ping:   "\uE200"   # первый символ glyph_E2.png
    "hud": {
        "icon_kills":  "K",
        "icon_deaths": "D",
        "icon_streak": "S",
        "icon_ping":   "MS",
    },

    "antifaud": {
        "killfarm_window": 120,
        "killfarm_count": 3,
        "fast_mine_window": 10,
        "fast_mine_count": 20,
    },
}

# ── Default messages ──────────────────────────────────────────────────────────
DEFAULT_MESSAGES = {
    "alert_online": "§c[StatPro] §fАномалия у §e{player}§f: {reason}",
    "alert_offline_prefix": "§c[StatPro] §7Пока вас не было:",
}


def _write_yaml(path: str, data: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if _YAML:
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
    else:
        with open(path, "w", encoding="utf-8") as f:
            for k, v in data.items():
                f.write(f"{k}: {v!r}\n")


def _read_yaml(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    if _YAML:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    result = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                k, _, v = line.partition(":")
                try:
                    result[k.strip()] = eval(v.strip())
                except Exception:
                    result[k.strip()] = v.strip()
    return result


def _deep_merge(base: dict, override: dict) -> dict:
    result = dict(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def load_config(path: str) -> dict:
    if not os.path.exists(path):
        _write_yaml(path, DEFAULT_CONFIG)
    user = _read_yaml(path)
    return _deep_merge(DEFAULT_CONFIG, user)


def load_messages(path: str) -> dict:
    if not os.path.exists(path):
        _write_yaml(path, DEFAULT_MESSAGES)
    user = _read_yaml(path)
    return _deep_merge(DEFAULT_MESSAGES, user)
