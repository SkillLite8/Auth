from endstone.scoreboard import Criteria, DisplaySlot


def _fmt_time(seconds):
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h:
        return str(h) + "ч " + str(m).zfill(2) + "м"
    return str(m) + "м " + str(s).zfill(2) + "с"


class ScoreboardManager:

    OBJECTIVE_NAME = "statpro_hud"

    # Префиксы из РП emberboss:
    # §s§v — вертикальный список (sidebar справа)
    # §s§h — горизонтальный ряд 1 (вверху)
    # §s§2§h — горизонтальный ряд 2 (вверху, вторая строка)
    H1 = "§s§h"
    H2 = "§s§2§h"
    V  = "§s§v"

    def __init__(self, stats_manager, messages, server, logger=None):
        self._stats = stats_manager
        self._msg = messages
        self._logger = logger
        self._sb = server.scoreboard

    def update_player(self, player):
        try:
            stats = self._stats.get(player.name)
            ping = getattr(player, "ping", 0) or 0

            obj = self._sb.get_objective(self.OBJECTIVE_NAME)
            if obj is not None:
                obj.unregister()

            obj = self._sb.add_objective(
                self.OBJECTIVE_NAME,
                Criteria.DUMMY,
                "§fStatPro"
            )
            obj.set_display(DisplaySlot.SIDE_BAR)

            # Горизонтальные виджеты вверху (ряд 1): убийства и пинг
            # Горизонтальные виджеты вверху (ряд 2): монеты/время
            # Вертикальный список справа: остальная стата

            entries = [
                # Горизонтальный ряд 1 (вверх справа)
                (self.H1 + "§f⚔ " + str(stats.kills), 20),
                (self.H1 + "§a📶 " + str(ping), 19),
                # Горизонтальный ряд 2
                (self.H2 + "§6⏱ " + _fmt_time(stats.session_time), 18),
                # Вертикальный список справа
                (self.V + "§7Смерти: §c" + str(stats.deaths), 10),
                (self.V + "§7K/D: §e" + str(stats.kd_ratio), 9),
                (self.V + "§7Мобов: §b" + str(stats.mob_kills), 8),
                (self.V + "§7Урон: §d" + str(int(stats.damage_dealt)), 7),
                (self.V + "§7Добыто: §f" + str(stats.blocks_mined), 6),
            ]

            for line, score_val in entries:
                score = obj.get_score(line)
                score.value = score_val

        except Exception as e:
            if self._logger:
                self._logger.warning("HUD error: " + str(e))

    def remove_player(self, player):
        pass
