import time


def _fmt_time(seconds):
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h:
        return str(h) + "ч " + str(m).zfill(2) + "м"
    return str(m) + "м " + str(s).zfill(2) + "с"


class ScoreboardManager:

    OBJECTIVE_NAME = "statpro_hud"

    def __init__(self, stats_manager, messages, logger=None):
        self._stats = stats_manager
        self._msg = messages
        self._logger = logger

    def _msg_get(self, key, default):
        return self._msg.get(key, default)

    def update_player(self, player):
        try:
            self._update_via_scoreboard(player)
        except Exception as e:
            if self._logger:
                self._logger.warning("Scoreboard failed for " + player.name + ": " + str(e))
            try:
                self._update_via_tip(player)
            except Exception:
                pass

    def _update_via_scoreboard(self, player):
        sb = player.scoreboard
        stats = self._stats.get(player.name)

        obj = sb.get_objective(self.OBJECTIVE_NAME)
        if obj is not None:
            obj.unregister()

        title = self._msg_get("scoreboard_title", "§6§lСтатистика")
        obj = sb.add_objective(self.OBJECTIVE_NAME, "dummy", title)
        obj.display_slot = "sidebar"

        lines = self._build_lines(player, stats)
        for idx, line in enumerate(reversed(lines)):
            score = obj.get_score(line)
            score.value = idx + 1

    def _update_via_tip(self, player):
        stats = self._stats.get(player.name)
        ping = getattr(player, "ping", 0) or 0
        session = stats.session_time
        tip = (
            "§6§lStatPro §8| "
            "§f⚔" + str(stats.kills) + " §7/ §c☠" + str(stats.deaths) +
            " §7| §eK/D:" + str(stats.kd_ratio) +
            " §7| §a🌐" + str(ping) + "мс" +
            " §7| §6⏱" + _fmt_time(session)
        )
        player.send_tip(tip)

    def _build_lines(self, player, stats):
        session = stats.session_time
        ping = getattr(player, "ping", 0) or 0
        sep = self._msg_get("sb_sep", "§8§m──────────────")
        return [
            sep,
            "§f⚔ §7Убийства: §a" + str(stats.kills),
            "§f☠ §7Смерти: §c" + str(stats.deaths),
            "§f⚖ §7K/D: §e" + str(stats.kd_ratio),
            sep,
            "§f💀 §7Мобов: §b" + str(stats.mob_kills),
            "§f🗡 §7Урон: §d" + str(int(stats.damage_dealt)),
            sep,
            "§f⏱ §7Сессия: §6" + _fmt_time(session),
            "§f🌐 §7Пинг: §a" + str(ping) + " мс",
            sep,
            "§7  §fStatPro §8by §7Server",
        ]

    def remove_player(self, player):
        try:
            sb = player.scoreboard
            obj = sb.get_objective(self.OBJECTIVE_NAME)
            if obj:
                obj.unregister()
        except Exception:
            pass
