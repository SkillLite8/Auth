from endstone.scoreboard import Criteria, DisplaySlot


def _fmt_time(seconds):
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h:
        return str(h) + "ч " + str(m).zfill(2) + "м"
    return str(m) + "м " + str(s).zfill(2) + "с"


class ScoreboardManager:

    OBJECTIVE_NAME = "statpro_hud"

    def __init__(self, stats_manager, messages, server, logger=None):
        self._stats = stats_manager
        self._msg = messages
        self._logger = logger
        self._sb = server.scoreboard

    def _get_sb(self):
        



    def update_player(self, player):
        try:
            sb = self._sb
            stats = self._stats.get(player.name)
            ping = getattr(player, "ping", 0) or 0
            session = stats.session_time

            # Удаляем старый objective если есть
            obj = sb.get_objective(self.OBJECTIVE_NAME)
            if obj is not None:
                obj.unregister()

            # Создаём новый
            obj = sb.add_objective(
                self.OBJECTIVE_NAME,
                Criteria.DUMMY,
                "§5§lStatPro"
            )
            # Показываем в sidebar
            obj.set_display(DisplaySlot.SIDE_BAR)

            lines = [
                "§8──────────────",
                "§7Убийства: §a" + str(stats.kills),
                "§7Смерти: §c" + str(stats.deaths),
                "§7K/D: §e" + str(stats.kd_ratio),
                "§7Мобов: §b" + str(stats.mob_kills),
                "§8──────────────",
                "§7Урон: §d" + str(int(stats.damage_dealt)),
                "§7Пинг: §a" + str(ping) + " мс",
                "§7Сессия: §6" + _fmt_time(session),
                "§8──────────────",
            ]

            for idx, line in enumerate(reversed(lines)):
                score = obj.get_score(line)
                score.value = idx + 1

        except Exception as e:
            if self._logger:
                self._logger.warning("HUD error: " + str(e))

    def remove_player(self, player):
        pass  # глобальный scoreboard — не удаляем при выходе одного игрока
