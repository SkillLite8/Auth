import time


def _fmt_time(seconds):
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h:
        return str(h) + "ч " + str(m).zfill(2) + "м"
    return str(m) + "м " + str(s).zfill(2) + "с"


class ScoreboardManager:

    OBJECTIVE_NAME = "statpro_hud"

    def __init__(self, stats_manager, messages, logger=None):
        self._stats = stats_manager
        self._msg = messages
        self._logger = logger

    def update_player(self, player):
        try:
            sb = player.scoreboard
            stats = self._stats.get(player.name)
            ping = getattr(player, "ping", 0) or 0
            session = stats.session_time

            obj = sb.get_objective(self.OBJECTIVE_NAME)
            if obj is not None:
                obj.unregister()

            obj = sb.add_objective(self.OBJECTIVE_NAME, "dummy", "§5§lStatPro")
            obj.display_slot = "sidebar"

            lines = [
                "§8──────────────",
                "§7Убийства: §a" + str(stats.kills),
                "§7Смерти: §c" + str(stats.deaths),
                "§7K/D: §e" + str(stats.kd_ratio),
                "§7Мобов: §b" + str(stats.mob_kills),
                "§8──────────────",
                "§7Урон: §d" + str(int(stats.damage_dealt)),
                "§7Пинг: §a" + str(ping) + " мс",
                "§7Сессия: §6" + _fmt_time(session),
                "§8──────────────",
            ]

            for idx, line in enumerate(reversed(lines)):
                score = obj.get_score(line)
                score.value = idx + 1

        except Exception as e:
            if self._logger:
                self._logger.warning("HUD error: " + str(e))

    def remove_player(self, player):
        try:
            sb = player.scoreboard
            obj = sb.get_objective(self.OBJECTIVE_NAME)
            if obj:
                obj.unregister()
        except Exception:
            pass
