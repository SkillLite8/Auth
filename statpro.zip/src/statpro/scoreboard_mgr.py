from endstone.scoreboard import Criteria, DisplaySlot


class ScoreboardManager:

    OBJECTIVE_NAME = "statpro_hud"

    H1 = "§s§h"   # горизонтальный ряд 1 (вверх справа)
    H2 = "§s§2§h" # горизонтальный ряд 2 (вверх справа, вторая строка)

    def __init__(self, stats_manager, messages, server, logger=None, cfg=None):
        self._stats = stats_manager
        self._msg = messages
        self._logger = logger
        self._sb = server.scoreboard
        hud = (cfg or {}).get("hud", {})
        self._icon_kills  = hud.get("icon_kills",  "K")
        self._icon_deaths = hud.get("icon_deaths", "D")
        self._icon_streak = hud.get("icon_streak", "S")
        self._icon_ping   = hud.get("icon_ping",   "MS")

    def update_player(self, player):
        try:
            stats = self._stats.get(player.name)
            ping = getattr(player, "ping", 0) or 0

            obj = self._sb.get_objective(self.OBJECTIVE_NAME)
            if obj is not None:
                obj.unregister()

            obj = self._sb.add_objective(
                self.OBJECTIVE_NAME,
                Criteria.DUMMY,
                "§fStatPro"
            )
            obj.set_display(DisplaySlot.SIDE_BAR)

            # ── Ряд 1: К/Д  (убийства / смерти) ──────────────────────────────
            kd_line = (
                self.H1
                + "§f" + self._icon_kills + " §a" + str(stats.kills)
                + " §7/ "
                + "§c" + self._icon_deaths + " §c" + str(stats.deaths)
            )

            # ── Ряд 2: Серия убийств ──────────────────────────────────────────
            if stats.killstreak >= 10:
                s_color = "§c"
            elif stats.killstreak >= 5:
                s_color = "§6"
            else:
                s_color = "§a"
            streak_line = (
                self.H2
                + "§f" + self._icon_streak + " " + s_color + str(stats.killstreak)
            )

            # ── Ряд 3 (вторая строка ряд 2): Пинг ────────────────────────────
            # Используем третий горизонтальный слот через разный score
            if ping < 80:
                p_color = "§a"
            elif ping < 150:
                p_color = "§e"
            else:
                p_color = "§c"
            ping_line = (
                self.H2
                + "§f" + self._icon_ping + " " + p_color + str(ping) + "ms"
            )

            entries = [
                (kd_line,     22),
                (streak_line, 21),
                (ping_line,   20),
            ]

            for line, score_val in entries:
                score = obj.get_score(line)
                score.value = score_val

        except Exception as e:
            if self._logger:
                self._logger.warning("HUD error: " + str(e))

    def remove_player(self, player):
        pass
