import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from endstone.player import Player
    from .stats_manager import StatsManager


def _fmt_time(seconds: float) -> str:
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h:
        return f"{h}ч {m:02d}м"
    return f"{m}м {s:02d}с"


class ScoreboardManager:
    """
    HUD через scoreboard sidebar (Endstone 0.10.5).
    Использует server.scoreboard (глобальный) + per-player scoreboard через player.scoreboard.
    Если scoreboard API недоступен — fallback на send_tip().
    """

    OBJECTIVE_NAME = "statpro_hud"

    def __init__(self, stats_manager: "StatsManager", messages: dict):
        self._stats = stats_manager
        self._msg = messages

    def _msg_get(self, key: str, default: str) -> str:
        return self._msg.get(key, default)

    def update_player(self, player: "Player") -> None:
        try:
            self._update_via_scoreboard(player)
        except Exception:
            try:
                self._update_via_tip(player)
            except Exception:
                pass

    def _update_via_scoreboard(self, player: "Player") -> None:
        sb = player.scoreboard
        name = player.name
        stats = self._stats.get(name)

        obj = sb.get_objective(self.OBJECTIVE_NAME)
        if obj is not None:
            obj.unregister()

        title = self._msg_get("scoreboard_title", "§6§lСтатистика")
        obj = sb.add_objective(self.OBJECTIVE_NAME, "dummy", title)
        obj.display_slot = "sidebar"

        lines = self._build_lines(player, stats)
        for idx, line in enumerate(reversed(lines)):
            score = obj.get_score(line)
            score.value = idx + 1

    def _update_via_tip(self, player: "Player") -> None:
        stats = self._stats.get(player.name)
        ping = getattr(player, "ping", 0) or 0
        session = stats.session_time

        kd = stats.kd_ratio
        kills = stats.kills
        deaths = stats.deaths

        tip = (
            f"§6§lStatPro §8| "
            f"§f⚔{kills} §7/ §c☠{deaths} §7| §eK/D:{kd} §7| "
            f"§a🌐{ping}мс §7| §6⏱{_fmt_time(session)}"
        )
        player.send_tip(tip)

    def _build_lines(self, player: "Player", stats) -> list[str]:
        session = stats.session_time
        ping = getattr(player, "ping", 0) or 0

        return [
            self._msg_get("sb_sep", "§8§m──────────────"),
            f"§f⚔ §7Убийства: §a{stats.kills}",
            f"§f☠ §7Смерти: §c{stats.deaths}",
            f"§f⚖ §7K/D: §e{stats.kd_ratio}",
            self._msg_get("sb_sep2", "§8§m──────────────"),
            f"§f💀 §7Мобов: §b{stats.mob_kills}",
            f"§f🗡 §7Урон: §d{int(stats.damage_dealt)}",
            self._msg_get("sb_sep3", "§8§m──────────────"),
            f"§f⏱ §7Сессия: §6{_fmt_time(session)}",
            f"§f🌐 §7Пинг: §a{ping} мс",
            self._msg_get("sb_sep4", "§8§m──────────────"),
            f"§7  §fStatPro §8by §7Server",
        ]

    def remove_player(self, player: "Player") -> None:
        try:
            sb = player.scoreboard
            obj = sb.get_objective(self.OBJECTIVE_NAME)
            if obj:
                obj.unregister()
        except Exception:
            pass
