from endstone.plugin import Plugin
from .plugin import StatPro

__all__ = ["StatPro"]
