from __future__ import annotations
import os

try:
    import yaml
    _YAML = True
except ImportError:
    _YAML = False


# ── Default config ────────────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "update_interval": 40,   # ticks between HUD refreshes (40t = 2s)
    "antifaud": {
        "killfarm_window": 120,   # seconds
        "killfarm_count": 3,      # kills of same victim to trigger
        "fast_mine_window": 10,   # seconds
        "fast_mine_count": 20,    # ore blocks in window to trigger
    },
}

# ── Default messages ──────────────────────────────────────────────────────────
DEFAULT_MESSAGES = {
    "scoreboard_title": "§6§lСтатистика",
    "sb_sep":  "§8§m─────────────",
    "sb_sep2": "§8§m─────────────",
    "sb_sep3": "§8§m─────────────",
    "sb_sep4": "§8§m─────────────",
    "alert_online": "§c[StatPro] §fАномалия у §e{player}§f: {reason}",
    "alert_offline_prefix": "§c[StatPro] §7Пока вас не было:",
}


def _write_yaml(path: str, data: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if _YAML:
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, allow_unicode=True, default_flow_style=False)
    else:
        # Fallback: write simple key: value lines (no nesting)
        with open(path, "w", encoding="utf-8") as f:
            for k, v in data.items():
                f.write(f"{k}: {v!r}\n")


def _read_yaml(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    if _YAML:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    # Fallback: key: value only
    result = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                k, _, v = line.partition(":")
                try:
                    result[k.strip()] = eval(v.strip())
                except Exception:
                    result[k.strip()] = v.strip()
    return result


def _deep_merge(base: dict, override: dict) -> dict:
    result = dict(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def load_config(path: str) -> dict:
    if not os.path.exists(path):
        _write_yaml(path, DEFAULT_CONFIG)
    user = _read_yaml(path)
    return _deep_merge(DEFAULT_CONFIG, user)


def load_messages(path: str) -> dict:
    if not os.path.exists(path):
        _write_yaml(path, DEFAULT_MESSAGES)
    user = _read_yaml(path)
    return _deep_merge(DEFAULT_MESSAGES, user)
