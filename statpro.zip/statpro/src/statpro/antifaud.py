from __future__ import annotations
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .stats_manager import PlayerStats

# ── Thresholds (tune in config) ───────────────────────────────────────────────
KILLFARM_WINDOW = 120        # seconds
KILLFARM_SAME_VICTIM = 3     # kills of same player within window
FAST_MINE_WINDOW = 10        # seconds
FAST_MINE_COUNT = 20         # ore blocks in window


class AnomalyDetector:
    """Detects suspicious patterns in player statistics."""

    def __init__(self, thresholds: dict | None = None):
        t = thresholds or {}
        self.killfarm_window: int = t.get("killfarm_window", KILLFARM_WINDOW)
        self.killfarm_count: int = t.get("killfarm_count", KILLFARM_SAME_VICTIM)
        self.fast_mine_window: int = t.get("fast_mine_window", FAST_MINE_WINDOW)
        self.fast_mine_count: int = t.get("fast_mine_count", FAST_MINE_COUNT)

    # ── Kill-farm ─────────────────────────────────────────────────────────────
    def check_killfarm(self, stats: "PlayerStats", victim: str) -> str | None:
        now = time.time()
        stats.kill_history.append((now, victim))
        # Keep only recent entries
        stats.kill_history = [
            (t, v) for t, v in stats.kill_history
            if now - t <= self.killfarm_window
        ]
        count = sum(1 for _, v in stats.kill_history if v == victim)
        if count >= self.killfarm_count:
            return f"KillFarm: убил {victim} {count}x за {self.killfarm_window}с"
        return None

    # ── Fast mining ───────────────────────────────────────────────────────────
    def check_fast_mine(self, stats: "PlayerStats", block: str) -> str | None:
        now = time.time()
        stats.mine_history.append((now, block))
        stats.mine_history = [
            (t, b) for t, b in stats.mine_history
            if now - t <= self.fast_mine_window
        ]
        ore_blocks = {"diamond_ore", "deepslate_diamond_ore",
                      "gold_ore", "deepslate_gold_ore",
                      "ancient_debris", "emerald_ore"}
        count = sum(1 for _, b in stats.mine_history if b in ore_blocks)
        if count >= self.fast_mine_count:
            return f"FastMine: {count} ценных руд за {self.fast_mine_window}с"
        return None
