from __future__ import annotations
import json
import os
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from endstone.player import Player


class PlayerStats:
    """Holds all statistics for a single player."""

    def __init__(self):
        self.kills: int = 0
        self.mob_kills: int = 0
        self.deaths: int = 0
        self.damage_dealt: float = 0.0
        self.blocks_walked: float = 0.0
        self.blocks_swum: float = 0.0
        self.blocks_flown: float = 0.0
        self.jumps: int = 0
        self.food_eaten: int = 0
        self.blocks_mined: int = 0
        self.diamonds_mined: int = 0
        self.gold_mined: int = 0
        self.netherite_mined: int = 0
        self.messages_sent: int = 0
        self.login_count: int = 0
        self.total_playtime: float = 0.0  # seconds
        self.session_start: float = 0.0   # timestamp

        # Anti-fraud
        self.kill_history: list[tuple[float, str]] = []  # (timestamp, victim)
        self.mine_history: list[tuple[float, str]] = []  # (timestamp, block)

    # ── Computed ──────────────────────────────────────────────────────────────
    @property
    def kd_ratio(self) -> float:
        return round(self.kills / max(self.deaths, 1), 2)

    @property
    def session_time(self) -> float:
        if self.session_start:
            return time.time() - self.session_start
        return 0.0

    # ── Serialization ─────────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "kills": self.kills,
            "mob_kills": self.mob_kills,
            "deaths": self.deaths,
            "damage_dealt": self.damage_dealt,
            "blocks_walked": self.blocks_walked,
            "blocks_swum": self.blocks_swum,
            "blocks_flown": self.blocks_flown,
            "jumps": self.jumps,
            "food_eaten": self.food_eaten,
            "blocks_mined": self.blocks_mined,
            "diamonds_mined": self.diamonds_mined,
            "gold_mined": self.gold_mined,
            "netherite_mined": self.netherite_mined,
            "messages_sent": self.messages_sent,
            "login_count": self.login_count,
            "total_playtime": self.total_playtime,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "PlayerStats":
        s = cls()
        for key, val in data.items():
            if hasattr(s, key):
                setattr(s, key, val)
        return s


class StatsManager:
    """Loads and saves player stats from disk."""

    def __init__(self, data_dir: str):
        self._dir = data_dir
        self._cache: dict[str, PlayerStats] = {}
        os.makedirs(data_dir, exist_ok=True)

    # ── Internal ──────────────────────────────────────────────────────────────
    def _path(self, name: str) -> str:
        player_dir = os.path.join(self._dir, "players", name)
        os.makedirs(player_dir, exist_ok=True)
        return os.path.join(player_dir, "stats.json")

    # ── Public API ────────────────────────────────────────────────────────────
    def get(self, name: str) -> PlayerStats:
        if name not in self._cache:
            path = self._path(name)
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    self._cache[name] = PlayerStats.from_dict(json.load(f))
            else:
                self._cache[name] = PlayerStats()
        return self._cache[name]

    def save(self, name: str) -> None:
        stats = self._cache.get(name)
        if stats is None:
            return
        with open(self._path(name), "w", encoding="utf-8") as f:
            json.dump(stats.to_dict(), f, indent=2, ensure_ascii=False)

    def save_all(self) -> None:
        for name in list(self._cache.keys()):
            self.save(name)

    def all_names(self) -> list[str]:
        players_dir = os.path.join(self._dir, "players")
        if not os.path.isdir(players_dir):
            return []
        return [
            d for d in os.listdir(players_dir)
            if os.path.isdir(os.path.join(players_dir, d))
        ]

    def flush_session(self, name: str) -> None:
        """Add session time to total and reset session start."""
        stats = self.get(name)
        if stats.session_start:
            stats.total_playtime += stats.session_time
            stats.session_start = 0.0
        self.save(name)
