from __future__ import annotations
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from endstone.player import Player
    from endstone.scoreboard import Scoreboard, Objective
    from .stats_manager import StatsManager


def _fmt_time(seconds: float) -> str:
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h:
        return f"{h}ч {m:02d}м"
    return f"{m}м {s:02d}с"


class ScoreboardManager:
    """Creates and updates the sidebar scoreboard for every online player."""

    OBJECTIVE_NAME = "statpro_hud"

    def __init__(self, stats_manager: "StatsManager", messages: dict):
        self._stats = stats_manager
        self._msg = messages

    def _msg_get(self, key: str, default: str) -> str:
        return self._msg.get(key, default)

    def update_player(self, player: "Player") -> None:
        """Rebuild the sidebar scoreboard for a single player."""
        try:
            sb: "Scoreboard" = player.scoreboard
            name = player.name
            stats = self._stats.get(name)

            # Remove old objective if exists
            old_obj = sb.get_objective(self.OBJECTIVE_NAME)
            if old_obj:
                old_obj.unregister()

            # Create fresh objective
            obj: "Objective" = sb.add_objective(
                self.OBJECTIVE_NAME,
                "dummy",
                self._msg_get("scoreboard_title", "§6§lСтатистика")
            )
            obj.display_slot = "sidebar"

            # ── Build lines (score = display order, higher = top) ──────────
            lines = self._build_lines(player, stats)
            for idx, line in enumerate(reversed(lines)):
                score = obj.get_score(line)
                score.value = idx + 1

        except Exception:
            pass  # Never crash server over HUD update

    def _build_lines(self, player: "Player", stats) -> list[str]:
        """Build the list of scoreboard lines top→bottom."""
        session = stats.session_time
        total_playtime = stats.total_playtime + session
        ping = getattr(player, "ping", 0) or 0

        lines = [
            self._msg_get("sb_sep", "§8§m─────────────"),
            f"§f⚔ §7Убийства: §a{stats.kills}",
            f"§f☠ §7Смерти: §c{stats.deaths}",
            f"§f⚖ §7K/D: §e{stats.kd_ratio}",
            self._msg_get("sb_sep2", "§8§m─────────────"),
            f"§f💀 §7Мобов: §b{stats.mob_kills}",
            f"§f🗡 §7Урон: §d{int(stats.damage_dealt)}",
            self._msg_get("sb_sep3", "§8§m─────────────"),
            f"§f⏱ §7Сессия: §6{_fmt_time(session)}",
            f"§f🌐 §7Пинг: §a{ping} мс",
            self._msg_get("sb_sep4", "§8§m─────────────"),
            f"§7  §fStatPro §8by §7Server",
        ]
        return lines

    def remove_player(self, player: "Player") -> None:
        try:
            sb = player.scoreboard
            obj = sb.get_objective(self.OBJECTIVE_NAME)
            if obj:
                obj.unregister()
        except Exception:
            pass
