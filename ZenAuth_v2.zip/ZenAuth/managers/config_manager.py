import json
import os


class ConfigManager:

    def __init__(self, plugin_dir: str):
        self._path = os.path.join(plugin_dir, "config.json")
        self._data = {}
        self._load()

    def _load(self):
        if not os.path.exists(self._path):
            return
        with open(self._path, "r", encoding="utf-8") as f:
            self._data = json.load(f)

    def get(self, key: str, default=None):
        keys = key.split(".")
        val = self._data
        for k in keys:
            if isinstance(val, dict) and k in val:
                val = val[k]
            else:
                return default
        return val

    def get_message(self, key: str) -> str:
        return str(self.get(f"messages.{key}", f"[missing:{key}]"))

    def get_form(self, form: str, key: str, default: str = "") -> str:
        return str(self.get(f"forms.{form}.{key}", default))

    @staticmethod
    def write_default(plugin_dir: str):
        config_path = os.path.join(plugin_dir, "config.json")
        if os.path.exists(config_path):
            return
        default = {
            "session": {
                "duration_hours": 24,
                "kick_timeout_seconds": 60,
                "max_accounts_per_device": 3,
                "spam_login_count": 3,
                "spam_login_window_minutes": 15,
                "spam_ban_minutes": 30
            },
            "security": {
                "max_attempts": 3,
                "bruteforce_ban_minutes": 15,
                "password_min_length": 6,
                "password_max_length": 15
            },
            "title": {
                "main_title": "§bSPAM",
                "main_subtitle": "§fПожалуйста, авторизуйтесь."
            },
            "sounds": {
                "form_open": "random.click",
                "login_success": "random.levelup",
                "login_fail": "mob.villager.no"
            },
            "forms": {
                "login": {
                    "title": "§bАвторизация",
                    "label": "§7Введите пароль для входа в аккаунт:",
                    "password_placeholder": "Пароль",
                    "submit_button": "§aВойти",
                    "register_button": "§eРегистрация"
                },
                "register": {
                    "title": "§aРегистрация",
                    "label": "§7Придумайте надёжный пароль:",
                    "password_placeholder": "Пароль (6-15 символов, a-z, A-Z, 0-9)",
                    "confirm_placeholder": "Подтвердите пароль",
                    "secret_placeholder": "Секретное слово (необязательно, только буквы)",
                    "submit_button": "§aЗарегистрироваться"
                },
                "changepass": {
                    "title": "§eСмена пароля",
                    "label": "§7Введите старый пароль или секретное слово:",
                    "old_placeholder": "Старый пароль или секретное слово",
                    "new_placeholder": "Новый пароль",
                    "confirm_placeholder": "Подтвердите новый пароль",
                    "submit_button": "§aСменить пароль"
                },
                "secret": {
                    "title": "§eСекретное слово",
                    "label": "§7Введите новое секретное слово:",
                    "secret_placeholder": "Только буквы (лат. или рус.)",
                    "submit_button": "§aУстановить"
                },
                "admin": {
                    "title": "§4ZenAdmin §cPanel",
                    "search_placeholder": "Ник игрока (оффлайн или онлайн)",
                    "reset_pass_button": "§e⚙ Сбросить пароль",
                    "delete_secret_button": "§e⚙ Удалить секретное слово",
                    "wipe_button": "§c✘ Полная очистка (Wipe)",
                    "logs_button": "§b✦ Логи игрока",
                    "back_button": "§7← Назад",
                    "online_players_button": "§a▶ Онлайн игроки"
                },
                "logs": {
                    "title": "§bЛоги игрока"
                }
            },
            "messages": {
                "login_success": "§a✔ Добро пожаловать, §e{player}§a!",
                "login_fail": "§c✘ Неверный пароль! Осталось попыток: §e{attempts}",
                "register_success": "§a✔ Аккаунт создан! Добро пожаловать, §e{player}§a!",
                "already_logged": "§c✘ Вы уже авторизованы.",
                "not_logged": "§c✘ Сначала авторизуйтесь.",
                "password_invalid": "§c✘ Пароль: только латинские буквы и цифры, 6-15 символов.",
                "passwords_not_match": "§c✘ Пароли не совпадают.",
                "account_exists": "§c✘ Аккаунт с таким именем уже существует.",
                "too_many_accounts": "§c✘ С вашего устройства зарегистрировано слишком много аккаунтов.",
                "bruteforce_ban": "§c✘ Слишком много неудачных попыток. Бан на §e{minutes} мин.",
                "spam_ban": "§c✘ Слишком частые входы на сервер. Бан на §e{minutes} мин.",
                "kick_timeout": "§c✘ Время авторизации истекло. Подключитесь снова.",
                "kick_banned": "§c✘ Вы заблокированы. Осталось: §e{time}",
                "secret_set": "§a✔ Секретное слово успешно установлено.",
                "secret_invalid": "§c✘ Секретное слово: только буквы (латинские или русские).",
                "secret_remind": "§e⚠ У вас не установлено секретное слово! Используйте §b/auth secret §eдля защиты аккаунта.",
                "secret_wrong": "§c✘ Неверное секретное слово.",
                "password_changed": "§a✔ Пароль успешно изменён.",
                "old_password_wrong": "§c✘ Неверный старый пароль или секретное слово.",
                "no_permission": "§c✘ Недостаточно прав.",
                "player_not_found": "§c✘ Игрок §e{player} §cне найден в базе данных.",
                "admin_reset_success": "§a✔ Пароль игрока §e{player} §aсброшен.",
                "admin_secret_deleted": "§a✔ Секретное слово игрока §e{player} §aудалено.",
                "admin_wipe_success": "§a✔ Данные игрока §e{player} §aполностью удалены.",
                "auto_login": "§a✔ Добро пожаловать обратно, §e{player}§a!",
                "provide_nick": "§c✘ Укажите ник игрока.",
                "logs_no_data": "§c✘ Логи игрока §e{player} §cне найдены.",
                "admin_kick_reset": "§cАдминистратор сбросил ваш пароль. Авторизуйтесь заново.",
                "admin_kick_wipe": "§cВаши данные удалены администратором. Зарегистрируйтесь заново."
            }
        }
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(default, f, ensure_ascii=False, indent=2)

    @staticmethod
    def write_setup_guide(plugin_dir: str):
        guide_path = os.path.join(plugin_dir, "НАСТРОЙКА.txt")
        if os.path.exists(guide_path):
            return
        content = (
            "╔══════════════════════════════════════════════════════════╗\n"
            "║           ZenAuth v2.0 — Руководство по настройке        ║\n"
            "╚══════════════════════════════════════════════════════════╝\n"
            "\n"
            "Все настройки хранятся в файле config.json рядом с этим файлом.\n"
            "В код лезть НЕ нужно — всё управляется через конфиг.\n"
            "\n"
            "═══════════════════════════════════════\n"
            "РАЗДЕЛ: session\n"
            "═══════════════════════════════════════\n"
            "duration_hours            Время жизни авто-сессии в часах.         По умолчанию: 24\n"
            "kick_timeout_seconds      Секунд до кика неавторизованного игрока. По умолчанию: 60\n"
            "max_accounts_per_device   Макс. аккаунтов на одно устройство.      По умолчанию: 3\n"
            "spam_login_count          Входов за окно времени до спам-бана.      По умолчанию: 3\n"
            "spam_login_window_minutes Ширина окна проверки спама (минут).       По умолчанию: 15\n"
            "spam_ban_minutes          Длительность бана за спам-входы (минут).  По умолчанию: 30\n"
            "\n"
            "═══════════════════════════════════════\n"
            "РАЗДЕЛ: security\n"
            "═══════════════════════════════════════\n"
            "max_attempts              Попыток ввода пароля до бана (брутфорс).  По умолчанию: 3\n"
            "bruteforce_ban_minutes    Длительность бана за брутфорс (минут).    По умолчанию: 15\n"
            "password_min_length       Минимальная длина пароля.                 По умолчанию: 6\n"
            "password_max_length       Максимальная длина пароля.                По умолчанию: 15\n"
            "\n"
            "═══════════════════════════════════════\n"
            "РАЗДЕЛ: title\n"
            "═══════════════════════════════════════\n"
            "main_title    Крупный заголовок на экране при входе. Поддерживает §-коды.\n"
            "main_subtitle Подзаголовок на экране при входе. Поддерживает §-коды.\n"
            "\n"
            "═══════════════════════════════════════\n"
            "РАЗДЕЛ: sounds\n"
            "═══════════════════════════════════════\n"
            "form_open     Звук при открытии формы авторизации.\n"
            "login_success Звук при успешном входе.\n"
            "login_fail    Звук при неверном пароле.\n"
            "Примеры звуков: random.click, random.levelup, mob.villager.no, note.pling\n"
            "\n"
            "═══════════════════════════════════════\n"
            "РАЗДЕЛ: forms\n"
            "═══════════════════════════════════════\n"
            "Подразделы: login, register, changepass, secret, admin, logs\n"
            "В каждом подразделе можно изменить title, label, тексты кнопок и плейсхолдеры.\n"
            "Все значения поддерживают §-коды цветов Minecraft.\n"
            "\n"
            "═══════════════════════════════════════\n"
            "РАЗДЕЛ: messages\n"
            "═══════════════════════════════════════\n"
            "Все сообщения в чате. Поддерживаемые плейсхолдеры:\n"
            "  {player}   — имя игрока\n"
            "  {attempts} — оставшиеся попытки ввода пароля\n"
            "  {minutes}  — длительность бана в минутах\n"
            "  {time}     — оставшееся время бана\n"
            "\n"
            "═══════════════════════════════════════\n"
            "КОМАНДЫ\n"
            "═══════════════════════════════════════\n"
            "/auth                              Открыть форму входа (или смены пароля если уже вошёл)\n"
            "/auth secret [слово]               Установить секретное слово (через форму или аргумент)\n"
            "/auth changepass [старый] [новый]  Сменить пароль через команду или форму\n"
            "/auth admin                        ZenAdmin панель (требует право zenauth.admin)\n"
            "/auth logs [ник]                   Логи игрока (требует право zenauth.admin)\n"
            "\n"
            "═══════════════════════════════════════\n"
            "ПРАВА\n"
            "═══════════════════════════════════════\n"
            "zenauth.use    Базовое использование — выдаётся всем по умолчанию\n"
            "zenauth.admin  Доступ к /auth admin и /auth logs — только OP по умолчанию\n"
            "\n"
            "═══════════════════════════════════════\n"
            "СТРУКТУРА ФАЙЛОВ ДАННЫХ\n"
            "═══════════════════════════════════════\n"
            "config.json    — конфигурация плагина\n"
            "НАСТРОЙКА.txt  — этот файл\n"
            "players/       — JSON-файлы игроков (имя_игрока.json)\n"
            "sessions/      — файлы авто-сессий\n"
            "player_logs/   — история действий каждого игрока\n"
            "logs.txt       — общий лог-файл всех действий\n"
            "\n"
            "После изменения config.json выполните /reload на сервере или перезапустите его.\n"
        )
        with open(guide_path, "w", encoding="utf-8") as f:
            f.write(content)
