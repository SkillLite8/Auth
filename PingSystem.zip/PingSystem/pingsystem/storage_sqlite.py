"""
Optional SQLite storage backend.
Same interface as JsonStorage — drop-in replacement.
"""

from __future__ import annotations
import json
import logging
import os
import sqlite3
from typing import Dict, Optional

from .ping_data import PlayerPingData

log = logging.getLogger("PingSystem.storage.sqlite")


class SqliteStorage:
    """Stores all player data in a single SQLite database."""

    def __init__(self, data_dir: str, buffer_capacity: int = 120) -> None:
        os.makedirs(data_dir, exist_ok=True)
        self._path     = os.path.join(data_dir, "pingsystem.db")
        self._capacity = buffer_capacity
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self._path, timeout=5, check_same_thread=False)
        con.execute("PRAGMA journal_mode=WAL")
        return con

    def _init_db(self) -> None:
        with self._connect() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS players (
                    xuid TEXT PRIMARY KEY,
                    data TEXT NOT NULL
                )
            """)

    # ------------------------------------------------------------------ #
    def load(self, xuid: str) -> Optional[PlayerPingData]:
        try:
            with self._connect() as con:
                row = con.execute(
                    "SELECT data FROM players WHERE xuid = ?", (xuid,)
                ).fetchone()
            if row is None:
                return None
            return PlayerPingData.from_dict(json.loads(row[0]), self._capacity)
        except Exception as exc:
            log.warning("SQLite load failed for %s: %s", xuid, exc)
            return None

    def save(self, data: PlayerPingData) -> None:
        try:
            payload = json.dumps(data.to_dict(), separators=(",", ":"))
            with self._connect() as con:
                con.execute(
                    "INSERT OR REPLACE INTO players (xuid, data) VALUES (?, ?)",
                    (data.xuid, payload),
                )
        except Exception as exc:
            log.warning("SQLite save failed for %s: %s", data.xuid, exc)

    def save_all(self, players: Dict[str, PlayerPingData]) -> None:
        for data in players.values():
            self.save(data)

    def delete(self, xuid: str) -> None:
        try:
            with self._connect() as con:
                con.execute("DELETE FROM players WHERE xuid = ?", (xuid,))
        except Exception as exc:
            log.warning("SQLite delete failed for %s: %s", xuid, exc)
