"""
Ping formatter: resolves placeholders and applies colour codes.
No external dependencies — pure string operations.
"""

from __future__ import annotations
from typing import Dict

from .ping_data import PlayerPingData


# ── Colour constants (Minecraft §-codes) ────────────────────────────────── #
COLOR_GREEN  = "§a"
COLOR_YELLOW = "§e"
COLOR_ORANGE = "§6"
COLOR_RED    = "§c"
COLOR_RESET  = "§r"

# Dot indicator (4-dot quality bar)
_DOT_FULL  = "●"
_DOT_EMPTY = "○"


class PingFormatter:
    """
    Stateless formatter.
    All methods are classmethods — instantiate only to cache config values.
    """

    def __init__(
        self,
        good: int = 50,
        medium: int = 100,
        bad: int = 200,
    ) -> None:
        self.good   = good
        self.medium = medium
        self.bad    = bad

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def format_nametag(
        self,
        data: PlayerPingData,
        style_format: str,
        name_override: str = "",
    ) -> str:
        """
        Resolve all placeholders in *style_format* for the given player.
        Returns the final coloured string ready to set as nametag.
        """
        ping  = data.current
        color = self.ping_color(ping)
        icon  = self.ping_icon(ping)
        name  = name_override or data.name

        result = style_format
        result = result.replace("%player%",    name)
        result = result.replace("%ping%",      str(ping))
        result = result.replace("%ping_avg%",  str(int(data.average)))
        result = result.replace("%ping_min%",  str(data.minimum))
        result = result.replace("%ping_max%",  str(data.maximum))
        result = result.replace("%ping_color%", color)
        result = result.replace("%ping_icon%",  icon)
        return result

    def format_full_name(
        self,
        player_name: str,
        data: PlayerPingData,
        nametag_suffix: str,
    ) -> str:
        """Combine player name with the ping suffix (used for full nametag)."""
        if not nametag_suffix:
            return player_name
        return f"{player_name} {nametag_suffix}"

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    def ping_color(self, ping: int) -> str:
        if ping <= self.good:
            return COLOR_GREEN
        if ping <= self.medium:
            return COLOR_YELLOW
        if ping <= self.bad:
            return COLOR_ORANGE
        return COLOR_RED

    def ping_icon(self, ping: int) -> str:
        """4-dot quality bar: ●●●○ etc."""
        if ping <= self.good:
            dots = 4
        elif ping <= self.medium:
            dots = 3
        elif ping <= self.bad:
            dots = 2
        else:
            dots = 1
        color = self.ping_color(ping)
        return color + (_DOT_FULL * dots) + _DOT_EMPTY * (4 - dots) + COLOR_RESET

    def stat_message(self, data: PlayerPingData, lag_threshold: int) -> str:
        """Formatted multi-line stat message for /pingstat."""
        color   = self.ping_color(data.current)
        avg_c   = self.ping_color(int(data.average))
        lines = [
            f"§7--- §bPingSystem §7| §f{data.name} §7---",
            f"§7Current:  {color}{data.current} ms{COLOR_RESET}",
            f"§7Average:  {avg_c}{int(data.average)} ms{COLOR_RESET}",
            f"§7Min / Max: §a{data.minimum}§7 / §c{data.maximum} ms{COLOR_RESET}",
            f"§7Jitter:   §e{data.jitter:.1f} ms{COLOR_RESET}",
            f"§7Lag %:    §c{data.lag_percent(lag_threshold):.1f}%{COLOR_RESET}",
            f"§7Spikes:   §6{data.spike_count()}{COLOR_RESET}",
        ]
        if data.geo_country:
            lines.append(f"§7Country:  §f{data.geo_country}")
        if data.geo_isp:
            lines.append(f"§7ISP:      §f{data.geo_isp}")
        return "\n".join(lines)

    def admin_message(self, data: PlayerPingData, lag_threshold: int) -> str:
        """Extended stat for /admping — includes recent anomaly log."""
        base = self.stat_message(data, lag_threshold)
        events = data.recent_anomalies(10)
        if not events:
            return base + "\n§7No recent anomalies."

        import datetime
        lines = [base, "§7--- §cRecent Anomalies §7---"]
        for ev in reversed(events):
            dt = datetime.datetime.fromtimestamp(ev.timestamp).strftime("%H:%M:%S")
            dur = f" ({ev.duration:.1f}s)" if ev.duration else ""
            lines.append(f"§8[{dt}] §c{ev.kind}§7 {ev.ping}ms{dur}")
        return "\n".join(lines)
