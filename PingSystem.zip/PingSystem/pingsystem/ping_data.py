"""
Per-player ping data container.
Holds the ring buffer, anomaly log, style preference and geo info.
"""

from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

from .ring_buffer import RingBuffer


# ── Anomaly types ──────────────────────────────────────────────────────────── #
ANOMALY_SPIKE    = "SPIKE"
ANOMALY_HIGH     = "HIGH_PING"
ANOMALY_JITTER   = "JITTER"


@dataclass
class AnomalyEvent:
    timestamp: float
    ping: int
    kind: str          # SPIKE / HIGH_PING / JITTER
    duration: float    # seconds (for HIGH_PING); 0 for instant events

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "ping": self.ping,
            "type": self.kind,
            "duration": self.duration,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AnomalyEvent":
        return cls(
            timestamp=d.get("timestamp", 0.0),
            ping=d.get("ping", 0),
            kind=d.get("type", ANOMALY_SPIKE),
            duration=d.get("duration", 0.0),
        )


# ── Main data class ────────────────────────────────────────────────────────── #
@dataclass
class PlayerPingData:
    xuid: str
    name: str
    buffer: RingBuffer            = field(default_factory=lambda: RingBuffer(120))
    anomalies: List[AnomalyEvent] = field(default_factory=list)
    style: str                    = "1"   # style key from config
    geo_country: str              = ""
    geo_isp: str                  = ""
    # internal tracking
    high_ping_start: float        = 0.0   # monotonic time when HIGH_PING began
    last_update: float            = field(default_factory=time.monotonic)

    # ------------------------------------------------------------------ #
    # Convenience metrics
    # ------------------------------------------------------------------ #
    @property
    def current(self) -> int:
        return self.buffer.latest()

    @property
    def average(self) -> float:
        return self.buffer.average()

    @property
    def minimum(self) -> int:
        return self.buffer.minimum()

    @property
    def maximum(self) -> int:
        return self.buffer.maximum()

    @property
    def jitter(self) -> float:
        return self.buffer.jitter()

    def lag_percent(self, threshold: int) -> float:
        return self.buffer.lag_percent(threshold)

    def spike_count(self) -> int:
        return sum(1 for a in self.anomalies if a.kind == ANOMALY_SPIKE)

    def recent_anomalies(self, n: int = 10) -> List[AnomalyEvent]:
        return self.anomalies[-n:]

    # ------------------------------------------------------------------ #
    # Serialisation (offline persistence)
    # ------------------------------------------------------------------ #
    def to_dict(self) -> Dict[str, Any]:
        return {
            "xuid": self.xuid,
            "name": self.name,
            "history": self.buffer.to_list(),
            "anomalies": [a.to_dict() for a in self.anomalies[-200:]],
            "style": self.style,
            "geo_country": self.geo_country,
            "geo_isp": self.geo_isp,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any], capacity: int = 120) -> "PlayerPingData":
        obj = cls(
            xuid=d.get("xuid", ""),
            name=d.get("name", ""),
            style=d.get("style", "1"),
            geo_country=d.get("geo_country", ""),
            geo_isp=d.get("geo_isp", ""),
        )
        obj.buffer = RingBuffer.from_list(d.get("history", []), capacity)
        obj.anomalies = [AnomalyEvent.from_dict(a) for a in d.get("anomalies", [])]
        return obj
