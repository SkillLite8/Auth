"""
Command handlers for PingSystem.
Each function receives the Endstone CommandSender and the plugin reference.
"""

from __future__ import annotations
import logging
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from .plugin import PingSystemPlugin

log = logging.getLogger("PingSystem.commands")


# ── /pingstat ──────────────────────────────────────────────────────────────── #
def cmd_pingstat(sender, plugin: "PingSystemPlugin", args: List[str]) -> bool:
    """Show personal ping statistics."""
    # Works for players only
    if not hasattr(sender, "xuid"):
        sender.send_message("§cThis command is for players only.")
        return True

    data = plugin.player_store.get(sender.xuid)
    if data is None:
        sender.send_message("§cNo ping data yet. Wait a moment and try again.")
        _play_error(sender, plugin)
        return True

    msg = plugin.formatter.stat_message(data, plugin.cfg_thresholds["bad"])
    sender.send_message(msg)
    return True


# ── /pingdis ──────────────────────────────────────────────────────────────── #
def cmd_pingdis(sender, plugin: "PingSystemPlugin", args: List[str]) -> bool:
    """Choose personal nametag display style."""
    if not hasattr(sender, "xuid"):
        sender.send_message("§cThis command is for players only.")
        return True

    styles = plugin.config.get("styles", {})

    # No argument → show menu
    if not args:
        _play_gui(sender, plugin)
        lines = ["§7--- §bPingSystem §7| Select Display Style ---"]
        for key, style in styles.items():
            name   = style.get("name", key)
            fmt    = style.get("format", "")
            lines.append(f"§7  §e/pingdis {key}§7 — §f{name}§7 ({fmt})")
        sender.send_message("\n".join(lines))
        return True

    choice = args[0].strip()
    if choice not in styles:
        sender.send_message(f"§cUnknown style '{choice}'. Use /pingdis to see options.")
        _play_error(sender, plugin)
        return True

    data = plugin.player_store.get(sender.xuid)
    if data is None:
        sender.send_message("§cNo player data found.")
        return True

    data.style = choice
    style_name = styles[choice].get("name", choice)
    sender.send_message(f"§aDisplay style set to §f{style_name}§a.")
    _play_gui(sender, plugin)
    return True


# ── /admping ──────────────────────────────────────────────────────────────── #
def cmd_admping(sender, plugin: "PingSystemPlugin", args: List[str]) -> bool:
    """Admin: show full ping stats for a target player."""
    perm = plugin.config.get("permissions", {}).get("admin-command", "pingsystem.admin")
    if not sender.has_permission(perm):
        sender.send_message("§cYou don't have permission to use this command.")
        _play_error(sender, plugin)
        return True

    if not args:
        sender.send_message("§cUsage: /admping <player>")
        return True

    target_name = args[0].lower()
    data = None
    for d in plugin.player_store.values():
        if d.name.lower() == target_name:
            data = d
            break

    if data is None:
        sender.send_message(f"§cPlayer '{args[0]}' not found (must be online).")
        _play_error(sender, plugin)
        return True

    msg = plugin.formatter.admin_message(data, plugin.cfg_thresholds["bad"])
    sender.send_message(msg)
    return True


# ── Sound helpers ─────────────────────────────────────────────────────────── #
def _play_gui(sender, plugin: "PingSystemPlugin") -> None:
    if plugin.config.get("sounds", {}).get("gui-open", True):
        _play(sender, plugin, "gui-open")

def _play_error(sender, plugin: "PingSystemPlugin") -> None:
    if plugin.config.get("sounds", {}).get("error", True):
        _play(sender, plugin, "error")

def _play(sender, plugin: "PingSystemPlugin", key: str) -> None:
    sound = plugin.config.get("sounds", {}).get("sounds-map", {}).get(key, "")
    if sound and hasattr(sender, "play_sound"):
        try:
            sender.play_sound(sender.location, sound, 1.0, 1.0)
        except Exception:
            pass
