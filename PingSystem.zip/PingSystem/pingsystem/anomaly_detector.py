"""
Anomaly detector: analyses each new ping sample and records events.
Runs synchronously inside the scheduler thread — zero allocations on happy path.
"""

from __future__ import annotations
import time
from typing import Optional

from .ping_data import PlayerPingData, AnomalyEvent, ANOMALY_SPIKE, ANOMALY_HIGH, ANOMALY_JITTER


class AnomalyDetector:
    """
    Stateless helper — all state lives inside PlayerPingData.
    Call `analyse(data, new_ping, cfg_thresholds)` after every push.
    """

    # Max anomaly log entries kept in memory
    MAX_LOG = 500

    @classmethod
    def analyse(
        cls,
        data: PlayerPingData,
        new_ping: int,
        spike_threshold: int,
        jitter_threshold: int,
        high_threshold: int,
        high_duration: float,
        sound_cb=None,           # optional callable(player_name, event_type)
    ) -> Optional[str]:
        """
        Returns detected anomaly type string or None.
        side-effect: appends to data.anomalies, updates data.high_ping_start.
        """
        now = time.monotonic()
        avg = data.average         # computed before push — still valid
        prev = data.buffer.previous()
        detected: Optional[str] = None

        # ── 1. SPIKE ──────────────────────────────────────────────── #
        if avg > 0 and (new_ping - avg) > spike_threshold:
            detected = ANOMALY_SPIKE
            cls._log(data, new_ping, ANOMALY_SPIKE, 0.0)
            if sound_cb:
                sound_cb(data.name, ANOMALY_SPIKE)

        # ── 2. JITTER ─────────────────────────────────────────────── #
        elif prev > 0 and abs(new_ping - prev) > jitter_threshold:
            detected = ANOMALY_JITTER
            cls._log(data, new_ping, ANOMALY_JITTER, 0.0)

        # ── 3. HIGH PING (sustained) ──────────────────────────────── #
        if new_ping > high_threshold:
            if data.high_ping_start == 0.0:
                data.high_ping_start = now          # start timer
            elif (now - data.high_ping_start) >= high_duration:
                # emit HIGH_PING event once per period
                dur = now - data.high_ping_start
                cls._log(data, new_ping, ANOMALY_HIGH, dur)
                data.high_ping_start = now          # reset so we emit periodically
                if not detected:
                    detected = ANOMALY_HIGH
                if sound_cb:
                    sound_cb(data.name, ANOMALY_HIGH)
        else:
            data.high_ping_start = 0.0              # reset when ping drops

        return detected

    # ------------------------------------------------------------------ #
    @classmethod
    def _log(cls, data: PlayerPingData, ping: int, kind: str, dur: float) -> None:
        data.anomalies.append(AnomalyEvent(time.time(), ping, kind, dur))
        # trim to avoid unbounded growth in long sessions
        if len(data.anomalies) > cls.MAX_LOG:
            data.anomalies = data.anomalies[-cls.MAX_LOG:]
