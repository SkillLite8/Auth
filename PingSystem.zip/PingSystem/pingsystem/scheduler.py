"""
Lightweight async scheduler — runs the ping-update loop on a daemon thread.
Uses threading.Event for clean shutdown; no heavy asyncio overhead.

Design notes:
  - One thread per server (not per player).
  - Ping collection is O(1) ring buffer push.
  - Nametag updates are sent back to the main thread via a queue so Endstone
    API calls happen on the correct thread.
"""

from __future__ import annotations
import logging
import queue
import threading
import time
from typing import Any, Callable, Dict, Optional

log = logging.getLogger("PingSystem.scheduler")


class NametagUpdate:
    """Value object passed from scheduler thread → main thread handler."""
    __slots__ = ("xuid", "display_name")

    def __init__(self, xuid: str, display_name: str) -> None:
        self.xuid         = xuid
        self.display_name = display_name


class PingScheduler:
    """
    Runs *interval* seconds apart; calls *tick_fn* each cycle.
    *tick_fn(nametag_queue)* — receives a queue to push NametagUpdate items.
    """

    def __init__(self, interval: float, tick_fn: Callable[[queue.Queue], None]) -> None:
        self._interval  = max(0.5, interval)
        self._tick_fn   = tick_fn
        self._stop      = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.nametag_queue: queue.Queue = queue.Queue()

    # ------------------------------------------------------------------ #
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop,
            name="PingSystem-Scheduler",
            daemon=True,
        )
        self._thread.start()
        log.info("Scheduler started (interval=%.1fs)", self._interval)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        log.info("Scheduler stopped.")

    # ------------------------------------------------------------------ #
    def _loop(self) -> None:
        while not self._stop.is_set():
            t0 = time.monotonic()
            try:
                self._tick_fn(self.nametag_queue)
            except Exception as exc:
                log.exception("Scheduler tick error: %s", exc)
            elapsed = time.monotonic() - t0
            sleep   = max(0.0, self._interval - elapsed)
            self._stop.wait(timeout=sleep)

    # ------------------------------------------------------------------ #
    def drain_nametag_updates(self) -> list:
        """
        Drain all pending nametag updates (called from Endstone's tick/event).
        Returns list of NametagUpdate objects.
        """
        updates = []
        try:
            while True:
                updates.append(self.nametag_queue.get_nowait())
        except queue.Empty:
            pass
        return updates
