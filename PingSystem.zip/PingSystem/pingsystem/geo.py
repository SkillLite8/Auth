"""
Async geolocation lookup via ip-api.com (free tier, no key required).
Called once per player join; result stored in PlayerPingData.
"""

from __future__ import annotations
import logging
import threading
from typing import Callable, Optional, Tuple

log = logging.getLogger("PingSystem.geo")

# ip-api endpoint
_API = "http://ip-api.com/json/{ip}?fields=country,isp,status"


def lookup_async(
    ip: str,
    timeout: float,
    callback: Callable[[str, str], None],
) -> None:
    """
    Spawn a daemon thread to look up *ip*.
    Calls callback(country, isp) on success, callback("", "") on failure.
    Totally non-blocking for the server thread.
    """
    t = threading.Thread(
        target=_fetch,
        args=(ip, timeout, callback),
        daemon=True,
        name=f"PingGeo-{ip}",
    )
    t.start()


def _fetch(ip: str, timeout: float, callback: Callable[[str, str], None]) -> None:
    country, isp = "", ""
    try:
        import urllib.request
        url = _API.format(ip=ip)
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            import json
            data = json.loads(resp.read())
            if data.get("status") == "success":
                country = data.get("country", "")
                isp     = data.get("isp", "")
    except Exception as exc:
        log.debug("Geo lookup failed for %s: %s", ip, exc)
    callback(country, isp)
