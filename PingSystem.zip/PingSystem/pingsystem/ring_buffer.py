"""
O(1) ring buffer for ping history.
Stores up to `capacity` integer values; oldest values are overwritten.
"""

from __future__ import annotations
from typing import List


class RingBuffer:
    """Fixed-size circular buffer — O(1) push, O(n) stats."""

    __slots__ = ("_buf", "_capacity", "_head", "_size")

    def __init__(self, capacity: int) -> None:
        self._capacity: int = max(1, capacity)
        self._buf: List[int] = [0] * self._capacity
        self._head: int = 0      # next write position
        self._size: int = 0      # current number of valid entries

    # ------------------------------------------------------------------ #
    def push(self, value: int) -> None:
        self._buf[self._head] = value
        self._head = (self._head + 1) % self._capacity
        if self._size < self._capacity:
            self._size += 1

    # ------------------------------------------------------------------ #
    def values(self) -> List[int]:
        """Return values in insertion order (oldest → newest)."""
        if self._size == 0:
            return []
        if self._size < self._capacity:
            return self._buf[: self._size]
        # full buffer — read from head (oldest) wrapping around
        start = self._head
        return self._buf[start:] + self._buf[:start]

    # ------------------------------------------------------------------ #
    def latest(self) -> int:
        """Most recently pushed value, or 0 if empty."""
        if self._size == 0:
            return 0
        idx = (self._head - 1) % self._capacity
        return self._buf[idx]

    def previous(self) -> int:
        """Second-most-recently pushed value, or 0 if size < 2."""
        if self._size < 2:
            return 0
        idx = (self._head - 2) % self._capacity
        return self._buf[idx]

    # ------------------------------------------------------------------ #
    @property
    def size(self) -> int:
        return self._size

    @property
    def capacity(self) -> int:
        return self._capacity

    # ------------------------------------------------------------------ #
    def average(self) -> float:
        vals = self.values()
        return sum(vals) / len(vals) if vals else 0.0

    def minimum(self) -> int:
        vals = self.values()
        return min(vals) if vals else 0

    def maximum(self) -> int:
        vals = self.values()
        return max(vals) if vals else 0

    def jitter(self) -> float:
        """Mean absolute deviation between consecutive samples."""
        vals = self.values()
        if len(vals) < 2:
            return 0.0
        diffs = [abs(vals[i] - vals[i - 1]) for i in range(1, len(vals))]
        return sum(diffs) / len(diffs)

    def lag_percent(self, threshold: int) -> float:
        """Percentage of samples above *threshold* ms."""
        vals = self.values()
        if not vals:
            return 0.0
        above = sum(1 for v in vals if v > threshold)
        return round(above / len(vals) * 100, 1)

    def to_list(self) -> List[int]:
        return self.values()

    @classmethod
    def from_list(cls, data: List[int], capacity: int) -> "RingBuffer":
        buf = cls(capacity)
        for v in data[-capacity:]:
            buf.push(v)
        return buf
