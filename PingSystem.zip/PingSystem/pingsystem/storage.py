"""
Offline persistence: JSON backend (SQLite optional, same interface).
All I/O is synchronous but called only from the scheduler thread.
"""

from __future__ import annotations
import json
import os
import logging
from typing import Dict, Optional

from .ping_data import PlayerPingData

log = logging.getLogger("PingSystem.storage")


class JsonStorage:
    """Stores one JSON file per player in <data_dir>/players/."""

    def __init__(self, data_dir: str, buffer_capacity: int = 120) -> None:
        self._dir      = os.path.join(data_dir, "players")
        self._capacity = buffer_capacity
        os.makedirs(self._dir, exist_ok=True)

    # ------------------------------------------------------------------ #
    def _path(self, xuid: str) -> str:
        return os.path.join(self._dir, f"{xuid}.json")

    # ------------------------------------------------------------------ #
    def load(self, xuid: str) -> Optional[PlayerPingData]:
        path = self._path(xuid)
        if not os.path.isfile(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                d = json.load(f)
            return PlayerPingData.from_dict(d, self._capacity)
        except Exception as exc:
            log.warning("Failed to load data for %s: %s", xuid, exc)
            return None

    def save(self, data: PlayerPingData) -> None:
        path = self._path(data.xuid)
        tmp  = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data.to_dict(), f, separators=(",", ":"))
            os.replace(tmp, path)
        except Exception as exc:
            log.warning("Failed to save data for %s: %s", data.xuid, exc)

    def save_all(self, players: Dict[str, PlayerPingData]) -> None:
        for data in players.values():
            self.save(data)

    def delete(self, xuid: str) -> None:
        path = self._path(xuid)
        try:
            if os.path.isfile(path):
                os.remove(path)
        except Exception as exc:
            log.warning("Failed to delete data for %s: %s", xuid, exc)


# ── Factory ──────────────────────────────────────────────────────────────── #
def create_storage(storage_type: str, data_dir: str, capacity: int):
    if storage_type == "sqlite":
        try:
            from .storage_sqlite import SqliteStorage
            return SqliteStorage(data_dir, capacity)
        except ImportError:
            log.warning("SQLite storage requested but unavailable; falling back to JSON.")
    return JsonStorage(data_dir, capacity)
