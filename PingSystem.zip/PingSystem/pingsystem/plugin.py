"""
PingSystem — main Endstone plugin class.
Wires together: config, storage, formatter, anomaly detector, scheduler, commands.
"""

from __future__ import annotations
import logging
import os
import threading
import time
from typing import Dict, Optional

from endstone.plugin import Plugin
from endstone.event import EventPriority
from endstone.event.player import PlayerJoinEvent, PlayerQuitEvent, PlayerChatEvent
from endstone import ColorFormat

from .ping_data import PlayerPingData
from .ring_buffer import RingBuffer
from .formatter import PingFormatter
from .anomaly_detector import AnomalyDetector
from .scheduler import PingScheduler, NametagUpdate
from .storage import create_storage
from .commands import cmd_pingstat, cmd_pingdis, cmd_admping

log = logging.getLogger("PingSystem")


class PingSystemPlugin(Plugin):
    """Main plugin class registered with Endstone."""

    # ── Endstone metadata ────────────────────────────────────────────── #
    name        = "PingSystem"
    version     = "1.0.0"
    api_version = "0.10.5"
    description = "Advanced ping display, analytics and anomaly detection."
    authors     = ["PingSystem"]

    commands = {
        "pingstat": {
            "description": "Show your personal ping statistics.",
            "usages": ["/pingstat"],
            "permissions": ["pingsystem.player"],
        },
        "pingdis": {
            "description": "Choose your ping display style.",
            "usages": ["/pingdis [style]"],
            "permissions": ["pingsystem.style"],
        },
        "admping": {
            "description": "Admin: show full ping data for a player.",
            "usages": ["/admping <player>"],
            "permissions": ["pingsystem.admin"],
        },
    }

    permissions = {
        "pingsystem.player": {
            "description": "Use /pingstat",
            "default": True,
        },
        "pingsystem.style": {
            "description": "Use /pingdis",
            "default": True,
        },
        "pingsystem.admin": {
            "description": "Use /admping",
            "default": "op",
        },
    }

    # ================================================================== #
    def on_enable(self) -> None:
        self._load_config()
        self._init_storage()
        self._init_formatter()

        # In-memory player store: xuid → PlayerPingData
        self.player_store: Dict[str, PlayerPingData] = {}
        self._store_lock = threading.Lock()

        # Nametag format from config (used for players without personal style)
        self._default_format: str = self.config.get("ping", {}).get(
            "format", "%player% %ping_color%[%ping% ms]"
        )
        self._styles: Dict[str, dict] = self.config.get("styles", {})

        # Scheduler
        interval = float(self.config.get("update-interval", 2))
        self._scheduler = PingScheduler(interval, self._tick)
        self._scheduler.start()

        # Auto-save timer
        save_interval = int(
            self.config.get("storage", {}).get("save-interval", 60)
        )
        self._save_timer = _RepeatingTimer(save_interval, self._auto_save)
        self._save_timer.start()

        # Register events
        self.register_events(self)

        # Flush nametag updates every server tick via a lightweight repeating task
        # Endstone's scheduler runs on the main thread — safe for API calls.
        self.server.scheduler.run_task_timer(
            self,
            self._flush_nametag_updates,
            delay=20,   # 1 second
            period=20,
        )

        log.info("PingSystem %s enabled.", self.version)

    # ------------------------------------------------------------------ #
    def on_disable(self) -> None:
        if hasattr(self, "_scheduler"):
            self._scheduler.stop()
        if hasattr(self, "_save_timer"):
            self._save_timer.cancel()
        self._save_all()
        log.info("PingSystem disabled.")

    # ================================================================== #
    # Config helpers
    # ================================================================== #
    def _load_config(self) -> None:
        self.save_default_config()
        # cfg_thresholds: quick lookup dict
        thr = self.config.get("thresholds", {})
        self.cfg_thresholds = {
            "good":          int(thr.get("good",          50)),
            "medium":        int(thr.get("medium",        100)),
            "bad":           int(thr.get("bad",           200)),
            "spike":         int(thr.get("spike",         80)),
            "jitter":        int(thr.get("jitter",        40)),
            "high":          int(thr.get("high-ping",     200)),
            "high-duration": float(thr.get("high-duration", 5)),
        }
        self._buf_capacity = int(self.config.get("buffer-size", 120))
        self._geo_enabled  = bool(
            self.config.get("geolocation", {}).get("enabled", False)
        )
        self._geo_timeout  = float(
            self.config.get("geolocation", {}).get("timeout", 3)
        )
        self._lag_sound_enabled = bool(
            self.config.get("sounds", {}).get("lag-alert", True)
        )

    def _init_storage(self) -> None:
        storage_cfg = self.config.get("storage", {})
        stype       = storage_cfg.get("type", "json")
        data_dir    = os.path.join(self.data_folder, storage_cfg.get("data-dir", "data"))
        self._storage = create_storage(stype, data_dir, self._buf_capacity)

    def _init_formatter(self) -> None:
        self.formatter = PingFormatter(
            good   = self.cfg_thresholds["good"],
            medium = self.cfg_thresholds["medium"],
            bad    = self.cfg_thresholds["bad"],
        )

    # ================================================================== #
    # Event listeners
    # ================================================================== #
    @EventPriority.NORMAL
    def on_player_join(self, event: PlayerJoinEvent) -> None:
        player = event.player
        xuid   = player.xuid

        # Try loading saved data
        data = self._storage.load(xuid)
        if data is None:
            data = PlayerPingData(xuid=xuid, name=player.name,
                                  buffer=RingBuffer(self._buf_capacity))
        else:
            data.name = player.name  # update name in case of rename

        with self._store_lock:
            self.player_store[xuid] = data

        # Async geolocation
        if self._geo_enabled:
            self._start_geo(player, data)

        log.debug("Player joined: %s (%s)", player.name, xuid)

    @EventPriority.NORMAL
    def on_player_quit(self, event: PlayerQuitEvent) -> None:
        player = event.player
        xuid   = player.xuid
        with self._store_lock:
            data = self.player_store.pop(xuid, None)
        if data:
            self._storage.save(data)
        log.debug("Player left: %s", player.name)

    # ================================================================== #
    # Commands
    # ================================================================== #
    def on_command(self, sender, command, args) -> bool:
        name = command.name.lower()
        if name == "pingstat":
            return cmd_pingstat(sender, self, list(args))
        if name == "pingdis":
            return cmd_pingdis(sender, self, list(args))
        if name == "admping":
            return cmd_admping(sender, self, list(args))
        return False

    # ================================================================== #
    # Scheduler tick (runs on daemon thread)
    # ================================================================== #
    def _tick(self, nametag_queue) -> None:
        """
        Collect ping for all online players, run anomaly detection,
        enqueue nametag updates (applied on main thread).
        """
        try:
            online = {p.xuid: p for p in self.server.online_players}
        except Exception:
            return

        with self._store_lock:
            snapshot = dict(self.player_store)

        for xuid, player in online.items():
            data = snapshot.get(xuid)
            if data is None:
                continue

            try:
                ping = player.ping   # ms (int)
            except Exception:
                continue

            if ping < 0:
                ping = 0

            # Push to ring buffer
            data.buffer.push(ping)
            data.last_update = time.monotonic()

            # Anomaly detection
            sound_cb = self._sound_lag_alert if self._lag_sound_enabled else None
            AnomalyDetector.analyse(
                data,
                ping,
                spike_threshold = self.cfg_thresholds["spike"],
                jitter_threshold= self.cfg_thresholds["jitter"],
                high_threshold  = self.cfg_thresholds["high"],
                high_duration   = self.cfg_thresholds["high-duration"],
                sound_cb        = sound_cb,
            )

            # Resolve nametag for this player
            display = self._resolve_nametag(player, data)
            nametag_queue.put(NametagUpdate(xuid, display))

    # ================================================================== #
    # Nametag resolution
    # ================================================================== #
    def _resolve_nametag(self, player, data: PlayerPingData) -> str:
        """
        Each player has a personal style; resolve the format string.
        The full nametag = <playerName> <pingSuffix> (or custom if style uses %player%).
        """
        style_key = data.style
        style_cfg  = self._styles.get(style_key, {})
        fmt        = style_cfg.get("format", self._default_format)

        if "%player%" in fmt:
            # Format replaces entire nametag
            return self.formatter.format_nametag(data, fmt, player.name)
        else:
            # Append suffix to player name
            suffix = self.formatter.format_nametag(data, fmt)
            return self.formatter.format_full_name(player.name, data, suffix)

    # ================================================================== #
    # Flush nametag updates (main thread, called by Endstone task)
    # ================================================================== #
    def _flush_nametag_updates(self) -> None:
        updates = self._scheduler.drain_nametag_updates()
        if not updates:
            return

        xuid_map: Dict[str, str] = {u.xuid: u.display_name for u in updates}
        try:
            for player in self.server.online_players:
                name = xuid_map.get(player.xuid)
                if name is not None:
                    try:
                        player.name_tag = name
                    except Exception:
                        pass
        except Exception as exc:
            log.debug("Nametag flush error: %s", exc)

    # ================================================================== #
    # Geo
    # ================================================================== #
    def _start_geo(self, player, data: PlayerPingData) -> None:
        from .geo import lookup_async
        ip = str(player.address.hostname) if hasattr(player, "address") else ""
        if not ip or ip.startswith("127.") or ip == "::1":
            return

        def _cb(country: str, isp: str) -> None:
            data.geo_country = country
            data.geo_isp     = isp

        lookup_async(ip, self._geo_timeout, _cb)

    # ================================================================== #
    # Sound lag alert (called from scheduler daemon thread, deferred to main)
    # ================================================================== #
    def _sound_lag_alert(self, player_name: str, event_type: str) -> None:
        sound_key = "lag-alert"
        sounds_map = self.config.get("sounds", {}).get("sounds-map", {})
        sound      = sounds_map.get(sound_key, "note.bass")

        def _emit():
            try:
                for p in self.server.online_players:
                    if p.name == player_name and hasattr(p, "play_sound"):
                        p.play_sound(p.location, sound, 1.0, 1.0)
                        break
            except Exception:
                pass

        # Queue on main thread via Endstone's scheduler (0 delay)
        try:
            self.server.scheduler.run_task(self, _emit)
        except Exception:
            pass

    # ================================================================== #
    # Persistence helpers
    # ================================================================== #
    def _auto_save(self) -> None:
        with self._store_lock:
            snapshot = dict(self.player_store)
        self._storage.save_all(snapshot)
        log.debug("Auto-save: %d players.", len(snapshot))

    def _save_all(self) -> None:
        with self._store_lock:
            snapshot = dict(self.player_store)
        self._storage.save_all(snapshot)


# ── Simple repeating timer ────────────────────────────────────────────────── #
class _RepeatingTimer:
    def __init__(self, interval: float, fn) -> None:
        self._interval = interval
        self._fn = fn
        self._timer: Optional[threading.Timer] = None

    def start(self) -> None:
        self._schedule()

    def _schedule(self) -> None:
        self._timer = threading.Timer(self._interval, self._run)
        self._timer.daemon = True
        self._timer.start()

    def _run(self) -> None:
        try:
            self._fn()
        except Exception as exc:
            log.exception("RepeatingTimer error: %s", exc)
        self._schedule()

    def cancel(self) -> None:
        if self._timer:
            self._timer.cancel()
