"""
PingSystem — Advanced ping display & analytics plugin for Endstone.
Entry point: exposes the Plugin class.
"""

from .plugin import PingSystemPlugin

__all__ = ["PingSystemPlugin"]
