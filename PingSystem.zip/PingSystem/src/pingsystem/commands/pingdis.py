"""
PingSystem - /pingdis command
Lets the player choose their personal ping display style.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from endstone.command import Command, CommandSender

if TYPE_CHECKING:
    from ..plugin import PingSystemPlugin


class PingDisCommand:
    def __init__(self, plugin: "PingSystemPlugin") -> None:
        self._plugin = plugin

    def execute(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        cfg = self._plugin.config
        prefix = cfg.get("messages.prefix", "§8[§bPing§8] §r")

        if not hasattr(sender, "xuid"):
            sender.send_message(f"{prefix}§cThis command can only be used by players.")
            return True

        player = sender
        xuid = player.xuid

        styles_def: dict = cfg.get("styles.definitions", {})
        available = list(styles_def.keys())

        # No arg → show menu
        if not args:
            self._show_menu(sender, player, styles_def, available, prefix)
            if cfg.get("sounds.gui-open", True):
                try:
                    player.play_sound(player.location, "random.click", 0.6, 1.1)
                except Exception:
                    pass
            return True

        # Arg provided → set style
        chosen = args[0].lower()
        if chosen not in available:
            invalid_msg = cfg.get("messages.style-invalid", "§cInvalid style. Available: %styles%")
            sender.send_message(f"{prefix}{invalid_msg.replace('%styles%', ', '.join(available))}")
            if cfg.get("sounds.error", True):
                try:
                    player.play_sound(player.location, "note.bass", 0.5, 0.5)
                except Exception:
                    pass
            return True

        self._plugin.ping_manager.set_style(xuid, chosen)
        changed_msg = cfg.get("messages.style-changed", "§aDisplay style changed to: §e%style%")
        sender.send_message(f"{prefix}{changed_msg.replace('%style%', chosen)}")

        if cfg.get("sounds.gui-open", True):
            try:
                player.play_sound(player.location, "random.orb", 0.5, 1.5)
            except Exception:
                pass

        # Show preview
        ping = player.ping
        preview_fmt = styles_def.get(chosen, {}).get("format", "[%ping% ms]")
        preview = (
            preview_fmt
            .replace("%ping%",       str(ping))
            .replace("%ping_avg%",   str(ping))
            .replace("%ping_color%", "§a")
            .replace("%ping_icon%",  "●●●●")
        )
        sender.send_message(f"  §7Preview: §f{preview}")
        return True

    def _show_menu(self, sender, player, styles_def: dict, available: list, prefix: str) -> None:
        current = self._plugin.ping_manager.get_style(player.xuid)
        ping = player.ping
        sep = f"§8{'─' * 30}"

        sender.send_message(f"")
        sender.send_message(f"{prefix}§bPing Display Styles")
        sender.send_message(sep)

        for sid in available:
            info = styles_def.get(sid, {})
            fmt  = info.get("format", "[%ping% ms]")
            desc = info.get("description", "")
            preview = (
                fmt
                .replace("%ping%",       str(ping))
                .replace("%ping_avg%",   str(ping))
                .replace("%ping_color%", "§a")
                .replace("%ping_icon%",  "●●●●")
            )
            marker = "§a▶ " if sid == current else "  "
            sender.send_message(f"{marker}§e{sid}§8: §f{preview}  §8({desc})")

        sender.send_message(sep)
        sender.send_message(f"  §7Usage: §f/pingdis §e<style>")
        sender.send_message(f"")
