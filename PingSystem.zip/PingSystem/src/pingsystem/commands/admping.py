"""
PingSystem - /admping command
Admin command: full statistics for any player.
"""

from __future__ import annotations

from time import time
from typing import TYPE_CHECKING

from endstone import ColorFormat
from endstone.command import Command, CommandSender

if TYPE_CHECKING:
    from ..plugin import PingSystemPlugin


class AdminPingCommand:
    def __init__(self, plugin: "PingSystemPlugin") -> None:
        self._plugin = plugin

    def execute(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        cfg = self._plugin.config
        prefix = cfg.get("messages.prefix", "§8[§bPing§8] §r")

        if not args:
            sender.send_message(f"{prefix}§cUsage: /admping <player>")
            return True

        target_name = args[0]
        target = self._find_player(target_name)

        if target is None:
            msg = cfg.get("messages.player-not-found", "§cPlayer not found: %player%")
            sender.send_message(f"{prefix}{msg.replace('%player%', target_name)}")
            return True

        xuid  = target.xuid
        ping  = target.ping
        stats = self._plugin.ping_manager.get_stats(xuid)

        if stats is None:
            sender.send_message(f"{prefix}§cNo data for {target.name}.")
            return True

        c = self._ping_color(ping)
        sep = f"§8{'═' * 34}"
        sep2 = f"§8{'─' * 34}"

        sender.send_message(f"")
        sender.send_message(f"{prefix}§bAdmin Ping Report §8— §e{target.name}")
        sender.send_message(sep)
        sender.send_message(f"  §7XUID     §8│ §f{xuid}")
        sender.send_message(f"  §7Current  §8│ {c}{ping} ms§r")
        sender.send_message(f"  §7Average  §8│ §f{stats['avg']} ms")
        sender.send_message(f"  §7Min/Max  §8│ §a{stats['min']}§8/§c{stats['max']} ms")
        sender.send_message(f"  §7Jitter   §8│ §e{stats['jitter']} ms")
        sender.send_message(f"  §7Lag %    §8│ {'§c' if stats['lag_pct'] > 20 else '§a'}{stats['lag_pct']}%")
        sender.send_message(f"  §7Spikes   §8│ {'§c' if stats['spikes'] > 5 else '§a'}{stats['spikes']}")

        if stats.get("country"):
            sender.send_message(sep2)
            sender.send_message(f"  §7Country  §8│ §f{stats['country']}")
            if stats.get("isp"):
                sender.send_message(f"  §7ISP      §8│ §f{stats['isp']}")

        # Anomaly history
        anomalies = stats.get("anomalies", [])
        if anomalies:
            sender.send_message(sep2)
            sender.send_message(f"  §7Anomaly Log §8(last {min(10, len(anomalies))}):")
            for ev in reversed(anomalies[-10:]):
                age = time() - ev.timestamp
                age_str = f"{int(age)}s ago"
                dur = f" dur:{ev.duration:.1f}s" if ev.duration > 0 else ""
                type_color = "§c" if ev.type.value in ("SPIKE", "HIGH_PING") else "§e"
                sender.send_message(
                    f"    {type_color}{ev.type.value}§8 @ §f{ev.ping}ms "
                    f"§8(avg {ev.avg_at_detection:.0f}ms{dur}) §8{age_str}"
                )
        else:
            sender.send_message(sep2)
            sender.send_message(f"  §aNo anomalies detected this session.")

        sender.send_message(sep)
        sender.send_message(f"")
        return True

    def _find_player(self, name: str):
        for p in self._plugin.server.online_players:
            if p.name.lower() == name.lower():
                return p
        return None

    def _ping_color(self, ping: int) -> str:
        cfg = self._plugin.config
        if ping <= int(cfg.get("thresholds.good",   50)):  return ColorFormat.GREEN
        if ping <= int(cfg.get("thresholds.medium", 100)): return ColorFormat.YELLOW
        if ping <= int(cfg.get("thresholds.high",   200)): return ColorFormat.GOLD
        return ColorFormat.RED
