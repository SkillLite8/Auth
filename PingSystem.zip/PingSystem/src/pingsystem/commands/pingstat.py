"""
PingSystem - /pingstat command
Shows personal ping statistics to the player.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from endstone import ColorFormat
from endstone.command import Command, CommandSender

if TYPE_CHECKING:
    from ..plugin import PingSystemPlugin


def _bar(value: float, max_val: float = 100.0, width: int = 10) -> str:
    filled = max(0, min(width, round((value / max_val) * width)))
    return ColorFormat.GREEN + "█" * filled + ColorFormat.DARK_GRAY + "░" * (width - filled) + ColorFormat.RESET


class PingStatCommand:
    def __init__(self, plugin: "PingSystemPlugin") -> None:
        self._plugin = plugin

    def execute(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        cfg = self._plugin.config
        prefix = cfg.get("messages.prefix", "§8[§bPing§8] §r")

        # Must be a player
        if not hasattr(sender, "xuid"):
            sender.send_message(f"{prefix}§cThis command can only be used by players.")
            return True

        player = sender
        xuid = player.xuid
        ping = player.ping

        stats = self._plugin.ping_manager.get_stats(xuid)
        if stats is None:
            sender.send_message(f"{prefix}§cNo ping data available yet.")
            return True

        color = self._ping_color(ping)
        avg_color = self._ping_color(int(stats["avg"]))
        sep = f"§8{'─' * 32}"

        lines = [
            f"",
            f"{prefix}§bYour Ping Statistics",
            sep,
            f"  §7Current  §f: {color}{ping} ms§r",
            f"  §7Average  §f: {avg_color}{stats['avg']} ms§r  {_bar(stats['avg'], 300, 8)}",
            f"  §7Min/Max  §f: §a{stats['min']}§7 / §c{stats['max']} ms",
            f"  §7Jitter   §f: §e{stats['jitter']} ms",
            f"  §7Lag %    §f: {'§c' if stats['lag_pct'] > 20 else '§a'}{stats['lag_pct']}%",
            f"  §7Spikes   §f: {'§c' if stats['spikes'] > 3 else '§a'}{stats['spikes']}",
            sep,
            f"  §7Style    §f: §d{stats['style']}  §8(use /pingdis to change)",
        ]

        if stats.get("country"):
            lines.append(f"  §7Location §f: §f{stats['country']}  §7{stats.get('isp', '')}")

        recent = [a for a in stats["anomalies"][-5:]]
        if recent:
            lines.append(sep)
            lines.append(f"  §7Recent anomalies:")
            for ev in reversed(recent):
                lines.append(f"    §c{ev.type.value} §8@ §f{ev.ping}ms")

        lines.append(f"")
        for line in lines:
            sender.send_message(line)

        # Sound feedback
        if cfg.get("sounds.gui-open", True):
            try:
                player.play_sound(player.location, "random.click", 0.6, 1.2)
            except Exception:
                pass

        return True

    def _ping_color(self, ping: int) -> str:
        cfg = self._plugin.config
        if ping <= int(cfg.get("thresholds.good",   50)):  return ColorFormat.GREEN
        if ping <= int(cfg.get("thresholds.medium", 100)): return ColorFormat.YELLOW
        if ping <= int(cfg.get("thresholds.high",   200)): return ColorFormat.GOLD
        return ColorFormat.RED
