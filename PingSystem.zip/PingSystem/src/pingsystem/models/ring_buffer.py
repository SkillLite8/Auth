"""
PingSystem - RingBuffer
O(1) insertion, efficient circular buffer for ping history.
"""

from __future__ import annotations
from typing import List, Optional


class RingBuffer:
    """
    Fixed-size circular buffer for storing ping samples.
    All operations are O(1) except statistics which are O(n).
    """

    __slots__ = ("_data", "_size", "_head", "_count")

    def __init__(self, size: int = 120) -> None:
        self._size: int = size
        self._data: List[Optional[int]] = [None] * size
        self._head: int = 0
        self._count: int = 0

    def push(self, value: int) -> None:
        """Insert a new ping value (O(1))."""
        self._data[self._head] = value
        self._head = (self._head + 1) % self._size
        if self._count < self._size:
            self._count += 1

    def get_all(self) -> List[int]:
        """Return all stored values in insertion order."""
        if self._count == 0:
            return []
        if self._count < self._size:
            # Buffer not yet full — start from index 0
            return [v for v in self._data[: self._count] if v is not None]
        # Full buffer — oldest is at _head
        result: List[int] = []
        idx = self._head
        for _ in range(self._size):
            v = self._data[idx]
            if v is not None:
                result.append(v)
            idx = (idx + 1) % self._size
        return result

    def latest(self, n: int = 10) -> List[int]:
        """Return the n most recent values."""
        return self.get_all()[-n:]

    @property
    def count(self) -> int:
        return self._count

    @property
    def is_empty(self) -> bool:
        return self._count == 0

    def clear(self) -> None:
        self._data = [None] * self._size
        self._head = 0
        self._count = 0

    # ------------------------------------------------------------------
    # Statistics (O(n))
    # ------------------------------------------------------------------

    def average(self) -> float:
        values = self.get_all()
        return sum(values) / len(values) if values else 0.0

    def minimum(self) -> int:
        values = self.get_all()
        return min(values) if values else 0

    def maximum(self) -> int:
        values = self.get_all()
        return max(values) if values else 0

    def jitter(self) -> float:
        """Mean absolute deviation between consecutive samples."""
        values = self.get_all()
        if len(values) < 2:
            return 0.0
        diffs = [abs(values[i] - values[i - 1]) for i in range(1, len(values))]
        return sum(diffs) / len(diffs)

    def lag_percent(self, threshold: int = 200) -> float:
        """Percentage of samples above the high-ping threshold."""
        values = self.get_all()
        if not values:
            return 0.0
        above = sum(1 for v in values if v >= threshold)
        return (above / len(values)) * 100.0

    def spike_count(self, threshold_delta: int = 80) -> int:
        """Count samples that exceed average by threshold_delta."""
        values = self.get_all()
        if len(values) < 2:
            return 0
        avg = sum(values) / len(values)
        return sum(1 for v in values if v > avg + threshold_delta)
