"""
PingSystem - Data Models
Anomaly events, ping snapshots, and player ping data.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from time import time
from typing import List, Optional


class AnomalyType(str, Enum):
    SPIKE = "SPIKE"
    HIGH_PING = "HIGH_PING"
    JITTER = "JITTER"


@dataclass
class AnomalyEvent:
    """Represents a detected network anomaly."""
    type: AnomalyType
    ping: int
    timestamp: float = field(default_factory=time)
    duration: float = 0.0          # seconds (for HIGH_PING)
    avg_at_detection: float = 0.0

    def to_dict(self) -> dict:
        return {
            "type": self.type.value,
            "ping": self.ping,
            "timestamp": self.timestamp,
            "duration": self.duration,
            "avg": round(self.avg_at_detection, 1),
        }

    @staticmethod
    def from_dict(d: dict) -> "AnomalyEvent":
        return AnomalyEvent(
            type=AnomalyType(d["type"]),
            ping=d["ping"],
            timestamp=d.get("timestamp", 0),
            duration=d.get("duration", 0),
            avg_at_detection=d.get("avg", 0),
        )


@dataclass
class PingSnapshot:
    """Point-in-time statistics snapshot saved for offline storage."""
    xuid: str
    name: str
    last_ping: int
    avg: float
    min_ping: int
    max_ping: int
    jitter: float
    lag_percent: float
    spike_count: int
    session_start: float = field(default_factory=time)
    session_end: float = field(default_factory=time)
    anomalies: List[AnomalyEvent] = field(default_factory=list)
    display_style: str = "brackets"
    country: str = ""
    isp: str = ""

    def to_dict(self) -> dict:
        return {
            "xuid": self.xuid,
            "name": self.name,
            "last_ping": self.last_ping,
            "avg": round(self.avg, 1),
            "min": self.min_ping,
            "max": self.max_ping,
            "jitter": round(self.jitter, 1),
            "lag_pct": round(self.lag_percent, 1),
            "spikes": self.spike_count,
            "session_start": self.session_start,
            "session_end": self.session_end,
            "anomalies": [a.to_dict() for a in self.anomalies[-50:]],
            "style": self.display_style,
            "country": self.country,
            "isp": self.isp,
        }

    @staticmethod
    def from_dict(d: dict) -> "PingSnapshot":
        snap = PingSnapshot(
            xuid=d.get("xuid", ""),
            name=d.get("name", ""),
            last_ping=d.get("last_ping", 0),
            avg=d.get("avg", 0.0),
            min_ping=d.get("min", 0),
            max_ping=d.get("max", 0),
            jitter=d.get("jitter", 0.0),
            lag_percent=d.get("lag_pct", 0.0),
            spike_count=d.get("spikes", 0),
            session_start=d.get("session_start", 0),
            session_end=d.get("session_end", 0),
            display_style=d.get("style", "brackets"),
            country=d.get("country", ""),
            isp=d.get("isp", ""),
        )
        snap.anomalies = [AnomalyEvent.from_dict(a) for a in d.get("anomalies", [])]
        return snap


@dataclass
class LivePlayerData:
    """In-memory runtime data for an online player."""
    xuid: str
    name: str
    display_style: str = "brackets"
    country: str = ""
    isp: str = ""
    geo_loaded: bool = False

    # Anomaly tracking
    anomalies: List[AnomalyEvent] = field(default_factory=list)
    high_ping_start: Optional[float] = None   # timestamp when high ping started
    last_lag_alert: float = 0.0               # for alert cooldown

    def record_anomaly(self, event: AnomalyEvent) -> None:
        self.anomalies.append(event)
        # Keep last 200 in memory
        if len(self.anomalies) > 200:
            self.anomalies = self.anomalies[-200:]
