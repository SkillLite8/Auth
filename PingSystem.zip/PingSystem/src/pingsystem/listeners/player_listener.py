"""
PingSystem - Event Listeners
Handles player join, quit, and chat events.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from endstone.event import EventPriority
from endstone.event.player import PlayerJoinEvent, PlayerQuitEvent

if TYPE_CHECKING:
    from ..plugin import PingSystemPlugin


class PingEventListener:
    def __init__(self, plugin: "PingSystemPlugin") -> None:
        self._plugin = plugin

    # Endstone calls this via registration
    def on_player_join(self, event: PlayerJoinEvent) -> None:
        player = event.player
        self._plugin.ping_manager.on_player_join(player)
        self._plugin.logger.info(
            f"[PingSystem] Tracking ping for {player.name} (xuid={player.xuid})"
        )

    def on_player_quit(self, event: PlayerQuitEvent) -> None:
        player = event.player
        self._plugin.ping_manager.on_player_quit(player)
