"""
PingSystem - StorageManager
Offline persistence: JSON (default) or SQLite backend.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
from typing import Optional, TYPE_CHECKING

from ..models.data import PingSnapshot

if TYPE_CHECKING:
    from ..plugin import PingSystemPlugin


class StorageManager:
    def __init__(self, plugin: "PingSystemPlugin") -> None:
        self._plugin = plugin
        self._lock = threading.Lock()
        cfg = plugin.config
        self._type = cfg.get("storage.type", "json")
        data_dir = cfg.get("storage.data-dir", "data")

        # Resolve path relative to plugin data folder
        base = getattr(plugin, "data_folder", "plugins/PingSystem")
        self._data_dir = os.path.join(base, data_dir)
        os.makedirs(self._data_dir, exist_ok=True)

        if self._type == "sqlite":
            self._db_path = os.path.join(self._data_dir, "pingsystem.db")
            self._init_sqlite()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self, xuid: str) -> Optional[PingSnapshot]:
        try:
            if self._type == "sqlite":
                return self._load_sqlite(xuid)
            return self._load_json(xuid)
        except Exception as e:
            self._plugin.logger.warning(f"[Storage] Load error for {xuid}: {e}")
            return None

    def save(self, xuid: str, snapshot: PingSnapshot) -> None:
        try:
            if self._type == "sqlite":
                self._save_sqlite(xuid, snapshot)
            else:
                self._save_json(xuid, snapshot)
        except Exception as e:
            self._plugin.logger.warning(f"[Storage] Save error for {xuid}: {e}")

    # ------------------------------------------------------------------
    # JSON backend
    # ------------------------------------------------------------------

    def _json_path(self, xuid: str) -> str:
        return os.path.join(self._data_dir, f"{xuid}.json")

    def _load_json(self, xuid: str) -> Optional[PingSnapshot]:
        path = self._json_path(xuid)
        if not os.path.exists(path):
            return None
        with self._lock:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        return PingSnapshot.from_dict(data)

    def _save_json(self, xuid: str, snapshot: PingSnapshot) -> None:
        path = self._json_path(xuid)
        with self._lock:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(snapshot.to_dict(), f, ensure_ascii=False, indent=2)

    # ------------------------------------------------------------------
    # SQLite backend
    # ------------------------------------------------------------------

    def _init_sqlite(self) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS player_data (
                    xuid        TEXT PRIMARY KEY,
                    name        TEXT,
                    data        TEXT,
                    updated_at  REAL
                )
            """)
            conn.commit()

    def _load_sqlite(self, xuid: str) -> Optional[PingSnapshot]:
        with self._lock:
            with sqlite3.connect(self._db_path) as conn:
                row = conn.execute(
                    "SELECT data FROM player_data WHERE xuid = ?", (xuid,)
                ).fetchone()
        if not row:
            return None
        return PingSnapshot.from_dict(json.loads(row[0]))

    def _save_sqlite(self, xuid: str, snapshot: PingSnapshot) -> None:
        from time import time
        payload = json.dumps(snapshot.to_dict(), ensure_ascii=False)
        with self._lock:
            with sqlite3.connect(self._db_path) as conn:
                conn.execute("""
                    INSERT INTO player_data (xuid, name, data, updated_at)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(xuid) DO UPDATE SET
                        name = excluded.name,
                        data = excluded.data,
                        updated_at = excluded.updated_at
                """, (xuid, snapshot.name, payload, time()))
                conn.commit()
