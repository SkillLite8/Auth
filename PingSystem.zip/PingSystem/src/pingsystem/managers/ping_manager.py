"""
PingSystem - PingManager
Core manager: collects ping, computes stats, detects anomalies,
formats nametags, and dispatches updates.
"""

from __future__ import annotations

import threading
from time import time
from typing import Dict, Optional, TYPE_CHECKING

from endstone import ColorFormat
from endstone.scheduler import Task

from ..models.ring_buffer import RingBuffer
from ..models.data import AnomalyEvent, AnomalyType, LivePlayerData, PingSnapshot

if TYPE_CHECKING:
    from endstone.server import Server
    from endstone.player import Player
    from ..plugin import PingSystemPlugin


# Color codes mapped to ping thresholds
_PING_COLORS = {
    "good":   ColorFormat.GREEN,        # §a
    "medium": ColorFormat.YELLOW,       # §e
    "high":   ColorFormat.GOLD,         # §6
    "bad":    ColorFormat.RED,          # §c
}

_DOT_FULL  = "●"
_DOT_EMPTY = "○"


class PingManager:
    """
    Manages per-player ping data, anomaly detection, and nametag formatting.
    Thread-safe for async operations.
    """

    def __init__(self, plugin: "PingSystemPlugin") -> None:
        self._plugin = plugin
        self._server: Server = plugin.server
        self._lock = threading.RLock()

        # xuid -> RingBuffer
        self._buffers: Dict[str, RingBuffer] = {}
        # xuid -> LivePlayerData
        self._live: Dict[str, LivePlayerData] = {}

        self._update_task: Optional[Task] = None
        self._session_starts: Dict[str, float] = {}

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        cfg = self._plugin.config
        interval_ticks = max(20, int(cfg.get("update-interval", 2)) * 20)
        self._update_task = self._plugin.server.scheduler.run_task_timer(
            self._plugin, self._tick, 20, interval_ticks
        )

    def stop(self) -> None:
        if self._update_task:
            self._update_task.cancel()
            self._update_task = None

    # ------------------------------------------------------------------
    # Player session management
    # ------------------------------------------------------------------

    def on_player_join(self, player) -> None:
        xuid = player.xuid
        cfg = self._plugin.config
        buf_size = int(cfg.get("buffer.size", 120))

        with self._lock:
            # Load saved style from storage
            saved = self._plugin.storage_manager.load(xuid)
            style = saved.display_style if saved else cfg.get("styles.default", "brackets")

            self._buffers[xuid] = RingBuffer(buf_size)
            self._live[xuid] = LivePlayerData(
                xuid=xuid,
                name=player.name,
                display_style=style,
                country=saved.country if saved else "",
                isp=saved.isp if saved else "",
            )
            self._session_starts[xuid] = time()

        # Async geolocation
        if self._plugin.config.get("geolocation.enabled", False):
            self._plugin.server.scheduler.run_task_async(
                self._plugin,
                lambda: self._load_geo(player)
            )

    def on_player_quit(self, player) -> None:
        xuid = player.xuid
        with self._lock:
            snapshot = self._build_snapshot(xuid, player.name)
            if snapshot:
                self._plugin.storage_manager.save(xuid, snapshot)
            self._buffers.pop(xuid, None)
            self._live.pop(xuid, None)
            self._session_starts.pop(xuid, None)

    # ------------------------------------------------------------------
    # Core tick — runs every update-interval seconds
    # ------------------------------------------------------------------

    def _tick(self) -> None:
        try:
            for player in list(self._server.online_players):
                xuid = player.xuid
                ping = player.ping  # ms, provided by Endstone

                with self._lock:
                    buf = self._buffers.get(xuid)
                    live = self._live.get(xuid)
                    if buf is None or live is None:
                        continue

                    buf.push(ping)
                    self._detect_anomalies(player, buf, live, ping)

                # Update nametag (must be on main thread — scheduler ensures this)
                self._update_nametag(player)
        except Exception as e:
            self._plugin.logger.error(f"[PingManager] Tick error: {e}")

    # ------------------------------------------------------------------
    # Anomaly Detection
    # ------------------------------------------------------------------

    def _detect_anomalies(self, player, buf: RingBuffer, live: LivePlayerData, ping: int) -> None:
        cfg = self._plugin.config
        spike_delta  = int(cfg.get("thresholds.spike",  80))
        jitter_thr   = int(cfg.get("thresholds.jitter", 40))
        high_thr     = int(cfg.get("thresholds.high-ping", 200))
        high_dur     = float(cfg.get("thresholds.high-ping-duration", 10))
        alert_cd     = float(cfg.get("sounds.lag-alert-cooldown", 30))
        now          = time()

        avg = buf.average()

        # SPIKE
        if avg > 0 and ping > avg + spike_delta:
            evt = AnomalyEvent(type=AnomalyType.SPIKE, ping=ping, avg_at_detection=avg)
            live.record_anomaly(evt)
            self._maybe_alert(player, live, now, alert_cd)

        # HIGH PING sustained
        if ping >= high_thr:
            if live.high_ping_start is None:
                live.high_ping_start = now
            elif now - live.high_ping_start >= high_dur:
                duration = now - live.high_ping_start
                evt = AnomalyEvent(
                    type=AnomalyType.HIGH_PING,
                    ping=ping,
                    avg_at_detection=avg,
                    duration=duration,
                )
                live.record_anomaly(evt)
                live.high_ping_start = now   # reset to avoid spam
                self._maybe_alert(player, live, now, alert_cd)
        else:
            live.high_ping_start = None

        # JITTER
        if buf.jitter() > jitter_thr and buf.count >= 5:
            evt = AnomalyEvent(type=AnomalyType.JITTER, ping=ping, avg_at_detection=avg)
            live.record_anomaly(evt)

    def _maybe_alert(self, player, live: LivePlayerData, now: float, cooldown: float) -> None:
        if not self._plugin.config.get("sounds.lag-alert", True):
            return
        if now - live.last_lag_alert < cooldown:
            return
        live.last_lag_alert = now
        try:
            player.play_sound(player.location, "random.orb", 1.0, 0.5)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Nametag formatting
    # ------------------------------------------------------------------

    def _update_nametag(self, player) -> None:
        try:
            xuid = player.xuid
            with self._lock:
                buf  = self._buffers.get(xuid)
                live = self._live.get(xuid)
                if buf is None or live is None:
                    return
                ping     = player.ping
                avg      = buf.average()
                mn       = buf.minimum()
                mx       = buf.maximum()
                style_id = live.display_style

            tag = self._format_tag(player.name, ping, avg, mn, mx, style_id)
            player.name_tag = tag
        except Exception as e:
            self._plugin.logger.warning(f"[PingManager] Nametag error for {player.name}: {e}")

    def _format_tag(
        self,
        name: str,
        ping: int,
        avg: float,
        mn: int,
        mx: int,
        style_id: str,
    ) -> str:
        cfg = self._plugin.config
        color = self._ping_color(ping)
        icon  = self._ping_icon(ping)

        styles_def = cfg.get("styles.definitions", {})
        style_fmt  = (
            styles_def.get(style_id, {}).get("format")
            or cfg.get("styles.definitions.brackets.format", "[%ping% ms]")
        )

        suffix = (
            style_fmt
            .replace("%ping%",       str(ping))
            .replace("%ping_avg%",   str(round(avg)))
            .replace("%ping_min%",   str(mn))
            .replace("%ping_max%",   str(mx))
            .replace("%ping_color%", color)
            .replace("%ping_icon%",  icon)
        )

        base_fmt = cfg.get("ping.format", "%player% %ping_color%[%ping% ms]")
        return (
            base_fmt
            .replace("%player%",     name)
            .replace("%ping%",       str(ping))
            .replace("%ping_avg%",   str(round(avg)))
            .replace("%ping_min%",   str(mn))
            .replace("%ping_max%",   str(mx))
            .replace("%ping_color%", color)
            .replace("%ping_icon%",  icon)
        ).replace("[%ping% ms]", suffix)  # allow style override

    def _ping_color(self, ping: int) -> str:
        cfg = self._plugin.config
        if ping <= int(cfg.get("thresholds.good",   50)):  return ColorFormat.GREEN
        if ping <= int(cfg.get("thresholds.medium", 100)): return ColorFormat.YELLOW
        if ping <= int(cfg.get("thresholds.high",   200)): return ColorFormat.GOLD
        return ColorFormat.RED

    def _ping_icon(self, ping: int) -> str:
        cfg = self._plugin.config
        if ping <= int(cfg.get("thresholds.good",   50)):  return f"{_DOT_FULL}{_DOT_FULL}{_DOT_FULL}{_DOT_FULL}"
        if ping <= int(cfg.get("thresholds.medium", 100)): return f"{_DOT_FULL}{_DOT_FULL}{_DOT_FULL}{_DOT_EMPTY}"
        if ping <= int(cfg.get("thresholds.high",   200)): return f"{_DOT_FULL}{_DOT_FULL}{_DOT_EMPTY}{_DOT_EMPTY}"
        return f"{_DOT_FULL}{_DOT_EMPTY}{_DOT_EMPTY}{_DOT_EMPTY}"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_stats(self, xuid: str) -> Optional[dict]:
        with self._lock:
            buf  = self._buffers.get(xuid)
            live = self._live.get(xuid)
            if buf is None or live is None:
                return None
            cfg = self._plugin.config
            return {
                "ping":        0,   # caller should use player.ping
                "avg":         round(buf.average(), 1),
                "min":         buf.minimum(),
                "max":         buf.maximum(),
                "jitter":      round(buf.jitter(), 1),
                "lag_pct":     round(buf.lag_percent(int(cfg.get("thresholds.high-ping", 200))), 1),
                "spikes":      buf.spike_count(int(cfg.get("thresholds.spike", 80))),
                "anomalies":   list(live.anomalies),
                "style":       live.display_style,
                "country":     live.country,
                "isp":         live.isp,
            }

    def set_style(self, xuid: str, style: str) -> bool:
        with self._lock:
            live = self._live.get(xuid)
            if live is None:
                return False
            live.display_style = style
            return True

    def get_style(self, xuid: str) -> str:
        with self._lock:
            live = self._live.get(xuid)
            return live.display_style if live else "brackets"

    # ------------------------------------------------------------------
    # Snapshot builder (for offline save)
    # ------------------------------------------------------------------

    def _build_snapshot(self, xuid: str, name: str) -> Optional[PingSnapshot]:
        buf  = self._buffers.get(xuid)
        live = self._live.get(xuid)
        if buf is None or live is None:
            return None
        cfg = self._plugin.config
        return PingSnapshot(
            xuid=xuid,
            name=name,
            last_ping=buf.latest(1)[0] if buf.count > 0 else 0,
            avg=buf.average(),
            min_ping=buf.minimum(),
            max_ping=buf.maximum(),
            jitter=buf.jitter(),
            lag_percent=buf.lag_percent(int(cfg.get("thresholds.high-ping", 200))),
            spike_count=buf.spike_count(int(cfg.get("thresholds.spike", 80))),
            session_start=self._session_starts.get(xuid, time()),
            session_end=time(),
            anomalies=list(live.anomalies),
            display_style=live.display_style,
            country=live.country,
            isp=live.isp,
        )

    # ------------------------------------------------------------------
    # Geolocation (async)
    # ------------------------------------------------------------------

    def _load_geo(self, player) -> None:
        try:
            import urllib.request, json as _json
            api_url = self._plugin.config.get(
                "geolocation.api-url",
                "http://ip-api.com/json/%ip%?fields=country,isp"
            )
            addr = str(player.address.hostname)
            url = api_url.replace("%ip%", addr)
            with urllib.request.urlopen(url, timeout=5) as resp:
                data = _json.loads(resp.read().decode())
            with self._lock:
                live = self._live.get(player.xuid)
                if live:
                    live.country = data.get("country", "")
                    live.isp     = data.get("isp", "")
                    live.geo_loaded = True
        except Exception:
            pass  # Geo is optional, fail silently
