"""
PingSystem - Main Plugin
Endstone plugin entry point. Wires up all managers, listeners, and commands.
"""

from __future__ import annotations

import os

from endstone.plugin import Plugin
from endstone.command import Command, CommandSender

from .managers.ping_manager    import PingManager
from .managers.storage_manager import StorageManager
from .listeners.player_listener import PingEventListener
from .commands.pingstat  import PingStatCommand
from .commands.pingdis   import PingDisCommand
from .commands.admping   import AdminPingCommand


class PingSystemPlugin(Plugin):
    # ---------------------------------------------------------------
    # Endstone plugin metadata
    # ---------------------------------------------------------------
    api_version = "0.5"

    commands = {
        "pingstat": {
            "description": "View your personal ping statistics",
            "usages": ["/pingstat"],
            "permissions": ["pingsystem.pingstat"],
        },
        "pingdis": {
            "description": "Choose your ping display style",
            "usages": ["/pingdis [style]"],
            "permissions": ["pingsystem.pingdis"],
        },
        "admping": {
            "description": "Admin: view full ping stats for a player",
            "usages": ["/admping <player>"],
            "permissions": ["pingsystem.admin"],
        },
    }

    permissions = {
        "pingsystem.pingstat": {
            "description": "Use /pingstat",
            "default": True,
        },
        "pingsystem.pingdis": {
            "description": "Use /pingdis",
            "default": True,
        },
        "pingsystem.admin": {
            "description": "Use /admping",
            "default": "op",
        },
    }

    # ---------------------------------------------------------------
    # Lifecycle
    # ---------------------------------------------------------------

    def on_load(self) -> None:
        self.logger.info("PingSystem loading…")

    def on_enable(self) -> None:
        # Save default config if missing
        self.save_default_config()

        # Init managers
        self.storage_manager = StorageManager(self)
        self.ping_manager    = PingManager(self)

        # Register listeners
        self._listener = PingEventListener(self)
        self.server.plugin_manager.register_events(self._listener, self)

        # Init command handlers
        self._cmd_pingstat = PingStatCommand(self)
        self._cmd_pingdis  = PingDisCommand(self)
        self._cmd_admping  = AdminPingCommand(self)

        # Start ping collection loop
        self.ping_manager.start()

        # Register already-online players (reload scenario)
        for player in self.server.online_players:
            self.ping_manager.on_player_join(player)

        self.logger.info("PingSystem enabled ✓")

    def on_disable(self) -> None:
        self.ping_manager.stop()

        # Save all online players before shutdown
        for player in self.server.online_players:
            self.ping_manager.on_player_quit(player)

        self.logger.info("PingSystem disabled.")

    # ---------------------------------------------------------------
    # Command routing
    # ---------------------------------------------------------------

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        name = command.name.lower()

        if name == "pingstat":
            return self._cmd_pingstat.execute(sender, command, args)
        if name == "pingdis":
            return self._cmd_pingdis.execute(sender, command, args)
        if name == "admping":
            if not sender.has_permission("pingsystem.admin"):
                msg = self.config.get("messages.no-permission", "§cNo permission.")
                sender.send_message(msg)
                return True
            return self._cmd_admping.execute(sender, command, args)

        return False
