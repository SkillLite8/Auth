# 🏓 PingSystem — Endstone Plugin

Advanced real-time ping display, analytics and anomaly detection for Endstone 0.10.5+ servers.

---

## Features

| Category | Details |
|---|---|
| **Nametag display** | Live ping next to every player's name, colour-coded by quality |
| **Personal styles** | Each player picks their own display format via `/pingdis` |
| **Ring buffer** | O(1) per-player history (up to 120 samples, configurable) |
| **Metrics** | Current · Average · Min · Max · Jitter · Lag % · Spike count |
| **Anomaly detection** | SPIKE / HIGH\_PING / JITTER events with timestamps and duration |
| **Async geo** | Optional country + ISP lookup (ip-api.com, daemon thread, no lag) |
| **Persistence** | JSON (default) or SQLite — data survives restarts |
| **Sounds** | GUI open · Error · Lag alert (per config.yml) |
| **Fully configurable** | All thresholds, formats and sounds via `config.yml` |

---

## Installation

1. Copy the `pingsystem/` folder and `plugin.toml` + `config.yml` into your Endstone plugins directory.
2. Restart the server.
3. Edit `plugins/PingSystem/config.yml` to taste.

---

## Commands

### Player commands

| Command | Description |
|---|---|
| `/pingstat` | Show your personal ping statistics |
| `/pingdis` | Display the style menu |
| `/pingdis <1-5>` | Switch to a specific display style |

### Admin commands

| Command | Permission | Description |
|---|---|---|
| `/admping <player>` | `pingsystem.admin` | Full stats + anomaly log for any online player |

---

## Display Styles

Players choose via `/pingdis <number>`:

| # | Name | Example output |
|---|---|---|
| 1 | Brackets | `Steve §a[42 ms]` |
| 2 | Colored | `Steve §a42 ms` |
| 3 | Dots | `Steve §a●●●○` |
| 4 | Label | `Steve §aPing: 42` |
| 5 | None | `Steve` (disabled) |

---

## Colour Coding

| Range | Colour | Code |
|---|---|---|
| 0–50 ms | 🟢 Green | `§a` |
| 51–100 ms | 🟡 Yellow | `§e` |
| 101–200 ms | 🟠 Orange | `§6` |
| 200+ ms | 🔴 Red | `§c` |

Thresholds are configurable in `config.yml → thresholds`.

---

## Anomaly Detection

Three anomaly types are detected automatically and logged per player:

| Type | Trigger |
|---|---|
| `SPIKE` | `current_ping > average + spike_threshold` |
| `JITTER` | `|current - previous| > jitter_threshold` |
| `HIGH_PING` | Ping stays above `high-ping` for `high-duration` seconds |

Anomaly events contain: `timestamp · ping · type · duration`

---

## Placeholders (format strings)

| Placeholder | Value |
|---|---|
| `%player%` | Player name |
| `%ping%` | Current ping (ms) |
| `%ping_avg%` | Average ping |
| `%ping_min%` | Minimum ping |
| `%ping_max%` | Maximum ping |
| `%ping_color%` | `§a` / `§e` / `§6` / `§c` by quality |
| `%ping_icon%` | `§a●●●○` dot bar |

---

## config.yml Overview

```yaml
update-interval: 2          # nametag refresh in seconds

ping:
  format: "%player% %ping_color%[%ping% ms]"

thresholds:
  good: 50                  # ms — green boundary
  medium: 100               # ms — yellow boundary
  bad: 200                  # ms — orange/red boundary
  spike: 80                 # ms above avg → SPIKE
  jitter: 40                # ms delta → JITTER
  high-ping: 200            # ms sustained → HIGH_PING
  high-duration: 5          # seconds

buffer-size: 120            # ping samples per player

sounds:
  gui-open: true
  error: true
  lag-alert: true

geolocation:
  enabled: false            # async, ip-api.com

storage:
  type: "json"              # or "sqlite"
  save-interval: 60
```

---

## Architecture

```
PingSystemPlugin (main thread)
    │
    ├─ PlayerJoin/Quit events → player_store (dict, thread-safe)
    │
    ├─ PingScheduler (daemon thread, every N seconds)
    │     ├─ Read player.ping for each online player
    │     ├─ RingBuffer.push(ping)          ← O(1)
    │     ├─ AnomalyDetector.analyse(...)   ← stateless
    │     └─ nametag_queue.put(update)      ← lock-free
    │
    ├─ Endstone task (main thread, every 20 ticks)
    │     └─ drain nametag_queue → player.name_tag = ...
    │
    ├─ RepeatingTimer (daemon, every 60s)
    │     └─ storage.save_all(player_store)
    │
    └─ Geo lookup threads (daemon, per join, optional)
          └─ ip-api.com → PlayerPingData.geo_*
```

### Key design choices

- **No heavy tick-loops** — scheduler runs on a separate daemon thread.
- **O(1) ring buffer** — fixed-size circular array, no allocations after init.
- **Thread-safe** — `player_store` protected by `threading.Lock`; nametag updates via a `queue.Queue`.
- **Minimal allocations** — hot-path only does integer arithmetic and string replacement.
- **Offline persistence** — JSON (atomic write via `.tmp` + `os.replace`) or SQLite WAL mode.

---

## Permissions

| Node | Default | Description |
|---|---|---|
| `pingsystem.player` | `true` | Use `/pingstat` |
| `pingsystem.style` | `true` | Use `/pingdis` |
| `pingsystem.admin` | `op` | Use `/admping` |

---

## Requirements

- Endstone **0.10.5+**
- Python 3.11+ (bundled with Endstone)
- No external Python packages required (SQLite optional, stdlib only)
